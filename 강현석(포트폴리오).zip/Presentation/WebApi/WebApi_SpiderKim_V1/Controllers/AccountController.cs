﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Configuration;

using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Account;
using Lib.Crawling.Library.Utilities;
using Lib.Crawling.Library.Log;
using Lib.Crawling.Library.DataContainers;

using WebApi_SpiderKim_V1.Handlers;
using WebApi_SpiderKim_V1.WebUtilities;

namespace WebApi_SpiderKim_V1.Controllers
{

    #region // !++ AccountController
    /// <summary>
    /// AccountController
    /// </summary>
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {

        #region // !++ Event handler(funtions)
        /// <summary>
        /// StaticDataHandler
        /// </summary>
        public StaticDataHandler staticDataHandler = new StaticDataHandler();

        /// <summary>
        /// LibUtility
        /// </summary>
        public LibUtility libUtility = new LibUtility();

        /// <summary>
        /// LibWebUtility
        /// </summary>
        public LibWebUtility libWebUtility = new LibWebUtility();

        /// <summary>
        /// KeyGenerator
        /// </summary>
        public KeyGenerator keyGenerator = new KeyGenerator();

        /// <summary>
        /// LibraryController
        /// </summary>
        public LibraryController libraryController = new LibraryController();
        #endregion


        #region // !++ Class 상속
        private readonly IConfiguration _configuration;

        public AccountController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        #endregion


        #region // !++ SetMemberRegist (회원가입 : 개인)
        /// <summary>
        /// 회원가입 : 개인
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("MemberRegist")]
        [Produces("application/json", Type = typeof(MemberRegistEntity))]
        [AllowAnonymous]    // 인증되지 않은 사용자도 접근 가능
        public async Task<IActionResult> SetMemberRegist([FromBody] MemberRegistEntity model)
        {

            // Return message
            var resultClient = new ResultClientEntity<MemberRegistSuccessEntity>();

            try
            {

                #region // !++ Parameter value check
                if (model == null)
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied parameter.";
                    resultClient.error = "Invalied parameter.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }

                // E-mail 확인
                if (libUtility.GetEmailParamValue(model.vcEmail) == false)
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "The e-mail format is not correct.";
                    resultClient.error = "The e-mail format is not correct.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }

                // 비밀번호 길이 확인
                if (libUtility.GetByte(model.vcPassword) < 8)
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Password length is short.";
                    resultClient.error = "Password length is short.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }

                // 비밀번호 허용문자 확인
                if (libWebUtility.OnPassWordValue(model.vcPassword) == false)
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Not a valid password.";
                    resultClient.error = "Not a valid password.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }
                #endregion

                #region // !++ Data struct 변경
                // 회원 기본정보
                var memberEntity = new MemberEntity()
                {
                    iPlatFormSeq = model.iPlatFormSeq,
                    vcEmail = model.vcEmail,
                    vcName = model.vcName,
                    cBirthYear = model.cBirthYear,
                    cBirthMonth = model.cBirthMonth,
                    cBirthDay = model.cBirthDay,
                    tiGender = model.tiGender,
                    tiOrganization = model.tiOrganization
                };

                // 회원 상세정보
                var memberDetailEntity = new MemberDetailEntity()
                {
                    tiMemberStatus = 0,
                    tiEmailAgree = 2,
                    tiSmsAgress = 2
                };
                
                // 회원 연락처 정보
                var memberContactEntity = new MemberContactEntity();

                // 회원 비밀번호
                var memberPasswordEntity = new MemberPasswordEntity()
                {
                    vcPassword = model.vcPassword
                };

                // 회원 단체(기업) 정보
                var memberOrganizationEntity = new MemberOrganizationEntity();

                // 회원 E-mail 인증 정보
                var memberEmailAuthEntity = new MemberEmailAuthEntity()
                {
                    vcEmail = model.vcEmail,
                    vcAuth = keyGenerator.NewKey(model.vcEmail, "AuthCode").ToString()
                };

                // Container
                var dbModel = new MemberDataContainer()
                {
                    memberEntity = memberEntity,
                    memberDetailEntity = memberDetailEntity,
                    memberContactEntity = memberContactEntity,
                    memberPasswordEntity = memberPasswordEntity,
                    memberOrganizationEntity = memberOrganizationEntity,
                    memberEmailAuthEntity = memberEmailAuthEntity
                };
                #endregion

                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ Handler 호출
                var resultData = await AccountHandler.SetMemberRegist(dbConnectionEntity, dbModel);
                #endregion

                #region // !++ Client message
                if (resultData.result == 1)
                {

                    #region // !++ 인증 E-mail 발송
                    var emailData = new MemberEmailAuthEntity()
                    {
                        biMemberSeq = resultData.gClass,
                        vcEmail = dbModel.memberEntity.vcEmail,
                        vcAuth = dbModel.memberEmailAuthEntity.vcAuth
                    };
                    var resultEmail = SetSendConfirmEmail(dbModel.memberEntity, emailData);
                    #endregion

                    #region // !++ 최종 데이터
                    var responseData = new MemberRegistSuccessEntity()
                    {
                        email = dbModel.memberEntity.vcEmail,
                        name = dbModel.memberEntity.vcName
                    };
                    #endregion

                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = responseData;

                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API SetMemberRegist : \n [MemberRegistEntity:{0}], \n {1}, \n {2}",
                                        libUtility.ToJson(model), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }

        }
        #endregion


        #region // !++ SetMemberOrganizationRegist (회원가입 : 기업)
        /// <summary>
        /// 회원가입 : 기업
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("MemberOrganizationRegist")]
        [Produces("application/json", Type = typeof(MemberRegistDataContainer))]
        [AllowAnonymous]    // 인증되지 않은 사용자도 접근 가능
        public async Task<IActionResult> SetMemberOrganizationRegist([FromBody] MemberRegistDataContainer model)
        {
            // Return message
            var resultClient = new ResultClientEntity<MemberRegistSuccessEntity>();

            try
            {

                #region // !++ Parameter value check
                // Container
                if (model == null)
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied parameter.";
                    resultClient.error = "Invalied parameter.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }

                // 회원 기본정보
                if (model.tbMember == null)
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied parameter.";
                    resultClient.error = "Invalied parameter.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }

                // 회원 기업정보
                if (model.tbMemberOrganization == null)
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied parameter.";
                    resultClient.error = "Invalied parameter.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }

                // E-mail 확인
                if (libUtility.GetEmailParamValue(model.tbMember.vcEmail) == false)
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "The e-mail format is not correct.";
                    resultClient.error = "The e-mail format is not correct.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }

                // 비밀번호 길이 확인
                if (libUtility.GetByte(model.tbMember.vcPassword) < 8)
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Password length is short.";
                    resultClient.error = "Password length is short.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }

                // 비밀번호 허용문자 확인
                if (libWebUtility.OnPassWordValue(model.tbMember.vcPassword) == false)
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Not a valid password.";
                    resultClient.error = "Not a valid password.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }
                #endregion

                #region // !++ Data struct 변경
                // 회원 기본정보
                var memberEntity = new MemberEntity()
                {
                    iPlatFormSeq = model.tbMember.iPlatFormSeq,
                    vcEmail = model.tbMember.vcEmail,
                    vcName = model.tbMember.vcName,
                    cBirthYear = model.tbMember.cBirthYear,
                    cBirthMonth = model.tbMember.cBirthMonth,
                    cBirthDay = model.tbMember.cBirthDay,
                    tiGender = model.tbMember.tiGender,
                    tiOrganization = model.tbMember.tiOrganization
                };

                // 회원 상세정보
                var memberDetailEntity = new MemberDetailEntity()
                {
                    tiMemberStatus = 0,
                    tiEmailAgree = 2,
                    tiSmsAgress = 2
                };

                // 회원 연락처 정보
                var memberContactEntity = new MemberContactEntity();

                // 회원 비밀번호
                var memberPasswordEntity = new MemberPasswordEntity()
                {
                    vcPassword = model.tbMember.vcPassword
                };

                // 회원 단체(기업) 정보
                var memberOrganizationEntity = new MemberOrganizationEntity()
                {
                    vcPersonName = model.tbMemberOrganization.vcPersonName,
                    vcBusiness = model.tbMemberOrganization.vcBusiness,
                    vcOrganizationSerial = model.tbMemberOrganization.vcOrganizationSerial
                };

                // 회원 E-mail 인증 정보
                var memberEmailAuthEntity = new MemberEmailAuthEntity()
                {
                    vcEmail = model.tbMember.vcEmail,
                    vcAuth = keyGenerator.NewKey(model.tbMember.vcEmail, "AuthCode").ToString()
                };

                // Container
                var dbModel = new MemberDataContainer()
                {
                    memberEntity = memberEntity,
                    memberDetailEntity = memberDetailEntity,
                    memberContactEntity = memberContactEntity,
                    memberPasswordEntity = memberPasswordEntity,
                    memberOrganizationEntity = memberOrganizationEntity,
                    memberEmailAuthEntity = memberEmailAuthEntity
                };
                #endregion

                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ Handler 호출
                var resultData = await AccountHandler.SetMemberRegist(dbConnectionEntity, dbModel);
                #endregion

                #region // !++ Client message
                if (resultData.result == 1)
                {

                    #region // !++ 인증 E-mail 발송
                    var emailData = new MemberEmailAuthEntity()
                    {
                        biMemberSeq = resultData.gClass,
                        vcEmail = dbModel.memberEntity.vcEmail,
                        vcAuth = dbModel.memberEmailAuthEntity.vcAuth
                    };
                    var resultEmail = SetSendConfirmEmail(dbModel.memberEntity, emailData);
                    #endregion

                    #region // !++ 최종 데이터
                    var responseData = new MemberRegistSuccessEntity()
                    {
                        email = dbModel.memberEntity.vcEmail,
                        name = dbModel.memberEntity.vcName
                    };
                    #endregion

                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = responseData;

                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API SetMemberOrganizationRegist : \n [MemberRegistDataContainer:{0}], \n {1}, \n {2}",
                                        libUtility.ToJson(model), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }
        }
        #endregion


        #region // !++ SetSendConformEmail (인증 E-mail 보내기)
        /// <summary>
        /// 인증 E-mail 보내기
        /// </summary>
        /// <param name="member"></param>
        /// <param name="model"></param>
        /// <returns></returns>
        private async Task<Boolean> SetSendConfirmEmail(MemberEntity member, MemberEmailAuthEntity model)
        {

            try
            {

                #region // !++ 인증 정보 암호화
                var authInfo = new AuthEmailEntity()
                {
                    biMemberSeq = model.biMemberSeq,
                    vcEmail = model.vcEmail,
                    vcAuth = model.vcAuth,
                    dtExpireDate = DateTime.UtcNow.AddHours(Int32.Parse(_configuration.GetSection("SpiderKimSendEmail").GetSection("EmailExpireDateTime").Value))
                };
                var authEncrypt = libUtility.Encrypt(libUtility.ToJson(authInfo));
                #endregion

                #region // !++ 메일 정보 셋팅
                var mailMessage = new SendEmailEntity()
                {
                    SMTPMailServer = _configuration.GetSection("SpiderKimSendEmail").GetSection("EmailSMTP").Value,
                    FromEmail = _configuration.GetSection("SpiderKimSendEmail").GetSection("EmailAddrress").Value,
                    FromEmailDisplayName = _configuration.GetSection("SpiderKimEmailDescription").GetSection("MemberAuthDisplayName").Value,
                    FromEmailPassword = _configuration.GetSection("SpiderKimSendEmail").GetSection("EmailPassword").Value,
                    FromEmailPort = Int32.Parse(_configuration.GetSection("SpiderKimSendEmail").GetSection("EmailSSLPort").Value),
                    FromEmailTLS = Int32.Parse(_configuration.GetSection("SpiderKimSendEmail").GetSection("EmailTLSPort").Value),
                    ToEmail = model.vcEmail,
                    ToEmailDisplayName = member.vcName,
                    Subject = _configuration.GetSection("SpiderKimEmailDescription").GetSection("MemberAuthSubject").Value,
                    BodyContents = String.Concat(_configuration.GetSection("SpiderKimSendEmail").GetSection("EmailReturnHttp").Value,
                                _configuration.GetSection("SpiderKimSendEmail").GetSection("EmailReturnUrl").Value
                                , authEncrypt)
                };
                #endregion

                var sendResult = await libUtility.SendEmail(mailMessage);

                return sendResult;

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API SetSendConformEmail : \n [MemberEntity:{0}], \n [MemberEmailAuthEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(member), libUtility.ToJson(model), exc.Message, exc.StackTrace);

                return false;
            }

        }
        #endregion


        #region // !++ SetEmailAuth (E-mail 인증 Request 처리)
        /// <summary>
        /// E-mail 인증 Request 처리
        /// </summary>
        /// <param name="authKey"></param>
        /// <returns></returns>
        [HttpPost("emailapproval")]
        [Produces("application/json", Type = typeof(AuthKeyEntity))]
        [AllowAnonymous]    // 인증되지 않은 사용자도 접근 가능
        public async Task<IActionResult> SetEmailAuth([FromBody] AuthKeyEntity model)
        {

            // Return message
            var resultClient = new ResultClientEntity<MemberEmailAuthApprovalEntity>();

            try
            {

                #region // !++ Parameter value check
                if (String.IsNullOrEmpty(model.authKey))
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "invalid eamil auth value.";
                    resultClient.error = "invalid eamil auth value.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }
                #endregion


                #region // !++ Decryption (복호화 및 JSON 정보 축출)
                var authDecrypt = libUtility.FromJson<AuthEmailEntity>(libUtility.Decrypt(model.authKey));

                // TODO : 만약 인증 유효기간을 체크하려면 dtExpireDate 로 하면됨!!
                #endregion

                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ Handler 호출
                var resultData = await AccountHandler.SetMemberEmailAuth(dbConnectionEntity, authDecrypt);
                #endregion

                #region // !++ Client message
                if (resultData.result == 1)
                {

                    var responseData = new MemberEmailAuthApprovalEntity()
                    {
                        vcName = resultData.gClass,
                        vcEmail = authDecrypt.vcEmail
                    };

                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = responseData;

                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API SetEmailAuth : \n [AuthKeyEntity:{0}], \n {1}, \n {2}",
                                       libUtility.ToJson(model), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }

        }
        #endregion




    }
    #endregion

}