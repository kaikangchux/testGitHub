﻿using System;
using System.Collections.Generic;
using System.Text;

using log4net.Appender;
using log4net.Core;
using log4net.Layout;

namespace Lib.Crawling.Library.Log
{

    #region // !++ ConsoleLogger
    public class ConsoleLogger : LoggerBase
    {

        public override IAppender GetAppender()
        {
            var appender = new ConsoleAppender
            {
                Threshold = Level.All,
                Layout = new PatternLayout(logLayout),
            };
            appender.ActivateOptions();
            return appender;
        }

        public override void Log(ELogType eLogType, string logMsg)
        {
            base.Log(eLogType, logMsg);
        }

        public override void Log(ELogType eLogType, string logFormat, params object[] paramArray)
        {
            base.Log(eLogType, logFormat, paramArray);
        }

        public override void Log(ELogType eLogType, string logMsg, Exception exc)
        {
            base.Log(eLogType, logMsg, exc);
        }

        public override void Log(ELogType eLogType, Exception exc)
        {
            base.Log(eLogType, exc);
        }

    }
    #endregion

}
