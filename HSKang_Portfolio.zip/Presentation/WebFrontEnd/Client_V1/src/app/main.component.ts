import { Component, OnDestroy } from '@angular/core';
import { ConfigService } from './config';
import { Subscription } from 'rxjs';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
    selector: 'app-main',
    templateUrl: './main.component.html',
    styleUrls: []
})
export class MainComponent implements OnDestroy
{
    settingsWatcher:Subscription;
    uiSettings: any = {layout: {header: 'hide', footer: 'hide', dashboard:'hide'}};
    isDashboardView:boolean = false;

    constructor(private config:ConfigService, private router:Router)
    {
        this.settingsWatcher = 
            this.config.onSettingsChange.subscribe((newSettings) => {
                this.uiSettings = newSettings;
            });

        this.router.events.pipe(
            filter(event => event instanceof NavigationEnd)
        ).subscribe((event: NavigationEnd) => {        
            let url = event.urlAfterRedirects;
            this.isDashboardView = (url.includes(ConfigService.DASH_BOARD_ROUTE));
        });
    }

    ngOnDestroy():void{
        this.settingsWatcher.unsubscribe();
    }
}