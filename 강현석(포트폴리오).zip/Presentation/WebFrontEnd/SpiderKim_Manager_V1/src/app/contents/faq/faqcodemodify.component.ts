import { Component, OnInit, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { FormGroup, FormBuilder, Validators, ValidationErrors } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { NgxSpinnerService } from "ngx-spinner";

import { CommonService, FaqService } from '../../service';
import { FaqCodeModel } from '../../model';

@Component({ 
    selector: 'app-popup',
    templateUrl: './faqcodemodify.component.html', 
    styleUrls: ['../scss/regEdit.component.scss']
})

export class FaqCodeModifyComponent implements OnInit
{
    mFaqCode:FaqCodeModel;
    mSeq:number;
    modifyForm:FormGroup;

    constructor(private mService:FaqService,
                private cmnService:CommonService,
                private translate:TranslateService,
                private spinnerService:NgxSpinnerService,
                public dialogRef: MatDialogRef<FaqCodeModifyComponent>, 
                @Inject(MAT_DIALOG_DATA) public data:any,
                private fb:FormBuilder){
        
        this.mSeq = (data.iSeq === null) ? -1 : data.iSeq;
    }

    ngOnInit():void
    {
        this.getFaqCodeDetail(this.mSeq);

        this.modifyForm = this.fb.group({
            iSeq:[this.mSeq],
            vcTitle:['', Validators.required]
        });
    }

    // FAQ code 상세정보
    getFaqCodeDetail(mSeq:number):void
    {
        setTimeout(()=>this.spinnerService.show(), 0);

        this.mService.getFaqCodeDetail(mSeq).subscribe(
            detailData => {
                this.spinnerService.hide();
                this.mFaqCode = detailData.data;
                this.modifyForm.patchValue ({iSeq: this.mFaqCode.iSeq});
                this.modifyForm.patchValue ({vcTitle: this.mFaqCode.vcTitle});
            },
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

    // Action
    onModify():void
    {
        this.mService.regEditFaqCode(this.modifyForm.value, (this.mSeq < 0), this.mSeq).subscribe(
            (res) => this.onClose(true),
            (err) => { this.onClose(false); console.log(err);}
        );
    }

    // Reset
    onReset():void
    {
        this.modifyForm.patchValue ({vcTitle: ''});
    }

    // popup close
    onClose(param:any):void{
        this.dialogRef.close(param);
    }

}