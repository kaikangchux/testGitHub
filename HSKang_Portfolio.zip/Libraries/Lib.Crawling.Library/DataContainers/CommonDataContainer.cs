﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace Lib.Crawling.Library.DataContainers
{

    #region // !++ ListPageDataContainer
    /// <summary>
    /// 리스트 정보
    /// </summary>
    /// <typeparam name="T">제네릭</typeparam>
    [Serializable]
    public class ListPageDataContainer<T>
    {
        /// <summary>
        /// 레코드 수
        /// </summary>
        public Int32 totalRecord { get; set; }

        /// <summary>
        /// General Class
        /// </summary>
        public T gClass { get; set; }

        public ListPageDataContainer()
        {
            totalRecord = 0;
            ConstructorInfo constuctor = typeof(T).GetConstructor(Type.EmptyTypes);
            if (null != constuctor)
                gClass = (T)constuctor.Invoke(null);
            else
                gClass = default(T);
        }
        ~ListPageDataContainer()
        {
            totalRecord = 0;
            gClass = default(T);
        }
    }
    #endregion

}
