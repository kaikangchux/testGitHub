// 게시판댓글정보
export class BoardCommentModel
{

  biSeq: number;
  biBoardSeq: number;
  biMemberSeq: number;
  vcAccount: string;
  vcName: string;
  tDescription: string;
  vcIP: string;
  dtRegDate: string;

  constructor() {
    this.biSeq = 0;
    this.biBoardSeq = 0;
    this.biMemberSeq = 0;
    this.vcAccount = '';
    this.vcName = '';
    this.tDescription = '';
    this.vcIP = '';
    this.dtRegDate = '';
  }
}
