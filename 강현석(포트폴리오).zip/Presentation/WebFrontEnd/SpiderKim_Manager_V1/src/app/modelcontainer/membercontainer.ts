import { MemberModel, MemberDetailModel, MemberContactModel, MemberPasswordModel, MemberOrganizationModel, MemberEmailAuthModel } from '../model';

// 회원정보
export class MemberContainer
{

    tbMember:MemberModel;
    tbMemberDetail:MemberDetailModel;
    tbMemberContactModel:MemberContactModel;
    tbMemberPassword:MemberPasswordModel;
    tbMemberOrganization:MemberOrganizationModel;
    tbMemberEmailAuth:MemberEmailAuthModel;

    constructor()
    {
        this.tbMember = null;
        this.tbMemberDetail = null;
        this.tbMemberContactModel = null;
        this.tbMemberPassword = null;
        this.tbMemberOrganization = null;
        this.tbMemberEmailAuth = null;
    }

}