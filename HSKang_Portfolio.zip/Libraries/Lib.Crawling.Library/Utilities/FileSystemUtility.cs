﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;

namespace Lib.Crawling.Library.Utilities
{

    #region // !++ FileSystemUtility
    /// <summary>
    /// File System
    /// </summary>
    public class FileSystemUtility
    {

        public String ErrorMsg = null;
        public Boolean ExistFolder(String FullPath)
        {
            return Directory.Exists(FullPath);
        }
        public Boolean ExistFile(String FullPath)
        {
            return File.Exists(FullPath);
        }
        public Boolean MakeFolder(String FullPath)
        {
            Boolean result = false;
            try
            {
                if (!ExistFolder(FullPath))
                    Directory.CreateDirectory(FullPath);
                result = true;
            }
            catch (Exception ex)
            {
                ErrorMsg = ex.Message.ToString();
                result = false;
            }
            return result;
        }
        public Boolean CheckFileExt(String[] arrFileExt, String FileExt)
        {
            if (arrFileExt == null)
                return true;
            Boolean result = false;
            for (int i = 0; i < arrFileExt.Length; i++)
            {
                if (FileExt.ToLower() == arrFileExt[i].ToLower())
                {
                    result = true;
                    break;
                }
            }
            return result;
        }
        public String GetFileExt(String FileName)
        {
            if (FileName == "" || FileName == null)
                return null;

            Int32 l_Pos = FileName.LastIndexOf('.');
            if (l_Pos >= 0)
                FileName = FileName.Substring(l_Pos + 1);
            return FileName;
        }
        public String GetFileName(String FileName)
        {
            if (FileName == "" || FileName == null)
                return null;

            Int32 l_Pos = FileName.LastIndexOf('\\');
            if (l_Pos >= 0)
                FileName = FileName.Substring(l_Pos + 1);
            return FileName;
        }
        public String GetFilePath(String FullFilePath)
        {
            if (FullFilePath == "" || FullFilePath == null)
                return null;
            Int32 l_Pos = FullFilePath.LastIndexOf('\\');
            if (l_Pos >= 0)
                FullFilePath = FullFilePath.Substring(0, l_Pos);
            return FullFilePath;
        }
        public String[] GetLogicalDrives()
        {
            return Directory.GetLogicalDrives();
        }
        public String[] GetDirectories(String Path)
        {
            return Directory.GetDirectories(Path);
        }
        public String[] GetFiles(String Path)
        {
            return Directory.GetFiles(Path);
        }
        public String GetParent(String Path)
        {
            return Directory.GetParent(Path).FullName;
        }
        public String GetReadTextFile(String Path)
        {
            if (File.Exists(Path))
                return File.ReadAllText(Path, Encoding.UTF8);
            else
                return "";
        }

    }
    #endregion


    #region // !++ UploadFile
    /// <summary>
    /// 
    /// </summary>
    /*
    public class UploadFile : FileSystemUtility
    {
        public string m_Path = null;            // 파일이 저장될 경로
        public string m_Error = null;           // 에러메시지
        public int m_ErrorNumber = 0;           // 에러번호
        public HttpPostedFile m_File = null;    // Request 파일
        public int? m_MaxFileSize = null;       // 최대허용크기
        public string[] m_arrFileExt = null;    // 허용확장자
        public string m_FileReName = null;      // 업로드후 변경된 이름
        public bool m_bThumb = false;           // 섬네일저장여부
        public int? m_Width = null;             // width 사이즈
        public int? m_Height = null;            // height 사이즈
        public string m_ThumbFileName = null;   // 섬네일파일이름
        public UploadFile(string FullPath, HttpPostedFile File)
        {
            m_Path = FullPath;
            m_File = File;
            MakeFolder(FullPath);
        }
        public bool Save()
        {
            bool result = false;
            if (m_File == null)
            {
                m_Error = "파일이 없습니다.";
                m_ErrorNumber = 1;
                return false;
            }
            if (m_MaxFileSize != null && m_MaxFileSize < m_File.ContentLength)
            {
                m_Error = "업로드 최대 용량을 초과하였습니다.";
                m_ErrorNumber = 2;
                return false;
            }

            string l_FileName = GetFileName(m_File.FileName);
            string l_FileExt = GetFileExt(l_FileName);
            if (m_FileReName == null)
                m_FileReName = DateTime.Now.ToString("yyyyMMddHHmmss") + "." + l_FileExt;

            if (!CheckFileExt(m_arrFileExt, l_FileExt))
            {
                m_Error = "허용하지 않는 파일입니다.";
                m_ErrorNumber = 3;
                return false;
            }

            try
            {
                m_File.SaveAs(m_Path + "\\" + m_FileReName);
                if (m_bThumb)
                {
                    ThumbNail thumb = new ThumbNail(m_Path + "\\" + m_FileReName, m_Path);
                    thumb.m_Width = m_Width;
                    thumb.m_Height = m_Height;
                    if (thumb.Save())
                    {
                        m_ThumbFileName = thumb.m_FileReName;
                        result = true;
                    }
                    else
                    {
                        thumb = null;
                        result = false;
                    }
                }
                else
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                m_Error = ex.Message.ToString();
                m_ErrorNumber = 4;
                return false;
            }

            return result;
        }
    }
    */
    #endregion

    #region // !++ ThumbNail
    /// <summary>
    /// 
    /// </summary>
    public class ThumbNail : FileSystemUtility
    {
        public String m_Path;
        public String m_Error = null;
        public Int32 m_ErrorNumber = 0;
        public Int32? m_Width = null;
        public Int32? m_Height = null;
        public String m_FileReName = null;
        private Image m_Img = null;
        private String m_ThumbPath = null;
        public ThumbNail(String PullPath, String ThumbPath)
        {
            if (ExistFile(PullPath))
            {
                m_Path = PullPath;
                try
                {
                    m_Img = Image.FromFile(PullPath);
                }
                catch (Exception ex)
                {
                    m_Error = ex.Message.ToString();
                    m_ErrorNumber = 1;
                    m_Img = null;
                }
                MakeFolder(ThumbPath);
                m_ThumbPath = ThumbPath;
            }
        }
        public Boolean Save()
        {
            Boolean result = false;
            if (m_Img == null)
                return false;
            Double l_Width;
            Double l_Height;

            if (m_Width == null)
                l_Width = m_Img.Size.Width;
            else
                l_Width = Convert.ToInt32(m_Width);

            if (m_Height == null)
                l_Height = m_Img.Size.Height / (m_Img.Size.Width / l_Width);
            else
                l_Height = Convert.ToInt32(m_Height);
            try
            {
                m_FileReName = GetFileName(m_Path) + "_thumb." + GetFileExt(m_Path);
                Image Thumb = m_Img.GetThumbnailImage(Convert.ToInt32(l_Width), Convert.ToInt32(l_Height), new Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                Thumb.Save(m_ThumbPath + "\\" + m_FileReName, ImageFormat.Jpeg);
                result = true;
            }
            catch (Exception ex)
            {
                m_Error = ex.Message.ToString();
                m_ErrorNumber = 1;
                return false;
            }
            return result;
        }
        private Boolean ThumbnailCallback()
        {
            return true;
        }
    }
    #endregion

    #region // !++ WaterMark
    /// <summary>
    /// 
    /// </summary>
    public class WaterMark : FileSystemUtility
    {
        private Bitmap oBitmap = null;
        private String m_FullPath;
        public String m_Msg = null;
        public String m_FileReName = null;
        public Int32 m_FontSize = 12;
        public Int32 m_Left = 20;
        public Int32 m_Top = 20;
        public WaterMark(String FullPath)
        {
            oBitmap = new Bitmap(FullPath);
            m_FullPath = FullPath;
        }
        public void Save()
        {
            if (m_FileReName == null)
                m_FileReName = DateTime.Now.ToString("yyyyMMddHHmmss") + "." + GetFileExt(m_FullPath);
            String FilePath = GetFilePath(m_FullPath);
            SolidBrush oBrush = new SolidBrush(Color.Gray);
            Graphics oGraphics = Graphics.FromImage(oBitmap);
            oGraphics.DrawString(m_Msg, new Font("dotum", m_FontSize, FontStyle.Bold), oBrush, m_Left, m_Top);
            oBitmap.Save(FilePath + "\\" + m_FileReName, ImageFormat.Jpeg);
            oBitmap.Dispose();
            oBrush.Dispose();
            oGraphics.Dispose();
            oBitmap = null;
            oBrush = null;
            oGraphics = null;
        }
    }
    #endregion

}
