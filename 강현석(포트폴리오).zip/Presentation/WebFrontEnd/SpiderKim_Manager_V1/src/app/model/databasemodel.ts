// DB정보
export class DatabaseModel
{

  iSeq: number;
  tiDBType: number;
  vcName: string;
  vcAddress: string;
  iPort: number;
  vcAccount: string;
  vcPassword: string;
  vcDataBase: string;
  tiUse: number;
  iManagerSeq: number;
  dtRegDate: string;

  constructor() {
    this.iSeq = 0;
    this.tiDBType = 0;
    this.vcName = '';
    this.vcAddress = '';
    this.iPort = 0;
    this.vcAccount = '';
    this.vcPassword = '';
    this.vcDataBase = '';
    this.tiUse = 0;
    this.iManagerSeq = 0;
    this.dtRegDate = '';
  }
}
