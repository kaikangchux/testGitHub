import { Component } from '@angular/core';

@Component({
    selector: 'app-register',
    templateUrl: './register.select.component.html',
    styleUrls: ['./register.select.component.scss']
})

export class RegisterSelectComponent
{
    
}