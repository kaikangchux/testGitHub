﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

using log4net;
using log4net.Appender;
using log4net.Config;

using Lib.Crawling.Library.Utilities;

namespace Lib.Crawling.Library.Log
{

    public static class Logger
    {
        private static LoggerBase loggerBase = null;
        private static LibUtility libUtility = new LibUtility();

        public static void Init(List<LoggerBase> loggerBaseList)
        {
            List<IAppender> iAppenderList = new List<IAppender>();

            for (int i = 0; i < loggerBaseList.Count; i++)
            {
                IAppender iAppender = loggerBaseList[i].GetAppender();
                if (iAppender != null)
                {
                    iAppenderList.Add(iAppender);
                }
            }

            loggerBase = loggerBaseList.FirstOrDefault();

            var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());

            BasicConfigurator.Configure(logRepository, iAppenderList.ToArray());
        }

        public static void SetProperty(string propertyName, string propertyValue)
        {
            LogicalThreadContext.Properties[propertyName] = propertyValue;
        }
        public static void SetProperty(string propertyName, int propertyValue)
        {
            LogicalThreadContext.Properties[propertyName] = propertyValue;
        }

        public static void Log(ELogType eLogType, string logMsg)
        {
            if (loggerBase == null) return;
            loggerBase.Log(eLogType, logMsg);
            LogConsole(eLogType, logMsg);
        }
        public static void Log(ELogType eLogType, string logFormat, params object[] paramArray)
        {
            if (loggerBase == null) return;
            loggerBase.Log(eLogType, logFormat, paramArray);
            LogConsole(eLogType, logFormat, paramArray);
        }
        public static void Log(ELogType eLogType, string logMsg, Exception exc)
        {
            if (loggerBase == null) return;
            loggerBase.Log(eLogType, logMsg, exc);
            LogConsole(eLogType, logMsg);
        }

        public static void Log(ELogType eLogType, Exception exc)
        {
            if (loggerBase == null) return;
            loggerBase.Log(eLogType, exc);
        }

        #region //+ LogConsole
        /// <summary>
        /// Console에 Log 남기기. 파라미터가 message 형태로 구성되었습니다.
        /// </summary>
        /// <param name="eLogType">로그 종류</param>
        /// <param name="logMsg">로그 내용</param>
        public static void LogConsole(ELogType eLogType, string logMsg)
        {
            switch (eLogType)
            {
                //■ [Debug] DebugMessage
                case ELogType.Debug: logMsg = "■ [Debug] " + logMsg; break;
                //● [Info] InfoMessage 
                case ELogType.Info: logMsg = "● [Info] " + logMsg; break;
                //▲ [Warning] WarningMessage
                case ELogType.Warning: logMsg = "▲ [Warning] " + logMsg; break;
                //★ [Error] ErrorMessage
                case ELogType.Error: logMsg = "★ [Error] " + logMsg; break;
                //♥ [Fatal] FatalMessage
                case ELogType.Fatal: logMsg = "♥ [Fatal] " + logMsg; break;
            }

            // Debug 사용여부 검사
            if (eLogType != ELogType.Debug || LoggerBase.isDebug)
            {
                System.Diagnostics.Debug.WriteLine(logMsg);
            }
        }

        /// <summary>
        /// Console에 Log 남기기. 파라미터가 Format, Args 형태로 구성되었습니다.
        /// </summary>
        /// <param name="eLogType">로그 종류</param>
        /// <param name="logFormat">로그 포멧</param>
        /// <param name="paramArray">로그 독립변수</param>
        public static void LogConsole(ELogType eLogType, string logFormat, params object[] paramArray)
        {
            switch (eLogType)
            {
                //■ [Debug] DebugMessage
                case ELogType.Debug: logFormat = "■ [Debug] " + logFormat; break;
                //● [Info] InfoMessage
                case ELogType.Info: logFormat = "● [Info] " + logFormat; break;
                //▲ [Warning] WarningMessage
                case ELogType.Warning: logFormat = "▲ [Warning] " + logFormat; break;
                //★ [Error] ErrorMessage
                case ELogType.Error: logFormat = "★ [Error] " + logFormat; break;
                //♥ [Fatal] FatalMessage
                case ELogType.Fatal: logFormat = "♥ [Fatal] " + logFormat; break;
            }

            // Debug 사용여부 검사
            if (eLogType != ELogType.Debug || LoggerBase.isDebug)
            {
                System.Diagnostics.Debug.WriteLine(logFormat, paramArray);
            }
        }
        #endregion End LogByConsole

        public static bool CreateLogger(string logName)
        {
            List<LoggerBase> loggerBaseList = new List<LoggerBase>();
            LoggerBase loggerBase = null;

            // 로그 파일 위치
            // string filePath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            string filePath = AppDomain.CurrentDomain.BaseDirectory;

            // var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
            // XmlConfigurator.Configure(logRepository, new FileInfo(filePath + "log4net.xml"));

            // 로그 파일 위치 확인
            if (string.IsNullOrEmpty(filePath))
            {
                filePath = Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments);
            }

            // string logFileName = filePath + @"\ApplicationLog\" + logName + ".log";
            string logFileName = filePath + @"\ApplicationLog\" + logName + "_" + libUtility.GetDateString(1, 3) + ".log";

            // string winEventSourceName = "WebCrawler_" + logName;
            // string winEventSectionName = "Alice";

            // 모든 로그를 출력하는 로거
            loggerBase = new FileLogger(logFileName);
            loggerBaseList.Add(loggerBase);

            //// 콘솔 로그를 남기는 로거
            //logger = new ConsoleLogger();
            //loggers.Add(logger);

            // 윈도우 이벤트를 로그로 남기는 로거
            // loggerBase = new WindowEventLogger(winEventSectionName, winEventSourceName);
            // loggerBaseList.Add(loggerBase);

            Init(loggerBaseList);

            return true;
        }
    }

}
