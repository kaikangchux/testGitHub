﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lib.Crawling.Library.Models.AccountDB
{

    #region // !++ tbMemberContact
    /// <summary>
    /// tbMemberContact(회원연락처)
    /// </summary>
    [Table("tbMemberContact")]
    public class tbMemberContact
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        /// <summary>
        /// 회원고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// 연락처(국가코드)
        /// </summary>
        public String vcPhoneCountry { get; set; }

        /// <summary>
        /// 연락처(첫자리)
        /// </summary>
        public String vcPhoneFirst { get; set; }

        /// <summary>
        /// 연락처(가운데)
        /// </summary>
        public String vcPhoneSecond { get; set; }

        /// <summary>
        /// 연락처(마지막)
        /// </summary>
        public String vcPhoneThird { get; set; }

        /// <summary>
        /// 핸드폰(첫자리)
        /// </summary>
        public String vcMobileFirst { get; set; }

        /// <summary>
        /// 핸드폰(가운데)
        /// </summary>
        public String vcMobileSecond { get; set; }

        /// <summary>
        /// 핸드폰(마지막)
        /// </summary>
        public String vcMobileThird { get; set; }

    }
    #endregion

}
