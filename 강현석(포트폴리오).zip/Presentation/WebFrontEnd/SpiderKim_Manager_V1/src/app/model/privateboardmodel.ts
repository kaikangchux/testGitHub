// 공지, 뉴스 등 게시판
export class PrivateBoardModel
{

  biSeq: number;
  tiType: number;
  vcTitleKeyText: string;
  vcDescriptKeyText: string;
  tiMain: number;
  iRead: number;
  iManagerSeq: number;
  dtRegDate: string;

  constructor() {
    this.biSeq = 0;
    this.tiType = 0;
    this.vcTitleKeyText = '';
    this.vcDescriptKeyText = '';
    this.tiMain = 0;
    this.iRead = 0;
    this.iManagerSeq = 0;
    this.dtRegDate = '';
  }
}
