﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lib.Crawling.Library.Models.AccountDB
{

    #region // !++ tbMemberDetail
    /// <summary>
    /// tbMemberDetail(회원상세정보)
    /// </summary>
    [Table("tbMemberDetail")]
    public class tbMemberDetail
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        /// <summary>
        /// 회원고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// 국가코드
        /// </summary>
        public Int16 siCountrySeq { get; set; }

        [Required, MinLength(2), MaxLength(64)]
        /// <summary>
        /// 도시
        /// </summary>
        public String vcCity { get; set; }

        [Required, MinLength(2), MaxLength(8)]
        /// <summary>
        /// 우편번호
        /// </summary>
        public String vcZipCode { get; set; }

        [Required, MinLength(8), MaxLength(128)]
        /// <summary>
        /// 주소
        /// </summary>
        public String vcAddressFront { get; set; }

        [Required, MinLength(4), MaxLength(128)]
        /// <summary>
        /// 상세주소
        /// </summary>
        public String vcAddressBack { get; set; }

        /// <summary>
        /// 회원등급
        /// </summary>
        public Int16 tiMemberGrade { get; set; }

        /// <summary>
        /// 회원상태
        /// </summary>
        public Int16 tiMemberStatus { get; set; }

        /// <summary>
        /// 메일수신여부(1:동의, 2:비동의)
        /// </summary>
        public Int16 tiEmailAgree { get; set; }

        /// <summary>
        /// 문자수신여부(1:동의, 2:비동의)
        /// </summary>
        public Int16 tiSmsAgress { get; set; }

    }
    #endregion

}
