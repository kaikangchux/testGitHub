﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.AccountDB
{

    #region // !++ tbMember
    /// <summary>
    /// 회원기본정보
    /// </summary>
    [Table("tbMember")]
    public class tbMember
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        /// <summary>
        /// 회원 고유번호
        /// </summary>
        public Int64 biSeq { get; set; }

        [Index(1), Required]
        /// <summary>
        /// 플랫폼 고유번호
        /// </summary>
        public Int32 iPlatFormSeq { get; set; }

        [Index(3), Required, MinLength(4), MaxLength(32)]
        /// <summary>
        /// GUID(Globally-Unique Identifier : 플랫폼일 경우 플랫폼 고유번호, 자체일 경우 Guid.NewGuid())
        /// </summary>
        public String vcGuid { get; set; }

        [Index(2), Required, MinLength(4), MaxLength(128)]
        /// <summary>
        /// E-mail
        /// </summary>
        public String vcEmail { get; set; }

        [Required, MinLength(2), MaxLength(32)]
        /// <summary>
        /// 이름
        /// </summary>
        public String vcName { get; set; }

        [Required, MinLength(4), MaxLength(4)]
        /// <summary>
        /// 생년월일(년도)
        /// </summary>
        public String cBirthYear { get; set; }

        [Required, MinLength(2), MaxLength(2)]
        /// <summary>
        /// 생년월일(월)
        /// </summary>
        public String cBirthMonth { get; set; }

        [Required, MinLength(2), MaxLength(2)]
        /// <summary>
        /// 생년월일(날짜)
        /// </summary>
        public String cBirthDay { get; set; }

        /// <summary>
        /// 성별(1:남성, 2:여성, 3:모름[정보없음])
        /// </summary>
        public Int16 tiGender { get; set; }

        /// <summary>
        /// 단체여부(1:개인, 2:단체[기업])
        /// </summary>
        public Int16 tiOrganization { get; set; }

        [Index(3), Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
