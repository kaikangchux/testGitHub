﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

using Lib.Crawling.Library.Entities.Account;

namespace Lib.Crawling.Library.DataContainers
{

    #region // !++ MemberDataContainer
    /// <summary>
    /// 회원정보(사용처 : 가입, 운영툴, 외 기타...)
    /// </summary>
    [Serializable]
    public class MemberDataContainer
    {

        /// <summary>
        /// 회원기본정보
        /// </summary>
        public MemberEntity memberEntity { get; set; }

        /// <summary>
        /// 회원상세정보
        /// </summary>
        public MemberDetailEntity memberDetailEntity { get; set; }

        /// <summary>
        /// 회원연락처정보
        /// </summary>
        public MemberContactEntity memberContactEntity { get; set; }

        /// <summary>
        /// 회원비밀번호정보
        /// </summary>
        public MemberPasswordEntity memberPasswordEntity { get; set; }

        /// <summary>
        /// 회원(단체)정보
        /// </summary>
        public MemberOrganizationEntity memberOrganizationEntity { get; set; }

        /// <summary>
        /// 회원Email인증
        /// </summary>
        public MemberEmailAuthEntity memberEmailAuthEntity { get; set; }

        public MemberDataContainer()
        {
            memberEntity = null;
            memberDetailEntity = null;
            memberContactEntity = null;
            memberPasswordEntity = null;
            memberOrganizationEntity = null;
            memberEmailAuthEntity = null;
        }
        ~MemberDataContainer()
        {
            memberEntity = null;
            memberDetailEntity = null;
            memberContactEntity = null;
            memberPasswordEntity = null;
            memberOrganizationEntity = null;
            memberEmailAuthEntity = null;
        }

    }
    #endregion


    #region // !++ MemberInfoDataContainer
    /// <summary>
    /// 회원(본인) 상세정보
    /// </summary>
    [Serializable]
    public class MemberInfoDataContainer
    {

        /// <summary>
        /// 회원기본정보
        /// </summary>
        public MemberEntity memberEntity { get; set; }

        /// <summary>
        /// 회원상세정보
        /// </summary>
        public MemberDetailEntity memberDetailEntity { get; set; }

        /// <summary>
        /// 회원연락처정보
        /// </summary>
        public MemberContactEntity memberContactEntity { get; set; }

        /// <summary>
        /// 회원비밀번호정보
        /// </summary>
        public MemberPasswordEntity memberPasswordEntity { get; set; }

        /// <summary>
        /// 회원(단체)정보
        /// </summary>
        public MemberOrganizationEntity memberOrganizationEntity { get; set; }

        public MemberInfoDataContainer()
        {
            memberEntity = null;
            memberDetailEntity = null;
            memberContactEntity = null;
            memberPasswordEntity = null;
            memberOrganizationEntity = null;
        }
        ~MemberInfoDataContainer()
        {
            memberEntity = null;
            memberDetailEntity = null;
            memberContactEntity = null;
            memberPasswordEntity = null;
            memberOrganizationEntity = null;
        }

    }
    #endregion


    #region // !++ MemberRegistDataContainer
    /// <summary>
    /// 회원가입
    /// </summary>
    [Serializable]
    public class MemberRegistDataContainer
    {

        /// <summary>
        /// 회원가입 기본정보
        /// </summary>
        public MemberRegistEntity tbMember { get; set; }

        /// <summary>
        /// 회원가입 기업
        /// </summary>
        public MemberOrganizationRegistEntity tbMemberOrganization { get; set; }

        public MemberRegistDataContainer()
        {
            tbMember = null;
            tbMemberOrganization = null;
        }
        ~MemberRegistDataContainer()
        {
            tbMember = null;
            tbMemberOrganization = null;
        }

    }
    #endregion

}
