﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.CrawlingDB
{

    #region // !++ tbBlog
    /// <summary>
    /// 블로그
    /// </summary>
    [Table("tbBlog")]
    public class tbBlog
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        /// <summary>
        /// 고유번호
        /// </summary>
        public Int64 biSeq { get; set; }

        [Required, MinLength(2), MaxLength(128)]
        /// <summary>
        /// 제목
        /// </summary>
        public String vcTitle { get; set; }

        /// <summary>
        /// 제목이미지경로
        /// </summary>
        public String vcTitleFolder { get; set; }

        /// <summary>
        /// 제목이미지파일명
        /// </summary>
        public String vcTitleImage { get; set; }

        /// <summary>
        /// 내용
        /// </summary>
        public String tDescription { get; set; }

        /// <summary>
        /// 조회수
        /// </summary>
        public Int32 iRead { get; set; }

        /// <summary>
        /// 댓글수
        /// </summary>
        public Int32 iComment { get; set; }

        /// <summary>
        /// 좋아요수
        /// </summary>
        public Int32 iLike { get; set; }

        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
