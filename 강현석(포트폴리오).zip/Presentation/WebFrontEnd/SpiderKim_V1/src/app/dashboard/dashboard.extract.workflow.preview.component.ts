import { Component, ViewChild, ElementRef, OnInit, OnDestroy, AfterViewInit } from '@angular/core';
import { DataExtractService } from '../service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
    selector: 'app-dashboard-workflow-preview',
    templateUrl: './dashboard.extract.workflow.preview.component.html',
    styleUrls: ['./dashboard.extract.workflow.preview.component.scss']
})
export class WorkFlowPreviewComponent implements OnInit, AfterViewInit, OnDestroy 
{
    constructor(private dataExtractService:DataExtractService, 
                private router: Router,
                private http:HttpClient){
    }

    ngOnInit():void {
    
    }

    toggle():void {

    }

    ngAfterViewInit():void {
    }

    ngOnDestroy() {
    }
}