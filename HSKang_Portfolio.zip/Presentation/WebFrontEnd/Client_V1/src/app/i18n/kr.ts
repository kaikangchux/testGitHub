export const TITLE_DEFAULT = "인공지능 웹 크롤링 | 스파이더킴";

export const locale = {
    lang : 'kr',
    data : {
        'COMMON' : {
            'COPYRIGHT' : '© 2019 UPENNSOLUTION Corp. All right reserved.',
            'LOGO_ALT' : '스파이더킴로고',
            'CONFIRM' : '확인'
        },
        'TITLE' : {
            '/' : TITLE_DEFAULT,
            'COMPANY' : '회사개요 | ' + TITLE_DEFAULT,
            'LOGIN' : '로그인 | ' + TITLE_DEFAULT,
            'JOIN'  : '회원가입 | ' + TITLE_DEFAULT,
            'REGISTER/MEMBER'  : '개인회원 | ' + TITLE_DEFAULT,
            'REGISTER/ORGANIZATION'  : '기업회원 | ' + TITLE_DEFAULT,
        },
        'HEADER' : {
            'LOGIN' : '로그인',
            'LOGOUT' : '로그아웃',
            'MENU'  : {
                'COMPANY' : {
                    'MAIN' : '회사소개',
                    'SUB' : { 'MENU1' : '회사개요', 'MENU2' : '조직 및 임직원', 'MENU3' : '언론보도', 'MENU4' : '오시는 길' }
                },
                'BUSINESS' : {
                    'MAIN' : '사업소개',
                    'SUB' : { 'MENU1' : '데이터 수집', 'MENU2' : '데이터 정제', 'MENU3' : '데이터 분석', 'MENU4' : '데이터 시각화' }
                },
                'CUSTOMER' : {
                    'MAIN' : '고객지원',
                    'SUB' : { 'MENU1' : '공지사항', 'MENU2' : 'FAQ', 'MENU3' : '문의' }
                },
                'RECRUIT' : {
                    'MAIN' : '인재채용'
                },
                'BLOG' : {
                    'MAIN' : '블로그'
                },
                'PRICE' : {
                    'MAIN' : '가격'
                },
                'DATA_STORE' : {
                    'MAIN' : '데이터스토어'
                },
            }
        },
        'LOGIN' : {
            'ID' : '아이디(E-mail)',
            'PW' : '비밀번호',
            'BTN' : '로그인',
            'ID_SAVE' : '아이디(E-mail) 저장',
            'ID_FIND' : '아이디(E-mail) 찾기',
            'PW_FIND' : '비밀번호 찾기',
            'REGISTER' : '스파이더킴 회원가입',
            'SOCIAL' : {
                'FACEBOOK' : '페이스북 계정으로 로그인',
                'NAVER' : '네이버 계정으로 로그인',
                'KAKAO' : '카카오 계정으로 로그인',
            }
        },
        'REGISTER' : {
            'LBL' : '회원가입',
            'SOCIAL' : {
                'FACEBOOK' : '페이스북 계정으로 회원가입',
                'NAVER' : '네이버 계정으로 회원가입',
                'KAKAO' : '카카오 계정으로 회원가입',
            },
            'TITLE' : '스파이더킴 회원가입',
            'MEMBER' : '개인회원',
            'ORGANIZATION' : '기업회원',
            'EMAIL' : '이메일',
            'EMAIL_DOMAIN_SELECT' : '선택',
            'PASSWORD' : '비밀번호',
            'PASSWORD_CONFIRM' : '비밀번호 확인',
            'PASSWORD_GUIDE' : '영문/숫자/특수문자 조합 8~20자\n특수문자는 !@#$%^&*_만 사용 가능합니다.',
            'NAME' : '이름',
            'PHONE' : '휴대폰',
            'PHONE_PLACEHOLDER' : '-없이 입력',
            'BIRTHDAY' : {
                'LBL' : '생년월일',
                'YYYY' : '년도 선택',
                'MM' : '월 선택',
                'DD' : '일 선택'
            },    
            'GENDER' : '성별',
            'MALE' : ' 남자',
            'FEMALE' : ' 여자',
            'ORGANIZATION_NAME' : '업체명',
            'ORGANIZATION_BUSINESS' : '업종',
            'ORGANIZATION_PERSON' : '담당자',
            'ORGANIZATION_CONTACT' : '연락처',
            'TERMS' : {
                'AGREE_ALL' : '약관 전체 동의',
                'AGREE_AGE' : '본인은 만 14세 이상입니다.',
                'AGREE_USAGE' : '이용약관에 동의합니다.',
                'AGREE_PRIVACY' : '개인정보 수집/이용에 동의합니다.',
                'VIEW' : '내용보기'
            },
            'SUBMIT' : '가입하기',
            'CONFIRM' : '메일인증 안내 입니다.',
            'CONFIRM_GUIDE1' : '안녕하세요. #님,\n 스파이더킴 회원가입 되었습니다.',
            'CONFIRM_GUIDE2' : '#로 메일을 보냈습니다. 이메일 인증을 완료해 주세요.',
            'COMPLETED' : '회원가입이 완료 되었습니다.',
            'COMPLETED_GUIDE' : '스파이더킴 회원가입을 축하합니다.\n가입하신 아이디는 # 입니다.',
            'HOME' : '홈으로'
        },
        'DASHBOARD' : {
            'TITLE' : '대시보드',
            'EXTRACT' : '데이터수집',
            'PAYMENT' : '이용권',
            'HELP' : '도움말 및 지원',
            'ACCOUNT' : '계정',
            'NOTIFY_SERVICE_REMAIN' : '서비스 종료시까지 #일 남았습니다.',
            'NOTIFY_UPGRADE' : 'Upgrade Now!',
            'PROJECT' : {
                'TITLE' : '나의 프로젝트',
                'COMPLETE' : '완료',
                'FAILED' : '실패',
                'SCHEDULE' : '스케줄링'
            },
            'ACCOUNT_SUMMARY' : {
                'TITLE' : '계정 요약',
                'REMAIN' : '#일 남음',
                'CLOSE' : '# 종료'
            },
            'NEWS' : '스파이더킴 소식',
            'UPGRADE' : '업그레이드',
            'HISTORY' : {
                'TITLE' : '프로젝트 히스토리',
                'LAST_EXEC' : '최종 실행',
                'NEXT_EXEC' : '다음 실행',
                'URL' : 'URL',
                'STATUS' : '상태',
                'RESULT' : '결과물'
            },
            'EXTRACT_GUIDE' : '데이터를 추출할 웹사이트의 URL을 입력하세요.'
        },
        'HOME' : {
            'MAIN' : {
                'TITLE' : "",
                "DESCRIPTION" : "",
                "REQUSET_BTN" : "",
                "CONSULT" : ""
            },
            'SECTION1' : {
                
            }
        },
        'ERROR' : {
            'INVALID_URL' : '형식에 맞지 않습니다.'
        }
    }
};