import { Component, OnInit, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { FormGroup, FormBuilder, Validators, ValidationErrors } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { NgxSpinnerService } from "ngx-spinner";

import { CommonService, PlatFormService } from '../../service';
import { PlatFormModel } from '../../model';

@Component({ 
    selector: 'app-popup',
    templateUrl: './platformdetail.component.html', 
    styleUrls: ['../scss/regEdit.component.scss']
})


export class PlatFormDetailComponent implements OnInit
{
    mPlatForm:PlatFormModel;
    mSeq:number;

    constructor(private mService:PlatFormService,
                private cmnService:CommonService,
                private translate:TranslateService,
                private spinnerService:NgxSpinnerService,
                public dialogRef: MatDialogRef<PlatFormDetailComponent>, 
                @Inject(MAT_DIALOG_DATA) public data:any,
                private fb:FormBuilder){
        
        this.mSeq = (data.iSeq === null) ? -1 : data.iSeq;
    }

    ngOnInit():void
    {
        this.getPlatFormDetail(this.mSeq);
    }

    // PlatForm 상세정보
    getPlatFormDetail(mSeq:number):void
    {
        setTimeout(() => this.spinnerService.show(), 0);

        this.mService.getPlatFormDetail(mSeq).subscribe(
            detailData => {
                this.spinnerService.hide();
                this.mPlatForm = detailData.data;
            },
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

    onClose(param:any):void{
        this.dialogRef.close(param);
    }
}