import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Router } from '@angular/router';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Component({
    selector: 'app-register-complete',
    templateUrl: './register.confirm.component.html',
    styleUrls: ['./register.confirm.component.scss']
})

export class RegisterConfirmComponent
{
    email:string;
    name:string;
    guide1:SafeHtml;
    guide2:SafeHtml;

    constructor(private translate:TranslateService,
                private router:Router,
                private sanitized: DomSanitizer){

        this.email = this.router.getCurrentNavigation().extras.state.data.email;
        this.name  = this.router.getCurrentNavigation().extras.state.data.name;

        let tmp = this.translate.instant('REGISTER.CONFIRM_GUIDE1');
        this.guide1 = this.sanitized.bypassSecurityTrustHtml(tmp.replace(/#/gi, `<span class='color'>${this.name}</span>`));
        tmp = this.translate.instant('REGISTER.CONFIRM_GUIDE2');
        this.guide2 = this.sanitized.bypassSecurityTrustHtml(tmp.replace(/#/gi, `<span class='color'>${this.email}</span>`));
    }
}