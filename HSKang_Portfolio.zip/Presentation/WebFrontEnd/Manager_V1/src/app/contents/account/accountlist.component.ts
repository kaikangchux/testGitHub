import { Component, OnInit, Optional} from '@angular/core';
import { Title } from "@angular/platform-browser";
import { TranslateService } from '@ngx-translate/core';
import { NgxSpinnerService } from "ngx-spinner";
import { MatDialog } from '@angular/material';

import { ConfigService } from '../../config';
import { CommonService, AccountService } from '../../service';
import { MemberModel } from '../../model';

@Component({
    selector: 'app-list',
    templateUrl: './accountlist.component.html',
    styleUrls: ['../scss/list.component.scss']
})

export class AccountListComponent implements OnInit
{

    start:number = 0;
    len:number = 20;
    total:number = 0;
    memberList:MemberModel[] = [];
    curPage:number = 1;

    constructor(private titleService:Title,
                private translate:TranslateService,
                private mService:AccountService,
                private spinnerService:NgxSpinnerService,
                private config:ConfigService,
                private cmnService:CommonService,
                public dialog: MatDialog){

        this.titleService.setTitle(this.translate.instant('TITLE.MEMBER'));
        this.config.setSettings({layout: {navbar: 'show'}});
    }

    ngOnInit():void
    {
        this.getMemberList(this.curPage, this.len);
    }

    getMemberList(curPage:number, len:number):void
    {
        this.spinnerService.show();

        this.mService.getMemberList(curPage, len).subscribe(
            list => {
                this.memberList = list.data.gClass;
                this.total = list.data.totalRecord;
                this.mService.changeMemberList(this.memberList);
            },
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

    pagingArr():number[]
    {
        let result = Math.ceil(this.total/this.len);
        return Array.from({length: result}, (v, k) => k+1);
    }

    pager(page:number)
    {
        if(page === this.curPage){
            return;
        }

        this.curPage = page;
        this.getMemberList(this.curPage, this.len);
    }

    // Member 상세

    // Member 수정
    
    // Member 삭제
    onDelete(iSeq:number):void
    {
        const result = window.confirm(this.translate.instant('DELETE.MSG'));
        if(!result){
            return;
        }

        this.spinnerService.show();
        /*
        this.mService.deleteMember(biSeq).subscribe(
            (res) => this.ngOnInit(),
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
        */
    }

}
