﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.CrawlingDB
{

    #region // !++ tbCompanyPeople
    /// <summary>
    /// 회사조직구성원
    /// </summary>
    [Table("tbCompanyPeople")]
    public class tbCompanyPeople
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        /// <summary>
        /// 고유번호
        /// </summary>
        public Int32 iSeq { get; set; }

        [Index(1), Required]
        /// <summary>
        /// 회사조직고유번호
        /// </summary>
        public Int32 iCompanyGroupSeq { get; set; }

        [Required, MinLength(2), MaxLength(32)]
        /// <summary>
        /// 이름
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 직급
        /// </summary>
        public String vcPosition { get; set; }

        /// <summary>
        /// 내용
        /// </summary>
        public String tDescription { get; set; }

        /// <summary>
        /// 이미지경로
        /// </summary>
        public String vcFolder { get; set; }

        /// <summary>
        /// 이미지파일명
        /// </summary>
        public String vcImage { get; set; }

        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
