// 회원로그인폼
export class MemberLoginFormModel
{
    iPlatFormSeq:number;
    vcEmail:string;
    vcPassword:string;

    constructor()
    {
        this.iPlatFormSeq = 0;
        this.vcEmail = '';
        this.vcPassword = '';
    }
}