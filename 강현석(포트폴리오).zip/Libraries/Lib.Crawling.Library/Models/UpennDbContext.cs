﻿using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.EntityFrameworkCore;

using Lib.Crawling.Library.Models.ManagerDB;

namespace Lib.Crawling.Library.Models
{

    #region // !++ UpennDbContext
    /// <summary>
    /// UpennDbContext
    /// </summary>
    public class UpennDbContext : DbContext
    {

        public UpennDbContext(DbContextOptions<UpennDbContext> options) : base(options)
        {

        }

        public virtual DbSet<tbManager> tbManager { get; set; }

        

    }
    #endregion

}
