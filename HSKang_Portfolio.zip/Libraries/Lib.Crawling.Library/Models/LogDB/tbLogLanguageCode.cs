﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.LogDB
{

    #region // !++ tbLogLanguageCode
    /// <summary>
    /// 언어(다국어)코드
    /// </summary>
    [Table("tbLogLanguageCode")]
    public class tbLogLanguageCode
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        /// <summary>
        /// 파티션 키(월별)
        /// </summary>
        public Int32 iPartKeyMonth { get; set; }

        [Index(1), Required]
        /// <summary>
        /// 트랜잭션ID
        /// </summary>
        public Int64 biTXIDX { get; set; }

        [Index(2), Required]
        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        [Required, MinLength(2), MaxLength(8)]
        /// <summary>
        /// API경로(URL)
        /// </summary>
        public String vcLanguageCode { get; set; }

        [Required, MinLength(2), MaxLength(32)]
        /// <summary>
        /// API계정
        /// </summary>
        public String vcLanguageName { get; set; }

        [Required]
        /// <summary>
        /// 사용여부(1:사용, 2:대기, 3:삭제)
        /// </summary>
        public Int16 tiStatus { get; set; }

        [Required]
        /// <summary>
        /// 로그분류(1:등록, 2:수정, 3:삭제)
        /// </summary>
        public Int16 tiType { get; set; }

        /// <summary>
        /// IP
        /// </summary>
        public String vcIP { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// UTC등록일시
        /// </summary>
        public DateTime dtUtcRegDate { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
