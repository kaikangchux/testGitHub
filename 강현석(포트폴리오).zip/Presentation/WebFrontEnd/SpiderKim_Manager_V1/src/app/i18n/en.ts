export const  locale = {
    lang : 'en',
    data : {
        'TITLE' : {
            'LOGIN' : '관리자 로그인',
            'LIST'  : '관리자페이지 리스트',
            'VIEW'  : "관리자페이지 상세"
        },
        'LOGIN' : {
            'LBL1' : 'Admin',
            'LBL2' : 'Login',
            'ID' : '아이디',
            'PW' : '비밀번호',
            'BTN' : '로그인',
            'ALT' : '스파이더킴로고'
        },
        'LIST' : {
            'TITLE' : 'Management - Manager List',
            'TBL' : {
                'TBLHEADER' : {
                    'IDX' : 'IDX',
                    'ID' : 'ID',
                    'GRADE' : 'Grade',
                    'NAME' : 'Name',
                    'EMAIL' : 'E-mail',
                    'PHONE' : 'Phone',
                    'DATE' : 'Register date',
                    'DETAIL' : 'Detail'
                }
            },
            'DETAIL' : 'DETAIL',
            'MODIFY': 'MODIFY',
            'DELETE': 'DELETE',
            'REGISTER' : 'REGISTER'
        },
        'VIEW' : {
            'TITLE' : 'Account Information'
        },
        'SIDEBAR' : {
            'MODIFY' : '변경',
            'LOGOUT' : '로그아웃'
        },
        'REGISTER' : {
            'TITLE' : 'Manager register',
            'ALT' : '닫기버튼',
            'SELECT' : '선택',
            'BTN' : {
                'LBL' : 'REGISTER'
            },
            'PHONE_PLACEHOLDER' : '-없이 입력'
        },
        'MODIFY' : {
            'TITLE' : 'Manager modify',
            'BTN' : {
                'LBL' : 'MODIFY'
            }
        },
        'DELETE' : {
            'MSG' : '삭제하시겠습니까?'
        }
    }
};
