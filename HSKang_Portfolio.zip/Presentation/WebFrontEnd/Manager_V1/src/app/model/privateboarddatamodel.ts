// 공지, 뉴스 등 게시판 데이터
export class PrivateBoardDataModel
{

  biSeq: number;
  biPrivateBoardSeq: number;
  vcFileName: string;
  vcSaveFolder: string;
  vcSaveName: string;
  vcSaveType: string;
  iSaveSize: number;
  iDownLoad: number;
  iManagerSeq: number;
  dtRegDate: string

  constructor() {
    this.biSeq = 0;
    this.biPrivateBoardSeq = 0;
    this.vcFileName = '';
    this.vcSaveFolder = '';
    this.vcSaveName = '';
    this.vcSaveType = '';
    this.iSaveSize = 0;
    this.iDownLoad = 0;
    this.iManagerSeq = 0;
    this.dtRegDate = '';
  }
}
