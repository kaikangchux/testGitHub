import { Component, OnInit, Optional} from '@angular/core';
import { Title } from "@angular/platform-browser";
import { TranslateService } from '@ngx-translate/core';
import { NgxSpinnerService } from "ngx-spinner";
import { MatDialog } from '@angular/material';

import { ConfigService } from '../../config';
import { CommonService, FaqService } from '../../service';
import { FaqModel } from '../../model';

import { FaqDetailComponent } from './faqdetail.component';
import { FaqRegistComponent } from './faqregist.component';
import { FaqModifyComponent } from './faqmodify.component';

@Component({
    selector: 'app-list',
    templateUrl: './faqlist.component.html',
    styleUrls: ['../scss/list.component.scss']
})

export class FaqListComponent implements OnInit
{

    start:number = 0;
    len:number = 20;
    total:number = 0;
    faqList:FaqModel[] = [];
    curPage:number = 1;

    constructor(private titleService:Title,
                private translate:TranslateService,
                private mService:FaqService,
                private spinnerService:NgxSpinnerService,
                private config:ConfigService,
                private cmnService:CommonService,
                public dialog: MatDialog){

        this.titleService.setTitle(this.translate.instant('TITLE.FAQ'));
        this.config.setSettings({layout: {navbar: 'show'}});
    }

    ngOnInit():void
    {
        this.getFaqList(this.curPage, this.len);
    }

    getFaqList(curPage:number, len:number):void
    {
        this.spinnerService.show();

        this.mService.getFaqList(curPage, len).subscribe(
            list => {
                this.faqList = list.data.gClass;
                this.total = list.data.totalRecord;
                this.mService.changeFaqList(this.faqList);
            },
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

    pagingArr():number[]
    {
        let result = Math.ceil(this.total/this.len);
        return Array.from({length: result}, (v, k) => k+1);
    }

    pager(page:number)
    {
        if(page === this.curPage){
            return;
        }

        this.curPage = page;
        this.getFaqList(this.curPage, this.len);
    }

    // FAQ 등록
    openRegist():void
    {
        const dialogRef =this.dialog.open(FaqRegistComponent, {data:null});

        // 팝업일 경우: 데이터 등록 후 리스트 갱신
        dialogRef.afterClosed().subscribe(res => {
            if(res === true){
                this.getFaqList(this.curPage, this.len);
            }
        });
    }

    // FAQ 상세정보
    openDetail(iSeq:number):void
    {
        this.dialog.open(FaqDetailComponent, {data:{iSeq:iSeq}});
    }

    // FAQ 정보수정
    openModify(iSeq:number, curPage:number):void
    {
        const dialogRef = this.dialog.open(FaqModifyComponent, {data:{iSeq:iSeq}});

        // 팝업일 경우: 데이터 수정 후 리스트 갱신
        dialogRef.afterClosed().subscribe(res => {
            if(res === true){
                if(curPage < 0){
                    this.curPage = 1;
                }
                this.getFaqList(this.curPage, this.len);
            }
        });
    }

    // FAQ 삭제
    onDelete(iSeq:number):void
    {
        const result = window.confirm(this.translate.instant('DELETE.MSG'));
        if(!result){
            return;
        }

        this.spinnerService.show();

        this.mService.deleteFaq(iSeq).subscribe(
            (res) => this.ngOnInit(),
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

}