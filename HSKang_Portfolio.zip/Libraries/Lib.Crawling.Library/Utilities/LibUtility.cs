﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Data;
using System.Net.Mail;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using ZeroFormatter;
using AngleSharp.Html.Dom;
using AngleSharp.Html.Parser;

using Lib.Crawling.Library.Log;
using Lib.Crawling.Library.Entities;

namespace Lib.Crawling.Library.Utilities
{

    #region // !++ LibUtility
    /// <summary>
    /// LibUtility
    /// </summary>
    public class LibUtility
    {

        #region // !++ Utility
        /// <summary>
        /// Security
        /// </summary>
        protected Security security = new Security();
        #endregion


        #region // !++ 파일 저장하기
        /// <summary>
        /// 파일 저장하기
        /// </summary>
        /// <param name="file"></param>
        /// <param name="fileName"></param>
        public void SaveFile(String file, String fileName = "0_Unknown")
        {
            //현재시간 String
            DateTime now = DateTime.Now;

            var dirPath = String.Concat(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), @"\WebUpload\File\");
            var filePath = String.Concat(fileName, "_", now.ToString("yyyyMMdd"), "_", now.ToString("HHmmss"), ".txt");

            //폴더 생성 유무 확인
            var dirInfo = new DirectoryInfo(dirPath);
            if (dirInfo.Exists == false)
            {
                //폴더 없음. 폴더 생성
                dirInfo.Create();
            }

            //Log 파일 저장
            try
            {
                var fileStream = new FileStream(String.Concat(dirPath, filePath), FileMode.Append, FileAccess.Write, FileShare.Write);
                var streamWriter = new StreamWriter(fileStream, Encoding.UTF8);

                streamWriter.Write(file);

                streamWriter.Close();
                fileStream.Close();
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "[Utility.SaveFile] Try Catch Fatal Error... e.Message: " + exc.Message + "\nfilePath: " + String.Concat(dirPath, filePath) + "\nfile: " + file, exc);
            }
        }
        #endregion End 파일 저장하기


        #region // !++ 랜덤 뽑아오기
        private static Random random = new Random();
        private static Random utcRandom = new Random(DateTime.UtcNow.Millisecond);

        /// <summary>
        /// 랜덤 수치 뽑기
        /// </summary>
        /// <returns></returns>
        public Int32 Next()
        {
            lock (random)
            {
                return random.Next();
            }
        }

        /// <summary>
        /// 수치 이하의 랜덤
        /// </summary>
        /// <param name="maxValue">지정 최대 수치</param>
        /// <returns></returns>
        public Int32 Next(Int32 maxValue)
        {
            lock (random)
            {
                return random.Next(maxValue);
            }
        }

        /// <summary>
        /// 범위 랜덤
        /// </summary>
        /// <param name="minValue">최소 수치</param>
        /// <param name="maxValue">최대 수치</param>
        /// <returns></returns>
        public Int32 Next(Int32 minValue, Int32 maxValue)
        {
            lock (random)
            {
                return random.Next(minValue, maxValue);
            }
        }

        /// <summary>
        /// 소수점 랜덤 수치 뽑기(0.0 ~ 1.0)
        /// </summary>
        /// <returns></returns>
        public Double NextDouble()
        {
            lock (random)
            {
                return random.NextDouble();
            }
        }

        /// <summary>
        /// UTC 랜덤
        /// </summary>
        /// <param name="minValue">최소 수치</param>
        /// <param name="maxValue">최대 수치</param>
        /// <returns></returns>
        public Int32 NextUtc(Int32 minValue, Int32 maxValue)
        {
            lock (utcRandom)
            {
                return utcRandom.Next(minValue, maxValue);
            }
        }


        /// <summary>
        /// 랜덤문자 생성(숫자만)
        /// </summary>
        /// <param name="stringLength"></param>
        /// <returns></returns>
        public String RandomString(Int32 stringLength)
        {
            Int32 randomNum = 0;
            Int32 i, j;
            String randomString = null;

            for (i = 0; i < stringLength; i++)
            {
                for (j = 48; j <= 57; j++)
                {
                    randomNum = Next(48, 57);
                }

                randomString += Convert.ToChar(randomNum);
            }
            return (randomString);
        }
        #endregion 랜덤 뽑아오기


        #region // !++ GUID 가져오기
        /// <summary>
        /// GUID 가져오기
        /// </summary>
        /// <returns></returns>
        public String GetGuid()
        {
            var guid = Guid.NewGuid().ToString();
            return guid;
        }
        #endregion


        #region // !++ 현재날짜 숫자로 가져오기
        /// <summary>
        /// 현재날짜(년월일시분초밀리초) 숫자로 가져오기
        /// </summary>
        /// <param name="range">범위(숫자)</param>
        /// <returns></returns>
        public String TodayCode(Int32 range)
        {
            String dayCode = null;
            String year = DateTime.Now.Year.ToString();
            String month = Right("0" + DateTime.Now.Month.ToString(), 2);
            String day = Right("0" + DateTime.Now.Day.ToString(), 2);
            String hour = Right("0" + DateTime.Now.Hour.ToString(), 2);
            String min = Right("0" + DateTime.Now.Minute.ToString(), 2);
            String sec = Right("0" + DateTime.Now.Second.ToString(), 2);
            String mSec = DateTime.Now.Millisecond.ToString();

            switch (range)
            {
                case 1: //년
                    dayCode = year;
                    break;
                case 2: //년+월
                    dayCode = String.Concat(year, month);
                    break;
                case 3: //년+월+일
                    dayCode = String.Concat(year, month, day);
                    break;
                case 4: //년+월+일+시
                    dayCode = String.Concat(year, month, day, hour);
                    break;
                case 5: //년+월+일+시+분
                    dayCode = String.Concat(year, month, day, hour, min);
                    break;
                case 6: //년+월+일+시+분+초
                    dayCode = String.Concat(year, month, day, hour, min, sec);
                    break;
                case 7: //년+월+일+시+분+초+밀리초
                    dayCode = String.Concat(year, month, day, hour, min, sec, mSec);
                    break;
                default:
                    dayCode = year;
                    break;
            }
            return dayCode;
        }
        #endregion 현재날짜 숫자로 가져오기


        #region // !++ Left 함수
        /// <summary>
        /// 좌측 문자열 짜르기 Left split
        /// </summary>
        /// <param name="target">찾을 문자열</param>
        /// <param name="length">문자열 길이</param>
        /// <returns></returns>
        public String Left(String target, Int32 length)
        {
            String l_Result;
            if (target.Length < length)
                length = target.Length;
            l_Result = target.Substring(0, length);
            return l_Result;
        }
        #endregion


        #region // !++ Right 함수
        /// <summary>
        /// 오른쪽 문자열 짜르기 right split
        /// </summary>
        /// <param name="target">찾을 문자열</param>
        /// <param name="length">문자열 길이</param>
        /// <returns></returns>
        public String Right(String target, Int32 length)
        {
            String l_Result;
            if (target.Length < length)
                length = target.Length;
            l_Result = target.Substring(target.Length - length, length);
            return l_Result;
        }
        #endregion


        #region // !++ Mid 함수
        /// <summary>
        /// 중간 문자열 짜르기 Mid split
        /// </summary>
        /// <param name="target">찾을 문자열 앞부분</param>
        /// <param name="startPoint">가져오는 문자열 길이</param>
        /// <param name="endPoint">찾을 문자열 뒷부분</param>
        /// <returns></returns>
        public String Mid(String target, Int32 startPoint, Int32 endPoint)
        {
            String l_Result;
            if (startPoint < target.Length || endPoint < target.Length)
            {
                l_Result = target.Substring(startPoint, endPoint);
                return l_Result;
            }
            else
                return target;
        }
        #endregion


        #region // !++ Split 함수
        /// <summary>
        /// Split Function
        /// </summary>
        /// <param name="target">리털 문자열</param>
        /// <param name="splitString">특수기호</param>
        /// <returns></returns>
        public String[] Split(String target, String splitString)
        {
            Int32 offset = 0;
            Int32 index = 0;
            Int32[] offsets = new Int32[target.Length + 1];

            while (index < target.Length)
            {
                Int32 indexOf = target.IndexOf(splitString, index);
                if (indexOf != -1)
                {
                    offsets[offset++] = indexOf;
                    index = (indexOf + splitString.Length);
                }
                else
                {
                    index = target.Length;
                }
            }

            var final = new String[offset + 1];
            if (offset == 0)
            {
                final[0] = target;
            }
            else
            {
                offset--;
                final[0] = target.Substring(0, offsets[0]);
                for (int i = 0; i < offset; i++)
                {
                    final[i + 1] = target.Substring(offsets[i] + splitString.Length, offsets[i + 1] - offsets[i] - splitString.Length);
                }
                final[offset + 1] = target.Substring(offsets[offset] + splitString.Length);
            }
            return final;
        }
        #endregion


        #region // !++ bool IsSpace(string p_String)
        /// <summary>
        /// 문자열 공란 Function IsSpace
        /// </summary>
        /// <param name="target">문자열</param>
        /// <returns></returns>
        public Boolean IsSpace(String target)
        {
            var bResult = false;
            if (target == "" || target == null)
                bResult = true;
            return bResult;
        }
        #endregion


        #region // !++ UnixTime To Long
        /// <summary>
        /// UnixTime To Long
        /// </summary>
        /// <returns></returns>
        public Int64 UnixTimeToLong()
        {
            var dtUnixTimeNow = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var biDateTime = (Int64)((DateTime.Now - dtUnixTimeNow).TotalSeconds * 1000);
            return biDateTime;
        }
        #endregion


        #region // !++ string GetParamValue(string p_String, string p_Param)
        /// <summary>
        /// 파라메타값 가져오기 (정규식 사용)
        /// </summary>
        /// <param name="p_String"></param>
        /// <param name="p_Param"></param>
        /// <returns></returns>
        public String GetParamValue(String p_String, String p_Param)
        {
            if (IsSpace(p_String))
                return "";
            p_String += "&";
            return Regex.Match(p_String, @"" + p_Param + "=([^(&)]*)&").Groups[1].Value.Trim();
        }
        #endregion


        #region // !++ RemoveStr(string p_String) //제거할 문자열
        /// <summary>
        /// 제거할 문자
        /// </summary>
        /// <param name="p_String">원본문자</param>
        /// <param name="p_Move">제거문자</param>
        /// <returns></returns>
        public String RemoveStr(String p_String, String p_Move)
        {
            var tmpStr = p_String;
            var l_StringLength = GetByte(p_String);
            if (l_StringLength > 0)
            {
                tmpStr = tmpStr.Replace(p_Move, "");
            }
            return tmpStr;
        }
        #endregion


        #region // !++ OnReplaceStar
        /// <summary>
        /// 문자 별(*)로 숨김
        /// </summary>
        /// <param name="p_Value"></param>
        /// <param name="p_Count"></param>
        /// <returns></returns>
        public String OnReplaceStar(String p_Value, Int32? p_Count)
        {
            var Option = "**************************************";
            if (p_Count == null)
                p_Count = 2;
            var l_Count = Convert.ToInt32(p_Count);
            if (p_Value.Length <= p_Count)
                return Right(Option, l_Count);
            return Left(p_Value, p_Value.Length - l_Count) + Right(Option, l_Count);
        }
        #endregion


        #region // !++ OnReplaceEnter
        /// <summary>
        /// 엔터 줄바꿈
        /// </summary>
        /// <param name="p_Value"></param>
        /// <returns></returns>
        public String OnReplaceEnter(String p_Value)
        {
            if (IsSpace(p_Value))
                return p_Value;
            return p_Value.Replace("\n", "<br/>");
        }
        #endregion


        #region // !++ GetLastDay
        /// <summary>
        /// 해당월 마지막 일 가져오기
        /// </summary>
        /// <param name="strYear"></param>
        /// <param name="strMonth"></param>
        /// <returns></returns>
        public Int32 GetLastDay(Int32 strYear, Int32 strMonth)
        {
            var LD = 0;
            switch (strMonth)
            {
                case 4:
                case 6:
                case 9:
                case 11:
                    LD = 30;
                    break;
                case 2:
                    if ((strYear % 4 == 0) && (strYear % 100 != 0) || (strYear % 400 == 0))
                        LD = 29;
                    else
                        LD = 28;
                    break;
                default:
                    LD = 31;
                    break;
            }
            return LD;
        }
        #endregion


        #region // !++ 날짜 문자로 가져오기
        /// <summary>
        /// 날짜 문자로 가져오기
        /// </summary>
        /// <param name="dateType">날짜타입(1:서버, 2:UTC)</param>
        /// <param name="strlength">문자열길이</param>
        /// <returns></returns>
        public String GetDateString(Int32 dateType, Int32 strlength)
        {
            var dtDate = new DateTime();
            var dayCode = String.Empty;
            var strYear = String.Empty;
            var strMonth = String.Empty;
            var strDay = String.Empty;
            var strHour = String.Empty;
            var strMin = String.Empty;
            var strSec = String.Empty;
            var strMsec = String.Empty;

            if (dateType == 1)
            {
                dtDate = DateTime.Now;
            }
            else
            {
                dtDate = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            }

            strYear = dtDate.Year.ToString();
            strMonth = Right("0" + dtDate.Month.ToString(), 2);
            strDay = Right("0" + dtDate.Day.ToString(), 2);
            strHour = Right("0" + dtDate.Hour.ToString(), 2);
            strMin = Right("0" + dtDate.Minute.ToString(), 2);
            strSec = Right("0" + dtDate.Second.ToString(), 2);
            strMsec = dtDate.ToString();

            switch (strlength)
            {
                case 1: //년
                    dayCode = strYear;
                    break;
                case 2: //년+월
                    dayCode = String.Concat(strYear, strMonth);
                    break;
                case 3: //년+월+일
                    dayCode = String.Concat(strYear, strMonth, strDay);
                    break;
                case 4: //년+월+일+시
                    dayCode = String.Concat(strYear, strMonth, strDay, strHour);
                    break;
                case 5: //년+월+일+시+분
                    dayCode = String.Concat(strYear, strMonth, strDay, strHour, strMin);
                    break;
                case 6: //년+월+일+시+분+초
                    dayCode = String.Concat(strYear, strMonth, strDay, strHour, strMin, strSec);
                    break;
                case 7: //년+월+일+시+분+초+밀리초
                    dayCode = String.Concat(strYear, strMonth, strDay, strHour, strMin, strSec, strMsec);
                    break;
                default:
                    dayCode = strYear;
                    break;
            }

            return dayCode;
        }
        #endregion


        #region // !++ 문자관련 Extension

        #region // !++ GetEmailParamValue (E-mail 확인)
        /// <summary>
        /// E-mail 확인 (정규식 사용)
        /// </summary>
        /// <param name="p_String"></param>
        /// <returns></returns>
        public Boolean GetEmailParamValue(String p_String)
        {
            if (p_String + "" == "")
                return false;
            var l_Reg = new Regex(@"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*");
            var l_IsMatch = l_Reg.IsMatch(p_String);
            return l_IsMatch;
        }
        #endregion


        #region // !++ GetOnlyNum (숫자형 확인)
        /// <summary>
        /// 문자열 유효성 : 숫자
        /// </summary>
        /// <param name="p_String">문자열</param>
        /// <returns></returns>
        public Boolean GetOnlyNum(String p_String)
        {
            if (p_String + "" == "")
                return false;

            var l_Reg = new Regex(@"^(\d)+$");
            var l_IsMatch = l_Reg.IsMatch(p_String);
            return l_IsMatch;
        }
        #endregion


        #region // !++ GetOnlyNumEng (숫자+영문 확인)
        /// <summary>
        /// 문자열 유효성 : 영문 & 숫자
        /// </summary>
        /// <param name="p_String">문자열</param>
        /// <returns></returns>
        public Boolean GetOnlyNumEng(String p_String)
        {
            if (p_String + "" == "")
                return false;

            var l_Reg = new Regex(@"^[0-9a-zA-Z ]+$");
            var l_IsMatch = l_Reg.IsMatch(p_String);
            return l_IsMatch;
        }
        #endregion


        #region // !++ GetOnlyNumEngKor (숫자+영문+한글 확인)
        /// <summary>
        /// 문자열 유효성 : 영문 & 숫자 & 한글
        /// </summary>
        /// <param name="p_String">문자열</param>
        /// <returns></returns>
        public Boolean GetOnlyNumEngKor(String p_String)
        {
            if (p_String + "" == "")
                return false;

            var l_Reg = new Regex(@"^[0-9a-zA-Z가-힣ㅏ-ㅣㄱ-ㅎ ]+$");
            var l_IsMatch = l_Reg.IsMatch(p_String);
            return l_IsMatch;
        }
        #endregion


        #region // !++ GetOnlyString (문자형 확인)
        /// <summary>
        /// 문자형 확인
        /// </summary>
        /// <param name="p_String"></param>
        /// <returns></returns>
        public Boolean GetOnlyString (String p_String)
        {
            if (p_String + "" == "")
                return false;

            var l_Reg = new Regex(@"[\!\""\#\$\%\&\'\(\)\*\+\,\-\.\/\:\;\<\=\>\?@\[\\\]\^_\`\{\|\}\~]");
            var l_IsMatch = l_Reg.IsMatch(p_String);
            return l_IsMatch;
        }
        #endregion

        #endregion


        #region // !++ Lit Json (by Newtonsoft)

        #region //+ Lit JSON Serialize
        /// <summary>
        /// Lit JSON Serialize
        /// </summary>
        /// <param name="obj">데이터</param>
        /// <returns></returns>
        public String ToJson(Object obj)
        {
            return JsonConvert.SerializeObject(obj);
        }
        #endregion


        #region //+ Lit JSON 비동기 Serialize
        /// <summary>
        /// Lit JSON 비동기 Serialize
        /// </summary>
        /// <param name="obj">데이터</param>
        /// <returns></returns>
        public async Task<String> ToJsonAsync(Object obj)
        {
            var serializeData = await Task.Run(() => JsonConvert.SerializeObject(obj));
            return serializeData;
        }
        #endregion


        #region //+ Lit JSON Deserialize
        /// <summary>
        /// Lit JSON Deserialize
        /// </summary>
        /// <param name="data">data</param>
        /// <returns></returns>
        public Object FromJson(String data)
        {
            return JsonConvert.DeserializeObject(data);
        }

        /// <summary>
        /// Lit JSON Generic Deserialize
        /// </summary>
        /// <typeparam name="T">Generic</typeparam>
        /// <param name="data">data</param>
        /// <returns></returns>
        public dynamic FromJson<T>(String data)
        {
            return JsonConvert.DeserializeObject<T>(data);
        }
        #endregion


        #region //+ Lit JSON 비동기 Deserialize
        /// <summary>
        /// Lit JSON 비동기 Deserialize
        /// </summary>
        /// <param name="data">data</param>
        /// <returns></returns>
        public async Task<Object> FromJsonAsync(String data)
        {
            var deserializeData = await Task.Run(() => JsonConvert.DeserializeObject(data));
            return deserializeData;
        }

        /// <summary>
        /// Lit JSON 비동기 Deserialize
        /// </summary>
        /// <typeparam name="T">Generic Entity</typeparam>
        /// <param name="data">data</param>
        /// <returns></returns>
        public async Task<dynamic> FromJsonAsync<T>(String data)
        {
            var deserializeData = await Task.Run(() => JsonConvert.DeserializeObject<T>(data));
            return deserializeData;
        }
        #endregion


        #region // !++ SetJsonObject
        /// <summary>
        /// 
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public JObject SetJsonObject(Object obj)
        {
            return JObject.FromObject(obj);
        }
        #endregion

        #endregion


        #region // !++ Bson Json (by ZeroFormatter)

        #region // !++ JSON Serialize
        /// <summary>
        /// 
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public Byte[] ToJsonBson(Object obj)
        {
            return ZeroFormatterSerializer.Serialize(obj);
        }
        #endregion


        #region // !++ JSON Deserialize
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="data"></param>
        /// <returns></returns>
        public Object FromJsonBson<T>(Byte[] data)
        {
            return ZeroFormatterSerializer.Deserialize<T>(data);
        }
        #endregion

        #endregion


        #region // !++ GetByte(string p_String)
        /// <summary>
        /// 문자열 유효성 : 문자 Byte 구하기
        /// </summary>
        /// <param name="p_String">문자열</param>
        /// <returns></returns>
        public Int32 GetByte(String p_String)
        {
            if (p_String == null || p_String == "")
                return 0;
            else
                // return Encoding.Default.GetByteCount(p_String);
                return Encoding.UTF8.GetByteCount(p_String);
        }
        #endregion


        #region // !++ 문자열 압축


        #region GZip 압축 Return byte[]
        /// <summary>
        /// GZip 압축 Return byte[]
        /// </summary>
        /// <param name="value">압축문자</param>
        /// <returns></returns>
        public async Task<Byte[]> GZipToByte(String value)
        {
            Byte[] compressBinary = null;
            var data = Encoding.UTF8.GetBytes(value.Trim());
            using (var output = new MemoryStream())
            {
                using (var gzip = new GZipStream(output, CompressionMode.Compress, true))
                {
                    await Task.Run(() => gzip.WriteAsync(data, 0, data.Length));
                    gzip.Close();
                    gzip.Dispose();
                }
                compressBinary = output.ToArray();
                output.Close();
                output.Dispose();
            }

            return compressBinary;
        }
        #endregion


        #region GZip 압축 Return string
        /// <summary>
        /// GZip 압축 Return string
        /// </summary>
        /// <param name="value">압축문자</param>
        /// <returns></returns>
        public async Task<String> GZipToString(String value)
        {
            var compressString = String.Empty;
            var data = Encoding.UTF8.GetBytes(value.Trim());

            using (var output = new MemoryStream())
            {
                using (var gzip = new GZipStream(output, CompressionMode.Compress, true))
                {
                    await Task.Run(() => gzip.WriteAsync(data, 0, data.Length));
                    gzip.Close();
                    gzip.Dispose();
                }
                data = output.ToArray();

                compressString = Convert.ToBase64String(data);
                output.Close();
                output.Dispose();
            }
            return compressString;
        }
        #endregion


        #region Deflate 압축 Return byte[]
        /// <summary>
        /// Deflate 압축 Return byte[]
        /// </summary>
        /// <param name="value">압축문자</param>
        /// <returns></returns>
        public async Task<Byte[]> DZipToByte(String value)
        {
            Byte[] compressBinary = null;
            var data = Encoding.UTF8.GetBytes(value.Trim());
            using (var output = new MemoryStream())
            {
                using (var dzip = new DeflateStream(output, CompressionMode.Compress, true))
                {
                    await Task.Run(() => dzip.WriteAsync(data, 0, data.Length));
                    dzip.Close();
                    dzip.Dispose();
                }

                compressBinary = output.ToArray();
                output.Close();
                output.Dispose();
            }
            return compressBinary;
        }
        #endregion


        #region Deflate 압축 Return string
        /// <summary>
        /// Deflate 압축 Return string
        /// </summary>
        /// <param name="value">압축문자</param>
        /// <returns></returns>
        public async Task<String> DZipToString(String value)
        {
            var compressString = String.Empty;
            var data = Encoding.UTF8.GetBytes(value.Trim());

            using (var output = new MemoryStream())
            {
                using (var dzip = new DeflateStream(output, CompressionMode.Compress, true))
                {
                    await Task.Run(() => dzip.WriteAsync(data, 0, data.Length));
                    dzip.Close();
                    dzip.Dispose();
                }
                data = output.ToArray();
                compressString = Convert.ToBase64String(data);
                output.Close();
                output.Dispose();
            }
            return compressString;
        }
        #endregion


        #endregion


        #region // !++ 문자열 압축해제


        #region GZip byte[] 압축해제
        /// <summary>
        /// GZip byte[] 압축해제
        /// </summary>
        /// <param name="value">압축해제 Byte[]</param>
        /// <returns></returns>
        public async Task<String> GZipFromByte(Byte[] value)
        {
            var decompressString = String.Empty;
            using (var input = new MemoryStream(value))
            {
                using (var gzip = new GZipStream(input, CompressionMode.Decompress, true))
                {
                    using (var output = new MemoryStream())
                    {
                        await Task.Run(() => gzip.CopyToAsync(output));
                        decompressString = Encoding.UTF8.GetString(output.ToArray());
                        output.Close();
                        output.Dispose();
                    }
                    gzip.Close();
                    gzip.Dispose();
                }
                input.Close();
                input.Dispose();
            }
            return decompressString;
        }
        #endregion


        #region GZip string 압축해제
        /// <summary>
        /// GZip string 압축해제
        /// </summary>
        /// <param name="value">압축해제 String</param>
        /// <returns></returns>
        public async Task<String> GZipFromString(String value)
        {
            var decompressString = String.Empty;
            var byteArray = Convert.FromBase64String(value.Trim());

            using (var input = new MemoryStream(byteArray))
            {
                using (var gzip = new GZipStream(input, CompressionMode.Decompress, true))
                {
                    using (var output = new MemoryStream())
                    {
                        await Task.Run(() => gzip.CopyToAsync(output));
                        decompressString = Encoding.UTF8.GetString(output.ToArray());
                        output.Close();
                        output.Dispose();
                    }
                    gzip.Close();
                    gzip.Dispose();
                }
                input.Close();
                input.Dispose();
            }
            return decompressString;
        }
        #endregion


        #region DZip byte[] 압축해제
        /// <summary>
        /// DZip byte[] 압축해제
        /// </summary>
        /// <param name="value">압축해제 Byte[]</param>
        /// <returns></returns>
        public async Task<String> DZipFromByte(Byte[] value)
        {
            var decompressString = String.Empty;
            using (var input = new MemoryStream(value))
            {
                using (var dzip = new DeflateStream(input, CompressionMode.Decompress, true))
                {
                    using (var output = new MemoryStream())
                    {
                        await Task.Run(() => dzip.CopyToAsync(output));
                        decompressString = Encoding.UTF8.GetString(output.ToArray());
                        output.Close();
                        output.Dispose();
                    }
                    dzip.Close();
                    dzip.Dispose();
                }
                input.Close();
                input.Dispose();
            }
            return decompressString;
        }
        #endregion


        #region DZip string 압축해제
        /// <summary>
        /// DZip string 압축해제
        /// </summary>
        /// <param name="value">압축해제 String</param>
        /// <returns></returns>
        public async Task<String> DZipFromString(String value)
        {
            var decompressString = String.Empty;
            var byteArray = Convert.FromBase64String(value.Trim());

            using (var input = new MemoryStream(byteArray))
            {
                using (var dzip = new DeflateStream(input, CompressionMode.Decompress, true))
                {
                    using (var output = new MemoryStream())
                    {
                        await Task.Run(() => dzip.CopyToAsync(output));
                        decompressString = Encoding.UTF8.GetString(output.ToArray());
                        output.Close();
                        output.Dispose();
                    }
                    dzip.Close();
                    dzip.Dispose();
                }
                input.Close();
                input.Dispose();
            }
            return decompressString;
        }
        #endregion

        #endregion


        #region // !++ HTTP 통신모듈(HTTP Utility)


        #region // Get 방식
        /// <summary>
        /// Get 방식
        /// </summary>
        /// <param name="uri">URL(+ Method)</param>
        /// <returns></returns>
        public String HttpGet(String uri)
        {
            var webRequest = WebRequest.Create(uri);
            webRequest.Proxy = new WebProxy(uri, true);     // true means no proxy
            try
            {
                using (var webResponse = webRequest.GetResponse())
                {
                    using (var streamReader = new StreamReader(webResponse.GetResponseStream()))
                    {
                        return streamReader.ReadToEnd().Trim();
                    }
                }
            }
            catch (Exception exc)
            {
                exc.ToString();
                return null;
            }
        }
        #endregion


        #region // Post 방식
        /// <summary>
        /// Post 방식
        /// </summary>
        /// <param name="uri">URL</param>
        /// <param name="parameters">Parameter</param>
        /// <returns></returns>
        public String HttpPost(String uri, String parameters)
        {
            var webReuqest = WebRequest.Create(uri);
            webReuqest.Proxy = new WebProxy(uri, true);
            // Add these, as we're doing a POST
            webReuqest.ContentType = "application/x-www-form-urlencoded";
            webReuqest.Method = "POST";
            // We need to count how many bytes we're sending. Post'ed Faked Forms should be name=value&
            var byteArray = Encoding.ASCII.GetBytes(parameters);
            webReuqest.ContentLength = byteArray.Length;

            try
            {
                var stream = webReuqest.GetRequestStream();
                stream.Write(byteArray, 0, byteArray.Length);   //Push it out there
                stream.Close();
                using (var webResponse = webReuqest.GetResponse())
                {
                    if (webResponse == null)
                    {
                        return null;
                    }

                    else
                    {
                        using (var streamReader = new StreamReader(webResponse.GetResponseStream()))
                        {
                            return streamReader.ReadToEnd().Trim();
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                exc.ToString();
                return null;
            }

        }
        #endregion


        #region // Async Get 방식
        /// <summary>
        /// Async Get 방식
        /// </summary>
        /// <param name="uri">URL(+ Method)</param>
        /// <returns></returns>
        public async Task<String> HttpGetAsync(String uri)
        {
            // 통신 초기화
            using (var client = new HttpClient())
            {
                try
                {
                    // 타겟 URL 호출 및 Response string 받기
                    var page = await client.GetStringAsync(uri);
                    return page;
                }
                catch (Exception exc)
                {
                    exc.ToString();
                    return null;
                }

            }
        }
        #endregion


        #region // Async Post 방식
        /// <summary>
        /// Async Post 방식
        /// </summary>
        /// <param name="uri">URL</param>
        /// <param name="parameters">Parameter</param>
        /// <returns></returns>
        public async Task<String[]> HttpPostAsync(String uri, Dictionary<String, String> parameters)
        {
            var returnStringArray = new String[3] { String.Empty, String.Empty, String.Empty };
            // 통신 초기화
            using (var client = new HttpClient())
            {
                var contents = new FormUrlEncodedContent(parameters);
                try
                {
                    // 타겟 URL 호출 및 Response string 받기
                    var response = await client.PostAsync(uri, contents);
                    response.EnsureSuccessStatusCode();

                    IEnumerable<String> headerValues_CommonResponse = response.Headers.GetValues("COMMONRESPONSE");
                    returnStringArray[0] = headerValues_CommonResponse.FirstOrDefault();
                    IEnumerable<String> headerValues_Hash = response.Headers.GetValues("HASH");
                    returnStringArray[1] = headerValues_Hash.FirstOrDefault();

                    returnStringArray[2] = await response.Content.ReadAsStringAsync();
                }
                catch (Exception exc)
                {
                    exc.ToString();
                    returnStringArray[0] = String.Empty;
                    returnStringArray[1] = String.Empty;
                    returnStringArray[2] = String.Empty;
                    return null;
                }
            }
            return returnStringArray;
        }
        #endregion


        #region // !++ HttpWebSiteInfo (웹사이트 정보 취득)
        /// <summary>
        /// 웹사이트 정보 취득
        /// </summary>
        /// <param name="uri"></param>
        /// <returns></returns>
        public async Task<String> HttpWebSiteInfo(String uri)
        {

            try
            {
                // var webReuqest = WebRequest.CreateHttp(uri);
                var siteSource = String.Empty;

                using (var client = new WebClient())
                {
                    client.Encoding = Encoding.UTF8;
                    //  String siteSource = await client.DownloadStringTaskAsync(webReuqest.Address);
                    siteSource = await client.DownloadStringTaskAsync(uri);
                    return siteSource;
                }
            }
            catch (Exception exc)
            {
                exc.ToString();
                return null;
            }

        }
        #endregion


        #endregion


        #region // !++ HTTP Web page 가져오기
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<IHtmlDocument> GetHtmlInfo(String uri)
        {

            var cancellationToken = new CancellationTokenSource();
            var httpClient = new HttpClient();
            var request = await httpClient.GetAsync(uri);
            cancellationToken.Token.ThrowIfCancellationRequested();

            var response = await request.Content.ReadAsStreamAsync();
            cancellationToken.Token.ThrowIfCancellationRequested();

            var parser = new HtmlParser();
            var document = parser.ParseDocument(response);

            return document;

        }
        #endregion


        #region // !++ CSV(Text) 형태 파일 만들기
        /// <summary>
        /// 
        /// </summary>
        /// <param name="stream"></param>
        /// <param name="table"></param>
        /// <param name="header"></param>
        /// <param name="quoteall"></param>
        public void WriteToStream(TextWriter stream, DataTable table, Boolean header, Boolean quoteall)
        {
            if (header)
            {
                for (int i = 0; i < table.Columns.Count; i++)
                {
                    WriteItem(stream, table.Columns[i].Caption, quoteall);
                    if (i < table.Columns.Count - 1)
                        stream.Write(',');
                    else
                        stream.Write("\r\n");
                }
            }

            foreach (DataRow row in table.Rows)
            {
                for (int i = 0; i < table.Columns.Count; i++)
                {
                    WriteItem(stream, row[i], quoteall);
                    if (i < table.Columns.Count - 1)
                        stream.Write(',');
                    else
                        stream.Write("\r\n");
                }
            }
            stream.Flush();
            stream.Close();
        }

        private void WriteItem(TextWriter stream, Object item, Boolean quoteall)
        {
            if (item == null)
                return;

            String s = item.ToString();
            if (quoteall || s.IndexOfAny("\",\x0A\x0D".ToCharArray()) > -1)
                stream.Write("\"" + s.Replace("\"", "\"\"") + "\"");
            else
                stream.Write(s);
            stream.Flush();
        }
        #endregion CSV(Text) 형태 파일 만들기


        #region // !++ 암복호화
        /// <summary>
        /// 암호화
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public String Encrypt(String obj)
        {
            return security.Encrypt(obj.ToString().Trim());
        }

        /// <summary>
        /// 복호화
        /// </summary>
        /// <param name="encryptedString"></param>
        /// <returns></returns>
        public String Decrypt(String encryptedString)
        {
            return security.Decrypt(encryptedString.Trim());
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public String SetBase64(String obj)
        {
            return Convert.ToBase64String(Encoding.Unicode.GetBytes(obj));
        }
        #endregion


        #region // !++ SendEmail (E-mail 발송하기)
        /// <summary>
        /// E-mail 발송하기
        /// </summary>
        /// <param name="model"></param>
        /// 현재 구글 메일 서버를 이용해서 보내고 있음!!
        /// 구글 계정에서 메일 로그인 => 설정 => 전달 및 POP/IMAP 사용으로 설정
        /// 보안 수준이 낮은 앱 허용(https://myaccount.google.com/lesssecureapps?pli=1) 설정 변경
        /// <returns></returns>
        public async Task<Boolean> SendEmail(SendEmailEntity model)
        {

            Boolean result = false;

            try
            {

                #region // !++ E-mail message
                using (var mailMessage = new MailMessage())
                {
                    using (var client = new SmtpClient())
                    {
                        // provide credentials (SMTP서버 인증)
                        client.EnableSsl = true;
                        client.UseDefaultCredentials = false;
                        client.Credentials = new NetworkCredential(model.FromEmail, model.FromEmailPassword);
                        client.Host = model.SMTPMailServer;
                        client.Port = model.FromEmailTLS;
                        client.DeliveryMethod = SmtpDeliveryMethod.Network;

                        // configure the mail message (메일 메시지 설정)
                        mailMessage.From = new MailAddress(model.FromEmail, model.FromEmailDisplayName);    // 보내는 메일주소(이름)
                        if (String.IsNullOrEmpty(model.ToEmailDisplayName))
                        {
                            mailMessage.To.Insert(0, new MailAddress(model.ToEmail));   // 받는 메일주소
                        }
                        else
                        {
                            mailMessage.To.Insert(0, new MailAddress(model.ToEmail, model.ToEmailDisplayName));   // 받는 메일주소(이름)
                        }
                        mailMessage.Subject = model.Subject;    // 제목
                        mailMessage.Body = model.BodyContents;  // 내용
                        mailMessage.BodyEncoding = Encoding.UTF8;   // 인코딩 설정
                        mailMessage.IsBodyHtml = true;              // HTML 허용여부

                        // send email (메일 발송)
                        // client.Send(mailMessage);
                        await client.SendMailAsync(mailMessage);    // 비동기 메일 발송

                        result = true;
                    }
                }
                #endregion

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "LibUtility SendEmail : \n [SendEmailEntity:{0}], \n {1}, \n {2}",
                                        ToJson(model), exc.Message, exc.StackTrace);

                result = false;
                return result;
            }

            return result;
        }
        #endregion


        #region // !++ GetUrlQueryStringSeparation (URL, Query 분리)
        /// <summary>
        /// URL, Query 분리
        /// </summary>
        /// <param name="uri"></param>
        /// <returns></returns>
        public ResultEntity<UrlQueryStringSeparationEntity> GetUrlQueryStringSeparation(String uri)
        {

            var result = new ResultEntity<UrlQueryStringSeparationEntity>();

            try
            {

                var dataUrl = new UrlQueryStringSeparationEntity();
                var Url = new Uri(uri);
                var baseUri = Url.GetComponents(UriComponents.Scheme | UriComponents.Host | UriComponents.Port | UriComponents.Path, UriFormat.UriEscaped);

                dataUrl.vcUri = baseUri;

                if (String.IsNullOrWhiteSpace(Url.Query) == true)
                {
                    dataUrl.queryStringDictionary = null;
                }
                else
                {
                    dataUrl.queryStringDictionary = ParseQueryString(Url.Query);
                }
                result.gClass = dataUrl;
                result.bresult = true;
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "LibUtility GetUrlQueryStringSeparation : \n [URL:{0}], \n {1}, \n {2}",
                                        uri, exc.Message, exc.StackTrace);

                result.bresult = false;
                return result;
            }

            return result;
        }
        #endregion


        #region // !++ ParseQueryString (URL 파라미터 String Dictionary로 변환)
        /// <summary>
        /// URL 파라미터 Dictionary로 변환
        /// </summary>
        /// <param name="requestQueryString"></param>
        /// <returns></returns>
        internal Dictionary<String, String> ParseQueryString(String requestQueryString)
        {
            var rc = new Dictionary<String, String>();
            var ar1 = requestQueryString.Split(new Char[] { '&', '?' });

            try
            {
                foreach (var row in ar1)
                {
                    if (String.IsNullOrEmpty(row)) continue;
                        Int32 index = row.IndexOf('=');
                    if (index < 0) continue;
                        rc[Uri.UnescapeDataString(row.Substring(0, index))] = Uri.UnescapeDataString(row.Substring(index + 1)); // use Unescape only parts          
                }
                return rc;
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "LibUtility ParseQueryString : \n [Parameter:{0}], \n {1}, \n {2}",
                                        requestQueryString, exc.Message, exc.StackTrace);

                return null;
            }
        }
        #endregion


    }
    #endregion

}
