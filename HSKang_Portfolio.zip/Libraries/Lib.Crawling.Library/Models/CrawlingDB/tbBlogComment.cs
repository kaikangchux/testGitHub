﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.CrawlingDB
{

    #region // !++ tbBlogComment
    /// <summary>
    /// 블로그 댓글
    /// </summary>
    [Table("tbBlogComment")]
    public class tbBlogComment
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        /// <summary>
        /// 고유번호
        /// </summary>
        public Int64 biSeq { get; set; }

        [Index(1), Required]
        /// <summary>
        /// 블로그 고유번호
        /// </summary>
        public Int64 biBlogSeq { get; set; }

        [Index(2), Required]
        /// <summary>
        /// 회원고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        [Required, MinLength(4), MaxLength(32)]
        /// <summary>
        /// 계정ID
        /// </summary>
        public String vcAccount { get; set; }

        [Required, MinLength(2), MaxLength(32)]
        /// <summary>
        /// 이름
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 내용
        /// </summary>
        public String tDescription { get; set; }

        /// <summary>
        /// 등록IP
        /// </summary>
        public String vcIP { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
