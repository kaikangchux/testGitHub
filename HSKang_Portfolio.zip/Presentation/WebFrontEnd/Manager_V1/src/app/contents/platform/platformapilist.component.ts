import { Component, OnInit, Optional} from '@angular/core';
import { Title } from "@angular/platform-browser";
import { TranslateService } from '@ngx-translate/core';
import { NgxSpinnerService } from "ngx-spinner";
import { MatDialog } from '@angular/material';

import { ConfigService } from '../../config/config.service';
import { CommonService, PlatFormService } from '../../service';
import { PlatFormApiModel } from '../../model';

import { PlatFormApiDetailComponent } from './platformapidetail.component';
import { PlatFormApiRegistComponent } from './platformapiregist.component';
import { PlatFormApiModifyComponent } from './platformapimodify.component';


@Component({
    selector: 'app-list',
    templateUrl: './platformapilist.component.html',
    styleUrls: ['../scss/list.component.scss']
})

export class PlatFormApiListComponent implements OnInit
{

    start:number = 0;
    len:number = 20;
    total:number = 0;
    platformapiList:PlatFormApiModel[] = [];
    curPage:number = 1;

    constructor(private titleService:Title,
                private translate:TranslateService,
                private mService:PlatFormService,
                private spinnerService:NgxSpinnerService,
                private config:ConfigService,
                private cmnService:CommonService,
                public dialog: MatDialog){

        this.titleService.setTitle(this.translate.instant('TITLE.PlATFORMAPI'));
        this.config.setSettings({layout: {navbar: 'show'}});
    }

    ngOnInit():void
    {
        this.getPlatFormApiList(this.curPage, this.len);
    }

    getPlatFormApiList(curPage:number, len:number):void
    {
        this.spinnerService.show();

        this.mService.getPlatFormApi(curPage, len).subscribe(
            list => {
                this.platformapiList = list.data.gClass;
                this.total = list.data.totalRecord;
                this.mService.changePlatFormApi(this.platformapiList);
            },
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

    pagingArr():number[]
    {
        let result = Math.ceil(this.total/this.len);
        return Array.from({length: result}, (v, k) => k+1);
    }

    pager(page:number)
    {
        if(page === this.curPage){
            return;
        }

        this.curPage = page;
        this.getPlatFormApiList(this.curPage, this.len);
    }

    // PlatForm api 상세정보
    openDetail(iSeq:number):void
    {
        this.dialog.open(PlatFormApiDetailComponent, {data:{iSeq:iSeq}});
    }

    // PlatForm api 등록
    openRegist():void
    {
        const dialogRef =this.dialog.open(PlatFormApiRegistComponent, {data:null});

        // 팝업일 경우: 데이터 등록 후 리스트 갱신
        dialogRef.afterClosed().subscribe(res => {
            if(res === true){
                this.getPlatFormApiList(this.curPage, this.len);
            }
        });
    }

    // PlatForm api 정보수정
    openModify(iSeq:number, curPage:number):void
    {
        const dialogRef = this.dialog.open(PlatFormApiModifyComponent, {data:{iSeq:iSeq}});

        // 팝업일 경우: 데이터 수정 후 리스트 갱신
        dialogRef.afterClosed().subscribe(res => {
            if(res === true){
                if(curPage < 0){
                    this.curPage = 1;
                }
                this.getPlatFormApiList(this.curPage, this.len);
            }
        });
    }
    
    // PlatForm api 삭제
    onDelete(iSeq:number, iPlatFormSeq:number):void
    {
        const result = window.confirm(this.translate.instant('DELETE.MSG'));
        if(!result){
            return;
        }

        this.spinnerService.show();

        this.mService.deletePlatFormApi(iSeq, iPlatFormSeq).subscribe(
            (res) => this.ngOnInit(),
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

}