// 회원(단체) 정보
export class MemberOrganizationModel
{
    vcPersonName: string;
    vcBusiness: string;
    vcOrganizationSerial: string;

    constructor(){
        this.vcPersonName = '';
        this.vcBusiness = '';
        this.vcOrganizationSerial = '';
    }
}