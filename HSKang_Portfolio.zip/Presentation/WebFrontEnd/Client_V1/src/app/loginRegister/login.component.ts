import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgxSpinnerService } from "ngx-spinner";
import { filter } from 'rxjs/operators';
import { Router, NavigationEnd } from '@angular/router';
import { CookieManageService, MemberService } from '../service';
import { ConfigService } from '../config';
import { MemberLoginFormModel } from '../model';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})

export class LoginComponent implements OnInit
{
    loginForm:FormGroup;
    savedID:string;
    isSaveIDChecked:boolean;

    constructor(private router:Router,
                private fb:FormBuilder, 
                private spinnerService:NgxSpinnerService, 
                private cookieManagerService:CookieManageService,
                private memberService:MemberService){

        this.savedID = this.cookieManagerService.getCookie(ConfigService.ID_SAVE_COOKIE_NAME);
        this.isSaveIDChecked = (this.savedID)? true : false;
    }

    ngOnInit():void
    {
        this.loginForm = this.fb.group({
            iPlatFormSeq: [],
            emailID:[this.savedID, Validators.required],
            passWord:['', Validators.required]
        });

        this.router.events.pipe(
            filter(event => event instanceof NavigationEnd)
        ).subscribe((event: NavigationEnd) => {
            this.spinnerService.hide();
        });
    }

    login():void
    {
        this.spinnerService.show();
        if(!this.loginForm.valid){
            //TODO [disabled]="loginForm.invalid" 로 해놨으므로 이 if 문은 불필요
        }

        if(this.isSaveIDChecked){
            this.cookieManagerService.setCookie(ConfigService.ID_SAVE_COOKIE_NAME, this.loginForm.get('id').value, 20);
        }else{
            this.cookieManagerService.delCookie(ConfigService.ID_SAVE_COOKIE_NAME);
        }

        this.loginForm.patchValue({iPlatFormSeq: 1}); //1:직접 가입

        // 로그인정보
        let memberLoginFormModel = new MemberLoginFormModel();
        memberLoginFormModel.iPlatFormSeq = this.loginForm.get('iPlatFormSeq').value;
        memberLoginFormModel.vcEmail = this.loginForm.get('emailID').value;
        memberLoginFormModel.vcPassword = this.loginForm.get('passWord').value;
        // console.log(memberLoginFormModel);
        this.memberService.login(memberLoginFormModel);
    }

    onSaveID(e:any):void
    {
        this.isSaveIDChecked = e.target.checked;
    }
}