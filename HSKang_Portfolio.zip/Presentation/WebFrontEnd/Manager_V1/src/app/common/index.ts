export * from './resultserverdata';
export * from './resultserverdatalist';