import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard-navigation',
  templateUrl: './dashboard.navigation.component.html',
  styleUrls: ['./dashboard.navigation.component.scss']
})
export class DashboardNavigationComponent {

    constructor(private router:Router){}

    getImgFile(url:string, name:string):string{
        return (this.router.url == url) ?  name + '_on.png' : name + '_off.png';
    }

    getClass(url:string | string[]):string{
        if(typeof url === 'string'){
            return (this.router.url == url) ? 'selected' : '';
        }else{
            return (url.indexOf(this.router.url) > -1) ? 'selected' : '';
        }
    }
}