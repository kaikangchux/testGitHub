import { Component, OnInit, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { FormGroup, FormBuilder, Validators, ValidationErrors } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';

import { CommonService, ManagerService } from '../../service';
import { ManagerModel } from '../../model';

@Component({ 
    selector: 'app-popup',
    templateUrl: './regEdit.component.html', 
    styleUrls: ['../scss/regEdit.component.scss']
})

export class ManagerRegEditComponent implements OnInit
{
    mUser:ManagerModel;
    mUserIdx:number;
    regEditForm:FormGroup;
    ipAddress:any;
    isIDReadonly:boolean;
    regEditBtnLbl:string = '';

    constructor(private mService:ManagerService,
                private cmnService:CommonService,
                private translate:TranslateService,
                public dialogRef: MatDialogRef<ManagerRegEditComponent>, 
                @Inject(MAT_DIALOG_DATA) public data:any,
                private fb:FormBuilder){
        
        this.mUser = (data.mUser === null) ? new ManagerModel() : data.mUser;
        this.mUserIdx = (data.mUser === null) ? -1 : data.idx;
        this.isIDReadonly = (data.mUser === null) ? false : true;
        this.regEditBtnLbl = this.translate.instant((data.mUser === null) ? 'REGISTER.BTN.LBL' : 'MODIFY.BTN.LBL');
        this.cmnService.getIP().then(data => this.ipAddress = data.ip);
    }

    ngOnInit():void
    {
        this.regEditForm = this.fb.group({
            vcManagerID:[this.mUser.vcManagerID, Validators.required],
            vcPassword:[this.mUser.vcPassword, Validators.required],
            vcName:[this.mUser.vcName, Validators.required],
            vcEmailID:[this.mUser.vcEmailID, Validators.required],
            vcEmailAddress:[this.mUser.vcEmailAddress, Validators.required],
            vcPhone:[this.mUser.vcPhone, Validators.required],
            tiGrade:[this.mUser.tiGrade, Validators.required],
            vcIP:[this.mUser.vcIP]
        });
    }

    changeEmailAddr(emailAddr:string):void
    {
        if(!emailAddr)
            return;
        this.regEditForm.patchValue ({vcEmailAddress: emailAddr});
    }

    regEdit():void{
        //Debugging 폼 데이터에 에러가 있을 경우 console.log 확인함
        // Object.keys(this.regEditForm.controls).forEach(key => 
        //     {
        //         const controlErrors: ValidationErrors = this.regEditForm.get(key).errors;
        //         if (controlErrors != null) {
        //             Object.keys(controlErrors).forEach(keyError => {console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);});
        //         }
        //     }
        // );
        
        this.regEditForm.patchValue ({vcIP: this.ipAddress});

        this.mService.regEditManager(this.regEditForm.value, (this.mUserIdx < 0), this.mUserIdx).subscribe(
            (res) => this.onClose(true),
            (err) => { this.onClose(false); console.log(err);}
        );
    }

    onClose(param:any):void{
        this.dialogRef.close(param);
    }
}