﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.CrawlingDB
{

    #region // !++ tbInquiryAnswer
    /// <summary>
    /// tbInquiryAnswer
    /// </summary>
    [Table("tbInquiryAnswer")]
    public class tbInquiryAnswer
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        /// <summary>
        /// 제품문의 고유번호
        /// </summary>
        public Int64 biInquirySeq { get; set; }

        [Required]
        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        [Index(1), Required]
        /// <summary>
        /// 상태(1:확인, 2:진행, 3:완료)
        /// </summary>
        public Int16 tiStatus { get; set; }

        [Required, MinLength(10)]
        /// <summary>
        /// 답변내용
        /// </summary>
        public String tDescription { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
