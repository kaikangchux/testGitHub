// 관리자
export class ManagerModel
{
    iSeq: number;
    vcManagerID : string;
    vcPassword: string;
    vcName: string;
    vcEmailID: string;
    vcEmailAddress: string;
    vcPhone: string;
    tiGrade: number;
    vcIP: string;
    dtRegDate: string;
    //vcEmailS: string[];
    //vcPhoneS: string[];

    constructor() {
        this.iSeq = 0;
        this.vcManagerID = '';
        this.vcPassword = '';
        this.vcName = '';
        this.vcEmailID = '';
        this.vcEmailAddress = '';
        this.vcPhone = '';
        this.tiGrade = 0;
        this.vcIP = '';
        this.dtRegDate = '';
        //this.vcEmailS = null;
        //this.vcPhoneS = null;
    }
}

// 관리자 로그인 정보
export class ManagerLoginInfo
{
    adminSeq:number;
    adminId:string;
    adminName:string;
    adminGrade: string;
    isLogin: boolean;
    
    constructor() {
        this.adminSeq = 0;
        this.adminId = '';
        this.adminName = '';
        this.adminGrade = '';
        this.isLogin = false;
    }
}

// 관리자 로그인 토큰 정보
export class ManagerLoginTokenModel
{
    Token : string;
    ExpiredDate: string

    constructor()
    {

        this.Token = null;
        this.ExpiredDate = null;
    }
}