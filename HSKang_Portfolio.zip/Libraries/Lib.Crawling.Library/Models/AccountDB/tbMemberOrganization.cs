﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lib.Crawling.Library.Models.AccountDB
{

    #region // !++ tbMemberOrganization
    /// <summary>
    /// tbMemberOrganization(회원[단체]정보)
    /// </summary>
    [Table("tbMemberOrganization")]
    public class tbMemberOrganization
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        /// <summary>
        /// 회원고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        [Required, MinLength(2), MaxLength(32)]
        /// <summary>
        /// 담당자명
        /// </summary>
        public String vcPersonName { get; set; }

        [Required, MinLength(2), MaxLength(64)]
        /// <summary>
        /// 업종
        /// </summary>
        public String vcBusiness { get; set; }

        /// <summary>
        /// 사업자번호
        /// </summary>
        public String vcOrganizationSerial { get; set; }

    }
    #endregion

}
