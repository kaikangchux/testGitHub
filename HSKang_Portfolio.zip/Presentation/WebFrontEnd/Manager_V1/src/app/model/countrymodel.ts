// 국가정보
export class CountryModel
{

  siSeq: number;
  vcName: string;
  vcCountryCode: string;
  vcKeyText: string;
  tiStatus: number;
  iManagerSeq: number;
  dtRegDate: string;

  constructor() {
    this.siSeq = 0;
    this.vcName = '';
    this.vcCountryCode = '';
    this.vcKeyText = '';
    this.tiStatus = 0;
    this.iManagerSeq = 0;
    this.dtRegDate = '';
  }
}
