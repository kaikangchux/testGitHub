import { Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { ConfigService } from '../config/config.service';
import * as CryptoJS from 'crypto-js'; 

import { MemberLoginModel } from '../model';

@Injectable({
    providedIn: 'root'
})

export class CookieManageService
{
    interval:any;

    constructor(private cookieService:CookieService){}

    checkCookie(cookieName):boolean{
        return this.cookieService.check(cookieName);
    }

    getCookie(cookieName:string):any
    {
        return this.cookieService.get(cookieName);
    }

    // getUserInfoCookie(cookieName:string):MemberLoginModel
    // {
    //     let cookieData = this.cookieService.get(cookieName);
    //     let data:string;
    //     if(typeof data != 'undefined' && data !== null){
    //         data = CryptoJS.AES.decrypt(cookieData.trim(), ConfigService.CRYPT_KEY.trim()).toString(CryptoJS.enc.Utf8);
    //         return JSON.parse(data);
    //     }
    //     //return null;
    //     //TODO
    //     return {biSeq:1, iPlatFormSeq:1, vcEmailID:'test', vcEmailAddress:'hanmail.net', vcPassword:'', vcPhone:'01078945612', vcName:'이준수', cBirthYear:'1990', cBirthMonth:'01', cBirthDay:'24', tiGender:1, tiOrganization:1, dtRegDate:'2019-07-29 17:58:43'};
    // }

    setCookie(cookieName:string, val:string, expireDay:number=1):void{
        this.cookieService.set(cookieName, val, expireDay);
    }

    delCookie(cookieName:string):void{
        this.cookieService.delete(cookieName);
    }
}