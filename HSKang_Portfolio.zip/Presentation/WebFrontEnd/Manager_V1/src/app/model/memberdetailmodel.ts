// 회원상세정보
export class MemberDetailModel
{

  biMemberSeq: number;
  siCountrySeq: number;
  vcCity: string;
  vcZipCode: string;
  vcAddressFront: string;
  vcAddressBack: string;
  tiMemberGrade: number;
  tiMemberStatus: number;
  tiEmailAgree: number;
  tiSmsAgress: number;

  constructor() {
    this.biMemberSeq = 0;
    this.siCountrySeq = 0;
    this.vcCity = '';
    this.vcZipCode = '';
    this.vcAddressFront = '';
    this.vcAddressBack = '';
    this.tiMemberGrade = 0;
    this.tiMemberStatus = 0;
    this.tiEmailAgree = 0;
    this.tiSmsAgress = 0;
  }
}
