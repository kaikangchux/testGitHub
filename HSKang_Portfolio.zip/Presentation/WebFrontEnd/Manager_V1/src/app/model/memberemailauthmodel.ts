// 회원 E-mail 인증
export class MemberEmailAuthModel
{

    biMemberSeq:number;
    vcEmail:string;
    vcAuth:string;
    dtRegDate:string;
    dtAuthDate:string;

    constructor(){
        this.biMemberSeq = 0;
        this.vcEmail = '';
        this.vcAuth = '';
        this.dtRegDate = '';
        this.dtAuthDate = '';
    }

}