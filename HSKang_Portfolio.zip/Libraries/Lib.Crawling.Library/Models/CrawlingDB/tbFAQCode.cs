﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.CrawlingDB
{

    #region // !++ tbFAQCode
    /// <summary>
    /// tbFAQCode
    /// </summary>
    [Table("tbFAQCode")]
    public class tbFAQCode
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        /// <summary>
        /// 고유번호(AI)
        /// </summary>
        public Int32 iSeq { get; set; }

        [Required, MinLength(2), MaxLength(64)]
        /// <summary>
        /// 제목
        /// </summary>
        public String vcTitle { get; set; }

        /// <summary>
        /// 관리자고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
