﻿using System;

using DAL.Crawling.Manager;
using DAL.Crawling.Account;
using DAL.Crawling.Crawling;
using DAL.Crawling.LogData;
using DAL.Crawling.Mongo;

using Lib.Crawling.Library.Utilities;

namespace BLL.DB.DataProvider
{

    #region // !++ DataProvider
    /// <summary>
    /// DataProvider
    /// </summary>
    public class DataProvider
    {


        #region // !++ Utility

        /// <summary>
        /// LibUtility
        /// </summary>
        protected static LibUtility libUtility = new LibUtility();

        /// <summary>
        /// BulkUtility
        /// </summary>
        protected static BulkUtility bulkUtility = new BulkUtility();

        /// <summary>
        /// KeyGenerator
        /// </summary>
        protected static KeyGenerator keyGenerator = new KeyGenerator();

        /// <summary>
        /// Security
        /// </summary>
        protected static Security security = new Security();

        /// <summary>
        /// HashWord
        /// </summary>
        protected static HashWord hashWord = new HashWord();

        #endregion


        #region // !++ DataBase

        /// <summary>
        /// DalManager
        /// </summary>
        protected static DalManager dalManager = new DalManager();

        /// <summary>
        /// DalAccount
        /// </summary>
        protected static DalAccount dalAccount = new DalAccount();

        /// <summary>
        /// DalCrawling
        /// </summary>
        protected static DalCrawling dalCrawling = new DalCrawling();

        /// <summary>
        /// DalLogData
        /// </summary>
        protected static DalLogData dalLogData = new DalLogData();

        /// <summary>
        /// DalMongo
        /// </summary>
        protected static DalMongo dalMongo = new DalMongo();

        #endregion


    }
    #endregion

}
