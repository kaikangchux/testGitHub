﻿using System;
using System.Collections.Generic;
using System.Text;

using Lib.Crawling.Library.Entities.Manager;

namespace Lib.Crawling.Library.Repository.Manager
{

    #region // !++ IIManagerRepository
    /// <summary>
    /// 관리자 인터페이스
    /// </summary>
    public interface IIManagerRepository
    {

        /// <summary>
        /// 화면 출력(관리자 리스트)
        /// </summary>
        /// <returns></returns>
        List<ManagerEntity> GetAll();


        /// <summary>
        /// 입력(관리자 등록)
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        ManagerEntity Add(ManagerEntity model);

        /// <summary>
        /// 수정 (관리자 본인 정보 수정)
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        ManagerEntity Modify(ManagerEntity model);

        /// <summary>
        /// 삭제(관리자 삭제)
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        ManagerEntity Delete(ManagerEntity model);

        /// <summary>
        /// 등급 변경(관리자 등급 변경)
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        ManagerEntity GradeChange(ManagerEntity model);

        /// <summary>
        /// 로그인(관리자 로그인)
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        ManagerLoginEntity ManagerLogin(ManagerLoginEntity model);

    }
    #endregion

}
