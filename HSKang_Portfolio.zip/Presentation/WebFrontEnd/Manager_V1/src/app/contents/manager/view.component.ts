import { Component, OnInit, Injectable } from '@angular/core';
import { Title } from "@angular/platform-browser";
import { TranslateService } from '@ngx-translate/core';
import { NgxSpinnerService } from "ngx-spinner";
import { ActivatedRoute, Router } from '@angular/router';

import { ConfigService } from '../../config';
import { ManagerService } from '../../service';

@Component({
    selector: 'app-view',
    templateUrl: './view.component.html',
    styleUrls: ['../scss/view.component.scss']
})

export class ManagerViewComponent implements OnInit
{
    mInfo:any;
    iSeq:number;

    constructor(private titleService:Title,
                private translate:TranslateService,
                private mService:ManagerService,
                private spinnerService:NgxSpinnerService,
                private config:ConfigService,
                private router:Router,
                private route:ActivatedRoute){

        this.titleService.setTitle(this.translate.instant('TITLE.VIEW'));
        this.config.setSettings({layout: {navbar: 'show'}});
        this.route.params.subscribe((params) => this.iSeq = params['id']);
        this.mInfo = this.mService.getMUserInfo(this.iSeq);

        console.log(this.mInfo);//TODO delete
    }

    ngOnInit():void{
        
    }
}