// FAQ코드관리
export class FaqCodeModel
{

  iSeq: number;
  vcTitle: string;
  iManagerSeq: number;
  dtRegDate: string;

  constructor() {
    this.iSeq = 0;
    this.vcTitle = '';
    this.iManagerSeq = 0;
    this.dtRegDate = '';
  }
}
