import { Component, OnInit, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { FormGroup, FormBuilder, Validators, ValidationErrors } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { NgxSpinnerService } from "ngx-spinner";

import { CommonService, FaqService } from '../../service';
import { FaqCodeModel, FaqModel } from '../../model';

@Component({ 
    selector: 'app-popup',
    templateUrl: './faqdetail.component.html', 
    styleUrls: ['../scss/regEdit.component.scss']
})

export class FaqDetailComponent implements OnInit
{
    mFaq:FaqModel = null;
    mSeq:number;
    mFaqCode:FaqCodeModel = null;

    constructor(private mService:FaqService,
                private cmnService:CommonService,
                private translate:TranslateService,
                private spinnerService:NgxSpinnerService,
                public dialogRef: MatDialogRef<FaqDetailComponent>, 
                @Inject(MAT_DIALOG_DATA) public data:any,
                private fb:FormBuilder){

        this.mSeq = (data.iSeq === null) ? -1 : data.iSeq;
    }

    ngOnInit():void
    {
        // FAQ 상세정보 호출
        this.onDetail(this.mSeq);
    }

    // FAQ 상세정보
    onDetail(mSeq:number):void
    {
        setTimeout(() => this.spinnerService.show(), 0);

        this.mService.getFaqDetail(mSeq).subscribe(
            detailData => {
                this.spinnerService.hide();
                this.mFaq = detailData.data;
                
                // FAQ code 상세정보 호출(FAQ 정보 셋팅 먼저)
                this.getFaqCodeDetail(this.mFaq.iFaqCodeSeq);
            },
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

    // popup close
    onClose(param:any):void{
        this.dialogRef.close(param);
    }

    // Faq code 상세정보
    getFaqCodeDetail(iSeq:number):void
    {
        setTimeout(() => this.spinnerService.show(), 0);

        this.mService.getFaqCodeDetail(iSeq).subscribe(
            detailData => {
                this.spinnerService.hide();
                this.mFaqCode = detailData.data;
            },
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

}