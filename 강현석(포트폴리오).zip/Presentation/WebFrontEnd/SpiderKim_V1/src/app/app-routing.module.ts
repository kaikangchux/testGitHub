import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent, CompanyComponent } from './webcontents';

import { 
    DashboardComponent, 
    DashboardMainComponent, 
    DataExtractURLComponent, 
    DataExtractComponent
} from './dashboard';

import {
    LoginComponent, 
    RegisterSelectComponent, 
    RegisterCommonComponent, 
    RegisterMemberComponent, 
    RegisterOrganizationComponent, 
    RegisterCompleteComponent,
    RegisterConfirmComponent
} from './loginRegister';

import { AuthGuard, ConfirmGuard, CompletedGuard, DataExtractGuard } from './helper';

const routes: Routes = [
    { path: 'login', component: LoginComponent },
    { path: 'register', component: RegisterCommonComponent, children:[
        { path: 'member', component: RegisterMemberComponent },
        { path: 'organization', component: RegisterOrganizationComponent },
        { path: 'confirm', component: RegisterConfirmComponent, canActivate: [ConfirmGuard] },
        { path: 'completed', component: RegisterCompleteComponent, canActivate: [CompletedGuard]},
    ]},
    { path: 'join', component: RegisterSelectComponent, pathMatch: 'full' },
    //{ path: 'dashboard', component: DashComponent, canActivate: [AuthGuard] }, //TODO
    { path: 'dashboard', component: DashboardComponent, children:[
        { path: 'extract', component: DataExtractURLComponent },
        //{ path: 'extractdata', component: DataExtractComponent , canActivate: [DataExtractGuard] },
        { path: 'extractdata', component: DataExtractComponent },
        { path: 'payment', component: DashboardMainComponent },
        { path: 'help', component: DashboardMainComponent },
        { path: 'account', component: DashboardMainComponent },
        { path: '', component: DashboardMainComponent },
    ]},
    { path: 'company', component: CompanyComponent },
    { path: '', component: HomeComponent },
    { path: '**', redirectTo: '' }
];

@NgModule({
    imports: [RouterModule.forRoot(routes, {onSameUrlNavigation: 'reload'})],
    exports: [RouterModule]
})
export class AppRoutingModule { }