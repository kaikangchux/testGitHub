﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using BLL.DB.Account;
using BLL.DB.Crawling;
using BLL.DB.LogData;
using BLL.DB.Mongo;
using BLL.DB.Manager;

using Lib.Crawling.Library.Utilities;

namespace WebApi_SpiderKim_V1.Handlers
{

    #region // !++ Handler
    /// <summary>
    /// Handler
    /// </summary>
    public class Handler
    {

        #region // !++ Utility
        /// <summary>
        /// LibUtility
        /// </summary>
        protected static LibUtility libUtility = new LibUtility();

        /// <summary>
        /// BulkUtility
        /// </summary>
        protected static BulkUtility bulkUtility = new BulkUtility();

        /// <summary>
        /// KeyGenerator
        /// </summary>
        protected static KeyGenerator keyGenerator = new KeyGenerator();

        /// <summary>
        /// Security
        /// </summary>
        protected static Security security = new Security();

        /// <summary>
        /// HashWord
        /// </summary>
        protected static HashWord hashWord = new HashWord();
        #endregion


        #region // !++ BLL.DB
        /// <summary>
        /// BllAccount
        /// </summary>
        protected static BllAccount bllAccount = new BllAccount();

        /// <summary>
        /// BllCrawling
        /// </summary>
        protected static BllCrawling bllCrawling = new BllCrawling();

        /// <summary>
        /// BllLogData
        /// </summary>
        protected static BllLogData bllLogData = new BllLogData();

        /// <summary>
        /// BllMongo
        /// </summary>
        protected static BllMongo bllMongo = new BllMongo();

        /// <summary>
        /// DataBaseStaticInfo
        /// </summary>
        protected static DataBaseStaticInfo dbStaticInfo = new DataBaseStaticInfo();
        #endregion

    }
    #endregion

}
