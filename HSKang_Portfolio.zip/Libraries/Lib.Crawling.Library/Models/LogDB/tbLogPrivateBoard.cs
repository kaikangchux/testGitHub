﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.LogDB
{

    #region // !++ tbLogPrivateBoard
    /// <summary>
    /// LOG 공지, 뉴스 등 게시판
    /// </summary>
    [Table("tbLogPrivateBoard")]
    public class tbLogPrivateBoard
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        /// <summary>
        /// 파티션 키(월별)
        /// </summary>
        public Int32 iPartKeyMonth { get; set; }

        [Index(1), Required]
        /// <summary>
        /// 트랜잭션ID
        /// </summary>
        public Int64 biTXIDX { get; set; }

        [Index(2), Required]
        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        [Required]
        /// <summary>
        /// 고유번호
        /// </summary>
        public Int64 biSeq { get; set; }

        [Required]
        /// <summary>
        /// 게시판타입(1:공지사항, 2:뉴스, 3:..)
        /// </summary>
        public Int16 tiBoardType { get; set; }

        [Required, MinLength(2), MaxLength(64)]
        /// <summary>
        /// 제목(언어ID)
        /// </summary>
        public String vcTitleKeyText { get; set; }

        [Required, MinLength(2), MaxLength(64)]
        /// <summary>
        /// 내용(언어ID)
        /// </summary>
        public String vcDescriptKeyText { get; set; }

        [Required]
        /// <summary>
        /// Main등록여부(1:노출안함, 2:노출)
        /// </summary>
        public Int16 tiMain { get; set; }

        [Required]
        /// <summary>
        /// 로그분류(1:등록, 2:수정, 3:삭제)
        /// </summary>
        public Int16 tiType { get; set; }

        /// <summary>
        /// IP
        /// </summary>
        public String vcIP { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// UTC등록일시
        /// </summary>
        public DateTime dtUtcRegDate { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
