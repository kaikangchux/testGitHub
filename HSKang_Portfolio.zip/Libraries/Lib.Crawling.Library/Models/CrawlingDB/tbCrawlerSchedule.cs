﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.CrawlingDB
{

    #region // !++ tbCrawlerSchedule
    /// <summary>
    /// 크롤링 스케줄
    /// </summary>
    [Table("tbCrawlerSchedule")]
    public class tbCrawlerSchedule
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        /// <summary>
        /// 고유번호
        /// </summary>
        public Int64 biSeq { get; set; }

        [Index(1), Required]
        /// <summary>
        /// 회원 고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        [Required, MinLength(4), MaxLength(256)]
        /// <summary>
        /// 대상사이트URL
        /// </summary>
        public String vcTargetUrl { get; set; }

        /// <summary>
        /// 일일횟수
        /// </summary>
        public Int32 iRepeat { get; set; }

        /// <summary>
        /// 상태(0:대기(생성시-초기화 시간 필요), 1:수집진행, 2:완료)
        /// </summary>
        public Int16 tiStatus { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
