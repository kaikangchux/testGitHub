import { Component, OnInit, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { FormGroup, FormBuilder, Validators, ValidationErrors } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { NgxSpinnerService } from "ngx-spinner";

import { CommonService, FaqService } from '../../service';
import { FaqCodeModel } from '../../model';

@Component({ 
    selector: 'app-popup',
    templateUrl: './faqregist.component.html', 
    styleUrls: ['../scss/regEdit.component.scss']
})

export class FaqRegistComponent implements OnInit
{
    registForm:FormGroup;
    mFaqCode:FaqCodeModel[] = [];
    mTotalFaqCode:number = 0;

    currPageFaqCode:number = 1;
    lenFaqCode:number = 100;

    constructor(private mService:FaqService,
                private cmnService:CommonService,
                private translate:TranslateService,
                private spinnerService:NgxSpinnerService,
                public dialogRef: MatDialogRef<FaqRegistComponent>, 
                @Inject(MAT_DIALOG_DATA) public data:any,
                private fb:FormBuilder){
    }

    ngOnInit():void
    {
        this.registForm = this.fb.group({
            iFaqCodeSeq:['', Validators.required],
            vcTitleKeyText:['', Validators.required],
            vcDescriptKeyText:['', Validators.required],
            tiMain:[2, Validators.required]
        });

        // FAQ code 목록
        this.getFaqCodeList(this.currPageFaqCode, this.lenFaqCode);
    }

    // Action
    onRegist():void
    {
        this.mService.regEditFaq(this.registForm.value, true, 0).subscribe(
            (res) => this.onClose(true),
            (err) => { this.onClose(false); console.log(err);}
        );
    }

    // Reset
    onReset():void
    {
        this.registForm.patchValue ({iFaqCodeSeq: ''});
        this.registForm.patchValue ({vcTitleKeyText: ''});
        this.registForm.patchValue ({vcDescriptKeyText: ''});
        this.registForm.patchValue ({tiMain: 2});
    }

    // popup close
    onClose(param:any):void{
        this.dialogRef.close(param);
    }

    // Faq code list
    getFaqCodeList(curPage:number, len:number):void
    {
        setTimeout(() => this.spinnerService.show(), 0);

        this.mService.getFaqCodeList(curPage, len).subscribe(
            list => {
                this.mFaqCode = list.data.gClass;
                this.mTotalFaqCode = list.data.totalRecord;
            },
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

}