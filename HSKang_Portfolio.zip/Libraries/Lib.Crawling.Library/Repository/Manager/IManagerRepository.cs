﻿using System;
using System.Collections.Generic;
using System.Text;

using Lib.Crawling.Library.Entities.Manager;

namespace Lib.Crawling.Library.Repository.Manager
{

    #region // !++ IManagerRepository
    /// <summary>
    /// 인터페이스 상속
    /// </summary>
    public class IManagerRepository : IIManagerRepository
    {
        public List<ManagerEntity> GetAll()
        {
            throw new NotImplementedException();
        }

        public ManagerEntity Add(ManagerEntity model)
        {
            throw new NotImplementedException();
        }

        public ManagerEntity Modify(ManagerEntity model)
        {
            throw new NotImplementedException();
        }

        public ManagerEntity Delete(ManagerEntity model)
        {
            throw new NotImplementedException();
        }

        public ManagerEntity GradeChange(ManagerEntity model)
        {
            throw new NotImplementedException();
        }

        public ManagerLoginEntity ManagerLogin(ManagerLoginEntity model)
        {
            throw new NotImplementedException();
        }

    }
    #endregion

}
