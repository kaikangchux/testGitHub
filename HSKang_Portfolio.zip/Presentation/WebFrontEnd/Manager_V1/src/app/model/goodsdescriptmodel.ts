// 상품설명
export class GoodsDescriptModel
{

  iSeq: number;
  iGoodsSeq: number;
  iMinutePage: number;
  iOneTimePage: number;
  iSecret: number;
  iProject: number;
  iDataStorage: number;
  tiChangeIP: number;
  tiGatheringCycle: number;
  iManagerSeq: number;
  dtRegDate: string;

  constructor() {
    this.iSeq = 0;
    this.iGoodsSeq = 0;
    this.iMinutePage = 0;
    this.iOneTimePage = 0;
    this.iSecret = 0;
    this.iProject = 0;
    this.iDataStorage = 0;
    this.tiChangeIP = 0;
    this.tiGatheringCycle = 0;
    this.iManagerSeq = 0;
    this.dtRegDate = '';
  }

}
