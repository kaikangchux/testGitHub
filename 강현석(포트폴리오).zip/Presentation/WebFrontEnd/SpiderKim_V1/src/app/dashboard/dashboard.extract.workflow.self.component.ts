import { Component, ViewChild, ElementRef, OnInit, OnDestroy, AfterViewInit, ViewContainerRef, ComponentFactory, ComponentRef, ComponentFactoryResolver } from '@angular/core';
import { DataExtractService } from '../service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { NodeComponent } from './node.component';

enum NodeType {
    CLICK = "click",
    EXTRACT = "extract",
    LOOP = "loop",
    PAGINATION = "pagination",
}

@Component({
    selector: 'app-dashboard-workflow-self',
    templateUrl: './dashboard.extract.workflow.self.component.html',
    styleUrls: ['./dashboard.extract.workflow.self.component.scss']
})
export class WorkFlowSelfComponent implements OnInit, AfterViewInit, OnDestroy 
{
    //@ViewChild('workflow',  {static: false}) workflow: ElementRef;
    @ViewChild("worknodes", { read: ViewContainerRef, static: false }) container;

    constructor(private dataExtractService:DataExtractService, 
                private router: Router,
                private http:HttpClient,
                private resolver: ComponentFactoryResolver){
    }

    ngOnInit():void {
        
    }

    click(evnt:any):void {
        this.activeWorkWindow();
        this.createNodes(NodeType.CLICK);
    }

    createNodes(type:string): void {
        const factory: ComponentFactory<NodeComponent> = this.resolver.resolveComponentFactory(NodeComponent);
        const holaComponent: ComponentRef<NodeComponent> = this.container.createComponent(factory);
        holaComponent.instance.type = type;
    }

    activeWorkWindow():void
    {
        if(this.dataExtractService.activeWorkWindow){
            return;
        }
        this.dataExtractService.onEventEmitActivateWorkWindow(false);
    }

    ngAfterViewInit():void {
    }

    ngOnDestroy() {
    }
}