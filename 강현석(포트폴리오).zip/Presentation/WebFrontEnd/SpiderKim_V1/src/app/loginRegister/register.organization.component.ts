import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { MemberService } from '../service';
import { Router } from '@angular/router';

import { MemberModel, MemberOrganizationModel, MemberContainer } from '../model';

@Component({
    selector: 'app-register-organization',
    templateUrl: './register.organization.component.html',
    styleUrls: ['./register.member.component.scss']
})

export class RegisterOrganizationComponent implements OnInit
{
    organizationRegisterForm:FormGroup;

    constructor(private fb:FormBuilder, 
        private spinnerService:NgxSpinnerService,
        private memberService:MemberService,
        private router:Router){}

    ngOnInit():void
    {
        this.organizationRegisterForm = this.fb.group({
            vcEmailID : ['', Validators.required],
            vcEmailAddress : ['', Validators.required],
            vcPassword : ['', Validators.required],
            vcPassword_confirm : ['', Validators.required],
            vcName : ['', Validators.required],
            vcBusiness : ['', Validators.required],
            vcPersonName : ['', Validators.required],
            //vcPhone : ['', Validators.required],
            terms_agree_all : [false],
            terms_agree_age : [false, Validators.requiredTrue],
            terms_agree_usage : [false, Validators.requiredTrue],
            terms_agree_privacy : [false, Validators.requiredTrue],
            vcEmail: [],
            iPlatFormSeq: [],
            tiOrganization: []
        },
            {validator: this.passwordMatch('vcPassword', 'vcPassword_confirm')}
        );
    }

    passwordMatch(controlName: string, matchingControlName: string):any
    {
        return (formGroup: FormGroup) => {
            const control = formGroup.controls[controlName];
            const matchingControl = formGroup.controls[matchingControlName];

            if(!matchingControl){
                return;
            }
    
            if(matchingControl.errors && !matchingControl.errors.passwordNotMatch){
                return;
            }
    
            if(control.value !== matchingControl.value){
                matchingControl.setErrors({passwordNotMatch: true});
            }else{
                matchingControl.setErrors(null);
            }
        }
    }

    //TODO 이용약관, 개인정보수집/이용 약관
    onClickTermsView(param:string):void {
        alert("TODO");
    }

    changeEmailAddr(emailAddr:string):void
    {
        if(!emailAddr)
            return;

        this.organizationRegisterForm.patchValue({vcEmailAddress: emailAddr});
    }

    changeTermsCheckAll():void
    {
        this.organizationRegisterForm.patchValue({terms_agree_age: !this.organizationRegisterForm.get('terms_agree_age').value});
        this.organizationRegisterForm.patchValue({terms_agree_usage: !this.organizationRegisterForm.get('terms_agree_usage').value});
        this.organizationRegisterForm.patchValue({terms_agree_privacy: !this.organizationRegisterForm.get('terms_agree_privacy').value});
    }

    checkTerms():void
    {
        const ageTermCheck = this.organizationRegisterForm.get('terms_agree_age').value;
        const usageTermCheck = this.organizationRegisterForm.get('terms_agree_usage').value;
        const privacyTermCheck = this.organizationRegisterForm.get('terms_agree_privacy').value;

        if(ageTermCheck === true && usageTermCheck === true && privacyTermCheck === true){
            this.organizationRegisterForm.patchValue({terms_agree_all: true});
        }else{
            this.organizationRegisterForm.patchValue({terms_agree_all: false});
        }
    }

    onSubmit():void
    {
        this.spinnerService.show();

        //Debugging 폼 데이터에 에러가 있을 경우 console.log 확인함
        // Object.keys(this.memberRegisterForm.controls).forEach(key => 
        //     {
        //         const controlErrors: ValidationErrors = this.memberRegisterForm.get(key).errors;
        //         if (controlErrors != null) {
        //             Object.keys(controlErrors).forEach(keyError => {console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);});
        //         }
        //     }
        // );

        event.preventDefault(); //서브밋 버튼 동작에 따른 리로드 방지

        this.organizationRegisterForm.patchValue({tiOrganization: 2}); //1:개인, 2:단체(기업)
        this.organizationRegisterForm.patchValue({iPlatFormSeq: 1}); //1:직접 가입
        this.organizationRegisterForm.patchValue({vcEmail: this.organizationRegisterForm.get('vcEmailID').value + '@' + this.organizationRegisterForm.get('vcEmailAddress').value})

        //불필요한 폼 컨트롤 제거
        this.organizationRegisterForm.removeControl('vcEmailID');
        this.organizationRegisterForm.removeControl('vcEmailAddress');
        this.organizationRegisterForm.removeControl('vcPassword_confirm');
        this.organizationRegisterForm.removeControl('terms_agree_all');
        this.organizationRegisterForm.removeControl('terms_agree_age');
        this.organizationRegisterForm.removeControl('terms_agree_usage');
        this.organizationRegisterForm.removeControl('terms_agree_privacy');

        // 회원DataContainer
        let memberContainer = new MemberContainer();
        let memberModel = new MemberModel();
        // 회원기본정보
        memberModel.iPlatFormSeq = this.organizationRegisterForm.get('iPlatFormSeq').value;
        memberModel.vcEmail = this.organizationRegisterForm.get('vcEmail').value;
        memberModel.vcPassword = this.organizationRegisterForm.get('vcPassword').value;
        memberModel.vcName = this.organizationRegisterForm.get('vcName').value;
        memberModel.cBirthYear = '';
        memberModel.cBirthMonth = '';
        memberModel.cBirthDay = '';
        memberModel.tiGender = 3;
        memberModel.tiOrganization = this.organizationRegisterForm.get('tiOrganization').value;
        memberContainer.tbMember = memberModel;
        // 회원기업정보
        let memberOrganizationModel = new MemberOrganizationModel();
        memberOrganizationModel.vcPersonName = this.organizationRegisterForm.get('vcPersonName').value;
        memberOrganizationModel.vcBusiness = this.organizationRegisterForm.get('vcBusiness').value;
        memberOrganizationModel.vcOrganizationSerial = '';
        memberContainer.tbMemberOrganization = memberOrganizationModel;

        // console.log(memberContainer);

        this.memberService.registerOrganization(memberContainer).subscribe(
            (res) => {
                if(!res.success){
                    alert(res.msg);
                    this.memberService.logout();
                    return;
                }

                this.router.navigate(['./register/confirm'], {state: {data: {email:res.data.email, name:res.data.name}}});
            },
            (err) => {this.spinnerService.hide(); console.log(err);},
            () => this.spinnerService.hide()
        );
    }
}