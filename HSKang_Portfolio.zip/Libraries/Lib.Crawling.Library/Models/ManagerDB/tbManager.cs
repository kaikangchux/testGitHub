﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.ManagerDB
{

    #region // !++ tbManager
    /// <summary>
    /// tbManager
    /// </summary>
    [Table("tbManager")]
    public class tbManager
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iSeq { get; set; }

        [Index(1), Required, MinLength(4), MaxLength(32)]
        /// <summary>
        /// 계정
        /// </summary>
        public String vcManagerID { get; set; }

        [Required, MinLength(2), MaxLength(32)]
        /// <summary>
        /// 이름
        /// </summary>
        public String vcName { get; set; }

        [Required, MaxLength(64)]
        /// <summary>
        /// 비밀번호
        /// </summary>
        public String vcPassword { get; set; }

        [Required, MinLength(2), MaxLength(64)]
        /// <summary>
        /// E-mail ID
        /// </summary>
        public String vcEmailID { get; set; }

        [Required, MinLength(2), MaxLength(128)]
        /// <summary>
        /// E-mail address
        /// </summary>
        public String vcEmailAddress { get; set; }

        [Required, MinLength(9), MaxLength(16)]
        /// <summary>
        /// 연락처
        /// </summary>
        public String vcPhone { get; set; }

        /// <summary>
        /// 등급(팀- 10:프로그램, 20:기획)
        /// </summary>
        public Int16 tiGrade { get; set; }

        /// <summary>
        /// 접속IP
        /// </summary>
        public String vcIP { get; set; }

        [Index(2), Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
