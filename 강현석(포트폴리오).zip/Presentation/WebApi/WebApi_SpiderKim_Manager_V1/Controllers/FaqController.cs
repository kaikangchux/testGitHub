﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;

using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Manager;
using Lib.Crawling.Library.Entities.Crawling;
using Lib.Crawling.Library.Utilities;
using Lib.Crawling.Library.Log;
using Lib.Crawling.Library.DataContainers;

using WebApi_SpiderKim_Manager_V1.Handlers;
using WebApi_SpiderKim_Manager_V1.WebUtilities;

namespace WebApi_SpiderKim_Manager_V1.Controllers
{

    #region // !++ FaqController
    /// <summary>
    /// FaqController
    /// </summary>
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class FaqController : ControllerBase
    {

        #region // !++ Event handler(funtions)
        /// <summary>
        /// StaticDataHandler
        /// </summary>
        public StaticDataHandler staticDataHandler = new StaticDataHandler();

        /// <summary>
        /// LibUtility
        /// </summary>
        public LibUtility libUtility = new LibUtility();

        /// <summary>
        /// LibWebUtility
        /// </summary>
        public LibWebUtility libWebUtility = new LibWebUtility();

        /// <summary>
        /// LibraryController
        /// </summary>
        public LibraryController libraryController = new LibraryController();
        #endregion


        #region // !++ GetFaqCodeList (FAQ Code 리스트)
        /// <summary>
        /// FAQ Code 리스트
        /// </summary>
        /// <returns></returns>
        [HttpGet("FaqCodeList")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> GetFaqCodeList([FromQuery] Int32 page, Int32 pageSize)
        {

            // Return message
            var resultClient = new ResultClientEntity<ListPageDataContainer<List<FAQCodeEntity>>>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion

                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ Parameter value
                if (libUtility.IsSpace(libWebUtility.OnNullCheckInt(page.ToString()).ToString()))
                    page = 1;

                if (libUtility.IsSpace(pageSize.ToString()))
                    pageSize = 20;
                #endregion

                #region // !++ DB 정보가져오기
                var pageModel = new PageDBEntity()
                {
                    page = page,
                    pageSize = pageSize
                };
                var resultData = await CrawlingHandler.GetFaqCodeList(dbConnectionEntity, pageModel);
                #endregion

                #region // !++ Client message
                resultClient.success = true;
                resultClient.msg = String.Empty;
                resultClient.error = String.Empty;
                resultClient.data = resultData;
                #endregion

                return Ok(resultClient);

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API GetFaqCodeList : \n [Page:{0}], \n [PageSize:{1}], \n {2}, \n {3}",
                                        page, pageSize, exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }

        }
        #endregion


        #region // !++ GetFaqCodeInfo (FAQ Code 상세정보)
        /// <summary>
        /// FAQ Code 상세정보
        /// </summary>
        /// <returns></returns>
        [HttpGet("FaqCodeDetail/{id:int}")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> GetFaqCodeInfo(Int32 id)
        {

            // Return message
            var resultClient = new ResultClientEntity<FAQCodeEntity>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ Data struct 변경
                var model = new FAQCodeEntity()
                {
                    iSeq = id
                };
                #endregion

                #region // !++ 정보가져오기
                var resultData = await CrawlingHandler.GetFaqCodeDetail(dbConnectionEntity, model);
                #endregion

                #region // !++ Client message
                if (resultData != null)
                {
                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = resultData;
                    if (resultClient.data.iSeq == 0)
                    {
                        resultClient.data = null;
                    }
                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API GetFaqCodeInfo : \n [ID:{0}], \n {1}, \n {2}",
                                        id.ToString(), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }
        }
        #endregion


        #region // !++ SetFaqCodeRegist (FAQ Code 등록)
        /// <summary>
        /// FAQ Code 등록
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("faqcoderegist")]
        [Produces("application/json", Type = typeof(FAQCodeEntity))]
        [Consumes("application/json")] // application/xml
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> SetFaqCodeRegist([FromBody] FAQCodeEntity model)
        {

            // Return message
            var resultClient = new ResultClientEntity<Int32?>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ 관리자 정보 담기
                model.iManagerSeq = managerLogin.adminSeq;
                #endregion

                #region // !++ DB 등록하기
                var resultData = await CrawlingHandler.SetFaqCodeRegist(dbConnectionEntity, model);
                #endregion

                #region // !++ Client message
                if (resultData == 1)
                {
                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = null;

                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API SetFaqCodeRegist : \n [FAQCodeEntity:{0}], \n {1}, \n {2}",
                                        libUtility.ToJson(model), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }
        }
        #endregion


        #region // !++ SetFaqCodeModify (FAQ Code 수정)
        /// <summary>
        /// FAQ Code 수정
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPut("faqcodemodify")]
        [Produces("application/json", Type = typeof(FAQCodeEntity))]
        [Consumes("application/json")] // application/xml
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> SetFaqCodeModify([FromBody] FAQCodeEntity model)
        {

            // Return message
            var resultClient = new ResultClientEntity<Int32?>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ 관리자 정보 담기
                model.iManagerSeq = managerLogin.adminSeq;
                #endregion

                #region // !++ DB 등록하기
                var resultData = await CrawlingHandler.SetFaqCodeModify(dbConnectionEntity, model);
                #endregion

                #region // !++ Client message
                if (resultData == 1)
                {
                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = null;

                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API SetFaqCodeModify : \n [FAQCodeEntity:{0}], \n {1}, \n {2}",
                                        libUtility.ToJson(model), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }
        }
        #endregion


        #region // !++ SetFaqCodeDelete (FAQ Code 삭제)
        /// <summary>
        /// FAQ Code 삭제
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpDelete("faqcodedelete/{id:int}")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> SetFaqCodeDelete(Int32 id)
        {

            // Return message
            var resultClient = new ResultClientEntity<Int32?>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ 정보 담기
                var model = new FAQCodeEntity()
                {
                    iSeq = id,
                    iManagerSeq = managerLogin.adminSeq
                };
                #endregion

                #region // !++ DB 등록하기
                var resultData = await CrawlingHandler.SetFaqCodeDelete(dbConnectionEntity, model);
                #endregion

                #region // !++ Client message
                if (resultData == 1)
                {
                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = null;

                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API SetFaqCodeDelete : \n [iSeq:{0}], \n {1}, \n {2}",
                                        id, exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }
        }
        #endregion


        #region // !++ GetFaqList List (FAQ 리스트)
        /// <summary>
        /// FAQ 리스트
        /// </summary>
        /// <returns></returns>
        [HttpGet("FaqList")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> GetFaqList([FromQuery] Int32 page, Int32 pageSize)
        {

            // Return message
            var resultClient = new ResultClientEntity<ListPageDataContainer<List<FAQEntity>>>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion

                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ Parameter value
                if (libUtility.IsSpace(libWebUtility.OnNullCheckInt(page.ToString()).ToString()))
                    page = 1;

                if (libUtility.IsSpace(pageSize.ToString()))
                    pageSize = 20;
                #endregion

                #region // !++ DB 정보가져오기
                var pageModel = new PageDBEntity()
                {
                    page = page,
                    pageSize = pageSize
                };
                var resultData = await CrawlingHandler.GetFaqList(dbConnectionEntity, pageModel);
                #endregion

                #region // !++ Client message
                resultClient.success = true;
                resultClient.msg = String.Empty;
                resultClient.error = String.Empty;
                resultClient.data = resultData;
                #endregion

                return Ok(resultClient);

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API GetFaqList : \n [Page:{0}], \n [PageSize:{1}], \n {2}, \n {3}",
                                        page, pageSize, exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }

        }
        #endregion


        #region // !++ GetFaqInfo (FAQ 상세정보)
        /// <summary>
        /// FAQ 상세정보
        /// </summary>
        /// <returns></returns>
        [HttpGet("FaqDetail/{id:int}")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> GetFaqInfo(Int32 id)
        {

            // Return message
            var resultClient = new ResultClientEntity<FAQEntity>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ Data struct 변경
                var model = new FAQEntity()
                {
                    iSeq = id
                };
                #endregion

                #region // !++ 정보가져오기
                var resultData = await CrawlingHandler.GetFaqDetail(dbConnectionEntity, model);
                #endregion

                #region // !++ Client message
                if (resultData != null)
                {
                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = resultData;
                    if (resultData.iSeq == 0)
                    {
                        resultClient.data = null;
                    }
                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API GetFaqInfo : \n [ID:{0}], \n {1}, \n {2}",
                                        id.ToString(), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }
        }
        #endregion


        #region // !++ SetFaqRegist (FAQ 등록)
        /// <summary>
        /// FAQ 등록
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("faqregist")]
        [Produces("application/json", Type = typeof(FAQEntity))]
        [Consumes("application/json")] // application/xml
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> SetFaqRegist([FromBody] FAQEntity model)
        {

            // Return message
            var resultClient = new ResultClientEntity<Int32?>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ 관리자 정보 담기
                model.iManagerSeq = managerLogin.adminSeq;
                #endregion

                #region // !++ DB 등록하기
                var resultData = await CrawlingHandler.SetFaqRegist(dbConnectionEntity, model);
                #endregion

                #region // !++ Client message
                if (resultData == 1)
                {
                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = null;

                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API SetFaqRegist : \n [FAQEntity:{0}], \n {1}, \n {2}",
                                        libUtility.ToJson(model), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }
        }
        #endregion


        #region // !++ SetFaqModify (FAQ 수정)
        /// <summary>
        /// FAQ 수정
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPut("faqmodify")]
        [Produces("application/json", Type = typeof(FAQEntity))]
        [Consumes("application/json")] // application/xml
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> SetFaqModify([FromBody] FAQEntity model)
        {

            // Return message
            var resultClient = new ResultClientEntity<Int32?>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ 관리자 정보 담기
                model.iManagerSeq = managerLogin.adminSeq;
                #endregion

                #region // !++ DB 등록하기
                var resultData = await CrawlingHandler.SetFaqModify(dbConnectionEntity, model);
                #endregion

                #region // !++ Client message
                if (resultData == 1)
                {
                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = null;

                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API SetFaqModify : \n [FAQCodeEntity:{0}], \n {1}, \n {2}",
                                        libUtility.ToJson(model), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }
        }
        #endregion


        #region // !++ SetFaqDelete (FAQ 삭제)
        /// <summary>
        /// FAQ 삭제
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpDelete("faqdelete/{id:int}")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> SetFaqDelete(Int32 id)
        {

            // Return message
            var resultClient = new ResultClientEntity<Int32?>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ 정보 담기
                var model = new FAQEntity()
                {
                    iSeq = id,
                    iManagerSeq = managerLogin.adminSeq
                };
                #endregion

                #region // !++ DB 등록하기
                var resultData = await CrawlingHandler.SetFaqDelete(dbConnectionEntity, model);
                #endregion

                #region // !++ Client message
                if (resultData == 1)
                {
                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = null;

                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API SetFaqDelete : \n [iSeq:{0}], \n {1}, \n {2}",
                                        id, exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }
        }
        #endregion

    }
    #endregion

}