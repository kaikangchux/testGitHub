// 회원로그인 정보
export class MemberLoginModel
{

    biMemberSeq: number;
    iPlatFormSeq: number;
    vcEmail: string;
    vcName: string;
    tiOrganization: number;
    tiMemberGrade: number;
    tiMemberStatus: number;
    dtLoginDate: string;
    isLogin: boolean;

    constructor()
    {
        this.biMemberSeq = 0;
        this.iPlatFormSeq = 0;
        this.vcEmail = '';
        this.vcName = '';
        this.tiOrganization = 0;
        this.tiMemberGrade = 0;
        this.tiMemberStatus = 0;
        this.dtLoginDate = '';
        this.isLogin = false;
    }

}
