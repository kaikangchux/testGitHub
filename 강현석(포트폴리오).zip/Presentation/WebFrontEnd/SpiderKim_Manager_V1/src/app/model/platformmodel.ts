// 플랫폼정보
export class PlatFormModel
{

  iSeq: number;
  vcName: string;
  vcKeyText: string;
  vcKeyImage: string;
  tiStatus: number;
  iManagerSeq: number;
  dtRegDate: string;

  constructor() {
    this.iSeq = 0;
    this.vcName = '';
    this.vcKeyText = '';
    this.vcKeyImage = '';
    this.tiStatus = 0;
    this.iManagerSeq = 0;
    this.dtRegDate = '';
  }
}
