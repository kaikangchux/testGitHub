// 회사조직(분류)
export class CompanyGroupModel
{

  iSeq: number;
  vcName: string;
  vcNameKeyText: string;
  vcAbbreviation: string;
  vcAbbreviationKeyText: string;
  iManagerSeq: number;
  dtRegDate: string;

  constructor() {
    this.iSeq = 0;
    this.vcName = '';
    this.vcNameKeyText = '';
    this.vcAbbreviation = '';
    this.vcAbbreviationKeyText = '';
    this.iManagerSeq = 0;
    this.dtRegDate = '';
  }

}
