import { Component, OnInit, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { FormGroup, FormBuilder, Validators, ValidationErrors } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { NgxSpinnerService } from "ngx-spinner";

import { CommonService, PlatFormService } from '../../service';

@Component({ 
    selector: 'app-popup',
    templateUrl: './platformregist.component.html', 
    styleUrls: ['../scss/regEdit.component.scss']
})

export class PlatFormRegistComponent implements OnInit
{
    registForm:FormGroup;

    constructor(private mService:PlatFormService,
                private cmnService:CommonService,
                private translate:TranslateService,
                private spinnerService:NgxSpinnerService,
                public dialogRef: MatDialogRef<PlatFormRegistComponent>, 
                @Inject(MAT_DIALOG_DATA) public data:any,
                private fb:FormBuilder){
    }

    ngOnInit():void
    {
        this.registForm = this.fb.group({
            vcName:['', Validators.required],
            vcKeyText:['', Validators.required],
            vcKeyImage:['', Validators.required],
            tiStatus:[0, Validators.required]
        });
    }

    // Action
    onRegist():void
    {
        this.mService.regEditPlatForm(this.registForm.value, true).subscribe(
            (res) => this.onClose(true),
            (err) => { this.onClose(false); console.log(err);}
        );
    }

    // Reset
    onReset():void
    {
        this.registForm.patchValue ({vcName: ''});
        this.registForm.patchValue ({vcKeyText: ''});
        this.registForm.patchValue ({vcKeyImage: ''});
        this.registForm.patchValue ({tiStatus: 0});
    }

    // popup close
    onClose(param:any):void{
        this.dialogRef.close(param);
    }

}