// 블러그 좋아요
export class BlogLikeModel
{

  biBlogSeq: number;
  biMemberSeq: number;
  vcAccount: string;
  vcName: string;
  vcIP: string;
  dtRegDate: string;

  constructor() {
    this.biBlogSeq = 0;
    this.biMemberSeq = 0;
    this.vcAccount = '';
    this.vcName = '';
    this.vcIP = '';
    this.dtRegDate = '';
  }

}
