﻿using System;
using System.Collections.Generic;

using Lib.Crawling.Library.Log;
using Lib.Crawling.Library.Utilities;
using Lib.Crawling.Library.Entities.Mongo;

using MongoDB.Driver;

namespace DAL.Crawling.Mongo
{

    #region // !++ MongoDB
    /// <summary>
    /// MongoDB
    /// </summary>
    public class DalMongo
    {

        #region // !++ Utility
        /// <summary>
        /// LibUtility
        /// </summary>
        protected static LibUtility libUtility = new LibUtility();
        #endregion


        #region // !++ Mongo config
        /// <summary>
        /// MongoClient
        /// </summary>
        private static MongoClient mongoConnection;

        /// <summary>
        /// DalMongo
        /// </summary>
        private static DalMongo m_instance;
        #endregion


        #region // !++ Instance
        /// <summary>
        /// 
        /// </summary>
        public static DalMongo Instance
        {
            get
            {
                if (null == m_instance)
                {
                    m_instance = new DalMongo();
                }
                return m_instance;
            }
        }
        #endregion


        #region // !++ Mongo static connection Dictionary
        private static Dictionary<Int32, MongoClient> m_dicMongo = new Dictionary<Int32, MongoClient>();
        #endregion


        #region // !++ Connect (MongoDB 커넥션)
        /// <summary>
        /// MongoDB 커넥션
        /// </summary>
        /// <param name="mongoDbConnectionEntity"></param>
        /// <returns></returns>
        public Boolean mongoConnect(MongoDbConnectionEntity mongoDbConnectionEntity)
        {

            try
            {

                #region // !++ 추가 설정(필요할때 사용)
                /*
                settings.UseSsl = true,
                settings.SslSettings = new SslSettings(),
                settings.ConnectTimeout = new TimeSpan(1, 0, 0),
                settings.SslSettings.EnabledSslProtocols = SslProtocols.Tls12;
                
                MongoIdentity identity = new MongoInternalIdentity("", "");
                MongoIdentityEvidence evidence = new PasswordEvidence("");

                settings.Credential = new MongoCredential("SCRAM-SHA-1", identity, evidence);
                */
                #endregion


                #region // !++ MongoDB connection string
                var settings = new MongoClientSettings()
                {
                    Server = new MongoServerAddress(mongoDbConnectionEntity.ipAdress, mongoDbConnectionEntity.ipPort),
                };
                #endregion

                #region // !++ Mongo client connect
                mongoConnection = new MongoClient(settings);
                if (mongoConnection == null)
                {
                    return false;
                }
                #endregion

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Error, "mongoConnect Error : \n [MongoDbConnectionEntity:{0}], \n {1}, \n {2}",
                                            libUtility.ToJson(mongoDbConnectionEntity), exc.Message, exc.StackTrace);
                return false;
            }

            return true;
        }

        /// <summary>
        /// MongoDB 커넥션
        /// </summary>
        /// <param name="worldIdx"></param>
        /// <param name="mongoDbConnectionEntity"></param>
        /// <returns></returns>
        public Boolean mongoConnect(List<MongoDbConnectionDictionaryEntity> mongoConnList)
        {

            // 초기화
            m_dicMongo.Clear();

            m_dicMongo = new Dictionary<Int32, MongoClient>();

            try
            {

                #region // !++ 커넥션 리스트 정보 확인
                if (mongoConnList == null)
                {
                    return false;
                }
                if (mongoConnList.Count == 0)
                {
                    return false;
                }
                #endregion


                #region // !++ MongoDB 연결 및 Static connection 정보 만들기
                for (int i = 0; i < mongoConnList.Count; i++)
                {

                    #region // !++ MongoDB connection string
                    MongoClientSettings settings = new MongoClientSettings()
                    {
                        Server = new MongoServerAddress(mongoConnList[i].ipAdress, mongoConnList[i].ipPort),
                    };
                    #endregion


                    #region // !++ Mongo client connect
                    mongoConnection = new MongoClient(settings);
                    if (mongoConnection == null)
                    {
                        return false;
                    }
                    #endregion


                    #region // !++ Dictionary 만들기
                    if (m_dicMongo.ContainsKey(mongoConnList[i].worldIdx))
                    {
                        m_dicMongo[mongoConnList[i].worldIdx] = mongoConnection;
                    }
                    else
                    {
                        m_dicMongo.Add(mongoConnList[i].worldIdx, mongoConnection);
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Error, "mongoConnect Error : \n [MongoDbConnectionDictionaryEntity:{0}], \n {2}, \n {3}",
                                            libUtility.ToJson(mongoConnList), exc.Message, exc.StackTrace);
                return false;
            }

            return true;
        }
        #endregion


        #region // !++ mongoDisConnect (MongoDB 커넥션 해제)
        /// <summary>
        /// MongoDB 커넥션 해제
        /// </summary>
        public void mongoDisConnect()
        {
            try
            {

                #region // !++ Client disconnect
                if (mongoConnection != null)
                {
                    mongoConnection = null;
                }
                #endregion

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Error, "mongoDisConnect Error : \n {0}, \n {1}",
                                                   exc.Message, exc.StackTrace);
            }
        }
        #endregion


        #region // !++ GetCollection<T> (DataBase 및 Collection 정보)
        /// <summary>
        /// DataBase 및 Collection 정보
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="mongoDBCollectionEntity"></param>
        /// <returns></returns>
        public IMongoCollection<T> GetCollection<T>(MongoDBCollectionEntity mongoDBCollectionEntity)
        {

            try
            {

                #region // !++ DataBase 및 Collection 정보
                IMongoDatabase dataBase = mongoConnection.GetDatabase(mongoDBCollectionEntity.mongoDbTable);
                return dataBase.GetCollection<T>(mongoDBCollectionEntity.mongoDbCollection);
                #endregion

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Error, "GetCollection<T> Error : \n [MongoDBCollectionEntity:{0}], \n {1}, \n {2}",
                                            libUtility.ToJson(mongoDBCollectionEntity), exc.Message, exc.StackTrace);
                return null;
            }

        }

        /// <summary>
        /// Connection Dictionary, DataBase, Collection 정보
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="mongoDBCollectionEntity"></param>
        /// <returns></returns>
        public IMongoCollection<T> GetCollection<T>(MongoDBCollectionDicEntity mongoDBCollectionEntity)
        {

            try
            {

                #region // !++ Connection 정보 가져오기
                mongoConnection = GetMongoDictionary(mongoDBCollectionEntity.worldIdx);
                #endregion

                #region // !++ DataBase 및 Collection 정보
                IMongoDatabase dataBase = mongoConnection.GetDatabase(mongoDBCollectionEntity.mongoDbTable);
                return dataBase.GetCollection<T>(mongoDBCollectionEntity.mongoDbCollection);
                #endregion

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Error, "GetCollection<T> Error : \n [MongoDBCollectionDicEntity:{0}], \n {1}, \n {2}",
                                            libUtility.ToJson(mongoDBCollectionEntity), exc.Message, exc.StackTrace);
                return null;
            }

        }
        #endregion


        #region // !++ SetDispose (리소스 해제)
        /// <summary>
        /// 리소스 해제
        /// </summary>
        /// <param name="mongoDBCollectionEntity"></param>
        private void SetDispose()
        {

            try
            {
                mongoConnection.Cluster.Dispose();
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Error, "SetDispose Error : \n {0}, \n {1}",
                                                   exc.Message, exc.StackTrace);
            }

        }
        #endregion


        #region // !++ GetMongoDictionary (Mongo static connection Dictionary 정보 가져오기)
        /// <summary>
        /// Mongo static connection Dictionary 정보 가져오기
        /// </summary>
        /// <param name="worldIdx"></param>
        /// <returns></returns>
        internal MongoClient GetMongoDictionary(Int32 worldIdx)
        {
            if (m_dicMongo == null || m_dicMongo.Count == 0)
            {
                return null;
            }
            if (m_dicMongo.ContainsKey(worldIdx))
            {
                return m_dicMongo[worldIdx];
            }
            return null;
        }
        #endregion

    }
    #endregion

}
