﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Http;

using Lib.Crawling.Library.Log;

namespace WebApi_SpiderKim_Manager_V1.WebUtilities
{

    #region // !++ LibWebUtility
    /// <summary>
    /// LibWebUtility
    /// </summary>
    public class LibWebUtility
    {

        private readonly IHttpContextAccessor _httpContextAccessor;

        public LibWebUtility()
        {

        }

        public LibWebUtility(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        /// <summary>
        /// Encoder
        /// </summary>
        protected static UTF8Encoding encoder = new UTF8Encoding();


        #region // !++ Select 박스 선택
        /// <summary>
        /// Select 박스 선택
        /// </summary>
        /// <param name="p_Option"></param>
        /// <param name="p_Value"></param>
        /// <returns></returns>
        public String OnSelectBox(String p_Option, String p_Value)
        {
            if (p_Value == "")
                return "";
            if (p_Option == p_Value)
                return " selected=\"selected\"";
            else
                return "";
        }
        #endregion Select 박스 선택(value)


        #region // !++ bool IsSpace(string p_String)
        /// <summary>
        /// 공란확인(IsSpace)
        /// </summary>
        /// <param name="p_String">공란확인</param>
        /// <returns></returns>
        public Boolean IsSpace(String p_String)
        {
            Boolean bResult = false;
            if (p_String == "" || p_String == null)
                bResult = true;
            return bResult;
        }
        #endregion


        #region // !++ SetConvertToBase64(문자열)
        /// <summary>
        /// Base64 Encode
        /// </summary>
        /// <param name="p_String"></param>
        /// <returns></returns>
        public String SetConvertToBase64(String p_String)
        {
            Byte[] base64Byte;
            String result = String.Empty;

            try
            {
                base64Byte = encoder.GetBytes(p_String);
                result = Convert.ToBase64String(base64Byte).ToString();
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetConvertFromBase64 Error : \n [p_String:{0}], \n {1}, \n {2}",
                                                    p_String, exc.Message, exc.StackTrace);
                return result;
            }

            return result;
        }
        #endregion


        #region // !++ GetConvertFromBase64(문자열)
        /// <summary>
        /// Base64 Decode
        /// </summary>
        /// <param name="p_String"></param>
        /// <returns></returns>
        public String GetConvertFromBase64(String p_String)
        {
            Byte[] base64Byte;
            String result = String.Empty;

            try
            {
                base64Byte = Convert.FromBase64String(p_String);
                result = encoder.GetString(base64Byte);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetConvertFromBase64 Error : \n [p_String:{0}], \n {1}, \n {2}",
                                                    p_String, exc.Message, exc.StackTrace);
                return result;
            }

            return result;
        }
        #endregion


        #region // !++ OnTotalPage (전체 페이지 수)
        /// <summary>
        /// 전체 페이지 수
        /// </summary>
        /// <param name="p_recode"></param>
        /// <param name="p_page"></param>
        /// <returns></returns>
        public Int32 OnTotalPage(Int32 p_recode, Int32 p_page)
        {

            Int32 result = 0;

            Double doubleValue = (Double)p_recode / p_page;
            result = (Int32)Math.Ceiling(doubleValue);

            return result;

        }
        #endregion


        #region // !++ Request URL make view(Response.Write)

        #region // !++ DrawResponseRaw
        /// <summary>
        /// Client Http view
        /// </summary>
        /// <param name="contentType"></param>
        /// <param name="contentString"></param>
        public void DrawResponseRaw(Int32 contentType, String contentString)
        {
            try
            {
                DrawResponse(contentType, contentString, Encoding.UTF8);
            }
            // Thread Abort() 쓰레드 비정상 종료일 경우!! Thread 중단 요청 취소하고 계속 실행!!
            catch (ThreadAbortException exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "DrawResponseRaw Thread Abort Error : \n [ContentType:{0}], \n [ContentString:{1}], \n {2}, \n {3}",
                                                    contentType, contentString, exc.Message, exc.StackTrace);
                Thread.ResetAbort();
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "DrawResponseRaw Error : \n [ContentType:{0}], \n [ContentString:{1}], \n {2}, \n {3}",
                                                    contentType, contentString, exc.Message, exc.StackTrace);
            }
        }
        #endregion


        #region // !++ DrawResponse
        /// <summary>
        /// 
        /// </summary>
        /// <param name="contentType"></param>
        /// <param name="contentString"></param>
        /// <param name="encoding"></param>
        internal void DrawResponse(Int32 contentType, String contentString, Encoding encoding)
        {

            try
            {
                String content = Task.Run(() => DrawContentTyp(contentType)).Result;

                contentString = contentString == null ? string.Empty : contentString;

                // HttpContext.Current.Response.Clear();

                // euc-kr 일 경우 처리
                if (encoding == Encoding.GetEncoding("ks_c_5601-1987"))
                {
                    _httpContextAccessor.HttpContext.Response.Headers.Add("Cache-Control", "No-Cache");
                    _httpContextAccessor.HttpContext.Response.Headers.Add("Expire", "0");
                    _httpContextAccessor.HttpContext.Response.Headers.Add("Pragma", "No-Cache");
                    _httpContextAccessor.HttpContext.Response.Headers.Add("Charset", "ks_c_5601-1987"); //euc-kr
                }
                else
                {
                    _httpContextAccessor.HttpContext.Response.Headers.Add("Cache-Control", "No-Cache");
                    _httpContextAccessor.HttpContext.Response.Headers.Add("Expire", "0");
                    _httpContextAccessor.HttpContext.Response.Headers.Add("Pragma", "No-Cache");
                    _httpContextAccessor.HttpContext.Response.Headers.Add("Charset", "UTF-8");
                }
                _httpContextAccessor.HttpContext.Response.Headers.Add("Content-Type", content);
                _httpContextAccessor.HttpContext.Response.Headers.Add("Charset", encoding.ToString());
                _httpContextAccessor.HttpContext.Response.WriteAsync(contentString);
                _httpContextAccessor.HttpContext.Response.Body.FlushAsync();
                _httpContextAccessor.HttpContext.Response.Body.Close();

                // HttpContext.Current.Response.SuppressContent = true;
                // HttpContext.Current.ApplicationInstance.CompleteRequest();

            }
            // Thread Abort() 쓰레드 비정상 종료일 경우!! Thread 중단 요청 취소하고 계속 실행!!
            catch (ThreadAbortException exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "DrawResponse Thread Abort Error : \n [ContentType:{0}], \n [ContentString:{1}], \n [Encoding:{2}], \n {3}, \n {4}",
                                                    contentType, contentString, encoding, exc.Message, exc.StackTrace);
                Thread.ResetAbort();
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "DrawResponse Error : \n [ContentType:{0}], \n [ContentString:{1}], \n [Encoding:{2}], \n {3}, \n {4}",
                                                    contentType, contentString, encoding, exc.Message, exc.StackTrace);
            }
        }
        #endregion


        #region // !++ DrawContentTyp
        /// <summary>
        /// 
        /// </summary>
        /// <param name="contentType"></param>
        /// <returns></returns>
        internal static String DrawContentTyp(Int32 contentType)
        {

            String result = String.Empty;

            try
            {
                switch (contentType)
                {
                    case 1:
                        result = "application/x-www-form-urlencoded";
                        break;
                    case 2:
                        result = "application/json";
                        break;
                    case 3:
                        result = "text/plain";
                        break;
                    case 4:
                        result = "text/html";
                        break;
                    case 5:
                        result = "text/xml";
                        break;
                    default:
                        result = "application/x-www-form-urlencoded";
                        break;
                }
            }
            // Thread Abort() 쓰레드 비정상 종료일 경우!! Thread 중단 요청 취소하고 계속 실행!!
            catch (ThreadAbortException exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "DrawContentTyp Thread Abort Error : \n [ContentType:{0}], \n {1}, \n {2}",
                                                    contentType, exc.Message, exc.StackTrace);
                Thread.ResetAbort();
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "DrawContentTyp Error : \n [ContentType:{0}], \n {1}, \n {2}",
                                                   contentType, exc.Message, exc.StackTrace);
                return result;
            }

            return result;
        }
        #endregion

        #endregion


        #region // !++ OnAlert(string p_String)
        /// <summary>
        /// Javascript : alert
        /// 경고메시지
        /// </summary>
        /// <param name="p_String">메시지</param>
        public void OnAlert(string p_String)
        {
            _httpContextAccessor.HttpContext.Response.WriteAsync("<script type=\"text/javascript\">alert(\"" + p_String + "\");</script>");
        }
        #endregion


        #region // !++ OnScript(string p_String)
        /// <summary>
        /// javascript : 실행
        /// </summary>
        /// <param name="p_String">문자열</param>
        public void OnScript(String p_String)
        {
            _httpContextAccessor.HttpContext.Response.WriteAsync("<script type=\"text/javascript\">" + p_String + "</script>");
        }
        #endregion


        #region // !++ OnRemoveTags(string p_String)
        /// <summary>
        /// 문자열 유효성 : 태그제거
        /// </summary>
        /// <param name="p_String">문자열</param>
        /// <returns></returns>
        public String OnRemoveTags(String p_String)
        {
            if (p_String + "" == "")
                return null;

            Regex l_Reg = new Regex(@"<[^>]*>");
            return l_Reg.Replace(p_String, "");
        }
        #endregion


        #region // !++ LenStr(string p_String, int MaxLen, int MinLen)
        /// <summary>
        /// 문자열 유효성 : 허용하는 문자열 크기
        /// </summary>
        /// <param name="p_String">문자열</param>
        /// <param name="MaxLen">최대크기</param>
        /// <param name="MinLen">최소크기</param>
        /// <returns></returns>
        public String LenStr(String p_String, Int32? MaxLen, Int32? MinLen)
        {
            Int32 l_StringLength = encoder.GetByteCount(p_String);
            if (MaxLen < l_StringLength && MinLen != null)
            {
                OnAlert("문자열의 범위를 초과하셨습니다.");
            }
            if (MinLen > l_StringLength && MaxLen != null)
            {
                OnAlert("문자열의 범위가 부족합니다.");
            }
            return p_String;
        }
        #endregion


        #region // !++ OnNullCheckString(string p_String)
        /// <summary>
        /// 문자열 유효성 : Null 체크
        /// </summary>
        /// <param name="p_String">문자열</param>
        /// <returns></returns>
        public String OnNullCheckString(String p_String)
        {
            if (p_String + "" == "")
                p_String = String.Empty;
            return p_String;
        }
        #endregion


        #region // !++ OnNullCheckInt(string p_String)
        /// <summary>
        /// 문자열 유효성 : Null 체크
        /// </summary>
        /// <param name="p_String">문자열</param>
        /// <returns></returns>
        public Int32 OnNullCheckInt(String p_String)
        {
            if (p_String + "" == "")
                p_String = "0";
            return Convert.ToInt32(p_String);
        }
        #endregion


        #region // !++ OnNullCheckBigInt(string p_String)
        /// <summary>
        /// 문자열 유효성 : Null 체크
        /// </summary>
        /// <param name="p_String">문자열</param>
        /// <returns></returns>
        public Int64 OnNullCheckBigInt(String p_String)
        {
            if (p_String + "" == "")
                p_String = "0";
            return Convert.ToInt64(p_String);
        }
        #endregion


        #region // !++ OnNullCheckShort(string p_String)
        /// <summary>
        /// 문자열 유효성 : Null 체크
        /// </summary>
        /// <param name="p_String">문자열</param>
        /// <returns></returns>
        public Int16 OnNullCheckShort(String p_String)
        {
            if (p_String + "" == "")
                p_String = "0";
            return Convert.ToInt16(p_String);
        }
        #endregion


        #region // !++ OnNullCheckDouble(string p_String)
        /// <summary>
        /// 문자열 유효성 : Null 체크
        /// </summary>
        /// <param name="p_String">문자열</param>
        /// <returns></returns>
        public Double OnNullCheckDouble(String p_String)
        {
            if (p_String + "" == "")
                p_String = "0";
            return Convert.ToDouble(p_String);
        }
        #endregion


        #region // !++ OnSumOrMinusSelect (합산 또는 차감 선택)
        /// <summary>
        /// 합산 또는 차감 선택
        /// </summary>
        /// <returns></returns>
        public String OnSumOrMinusSelect()
        {

            String result = String.Empty;
            result = "<select name=\"usedChk\" id=\"usedChk\" msg =\"Plus or minus\" SELECT-ONE style=\"width: 120px; \">\r\n";
            result += "<option value=\"\"" + OnSelectBox("", "") + "\">Select!</option>\r\n";
            result += "<option value=\"1\"> + </option>\r\n";
            result += "<option value=\"2\"> - </option>\r\n";
            result += "</select>\r\n";
            return result;
        }
        #endregion


        #region // !++ OnAdLevelStr (관리자 레벨명 표기)
        /// <summary>
        /// 관리자 레벨명 표기
        /// </summary>
        /// <param name="p_Int">등급</param>
        /// <returns></returns>
        public String OnAdLevelStr(Int32 p_Int)
        {
            String l_Result = "";
            switch (p_Int)
            {
                case 1:
                    l_Result = "Super Admin";
                    break;
                case 2:
                    l_Result = "Data write";
                    break;
                case 3:
                    l_Result = "Only view";
                    break;
                default:
                    l_Result = "Unknown!";
                    break;
            }
            return l_Result;
        }
        #endregion


        #region // !++ OnAdLevel (관리자 레벨선택)
        /// <summary>
        /// 관리자 레벨선택
        /// </summary>
        /// <param name="p_String"></param>
        /// <returns></returns>
        public String OnAdLevel(String p_String)
        {
            String l_Result = "";
            l_Result += "<option value=\"\"" + OnSelectBox("", p_String) + ">Grade select</option>";
            l_Result += "<option value=\"1\"" + OnSelectBox("1", p_String) + ">Super Admin</option>";
            l_Result += "<option value=\"2\"" + OnSelectBox("2", p_String) + ">Data write</option>";
            l_Result += "<option value=\"3\"" + OnSelectBox("3", p_String) + ">Only view</option>";
            return l_Result;
        }
        #endregion


        #region // !++ OnEmail(string p_String)
        /// <summary>
        /// 이메일option
        /// </summary>
        /// <param name="p_String"></param>
        /// <returns></returns>
        public String OnEmail(String p_String)
        {
            String l_Result = "";
            l_Result += "<option value=\"\"" + OnSelectBox("", p_String) + ">direct input</option>";
            l_Result += "<option value=\"spiderkim.com\"" + OnSelectBox("spiderkim.com", p_String) + ">spiderkim.com</option>";
            l_Result += "<option value=\"gmail.com\"" + OnSelectBox("gmail.com", p_String) + ">gmail.com</option>";
            l_Result += "<option value=\"hotmail.com\"" + OnSelectBox("hotmail.com", p_String) + ">hotmail.com</option>";

            return l_Result;
        }
        #endregion


        #region // !++ OnGMConnectLogType(GM 접속 로그 타입)
        /// <summary>
        /// GM 접속 로그 타입
        /// </summary>
        /// <param name="p_Int"></param>
        /// <returns></returns>
        public String OnGMConnectLogType(Int32 p_Int)
        {
            String l_Result = "";

            switch (p_Int)
            {
                case 1:
                    l_Result = "login";
                    break;
                case 2:
                    l_Result = "log out";
                    break;
                default:
                    l_Result = "unknown";
                    break;
            }
            return l_Result;
        }
        #endregion


        #region // !++ OnFlagSign(수량 기호 변환)
        /// <summary>
        /// 수량 기호 변환
        /// </summary>
        /// <param name="p_Int"></param>
        /// <returns></returns>
        public String OnFlagSign(short p_Int)
        {
            String l_Result = "";

            switch (p_Int)
            {
                case 1:
                    l_Result = "+";
                    break;
                case 2:
                    l_Result = "-";
                    break;
                default:
                    l_Result = "unknown";
                    break;
            }
            return l_Result;
        }
        #endregion


        #region // !++ OnChangeBeforeAmount(이전 수량 정보)
        /// <summary>
        /// 이전 수량 정보
        /// </summary>
        /// <param name="p_Int"></param>
        /// <param name="useAmount"></param>
        /// <param name="afterAmount"></param>
        /// <returns></returns>
        public Int64 OnChangeBeforeAmount(short p_Int, Int64 useAmount, Int64 afterAmount)
        {

            Int64 l_Result = 0;

            switch (p_Int)
            {
                case 1:
                    l_Result = afterAmount - useAmount;
                    if (l_Result < 0)
                    {
                        l_Result = 0;
                    }
                    break;
                case 2:
                    l_Result = afterAmount + useAmount;
                    break;
                default:
                    l_Result = 0;
                    break;
            }
            return l_Result;

        }
        #endregion


        #region // !++ OnMemberSearchSelect (계정 검색 선택)
        /// <summary>
        /// 계정 검색 선택
        /// </summary>
        /// <param name="p_String"></param>
        /// <returns></returns>
        public String OnMemberSearchSelect(String p_String)
        {

            String l_Result = "";
            l_Result += "<option value=\"\"" + OnSelectBox("", p_String) + ">Search select</option>";
            l_Result += "<option value=\"1\"" + OnSelectBox("1", p_String) + ">Nick name</option>";
            l_Result += "<option value=\"2\"" + OnSelectBox("2", p_String) + ">Account Idx</option>";
            l_Result += "<option value=\"3\"" + OnSelectBox("3", p_String) + ">Character Idx</option>";
            return l_Result;

        }
        #endregion


        #region // !++ OnMemberSearch (계정 검색 타입)
        /// <summary>
        /// 계정 검색 타입
        /// </summary>
        /// <param name="p_String"></param>
        /// <returns></returns>
        public String OnMemberSearch(String p_String)
        {

            String l_Result = String.Empty;

            switch (p_String)
            {
                case "1":
                    l_Result = "Nick name";
                    break;
                case "2":
                    l_Result = "Account idx";
                    break;
                case "3":
                    l_Result = "Character idx";
                    break;
                default:
                    l_Result = "Unknown";
                    break;
            }

            return l_Result;

        }
        #endregion

    }
    #endregion

}
