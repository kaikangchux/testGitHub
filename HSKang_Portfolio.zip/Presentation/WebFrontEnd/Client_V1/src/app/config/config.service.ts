import { Injectable, OnDestroy } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class ConfigService implements OnDestroy
{
    // static PROTOCOL = 'http';
    // static URL = '127.0.0.1';
    // static PORT = '55030';

    // 강현석PC(디버그용)
    static PROTOCOL = 'http';
    static URL = 'localhost';
    static PORT = '10002';

    //강현석PC(테스트)
    // static PROTOCOL = 'http';
    // static URL = '192.168.0.25';
    // static PORT = '10002';

    static CRYPT_KEY = 'SpiderKimManager(!@#$%^&*1234567890)';
    static SPECIAL_UISET_ROUTE:string[] = ['/login', '/join'];
    static DASH_BOARD_ROUTE = '/dashboard';

    static ID_SAVE_COOKIE_NAME = 'idSave';
    static ID_SAVE_EXPIRE_DAY = 20; //20일
    static USER_LOCAL_STORAGE_NAME = 'currentUser';

    uiSettings: any = {layout: {header: 'hide', footer: 'hide', dashboard:'hide'}};
    onSettingsChange: BehaviorSubject<any>;

    constructor(){
        this.onSettingsChange = new BehaviorSubject(this.uiSettings);
    }

    public setSettings(settings:any){
        this.uiSettings = Object.assign({}, this.uiSettings, settings);
        this.onSettingsChange.next(this.uiSettings);
    }

    ngOnDestroy():void{
        this.onSettingsChange.unsubscribe();
    }
}