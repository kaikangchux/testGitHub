// 상품정보
export class GoodsModel
{

  iSeq: number;
  vcGoods: string;
  vcKeyText: string;
  iManagerSeq: number;
  dtRegDate: string;

  constructor() {
    this.iSeq = 0;
    this.vcGoods = '';
    this.vcKeyText = '';
    this.iManagerSeq = 0;
    this.dtRegDate = '';
  }

}
