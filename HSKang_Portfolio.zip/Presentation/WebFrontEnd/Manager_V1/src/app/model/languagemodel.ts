// 언어(다국어)
export class LanguageModel
{

  vcLanguageCode: string;
  vcKeyText: string;
  tiAbbreviated: number;
  vcText: string;
  tiStatus: number;
  iManagerSeq: number;
  dtRegDate: string;
  dtApprovalDate: string;

  constructor() {
    this.vcLanguageCode = '';
    this.vcKeyText = '';
    this.tiAbbreviated = 0;
    this.vcText = '';
    this.tiStatus = 0;
    this.iManagerSeq = 0;
    this.dtRegDate = '';
    this.dtApprovalDate = '';
  }
}
