// 회원(단체) 정보
export class MemberOrganizationModel
{
  biMemberSeq: number;
  vcPersonName: string;
  vcBusiness: string;
  vcOrganizationSerial: string;

  constructor() {
    this.biMemberSeq = 0;
    this.vcPersonName = '';
    this.vcBusiness = '';
    this.vcOrganizationSerial = '';
  }
}
