﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.CrawlingDB
{

    #region // !++ tbLanguageCode
    /// <summary>
    /// tbLanguageCode
    /// </summary>
    [Table("tbLanguageCode")]
    public class tbLanguageCode
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.None), MinLength(2), MaxLength(128)]
        /// <summary>
        /// 언어코드
        /// </summary>
        public String vcLanguageCode { get; set; }

        [Required, MinLength(2), MaxLength(32)]
        /// <summary>
        /// 언어명
        /// </summary>
        public String vcLanguageName { get; set; }

        /// <summary>
        /// 사용여부(1:사용, 2:대기, 3:삭제)
        /// </summary>
        public Int16 tiStatus { get; set; }

        /// <summary>
        /// 관리자고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
