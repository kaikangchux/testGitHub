import { Component, OnInit } from '@angular/core';
import { Title } from "@angular/platform-browser";
import { TranslateService } from '@ngx-translate/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgxSpinnerService } from "ngx-spinner";
import { filter } from 'rxjs/operators';
import { Router, NavigationEnd } from '@angular/router';

import { ManagerService } from '../service';
import { ConfigService } from '../config';


@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})

export class LoginComponent implements OnInit
{
    loginForm:FormGroup;

    constructor(private router:Router,
                private fb:FormBuilder, 
                private titleService:Title, 
                private translate:TranslateService,
                private spinnerService:NgxSpinnerService,
                private mService:ManagerService,
                private config:ConfigService){

        this.mService.logout(false);
        this.titleService.setTitle(this.translate.instant('TITLE.LOGIN'));
        this.config.setSettings({layout: {navbar: 'none'}});
    }

    ngOnInit():void
    {
        this.loginForm = this.fb.group({
            vcManagerID:['', Validators.required],
            vcPassword:['', Validators.required],
        });

        this.router.events.pipe(
            filter(event => event instanceof NavigationEnd)
            ).subscribe((event: NavigationEnd) => {
                this.spinnerService.hide();
            }
        );
    }

    login():void
    {
        this.spinnerService.show();
        if(!this.loginForm.valid){
            //TODO [disabled]="loginForm.invalid" 로 해놨으므로 이 if 문은 불필요
        }

        // this.mService.login(this.loginForm.controls.vcManagerID.value, this.loginForm.controls.vcPassword.value);
        this.mService.login(this.loginForm.value);
    }
}