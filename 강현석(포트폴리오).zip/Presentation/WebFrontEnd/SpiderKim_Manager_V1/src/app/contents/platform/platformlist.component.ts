import { Component, OnInit, Optional} from '@angular/core';
import { Title } from "@angular/platform-browser";
import { TranslateService } from '@ngx-translate/core';
import { NgxSpinnerService } from "ngx-spinner";
import { MatDialog } from '@angular/material';

import { ConfigService } from '../../config';
import { CommonService, PlatFormService } from '../../service';
import { PlatFormModel } from '../../model';

import { PlatFormDetailComponent } from './platformdetail.component';
import { PlatFormRegistComponent } from './platformregist.component';
import { PlatFormModifyComponent } from './platformmodify.component';

@Component({
    selector: 'app-list',
    templateUrl: './platformlist.component.html',
    styleUrls: ['../scss/list.component.scss']
})

export class PlatFormListComponent implements OnInit
{

    start:number = 0;
    len:number = 20;
    total:number = 0;
    platformList:PlatFormModel[] = [];
    curPage:number = 1;

    constructor(private titleService:Title,
                private translate:TranslateService,
                private mService:PlatFormService,
                private spinnerService:NgxSpinnerService,
                private config:ConfigService,
                private cmnService:CommonService,
                public dialog: MatDialog){

        this.titleService.setTitle(this.translate.instant('TITLE.PlATFORM'));
        this.config.setSettings({layout: {navbar: 'show'}});
    }

    ngOnInit():void
    {
        this.getPlatFormList(this.curPage, this.len);
    }

    getPlatFormList(curPage:number, len:number):void
    {
        this.spinnerService.show();

        this.mService.getPlatFormList(curPage, len).subscribe(
            list => {
                this.platformList = list.data.gClass;
                this.total = list.data.totalRecord;
                this.mService.changePlatFormList(this.platformList);
            },
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

    pagingArr():number[]
    {
        let result = Math.ceil(this.total/this.len);
        return Array.from({length: result}, (v, k) => k+1);
    }

    pager(page:number)
    {
        if(page === this.curPage){
            return;
        }

        this.curPage = page;
        this.getPlatFormList(this.curPage, this.len);
    }

    // PlatForm 상세정보
    openDetail(iSeq:number):void
    {
        this.dialog.open(PlatFormDetailComponent, {data:{iSeq:iSeq}});
    }

    // PlatForm 등록
    openRegist():void
    {
        const dialogRef =this.dialog.open(PlatFormRegistComponent, {data:null});

        // 팝업일 경우: 데이터 등록 후 리스트 갱신
        dialogRef.afterClosed().subscribe(res => {
            if(res === true){
                this.getPlatFormList(this.curPage, this.len);
            }
        });
    }

    // PlatForm 정보수정
    openModify(iSeq:number, curPage:number):void
    {
        const dialogRef = this.dialog.open(PlatFormModifyComponent, {data:{iSeq:iSeq}});

        // 팝업일 경우: 데이터 수정 후 리스트 갱신
        dialogRef.afterClosed().subscribe(res => {
            if(res === true){
                if(curPage < 0){
                    this.curPage = 1;
                }
                this.getPlatFormList(this.curPage, this.len);
            }
        });
    }
    
    // PlatForm 삭제
    onDelete(iSeq:number):void
    {
        const result = window.confirm(this.translate.instant('DELETE.MSG'));
        if(!result){
            return;
        }

        this.spinnerService.show();

        this.mService.deletePlatForm(iSeq).subscribe(
            (res) => this.ngOnInit(),
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

}