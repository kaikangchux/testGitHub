﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lib.Crawling.Library.Entities.Mongo
{

    #region // !++ MongoDbConnectionEntity
    /// <summary>
    /// 몽고 DB 커넥션 정보
    /// </summary>
    [Serializable]
    public class MongoDbConnectionEntity
    {

        /// <summary>
        /// IP OR Domain
        /// </summary>
        public String ipAdress { get; set; }

        /// <summary>
        /// PORT
        /// </summary>
        public Int32 ipPort { get; set; }

        public MongoDbConnectionEntity()
        {
            ipAdress = String.Empty;
            ipPort = 0;
        }
        ~MongoDbConnectionEntity()
        {
            ipAdress = String.Empty;
            ipPort = 0;
        }

    }
    #endregion


    #region // !++ MongoDbConnectionDictionaryEntity
    /// <summary>
    /// 몽고 DB 커넥션 정보
    /// </summary>
    [Serializable]
    public class MongoDbConnectionDictionaryEntity
    {

        /// <summary>
        /// 월드 번호
        /// </summary>
        public Int32 worldIdx { get; set; }

        /// <summary>
        /// IP OR Domain
        /// </summary>
        public String ipAdress { get; set; }

        /// <summary>
        /// PORT
        /// </summary>
        public Int32 ipPort { get; set; }

        public MongoDbConnectionDictionaryEntity()
        {
            worldIdx = 0;
            ipAdress = String.Empty;
            ipPort = 0;
        }
        ~MongoDbConnectionDictionaryEntity()
        {
            worldIdx = 0;
            ipAdress = String.Empty;
            ipPort = 0;
        }

    }
    #endregion


    #region // !++ MongoDBCollectionEntity
    /// <summary>
    /// 몽고DB 정보
    /// </summary>
    [Serializable]
    public class MongoDBCollectionEntity
    {

        /// <summary>
        /// 몽고 DB(Table) 명
        /// </summary>
        public String mongoDbTable { get; set; }

        /// <summary>
        /// 몽고 컬렉션 명
        /// </summary>
        public String mongoDbCollection { get; set; }

        public MongoDBCollectionEntity()
        {
            mongoDbTable = String.Empty;
            mongoDbCollection = String.Empty;
        }
        ~MongoDBCollectionEntity()
        {
            mongoDbTable = String.Empty;
            mongoDbCollection = String.Empty;
        }

    }
    #endregion


    #region // !++ MongoDBCollectionDicEntity
    /// <summary>
    /// 몽고DB 정보
    /// </summary>
    [Serializable]
    public class MongoDBCollectionDicEntity
    {

        /// <summary>
        /// 월드 번호
        /// </summary>
        public Int32 worldIdx { get; set; }

        /// <summary>
        /// 몽고 DB(Table) 명
        /// </summary>
        public String mongoDbTable { get; set; }

        /// <summary>
        /// 몽고 컬렉션 명
        /// </summary>
        public String mongoDbCollection { get; set; }

        public MongoDBCollectionDicEntity()
        {
            worldIdx = 0;
            mongoDbTable = String.Empty;
            mongoDbCollection = String.Empty;
        }
        ~MongoDBCollectionDicEntity()
        {
            worldIdx = 0;
            mongoDbTable = String.Empty;
            mongoDbCollection = String.Empty;
        }

    }
    #endregion


    #region // !++ MongoDBSearchEntity
    /// <summary>
    /// MongoDB 검색 조건
    /// </summary>
    [Serializable]
    public class MongoDBSearchEntity
    {

        /// <summary>
        /// 검색 필드명
        /// </summary>
        public String fieldName { get; set; }

        /// <summary>
        /// 검색조건
        /// </summary>
        public String fieldValue { get; set; }

        /// <summary>
        /// 검색조건2
        /// </summary>
        public String fieldValue2 { get; set; }

        public MongoDBSearchEntity()
        {
            fieldName = String.Empty;
            fieldValue = String.Empty;
            fieldValue2 = String.Empty;
        }
        ~MongoDBSearchEntity()
        {
            fieldName = String.Empty;
            fieldValue = String.Empty;
            fieldValue2 = String.Empty;
        }

    }
    #endregion

}
