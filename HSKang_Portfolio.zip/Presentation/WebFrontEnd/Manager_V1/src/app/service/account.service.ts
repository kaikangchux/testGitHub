import { Injectable, EventEmitter, OnDestroy } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/internal/Observable';

import { CommonService } from './common.service';
import { ResultServerData, ResultServerDatalist } from '../common';
import { MemberModel, MemberDetailModel, MemberContactModel, MemberPasswordModel, MemberOrganizationModel, MemberEmailAuthModel } from '../model';
import { MemberContainer } from '../modelcontainer';

@Injectable({
    providedIn: 'root'
})

export class AccountService implements OnDestroy
{

    // 회원 기본(리스트)
    memberList:MemberModel[] = [];

    constructor(private router:Router,
        private cmnService:CommonService,
        private http:HttpClient){}


    // 회원리스트
    changeMemberList(memberList:MemberModel[]){
        this.memberList = memberList;
    }

    // 목록
    getMemberList(page:number, pageSize:number):Observable<any>
    {
        const url = this.cmnService.requestUrl(`/api/account/AccountList?page=${page}&pageSize=${pageSize}`);
        return this.http.get<ResultServerData<ResultServerDatalist<MemberModel[]>>>(url);
    }

    // 상세정보
    getMemberDetail(biSeq:number):Observable<any>
    {
        const url = this.cmnService.requestUrl(`/api/account/AccountDetail/${biSeq}`);
        return this.http.get<ResultServerData<ResultServerDatalist<MemberContainer>>>(url);
    }


    ngOnDestroy():void{
        
    }
}