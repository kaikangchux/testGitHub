﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Collections.Generic;

using Lib.Crawling.Library.Enum;
using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Manager;
using Lib.Crawling.Library.Entities.LogDB;
using Lib.Crawling.Library.DataContainers;
using Lib.Crawling.Library.Log;
using Lib.Crawling.Library.Models.ManagerDB;

using BLL.DB.LogData;

namespace BLL.DB.Manager
{

    #region // !++ BllManager
    /// <summary>
    /// BllManager
    /// </summary>
    public class BllManager : DataProvider.DataProvider
    {

        #region // !++ DataBaseControl => DataProduct => BllLogData
        /// <summary>
        /// BllLogData
        /// </summary>
        protected BllLogData bllLogData = new BllLogData();
        #endregion


        #region // !++ BLL_Manager_Login_Sel (관리자 계정 로그인)
        /// <summary>
        /// 관리자 계정 로그인
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="managerEntity"></param>
        /// <returns>
        ///  1 : Success_DB_Normal
        /// -2 : Error_DB_Exception
        /// -4 : Error_DB_ParameterEmpty
        /// -8 : Error_DB_NotFound
        /// -9 : Error_DB_Discord
        /// -10: Error_DB_UseDeny
        /// </returns>
        public async Task<ResultEntity<ManagerEntity>> BLL_Manager_Login_Sel(DBConnectionEntity dbConnectionEntity, ManagerEntity managerEntity)
        {
            var getResult = new ResultEntity<ManagerEntity>();
            // Hash 암호화 전 비밀번호
            var vcOriginPassword = managerEntity.vcPassword;

            // 비밀번호 암호화 SHA512
            managerEntity.vcPassword = hashWord.SHA512(hashWord.hashCode + managerEntity.vcPassword);
            managerEntity.vcPassword = libUtility.Left(managerEntity.vcPassword, 64);

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbManager()
                {
                    vcManagerID = managerEntity.vcManagerID,
                    vcPassword = managerEntity.vcPassword
                };
                #endregion
                getResult = await dalManager.DAL_Manager_Login_Sel(dbConnectionEntity, dbData);

                // DAL_Manager_Login_Sel 확인
                if (getResult == null)
                {
                    Logger.Log(ELogType.Error, "BLL_Manager_Login_Sel : \n [DBConnectionEntity:{0}], \n [ManagerEntity:{1}], \n [ResultEntity:{2}]",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(managerEntity), libUtility.ToJson(getResult));

                    return getResult;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogManagerConnectionEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = getResult.gClass.iSeq,
                    vcManagerID = managerEntity.vcManagerID,
                    vcPassword = vcOriginPassword,
                    tiResult = 0,
                    tiStatus = (Int16)LogManagerLoginType.Login,
                    tiType = LogActionType.Insert,
                    vcIP = String.Empty             // IP 수정 예정
                };

                switch (getResult.result)
                {
                    case 1:
                        logData.tiResult = 1;
                        break;
                    case -7:
                        logData.tiResult = 2;
                        break;
                    case -8:
                        logData.tiResult = 3;
                        break;
                    default:
                        logData.tiResult = 4;
                        break;
                }
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogManagerConnection_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_Manager_Login_Sel : \n [DBConnectionEntity:{0}], \n [ManagerEntity:{1}], \n [ResultEntity:{2}], \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(managerEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);

                return getResult;
            }

            return getResult;
        }
        #endregion


        #region // !++ BLL_Manager_Sel (관리자 계정 목록 조회)
        /// <summary>
        /// 관리자 계정 목록 조회
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<ManagerEntity>>> BLL_Manager_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {
            var resultDataContainer = new ListPageDataContainer<List<ManagerEntity>>();
            var dataList = new List<ManagerEntity>();

            try
            {
                //+ DAL_Manager_Sel
                using (var ds = await dalManager.DAL_Manager_Sel(dbConnectionEntity, pageDBEntity))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var managerEntity = new ManagerEntity()
                                {
                                    iSeq = Int32.Parse(dt.Rows[i]["iSeq"].ToString()),
                                    vcManagerID = dt.Rows[i]["vcManagerID"].ToString(),
                                    vcName = dt.Rows[i]["vcName"].ToString(),
                                    vcEmailID = dt.Rows[i]["vcEmailID"].ToString(),
                                    vcEmailAddress = dt.Rows[i]["vcEmailAddress"].ToString(),
                                    vcPhone = dt.Rows[i]["vcPhone"].ToString(),
                                    tiGrade = Int16.Parse(dt.Rows[i]["tiGrade"].ToString()),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(managerEntity);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_Manager_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;
        }
        #endregion


        #region // !++ BLL_Manager_Detail_Sel (관리자 계정 상세조회)
        /// <summary>
        /// 관리자 계정 상세조회
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="managerEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ManagerEntity> BLL_Manager_Detail_Sel(DBConnectionEntity dbConnectionEntity, ManagerEntity managerEntity)
        {
            var getResult = new ResultEntity<ManagerEntity>();
            EResultCode eResultCode = 0;

            try
            {
                // 데이터 Struct 변경
                var dbData = new tbManager()
                {
                    iSeq = managerEntity.iSeq
                };
                getResult = await dalManager.DAL_Manager_Detail_Sel(dbConnectionEntity, dbData);

                // DAL_Manager_Detail_Sel 확인
                if (getResult == null)
                {
                    // DAL_Manager_Detail_Sel 실패. 오류 발생!
                    eResultCode = EResultCode.Error_DB_StoredProcedureFail;
                    getResult.ErrorMsg = eResultCode.ToString();
                    Logger.Log(ELogType.Error, "BLL_Manager_Detail_Sel : \n [DBConnectionEntity:{0}], \n [ManagerEntity:{1}], \n [ResultEntity:{2}]",
                                            libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(managerEntity), libUtility.ToJson(getResult));
                    getResult.gClass = null;
                }
            }
            catch (Exception exc)
            {
                // DAL_Manager_Detail_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_Manager_Detail_Sel : \n [DBConnectionEntity:{0}], \n [ManagerEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(managerEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;
        }
        #endregion


        #region // !++ BLL_Manager_IDCheck_Sel (관리자 계정 중복 조회)
        /// <summary>
        /// 관리자 계정 중복 조회
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="managerEntity"></param>
        /// <returns>
        /// Success_DB_Normal     ( 1): 성공,
        /// Error_DB_Exception    (-2): 예외 발생,
        /// Error_DB_NoData       (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing (-5): 이미 사용중
        /// </returns>
        public async Task<Int32> BLL_Manager_IDCheck_Sel(DBConnectionEntity dbConnectionEntity, ManagerEntity managerEntity)
        {
            var result = new ResultEntity<Int32>();

            try
            {
                // 데이터 Struct 변경
                var dbData = new tbManager()
                {
                    vcManagerID = managerEntity.vcManagerID
                };
                result = await dalManager.DAL_Manager_IDCheck_Sel(dbConnectionEntity, dbData);
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_Manager_IDCheck_Sel : \n [DBConnectionEntity:{0}], \n [ManagerEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(managerEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_Manager_Ins (관리자 계정 등록)
        /// <summary>
        /// 관리자 계정 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="managerEntity"></param>
        /// <param name="managerLoginEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_Manager_Ins(DBConnectionEntity dbConnectionEntity, ManagerEntity managerEntity, ManagerLoginEntity managerLoginEntity)
        {
            var result = new ResultEntity<ManagerEntity>();
            EResultCode eResultCode = 0;

            // Hash 암호화 전 비밀번호
            var vcOriginPassword = managerEntity.vcPassword;

            // 비밀번호 암호화 SHA512
            managerEntity.vcPassword = hashWord.SHA512(hashWord.hashCode + managerEntity.vcPassword);
            managerEntity.vcPassword = libUtility.Left(managerEntity.vcPassword, 64);

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbManager()
                {
                    vcManagerID = managerEntity.vcManagerID,
                    vcName = managerEntity.vcName,
                    vcPassword = managerEntity.vcPassword,
                    vcEmailID = managerEntity.vcEmailID,
                    vcEmailAddress = managerEntity.vcEmailAddress,
                    vcPhone = managerEntity.vcPhone,
                    tiGrade = managerEntity.tiGrade,
                    vcIP = managerEntity.vcIP
                };
                #endregion
                result = await dalManager.DAL_Manager_Ins(dbConnectionEntity, dbData);

                // DAL_Manager_Ins 확인
                if (result.result < 1)
                {
                    // DAL_Manager_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogManagerEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iSeq = result.gClass.iSeq,
                    vcManagerID = managerEntity.vcManagerID,
                    vcName = managerEntity.vcName,
                    vcPassword = vcOriginPassword,
                    vcEmailID = managerEntity.vcEmailID,
                    vcEmailAddress = managerEntity.vcEmailAddress,
                    vcPhone = managerEntity.vcPhone,
                    tiGrade = managerEntity.tiGrade,
                    iManagerSeq = managerLoginEntity.adminSeq,
                    tiType = LogActionType.Insert,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogManager_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_Manager_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_Manager_Ins : \n [DBConnectionEntity:{0}], \n [ManagerEntity:{1}], \n [ManagerLoginEntity:{2}], \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(managerEntity), libUtility.ToJson(managerLoginEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_Manager_Upd (관리자 계정 본인 수정)
        /// <summary>
        /// 관리자 계정 본인 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="managerEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백,
        /// Error_DB_NotFound            (-8): 찾을 수 없음
        /// </returns>
        public async Task<Int32> BLL_Manager_Upd(DBConnectionEntity dbConnectionEntity, ManagerEntity managerEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            // Hash 암호화 전 비밀번호
            var vcOriginPassword = managerEntity.vcPassword;

            // 비밀번호 암호화 SHA512
            managerEntity.vcPassword = hashWord.SHA512(hashWord.hashCode + managerEntity.vcPassword);
            managerEntity.vcPassword = libUtility.Left(managerEntity.vcPassword, 64);

            try
            {
                // 데이터 Struct 변경
                var dbData = new tbManager()
                {
                    iSeq = managerEntity.iSeq,
                    vcPassword = managerEntity.vcPassword,
                    vcEmailID = managerEntity.vcEmailID,
                    vcEmailAddress = managerEntity.vcEmailAddress,
                    vcPhone = managerEntity.vcPhone
                };
                result = await dalManager.DAL_Manager_Upd(dbConnectionEntity, dbData);

                // DAL_Manager_Upd 확인
                if (result.result < 1)
                {
                    // DAL_Manager_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogManagerEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iSeq = managerEntity.iSeq,
                    vcManagerID = String.Empty,
                    vcName = String.Empty,
                    vcPassword = vcOriginPassword,
                    vcEmailID = managerEntity.vcEmailID,
                    vcEmailAddress = managerEntity.vcEmailAddress,
                    vcPhone = managerEntity.vcPhone,
                    tiGrade = 0,
                    iManagerSeq = managerEntity.iSeq,
                    tiType = LogActionType.Update,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogManager_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion
            }
            catch (Exception exc)
            {
                // DAL_Manager_Upd 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                result.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_Manager_Upd : \n [DBConnectionEntity:{0}], \n [ManagerEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(managerEntity), exc.Message, exc.StackTrace);
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_Manager_Grade_Upd (관리자 계정 등급 수정)
        /// <summary>
        /// 관리자 계정 등급 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="managerEntity"></param>
        /// <param name="managerLoginEntity"></param>
        /// <returns>
        /// </returns>
        public async Task<Int32> BLL_Manager_Grade_Upd(DBConnectionEntity dbConnectionEntity, ManagerEntity managerEntity, ManagerLoginEntity managerLoginEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbManager()
                {
                    iSeq = managerEntity.iSeq,
                    tiGrade = managerEntity.tiGrade
                };
                #endregion
                result = await dalManager.DAL_Manager_Grade_Upd(dbConnectionEntity, dbData);

                // DAL_Manager_Grade_Upd 확인
                if (result.result < 1)
                {
                    // DAL_Manager_Grade_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogManagerEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iSeq = managerEntity.iSeq,
                    vcManagerID = String.Empty,
                    vcName = String.Empty,
                    vcPassword = String.Empty,
                    vcEmailID = String.Empty,
                    vcEmailAddress = String.Empty,
                    vcPhone = String.Empty,
                    tiGrade = managerEntity.tiGrade,
                    iManagerSeq = managerLoginEntity.adminSeq,
                    tiType = LogActionType.Update,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogManager_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion
            }
            catch (Exception exc)
            {
                // DAL_Manager_Grade_Upd 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                result.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_Manager_Grade_Upd : \n [DBConnectionEntity:{0}], \n [ManagerEntity:{1}], \n [ManagerLoginEntity:{2}], \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(managerEntity), libUtility.ToJson(managerLoginEntity), exc.Message, exc.StackTrace);
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_Manager_Del (관리자 계정 삭제)
        /// <summary>
        /// 관리자 계정 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="managerEntity"></param>
        /// <returns>
        /// -1: Parameter Value Error, 
        /// -2: Error, 
        /// -3: 정보없음, 
        ///  2: Success
        /// </returns>
        public async Task<Int32> BLL_Manager_Del(DBConnectionEntity dbConnectionEntity, ManagerEntity managerEntity, ManagerLoginEntity managerLoginEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbManager()
                {
                    iSeq = managerEntity.iSeq
                };
                #endregion
                result = await dalManager.DAL_Manager_Del(dbConnectionEntity, dbData);

                // DAL_Manager_Del 확인
                if (result.result < 1)
                {
                    // DAL_Manager_Del 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogManagerEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iSeq = managerEntity.iSeq,
                    vcManagerID = String.Empty,
                    vcName = String.Empty,
                    vcPassword = String.Empty,
                    vcEmailID = String.Empty,
                    vcEmailAddress = String.Empty,
                    vcPhone = String.Empty,
                    tiGrade = 0,
                    iManagerSeq = managerLoginEntity.adminSeq,
                    tiType = LogActionType.Delete,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogManager_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion
            }
            catch (Exception exc)
            {
                // DAL_Manager_Del 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                result.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_Manager_Del : \n [DBConnectionEntity:{0}], \n [ManagerEntity:{1}], \n [ManagerLoginEntity:{2}], \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(managerEntity), libUtility.ToJson(managerLoginEntity), exc.Message, exc.StackTrace);
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_Manager_Logout_Sel (관리자 계정 로그아웃)
        /// <summary>
        /// 관리자 계정 로그아웃
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="managerLoginEntity"></param>
        /// <returns></returns>
        public async Task BLL_Manager_Logout_Sel(DBConnectionEntity dbConnectionEntity, ManagerLoginEntity managerLoginEntity)
        {

            try
            {

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogManagerConnectionEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = managerLoginEntity.adminSeq,
                    vcManagerID = managerLoginEntity.adminId,
                    vcPassword = String.Empty,
                    tiResult = 0,
                    tiStatus = (Int16)LogManagerLoginType.Logout,
                    tiType = LogActionType.Insert,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogManagerConnection_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_Manager_Logout_Sel : \n [DBConnectionEntity:{0}], \n [ManagerLoginEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(managerLoginEntity), exc.Message, exc.StackTrace);

            }

        }
        #endregion


        #region // !++ BLL_DataBase_Sel (DataBase 정보)
        /// <summary>
        /// DataBase 정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<List<DataBaseEntity>> BLL_DataBase_Sel(DBConnectionEntity dbConnectionEntity)
        {
            var resultDataContainer = new List<DataBaseEntity>();
            var dataList = new List<DataBaseEntity>();

            try
            {
                //+ DAL_DataBase_Sel
                using (var ds = await dalManager.DAL_DataBase_Sel(dbConnectionEntity))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var dataBaseEntity = new DataBaseEntity()
                                {
                                    iSeq = Int32.Parse(dt.Rows[i]["iSeq"].ToString()),
                                    tiDBType = Int16.Parse(dt.Rows[i]["tiDBType"].ToString()),
                                    vcAddress = dt.Rows[i]["vcAddress"].ToString(),
                                    iPort = Int32.Parse(dt.Rows[i]["iPort"].ToString()),
                                    vcAccount = dt.Rows[i]["vcAccount"].ToString(),
                                    vcPassword = dt.Rows[i]["vcPassword"].ToString(),
                                    vcDataBase = dt.Rows[i]["vcDataBase"].ToString()
                                };
                                dataList.Add(dataBaseEntity);
                            }
                            resultDataContainer = dataList;
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_DataBase_Sel : \n [DBConnectionEntity:{0}], \n {1}, \n {2}",
                                        libUtility.ToJson(dbConnectionEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;
        }
        #endregion


    }
    #endregion

}
