// 제품문의
export class InquiryModel
{

  biSeq: number;
  tiType: number;
  biMemberSeq: number;
  vcOrganization: string;
  vcBusiness: string;
  vcCompany: string;
  vcName: string;
  vcPhone: string;
  vcTitle: string;
  tDescription: string;
  tiAgree: number;
  tiStatus: number;
  vcIP: string;
  dtRegDate: string;

  constructor() {
    this.biSeq = 0;
    this.tiType = 0;
    this.biMemberSeq = 0;
    this.vcOrganization = '';
    this.vcBusiness = '';
    this.vcCompany = '';
    this.vcName = '';
    this.vcPhone = '';
    this.vcTitle = '';
    this.tDescription = '';
    this.tiAgree = 0;
    this.tiStatus = 0;
    this.vcIP = '';
    this.dtRegDate = '';
  }
}
