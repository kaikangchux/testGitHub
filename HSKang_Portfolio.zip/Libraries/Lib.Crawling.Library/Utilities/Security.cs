﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;

namespace Lib.Crawling.Library.Utilities
{

    #region //+ 암복호화 모듈 Class
    /// <summary>
    /// AES 알고리즘 암복호화 모듈
    /// Thread safe 하지 않기 때문에 Object lock 을 걸어준다!
    /// </summary>
    public class Security
    {
        //Encoding 방식 시작
        //UTF Encoding 방식
        protected UTF8Encoding encoder = new UTF8Encoding();
        //Encoding 방식 끝

        //AES 알고리즘 시작
        //Cookie 암호화 AES 변수선언
        protected RijndaelManaged rijndaelManaged = new RijndaelManaged();
        //AES 알고리즘 끝

        //암호화 Default Key(대칭 알고리즘에 사용할 비밀 키) 시작
        protected byte[] keyArray = { 67, 0, 96, 137, 136, 244, 106, 137, 177, 77, 171, 22, 211, 31, 215, 125, 147, 55, 237, 111, 108, 200, 27, 6, 126, 70, 59, 247, 127, 168, 91, 176 };
        //암호화 Default Key(대칭 알고리즘에 사용할 비밀 키) 끝

        //초기화 벡터(대칭 알고리즘에 사용될 벡터) 시작
        protected byte[] vectorIVArray = { 79, 141, 160, 209, 26, 138, 227, 41, 124, 50, 13, 42, 36, 76, 253, 108 };
        //초기화 벡터(대칭 알고리즘에 사용될 벡터) 끝

        // Lock
        protected static object locker = new object();

        #region // !++ Security
        /// <summary>
        /// Security
        /// </summary>
        public Security()
        {
            const Int32 chunkSize = 128;
            var md5 = new MD5CryptoServiceProvider();

            // 암호화 Code 시작
            var key = Convert.ToString(keyArray);
            var vectorIV = Convert.ToString(vectorIVArray);

            rijndaelManaged.Mode = CipherMode.CBC;
            rijndaelManaged.Padding = PaddingMode.PKCS7;

            rijndaelManaged.KeySize = chunkSize;
            rijndaelManaged.BlockSize = chunkSize;

            rijndaelManaged.Key = md5.ComputeHash(encoder.GetBytes(key));
            rijndaelManaged.IV = md5.ComputeHash(encoder.GetBytes(Convert.ToString(vectorIV)));
            // 암호화 Code 끝
        }
        #endregion

        #region // !++ 암호화
        /// <summary>
        /// 암호화
        /// </summary>
        /// <param name="target"></param>
        /// <returns></returns>
        public String Encrypt(String target)
        {
            if (target == null)
                target = "";

            lock (locker)
            {
                ICryptoTransform __interfaceTransform = rijndaelManaged.CreateEncryptor();

                byte[] __byteUtf8ValueArray = encoder.GetBytes(target);
                byte[] __byteEncrytedValueArray = __interfaceTransform.TransformFinalBlock(__byteUtf8ValueArray, 0, __byteUtf8ValueArray.Length);

                return Convert.ToBase64String(__byteEncrytedValueArray);
            }
        }
        #endregion


        #region // !++ 복호화
        /// <summary>
        /// 복호화
        /// </summary>
        /// <param name="target"></param>
        /// <returns></returns>
        public String Decrypt(String target)
        {
            if (target == null || target == "") throw new ArgumentException("복호화 데이터 없음!");

            lock (locker)
            {
                ICryptoTransform __interfaceTransform = rijndaelManaged.CreateDecryptor();

                byte[] __byteEncryptedValueArray = Convert.FromBase64String(target);
                byte[] __byteDecryptedValueArray = __interfaceTransform.TransformFinalBlock(__byteEncryptedValueArray, 0, __byteEncryptedValueArray.Length);

                return encoder.GetString(__byteDecryptedValueArray);
            }
        }
        #endregion

    }
    #endregion


    #region //+ 암호화 Hash Class
    /// <summary>
    /// 비밀번호 암호화
    /// </summary>
    public class HashWord
    {
        public String hashCode = "WebCrawling";
        public HashWord()
        {

        }

        #region // !++ MD5
        /// <summary>
        /// MD5 Hash Code
        /// </summary>
        /// <param name="target">변환할 문자열</param>
        /// <returns>변환 문자열 반환</returns>
        public String MD5(String target)
        {
            var encoder = new UTF8Encoding();
            var md5Hasher = new MD5CryptoServiceProvider();
            var hashedDataArray = md5Hasher.ComputeHash(encoder.GetBytes(target));
            encoder = null;
            md5Hasher = null;
            return byteArrayToString(hashedDataArray);
        }
        #endregion

        #region // !++ SHA1
        /// <summary>
        /// SHA1 Hash Code
        /// </summary>
        /// <param name="target">변환할 문자열</param>
        /// <returns>변환 문자열 반환</returns>
        public String SHA1(String target)
        {
            var encoder = new UTF8Encoding();
            var sha1Hasher = new SHA1CryptoServiceProvider();
            var hashedDataArray = sha1Hasher.ComputeHash(encoder.GetBytes(target));
            encoder = null;
            sha1Hasher = null;
            return byteArrayToString(hashedDataArray);
        }
        #endregion

        #region // !++ SHA256
        /// <summary>
        /// SHA256 Hash Code
        /// </summary>
        /// <param name="target">변환할 문자열</param>
        /// <returns>변환 문자열 반환</returns>
        public String SHA256(String target)
        {
            var encoder = new UTF8Encoding();
            var sha256Hasher = new SHA256Managed();
            var hashDataArray = sha256Hasher.ComputeHash(encoder.GetBytes(target));
            encoder = null;
            sha256Hasher = null;
            return byteArrayToString(hashDataArray);
        }
        #endregion

        #region // !++ SHA384
        /// <summary>
        /// SHA384 Hash Code
        /// </summary>
        /// <param name="target">변환할 문자열</param>
        /// <returns>변환 문자열 반환</returns>
        public String SHA384(String target)
        {
            var encoder = new UTF8Encoding();
            var sha384Hasher = new SHA384Managed();
            var hashDataArray = sha384Hasher.ComputeHash(encoder.GetBytes(target));
            encoder = null;
            sha384Hasher = null;
            return byteArrayToString(hashDataArray);
        }
        #endregion

        #region // !++ SHA512
        /// <summary>
        /// SHA512 Hash Code
        /// </summary>
        /// <param name="target">변환할 문자열</param>
        /// <returns>변환 문자열 반환</returns>
        public String SHA512(String target)
        {
            var encoder = new UTF8Encoding();
            var sha512Hasher = new SHA512Managed();
            var hashDataArray = sha512Hasher.ComputeHash(encoder.GetBytes(target));
            encoder = null;
            sha512Hasher = null;
            return byteArrayToString(hashDataArray);
        }
        #endregion

        #region // !++ byteArrayToString
        /// <summary>
        /// byteArrayToString
        /// </summary>
        /// <param name="targetArray"></param>
        /// <returns></returns>
        private String byteArrayToString(byte[] targetArray)
        {
            var sb = new StringBuilder("");
            for (int i = 0; i < targetArray.Length; i++)
            {
                sb.Append(targetArray[i].ToString("X2"));
            }
            return sb.ToString();
        }
        #endregion

    }
    #endregion

}
