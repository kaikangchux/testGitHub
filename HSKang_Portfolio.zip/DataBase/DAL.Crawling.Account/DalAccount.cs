﻿using System;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Account;
using Lib.Crawling.Library.Models.AccountDB;

using MySql.Data.MySqlClient;

namespace DAL.Crawling.Account
{

    #region // !++ DalAccount
    /// <summary>
    /// DalAccount
    /// </summary>
    public class DalAccount
    {

        #region // !++ DAL_Member_IDCheck_Sel (계정 중복확인)
        /// <summary>
        /// 계정 중복확인
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <returns></returns>
        public async Task<ResultEntity<Int32>> DAL_Member_IDCheck_Sel(DBConnectionEntity dbConnectionEntity, tbMember dbMember)
        {

            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_Member_IDCheck_Sel";
            using (var connection = new MySqlConnection(dbConnectionEntity.AccountDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_iPlatFormSeq", MySqlDbType.Int32).Value = dbMember.iPlatFormSeq;
                    command.Parameters.Add("@p_vcGuid", MySqlDbType.VarChar, 32).Value = dbMember.vcGuid;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteNonQueryAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Member_Ins (회원[계정] 정보 등록)
        /// <summary>
        /// 회원[계정] 정보 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbMemberDataContainer"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int64>> DAL_Member_Ins(DBConnectionEntity dbConnectionEntity, tbMemberDataContainer dbMemberDataContainer)
        {
            var getResult = new ResultEntity<Int64>();
            var storedProcedure = "usp_Member_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.AccountDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_iPlatFormSeq", MySqlDbType.Int32).Value = dbMemberDataContainer.TbMember.iPlatFormSeq;
                    command.Parameters.Add("@p_vcGuid", MySqlDbType.VarChar, 32).Value = dbMemberDataContainer.TbMember.vcGuid;
                    command.Parameters.Add("@p_vcEmail", MySqlDbType.VarChar, 128).Value = dbMemberDataContainer.TbMember.vcEmail;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 64).Value = dbMemberDataContainer.TbMember.vcName;
                    command.Parameters.Add("@p_cBirthYear", MySqlDbType.VarChar, 4).Value = dbMemberDataContainer.TbMember.cBirthYear;
                    command.Parameters.Add("@p_cBirthMonth", MySqlDbType.VarChar, 2).Value = dbMemberDataContainer.TbMember.cBirthMonth;
                    command.Parameters.Add("@p_cBirthDay", MySqlDbType.VarChar, 2).Value = dbMemberDataContainer.TbMember.cBirthDay;
                    command.Parameters.Add("@p_tiGender", MySqlDbType.Byte).Value = dbMemberDataContainer.TbMember.tiGender;
                    command.Parameters.Add("@p_tiOrganization", MySqlDbType.Byte).Value = dbMemberDataContainer.TbMember.tiOrganization;
                    command.Parameters.Add("@p_siCountrySeq", MySqlDbType.Int16).Value = dbMemberDataContainer.TbMemberDetail.siCountrySeq;
                    command.Parameters.Add("@p_vcCity", MySqlDbType.VarChar, 64).Value = dbMemberDataContainer.TbMemberDetail.vcCity;
                    command.Parameters.Add("@p_vcZipCode", MySqlDbType.VarChar, 8).Value = dbMemberDataContainer.TbMemberDetail.vcZipCode;
                    command.Parameters.Add("@p_vcAddressFront", MySqlDbType.VarChar, 128).Value = dbMemberDataContainer.TbMemberDetail.vcAddressFront;
                    command.Parameters.Add("@p_vcAddressBack", MySqlDbType.VarChar, 128).Value = dbMemberDataContainer.TbMemberDetail.vcAddressBack;
                    command.Parameters.Add("@p_tiMemberStatus", MySqlDbType.Byte).Value = dbMemberDataContainer.TbMemberDetail.tiMemberStatus;
                    command.Parameters.Add("@p_tiEmailAgree", MySqlDbType.Byte).Value = dbMemberDataContainer.TbMemberDetail.tiEmailAgree;
                    command.Parameters.Add("@p_tiSmsAgress", MySqlDbType.Byte).Value = dbMemberDataContainer.TbMemberDetail.tiSmsAgress;
                    command.Parameters.Add("@p_vcPhoneCountry", MySqlDbType.VarChar, 4).Value = dbMemberDataContainer.TbMemberContact.vcPhoneCountry;
                    command.Parameters.Add("@p_vcPhoneFirst", MySqlDbType.VarChar, 4).Value = dbMemberDataContainer.TbMemberContact.vcPhoneFirst;
                    command.Parameters.Add("@p_vcPhoneSecond", MySqlDbType.VarChar, 4).Value = dbMemberDataContainer.TbMemberContact.vcPhoneSecond;
                    command.Parameters.Add("@p_vcPhoneThird", MySqlDbType.VarChar, 4).Value = dbMemberDataContainer.TbMemberContact.vcPhoneThird;
                    command.Parameters.Add("@p_vcMobileFirst", MySqlDbType.VarChar, 4).Value = dbMemberDataContainer.TbMemberContact.vcMobileFirst;
                    command.Parameters.Add("@p_vcMobileSecond", MySqlDbType.VarChar, 4).Value = dbMemberDataContainer.TbMemberContact.vcMobileSecond;
                    command.Parameters.Add("@p_vcMobileThird", MySqlDbType.VarChar, 4).Value = dbMemberDataContainer.TbMemberContact.vcMobileThird;
                    command.Parameters.Add("@p_vcPassword", MySqlDbType.VarChar, 64).Value = dbMemberDataContainer.TbMemberPassword.vcPassword;
                    command.Parameters.Add("@p_vcPersonName", MySqlDbType.VarChar, 32).Value = dbMemberDataContainer.TbMemberOrganization.vcPersonName;
                    command.Parameters.Add("@p_vcBusiness", MySqlDbType.VarChar, 64).Value = dbMemberDataContainer.TbMemberOrganization.vcBusiness;
                    command.Parameters.Add("@p_vcOrganizationSerial", MySqlDbType.VarChar, 32).Value = dbMemberDataContainer.TbMemberOrganization.vcOrganizationSerial;
                    command.Parameters.Add("@p_vcAuth", MySqlDbType.VarChar, 256).Value = dbMemberDataContainer.TbMemberEmailAuth.vcAuth;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.gClass = Int64.Parse(command.Parameters["@p_biSeq"].Value.ToString());
                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Member_Login_Sel (로그인 정보)
        /// <summary>
        /// 로그인 정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <returns></returns>
        public async Task<ResultEntity<MemberLoginEntity>> DAL_Member_Login_Sel(DBConnectionEntity dbConnectionEntity, tbMember dbMember, tbMemberPassword dbMemberPassword)
        {

            var getResult = new ResultEntity<MemberLoginEntity>();
            var storedProcedure = "usp_Member_Login_Sel";
            using (var connection = new MySqlConnection(dbConnectionEntity.AccountDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_iPlatFormSeq", MySqlDbType.Int32).Value = dbMember.iPlatFormSeq;
                    command.Parameters.Add("@p_vcEmail", MySqlDbType.VarChar, 128).Value = dbMember.vcEmail;
                    command.Parameters.Add("@p_vcPassword", MySqlDbType.VarChar, 64).Value = dbMemberPassword.vcPassword;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 64).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_tiOrganization", MySqlDbType.Byte).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_tiMemberGrade", MySqlDbType.Byte).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_tiMemberStatus", MySqlDbType.Byte).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_dtLoginDate", MySqlDbType.DateTime).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteNonQueryAsync();
                    await command.Connection.CloseAsync();

                    var memberLoginEntity = new MemberLoginEntity()
                    {
                        biMemberSeq = Int64.Parse(command.Parameters["@p_biSeq"].Value.ToString()),
                        iPlatFormSeq = dbMember.iPlatFormSeq,
                        vcEmail = dbMember.vcEmail,
                        vcName = command.Parameters["@p_vcName"].Value.ToString(),
                        tiOrganization = Int16.Parse(command.Parameters["@p_tiOrganization"].Value.ToString()),
                        tiMemberGrade = Int16.Parse(command.Parameters["@p_tiMemberGrade"].Value.ToString()),
                        tiMemberStatus = Int16.Parse(command.Parameters["@p_tiMemberStatus"].Value.ToString()),
                        dtLoginDate = DateTime.Parse(command.Parameters["@p_dtLoginDate"].Value.ToString())
                    };
                    getResult.gClass = memberLoginEntity;
                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Member_Sel (회원[본인] 정보)
        /// <summary>
        /// 회원[본인] 정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbMember"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_Member_Sel(DBConnectionEntity dbConnectionEntity, tbMember dbMember)
        {

            var getResult = new DataSet();
            var storedProcedure = "CALL usp_Member_Sel(?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.AccountDBConnection))
            {
                var paramArray = new MySqlParameter[1];
                paramArray[0] = new MySqlParameter("@p_biSeq", MySqlDbType.Int64)
                {
                    Value = dbMember.biSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;

        }
        #endregion


        #region // !++ DAL_MemberEmailAuth_Upd (회원 E-mail 인증)
        /// <summary>
        /// 회원 E-mail 인증
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="memberEmailApprovalEntity"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<String>> DAL_MemberEmailAuth_Upd(DBConnectionEntity dbConnectionEntity, MemberEmailApprovalEntity memberEmailApprovalEntity)
        {
            var getResult = new ResultEntity<String>();
            var storedProcedure = "usp_MemberEmailAuth_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.AccountDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Value = memberEmailApprovalEntity.biMemberSeq;
                    command.Parameters.Add("@p_vcEmail", MySqlDbType.VarChar, 128).Value = memberEmailApprovalEntity.vcEmail;
                    command.Parameters.Add("@p_tiMemberStatus", MySqlDbType.Byte).Value = memberEmailApprovalEntity.tiMemberStatus;
                    command.Parameters.Add("@p_vcAuth", MySqlDbType.VarChar, 256).Value = memberEmailApprovalEntity.vcAuth;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 64).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.gClass = command.Parameters["@p_vcName"].Value.ToString();
                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion








        //******************************************************
        // 관리자(운영툴)
        //******************************************************


        #region // !++ DAL_ProhibitWords_Sel (금지어 정보)
        /// <summary>
        /// 금지어 정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_ProhibitWords_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {

            var getResult = new DataSet();
            var storedProcedure = "CALL usp_ProhibitWords_Sel(?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.AccountDBConnection))
            {
                var paramArray = new MySqlParameter[2];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;

        }
        #endregion


        #region // !++ DAL_ProhibitWords_Ins (금지어 등록)
        /// <summary>
        /// 금지어 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbProhibitWords"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_ProhibitWords_Ins(DBConnectionEntity dbConnectionEntity, tbProhibitWords dbProhibitWords)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_ProhibitWords_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.AccountDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_vcProhibitWords", MySqlDbType.VarChar, 32).Value = dbProhibitWords.vcProhibitWords;
                    command.Parameters.Add("@p_vcNote", MySqlDbType.VarChar, 256).Value = dbProhibitWords.vcNote;
                    command.Parameters.Add("@p_tiStatus", MySqlDbType.Bit).Value = dbProhibitWords.tiStatus;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbProhibitWords.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_ProhibitWords_Upd (금지어 수정)
        /// <summary>
        /// 금지어 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbProhibitWords"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_ProhibitWords_Upd(DBConnectionEntity dbConnectionEntity, tbProhibitWords dbProhibitWords)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_ProhibitWords_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.AccountDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_vcProhibitWords", MySqlDbType.VarChar, 32).Value = dbProhibitWords.vcProhibitWords;
                    command.Parameters.Add("@p_vcNote", MySqlDbType.VarChar, 256).Value = dbProhibitWords.vcNote;
                    command.Parameters.Add("@p_tiStatus", MySqlDbType.Bit).Value = dbProhibitWords.tiStatus;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbProhibitWords.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_ProhibitWords_Del (금지어 삭제)
        /// <summary>
        /// 금지어 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbProhibitWords"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_ProhibitWords_Del(DBConnectionEntity dbConnectionEntity, tbProhibitWords dbProhibitWords)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_ProhibitWords_Del";
            using (var connection = new MySqlConnection(dbConnectionEntity.AccountDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_vcProhibitWords", MySqlDbType.VarChar, 32).Value = dbProhibitWords.vcProhibitWords;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbProhibitWords.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Manager_Member_Sel (관리툴 => 회원 정보)
        /// <summary>
        /// 관리툴 => 회원 정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_Manager_Member_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {

            var getResult = new DataSet();
            var storedProcedure = "CALL usp_Manager_Member_Sel(?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.AccountDBConnection))
            {
                var paramArray = new MySqlParameter[2];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;

        }
        #endregion


        #region // !++ DAL_Manager_Member_Detail_Sel (관리툴 => 회원 상세 정보)
        /// <summary>
        /// 관리툴 => 회원 상세 정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbMember"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_Manager_Member_Detail_Sel(DBConnectionEntity dbConnectionEntity, tbMember dbMember)
        {

            var getResult = new DataSet();
            var storedProcedure = "CALL usp_Manager_Member_Detail_Sel(?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.AccountDBConnection))
            {
                var paramArray = new MySqlParameter[1];
                paramArray[0] = new MySqlParameter("@p_biSeq", MySqlDbType.Int64)
                {
                    Value = dbMember.biSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;

        }
        #endregion


    }
    #endregion

}
