﻿using System;
using System.Collections.Generic;
using System.Text;

using log4net.Appender;
using log4net.Core;
using log4net.Layout;

namespace Lib.Crawling.Library.Log
{

    /// <summary>
    /// 파일로 로그 남기기
    /// </summary>
    public class FileLogger : LoggerBase
    {
        protected string filePath = null;

        public FileLogger(string filePath) { this.filePath = filePath; }

        public override IAppender GetAppender()
        {
            var appender = new RollingFileAppender
            {
                Threshold = Level.All,
                Layout = new PatternLayout(logLayout),
                File = filePath,
                AppendToFile = true,
                RollingStyle = RollingFileAppender.RollingMode.Date,
                DatePattern = "_yyyyMMdd\".log\"",   // 날짜가 지나간 경우 이전 로그에 붙을 이름 구성
            };
            appender.ActivateOptions();
            return appender;
        }
    }

    /// <summary>
    /// 파일로 오류(Error) 로그 남기기
    /// </summary>
    public class FileLoggerForError : FileLogger
    {
        public FileLoggerForError(string filePath) : base(filePath) { }

        public override IAppender GetAppender()
        {
            var appender = new RollingFileAppender
            {
                Threshold = Level.Error,
                Layout = new PatternLayout(logLayout),
                // System.IO.Directory.GetCurrentDirectory() 이 값이 ASP.NET에서나 Winform등에서는 다를 수 있음. 다른곳에 가져다 쓰는경우 주의바람
                File = filePath,
                AppendToFile = true,
                RollingStyle = RollingFileAppender.RollingMode.Date,
                LockingModel = new FileAppender.MinimalLock(),
                DatePattern = "_yyyyMMdd\".log\"", // 시간이 지나간 경우 이전 로그에 붙을 이름 구성  
            };
            appender.ActivateOptions();
            return appender;
        }
    }

    /// <summary>
    /// 파일로 경고(Warning) 로그 남기기
    /// </summary>
    public class FileLoggerForWarn : FileLogger
    {
        public FileLoggerForWarn(string filePath) : base(filePath) { }

        public override IAppender GetAppender()
        {
            var appender = new RollingFileAppender
            {
                Threshold = Level.Warn,
                Layout = new PatternLayout(logLayout),
                // System.IO.Directory.GetCurrentDirectory() 이 값이 ASP.NET에서나 Winform등에서는 다를 수 있음. 다른곳에 가져다 쓰는경우 주의바람
                File = filePath,
                AppendToFile = true,
                RollingStyle = RollingFileAppender.RollingMode.Date,
                LockingModel = new FileAppender.MinimalLock(),
                DatePattern = "_yyyyMMdd\".log\"", // 시간이 지나간 경우 이전 로그에 붙을 이름 구성  
            };
            appender.ActivateOptions();
            return appender;
        }
    }

}
