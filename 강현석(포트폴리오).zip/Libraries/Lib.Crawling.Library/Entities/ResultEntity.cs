﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

using Newtonsoft.Json.Linq;

using Lib.Crawling.Library.Enum;

namespace Lib.Crawling.Library.Entities
{

    #region // !++ ResultEntity
    /// <summary>
    /// 결과값 Class
    /// </summary>
    /// <typeparam name="T">제네릭</typeparam>
    [Serializable]
    public class ResultEntity<T>
    {

        /// <summary>
        /// 결과 코드
        /// </summary>
        public EResultCode eCode { get; set; }

        /// <summary>
        /// Int32 결과값
        /// </summary>
        public Int32 result { get; set; }

        /// <summary>
        /// Int64 결과값
        /// </summary>
        public Int64 lresult { get; set; }

        /// <summary>
        /// Bool 결과값
        /// </summary>
        public Boolean bresult { get; set; }

        /// <summary>
        /// DB SP 에레메시지
        /// </summary>
        public String ErrorMsg { get; set; }

        /// <summary>
        /// General Class
        /// </summary>
        public T gClass { get; set; }

        public ResultEntity()
        {
            result = 0;
            lresult = 0;
            bresult = false;
            ErrorMsg = String.Empty;
            ConstructorInfo constuctor = typeof(T).GetConstructor(Type.EmptyTypes);
            if (null != constuctor)
                gClass = (T)constuctor.Invoke(null);
            else
                gClass = default(T);
        }
        ~ResultEntity()
        {
            result = 0;
            lresult = 0;
            bresult = false;
            ErrorMsg = String.Empty;
            gClass = default(T);
        }
    }
    #endregion


    #region // !++ ResultClientEntity
    /// <summary>
    /// Angular client api return 정보
    /// </summary>
    [Serializable]
    public class ResultClientEntity<T>
    {

        /// <summary>
        /// API 호출 성공 여부
        /// </example>
        /// <example>
        /// true
        /// false
        /// </example>
        public bool success;

        /// <summary>
        /// API 결과 메시지
        /// </summary>
        /// <example>
        /// "Load Characters info successful"
        /// "API Internal Error : Failed to load characters info"
        /// </example>
        public String msg;

        /// <summary>
        /// 에러 코드 (isSuccess == false일 때만 존재)
        /// </summary>
        public String error;

        /// <summary>
        /// API가 제공하는 데이터들 (isSuccess == true일 때만 존재)
        /// </summary>
        public T data;

        public ResultClientEntity()
        {
            success = false;
            msg = String.Empty;
            error = String.Empty;
            // data = null;
            ConstructorInfo constuctor = typeof(T).GetConstructor(Type.EmptyTypes);
            if (null != constuctor)
                data = (T)constuctor.Invoke(null);
            else
                data = default(T);
        }
        ~ResultClientEntity()
        {
            success = false;
            msg = String.Empty;
            error = String.Empty;
            data = default(T);
        }

    }
    #endregion

}
