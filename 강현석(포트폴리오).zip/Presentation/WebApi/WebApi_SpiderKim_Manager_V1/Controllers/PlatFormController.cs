﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;

using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Manager;
using Lib.Crawling.Library.Entities.Crawling;
using Lib.Crawling.Library.Utilities;
using Lib.Crawling.Library.Log;
using Lib.Crawling.Library.DataContainers;

using WebApi_SpiderKim_Manager_V1.Handlers;
using WebApi_SpiderKim_Manager_V1.WebUtilities;

namespace WebApi_SpiderKim_Manager_V1.Controllers
{

    #region // !++ PlatFormController
    /// <summary>
    /// PlatFormController
    /// </summary>
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class PlatFormController : ControllerBase
    {

        #region // !++ Event handler(funtions)
        /// <summary>
        /// StaticDataHandler
        /// </summary>
        public StaticDataHandler staticDataHandler = new StaticDataHandler();

        /// <summary>
        /// LibUtility
        /// </summary>
        public LibUtility libUtility = new LibUtility();

        /// <summary>
        /// LibWebUtility
        /// </summary>
        public LibWebUtility libWebUtility = new LibWebUtility();

        /// <summary>
        /// LibraryController
        /// </summary>
        public LibraryController libraryController = new LibraryController();
        #endregion


        #region // !++ GetPlatFormList (플랫폼 리스트)
        /// <summary>
        /// 플랫폼 리스트
        /// </summary>
        /// <returns></returns>
        [HttpGet("PlatFormList")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> GetPlatFormList([FromQuery] Int32 page, Int32 pageSize)
        {

            // Return message
            var resultClient = new ResultClientEntity<ListPageDataContainer<List<PlatFormEntity>>>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion

                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ Parameter value
                if (libUtility.IsSpace(libWebUtility.OnNullCheckInt(page.ToString()).ToString()))
                    page = 1;

                if (libUtility.IsSpace(pageSize.ToString()))
                    pageSize = 20;
                #endregion

                #region // !++ DB 정보가져오기
                var pageModel = new PageDBEntity()
                {
                    page = page,
                    pageSize = pageSize
                };
                var resultData = await CrawlingHandler.GetPlatFormList(dbConnectionEntity, pageModel);
                #endregion

                #region // !++ Client message
                resultClient.success = true;
                resultClient.msg = String.Empty;
                resultClient.error = String.Empty;
                resultClient.data = resultData;
                #endregion

                return Ok(resultClient);

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API GetPlatFormList : \n [Page:{0}], \n [PageSize:{1}], \n {2}, \n {3}",
                                        page, pageSize, exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }

        }
        #endregion


        #region // !++ GetPlatFormInfo (플랫폼 상세정보)
        /// <summary>
        /// 플랫폼 상세정보
        /// </summary>
        /// <returns></returns>
        [HttpGet("PlatFormDetail/{id:int}")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> GetPlatFormInfo(Int32 id)
        {

            // Return message
            var resultClient = new ResultClientEntity<PlatFormEntity>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ Data struct 변경
                var model = new PlatFormEntity()
                {
                    iSeq = id
                };
                #endregion

                #region // !++ 정보가져오기
                var resultData = await CrawlingHandler.GetPlatFormDetail(dbConnectionEntity, model);
                #endregion

                #region // !++ Client message
                if (resultData != null)
                {
                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = resultData;
                    if (resultClient.data.iSeq == 0)
                    {
                        resultClient.data = null;
                    }
                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API GetPlatFormInfo : \n [ID:{0}], \n {1}, \n {2}",
                                        id.ToString(), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }
        }
        #endregion


        #region // !++ SetPlatFormRegist (플랫폼 등록)
        /// <summary>
        /// 플랫폼 등록
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("platformregist")]
        [Produces("application/json", Type = typeof(PlatFormEntity))]
        [Consumes("application/json")] // application/xml
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> SetPlatFormRegist([FromBody] PlatFormEntity model)
        {

            // Return message
            var resultClient = new ResultClientEntity<Int32?>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ 관리자 정보 담기
                model.iManagerSeq = managerLogin.adminSeq;
                #endregion

                #region // !++ DB 등록하기
                var resultData = await CrawlingHandler.SetPlatFormRegist(dbConnectionEntity, model);
                #endregion

                #region // !++ Client message
                if (resultData == 1)
                {
                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = null;

                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API SetPlatFormRegist : \n [PlatFormEntity:{0}], \n {1}, \n {2}",
                                        libUtility.ToJson(model), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }
        }
        #endregion


        #region // !++ SetPlatFormModify (플랫폼 수정)
        /// <summary>
        /// 플랫폼 수정
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPut("platformmodify")]
        [Produces("application/json", Type = typeof(FAQCodeEntity))]
        [Consumes("application/json")] // application/xml
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> SetPlatFormModify([FromBody] PlatFormEntity model)
        {

            // Return message
            var resultClient = new ResultClientEntity<Int32?>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ 관리자 정보 담기
                model.iManagerSeq = managerLogin.adminSeq;
                #endregion

                #region // !++ DB 등록하기
                var resultData = await CrawlingHandler.SetPlatFormModify(dbConnectionEntity, model);
                #endregion

                #region // !++ Client message
                if (resultData == 1)
                {
                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = null;

                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API SetPlatFormModify : \n [PlatFormEntity:{0}], \n {1}, \n {2}",
                                        libUtility.ToJson(model), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }
        }
        #endregion


        #region // !++ SetPlatFormDelete (플랫폼 삭제)
        /// <summary>
        /// 플랫폼 삭제
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpDelete("platformdelete/{id:int}")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> SetPlatFormDelete(Int32 id)
        {

            // Return message
            var resultClient = new ResultClientEntity<Int32?>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ 정보 담기
                var model = new PlatFormEntity()
                {
                    iSeq = id,
                    iManagerSeq = managerLogin.adminSeq
                };
                #endregion

                #region // !++ DB 등록하기
                var resultData = await CrawlingHandler.SetPlatFormDelete(dbConnectionEntity, model);
                #endregion

                #region // !++ Client message
                if (resultData == 1)
                {
                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = null;

                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API SetPlatFormDelete : \n [iSeq:{0}], \n {1}, \n {2}",
                                        id, exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }
        }
        #endregion


        #region // !++ GetPlatFormApiList (플랫폼 API 리스트)
        /// <summary>
        /// 플랫폼 API 리스트
        /// </summary>
        /// <returns></returns>
        [HttpGet("PlatFormApiList")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> GetPlatFormApiList([FromQuery] Int32 page, Int32 pageSize)
        {

            // Return message
            var resultClient = new ResultClientEntity<ListPageDataContainer<List<PlatFormApiEntity>>>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion

                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ Parameter value
                if (libUtility.IsSpace(libWebUtility.OnNullCheckInt(page.ToString()).ToString()))
                    page = 1;

                if (libUtility.IsSpace(pageSize.ToString()))
                    pageSize = 20;
                #endregion

                #region // !++ DB 정보가져오기
                var pageModel = new PageDBEntity()
                {
                    page = page,
                    pageSize = pageSize
                };
                var resultData = await CrawlingHandler.GetPlatFormApiList(dbConnectionEntity, pageModel);
                #endregion

                #region // !++ Client message
                resultClient.success = true;
                resultClient.msg = String.Empty;
                resultClient.error = String.Empty;
                resultClient.data = resultData;
                #endregion

                return Ok(resultClient);

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API GetPlatFormApiList : \n [Page:{0}], \n [PageSize:{1}], \n {2}, \n {3}",
                                        page, pageSize, exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }

        }
        #endregion


        #region // !++ GetPlatFormApiInfo (플랫폼 API 상세정보)
        /// <summary>
        /// 플랫폼 API 상세정보
        /// </summary>
        /// <returns></returns>
        [HttpGet("PlatFormApiDetail/{id:int}")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> GetPlatFormApiInfo(Int32 id)
        {

            // Return message
            var resultClient = new ResultClientEntity<PlatFormApiEntity>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ Data struct 변경
                var model = new PlatFormApiEntity()
                {
                    iSeq = id
                };
                #endregion

                #region // !++ 정보가져오기
                var resultData = await CrawlingHandler.GetPlatFormApiDetail(dbConnectionEntity, model);
                #endregion

                #region // !++ Client message
                if (resultData != null)
                {
                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = resultData;
                    if (resultData.iSeq == 0)
                    {
                        resultClient.data = null;
                    }
                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API GetPlatFormApiInfo : \n [ID:{0}], \n {1}, \n {2}",
                                        id.ToString(), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }
        }
        #endregion


        #region // !++ SetPlatFormApiRegist (플랫폼 API 등록)
        /// <summary>
        /// 플랫폼 API 등록
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("platformapiregist")]
        [Produces("application/json", Type = typeof(PlatFormApiEntity))]
        [Consumes("application/json")] // application/xml
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> SetPlatFormApiRegist([FromBody] PlatFormApiEntity model)
        {

            // Return message
            var resultClient = new ResultClientEntity<Int32?>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ 관리자 정보 담기
                model.iManagerSeq = managerLogin.adminSeq;
                #endregion

                #region // !++ DB 등록하기
                var resultData = await CrawlingHandler.SetPlatFormApiRegist(dbConnectionEntity, model);
                #endregion

                #region // !++ Client message
                if (resultData == 1)
                {
                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = null;

                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API SetPlatFormApiRegist : \n [PlatFormApiEntity:{0}], \n {1}, \n {2}",
                                        libUtility.ToJson(model), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }
        }
        #endregion


        #region // !++ SetPlatFormApiModify (플랫폼 API 수정)
        /// <summary>
        /// 플랫폼 API 수정
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPut("platformapimodify")]
        [Produces("application/json", Type = typeof(PlatFormApiEntity))]
        [Consumes("application/json")] // application/xml
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> SetPlatFormApiModify([FromBody] PlatFormApiEntity model)
        {

            // Return message
            var resultClient = new ResultClientEntity<Int32?>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ 관리자 정보 담기
                model.iManagerSeq = managerLogin.adminSeq;
                #endregion

                #region // !++ DB 등록하기
                var resultData = await CrawlingHandler.SetPlatFormApiModify(dbConnectionEntity, model);
                #endregion

                #region // !++ Client message
                if (resultData == 1)
                {
                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = null;

                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API SetPlatFormApiModify : \n [PlatFormApiEntity:{0}], \n {1}, \n {2}",
                                        libUtility.ToJson(model), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }
        }
        #endregion


        #region // !++ SetPlatFormApiDelete (플랫폼 API 삭제)
        /// <summary>
        /// 플랫폼 API 삭제
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpDelete("platformapidelete/{id:int}/{secondid:int}")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> SetPlatFormApiDelete(Int32 id, Int32 secondid)
        {

            // Return message
            var resultClient = new ResultClientEntity<Int32?>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ 정보 담기
                var model = new PlatFormApiEntity()
                {
                    iSeq = id,
                    iPlatFormSeq = secondid,
                    iManagerSeq = managerLogin.adminSeq
                };
                #endregion

                #region // !++ DB 등록하기
                var resultData = await CrawlingHandler.SetPlatFormApiDelete(dbConnectionEntity, model);
                #endregion

                #region // !++ Client message
                if (resultData == 1)
                {
                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = null;

                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API SetPlatFormApiDelete : \n [iSeq:{0}], \n {1}, \n {2}",
                                        id, exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }
        }
        #endregion

    }
    #endregion

}