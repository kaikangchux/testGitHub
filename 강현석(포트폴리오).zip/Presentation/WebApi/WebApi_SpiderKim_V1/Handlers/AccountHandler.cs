﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Account;
using Lib.Crawling.Library.DataContainers;
using Lib.Crawling.Library.Log;

namespace WebApi_SpiderKim_V1.Handlers
{

    #region // !++ AccountHandler
    /// <summary>
    /// AccountHandler
    /// </summary>
    public class AccountHandler : Handler
    {

        #region // !++ SetMemberRegist (회원가입[자체])
        /// <summary>
        /// 회원가입(자체)
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="memberDataContainer"></param>
        /// <returns></returns>
        public static async Task<ResultEntity<Int64>> SetMemberRegist(DBConnectionEntity dbConnectionEntity, MemberDataContainer memberDataContainer)
        {
            var result = new ResultEntity<Int64>();

            try
            {
                result = await bllAccount.BLL_Member_Ins(dbConnectionEntity, memberDataContainer);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetMemberRegist : \n [DBConnectionEntity:{0}], \n [MemberDataContainer:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(memberDataContainer), exc.Message, exc.StackTrace);

                return result;
            }
            return result;
        }
        #endregion


        #region // !++ GetMemberLogin (회원 로그인[자체])
        /// <summary>
        /// 회원 로그인[자체]
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="memberEntity"></param>
        /// <param name="memberPasswordEntity"></param>
        /// <returns></returns>
        public static async Task<ResultEntity<MemberLoginEntity>> GetMemberLogin(DBConnectionEntity dbConnectionEntity, MemberEntity memberEntity, MemberPasswordEntity memberPasswordEntity)
        {

            // Return value
            var resultDataContainer = new ResultEntity<MemberLoginEntity>();

            try
            {

                var resultData = await bllAccount.BLL_Member_Login_Sel(dbConnectionEntity, memberEntity, memberPasswordEntity);
                if (resultData == null || resultData.result < 1)
                {
                    resultDataContainer.result = -99;
                }
                else
                {
                    // 로그인 struct 변경
                    var memberLogin = new MemberLoginEntity()
                    {
                        biMemberSeq = resultData.gClass.biMemberSeq,
                        iPlatFormSeq = resultData.gClass.iPlatFormSeq,
                        vcEmail = resultData.gClass.vcEmail,
                        vcName = resultData.gClass.vcName,
                        tiOrganization = resultData.gClass.tiOrganization,
                        tiMemberGrade = resultData.gClass.tiMemberGrade,
                        tiMemberStatus = resultData.gClass.tiMemberStatus,
                        dtLoginDate = resultData.gClass.dtLoginDate,
                        isLogin = true
                    };
                    resultDataContainer.bresult = true;
                    resultDataContainer.result = resultData.result;
                    resultDataContainer.gClass = memberLogin;
                }

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetMemberLogin : \n [DBConnectionEntity:{0}], \n [MemberEntity:{1}], \n [MemberPasswordEntity:{2}], \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(memberEntity), libUtility.ToJson(memberPasswordEntity), exc.Message, exc.StackTrace);

                return resultDataContainer;
            }

            return resultDataContainer;

        }
        #endregion


        #region // !++ SetMemberEmailAuth (회원 E-mail 인증)
        /// <summary>
        /// 회원 E-mail 인증
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="authEmailEntity"></param>
        /// <returns></returns>
        public static async Task<ResultEntity<String>> SetMemberEmailAuth(DBConnectionEntity dbConnectionEntity, AuthEmailEntity authEmailEntity)
        {
            var result = new ResultEntity<String>();

            try
            {
                result = await bllAccount.BLL_MemberEmailAuth_Upd(dbConnectionEntity, authEmailEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetMemberEmailAuth : \n [DBConnectionEntity:{0}], \n [AuthEmailEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(authEmailEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;
        }
        #endregion

    }
    #endregion

}
