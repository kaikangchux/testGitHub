import { Component, OnInit } from '@angular/core';
import { Title } from "@angular/platform-browser";
import { TranslateService } from '@ngx-translate/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { ConfigService } from './config';

@Component({
    selector: 'app-content',
    templateUrl: './contents.component.html',
    styleUrls: []
})
export class ContentsComponent implements OnInit
{
    routeArr:string[] = ['/login', '/register'];

    constructor(private titleService:Title,
                private translate:TranslateService,
                private router:Router,
                private config:ConfigService){

        this.router.events.pipe(
            filter(event => event instanceof NavigationEnd)
        ).subscribe((event: NavigationEnd) => {
            //let url = event.url;
            let url = event.urlAfterRedirects;
            this.updateUISetting(url);
            url = (url.length > 1) ? (url.slice(1)).toUpperCase() : url;
            //console.log(url);
            let title = this.translate.instant('TITLE.' + url);
            if(title == 'TITLE.' + url){
                title = this.translate.instant('TITLE./');
            }
            this.titleService.setTitle(title);
        });
    }

    ngOnInit():void
    {
        // this.router.events.pipe(
        //     filter(event => event instanceof NavigationEnd)
        // ).subscribe((event: NavigationEnd) => {
        //     //let url = event.url;
        //     let url = event.urlAfterRedirects;
        //     this.updateUISetting(url);
        //     url = (url.length > 1) ? (url.slice(1)).toUpperCase() : url;
        //     //console.log(url);
        //     this.titleService.setTitle(this.translate.instant("TITLE." + url));
        // });
    }

    updateUISetting(url:string):void{
        let uiSet = {header: 'show', footer: 'show', dashboard:'hide'};
        if(url.includes(ConfigService.DASH_BOARD_ROUTE)){
            uiSet = {header: 'hide', footer: 'hide', dashboard:'show'};
        }else{
            if(ConfigService.SPECIAL_UISET_ROUTE.indexOf(url) > -1){
                uiSet = {header: 'hide', footer: 'hide', dashboard:'hide'};
            }
        }
        this.config.setSettings({layout: uiSet});
    }
}