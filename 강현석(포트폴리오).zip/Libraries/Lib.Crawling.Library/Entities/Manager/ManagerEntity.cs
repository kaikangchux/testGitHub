﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lib.Crawling.Library.Entities.Manager
{

    #region // !++ ManagerEntity
    /// <summary>
    /// 관리자
    /// </summary>
    [Serializable]
    public class ManagerEntity
    {

        /// <summary>
        /// 계정 고유번호
        /// </summary>
        public Int32 iSeq { get; set; }

        /// <summary>
        /// 계정
        /// </summary>
        public String vcManagerID { get; set; }

        /// <summary>
        /// 이름
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 비밀번호
        /// </summary>
        public String vcPassword { get; set; }

        /// <summary>
        /// E-mail ID
        /// </summary>
        public String vcEmailID { get; set; }

        /// <summary>
        /// E-mail address
        /// </summary>
        public String vcEmailAddress { get; set; }

        /// <summary>
        /// 연락처
        /// </summary>
        public String vcPhone { get; set; }

        /// <summary>
        /// 등급(팀- 10:프로그램, 20:기획)
        /// </summary>
        public Int16 tiGrade { get; set; }

        /// <summary>
        /// 접속IP
        /// </summary>
        public String vcIP { get; set; }

        /// <summary>
        /// 등록일
        /// </summary>
        public DateTime dtRegDate { get; set; }

        /// <summary>
        /// Email 배열변수
        /// </summary>
        // public String[] vcEmailS { get; set; }

        /// <summary>
        /// 연락처 배열변수
        /// </summary>
        // public String[] vcPhoneS { get; set; }

        public ManagerEntity()
        {
            iSeq = 0;
            vcManagerID = String.Empty;
            vcPassword = String.Empty;
            vcName = String.Empty;
            vcEmailID = String.Empty;
            vcEmailAddress = String.Empty;
            vcPhone = String.Empty;
            tiGrade = 0;
            vcIP = String.Empty;
            dtRegDate = DateTime.MinValue;
            // vcEmailS = null;
            // vcPhoneS = null;
        }
        ~ManagerEntity()
        {
            iSeq = 0;
            vcManagerID = String.Empty;
            vcPassword = String.Empty;
            vcName = String.Empty;
            vcEmailID = String.Empty;
            vcEmailAddress = String.Empty;
            vcPhone = String.Empty;
            tiGrade = 0;
            vcIP = String.Empty;
            dtRegDate = DateTime.MinValue;
            // vcEmailS = null;
            // vcPhoneS = null;
        }

    }
    #endregion


    #region // !++ ManagerLoginEntity
    /// <summary>
    /// 관리자 로그인 정보
    /// </summary>
    [Serializable]
    public class ManagerLoginEntity
    {

        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 adminSeq { get; set; }

        /// <summary>
        /// 관리자 계정
        /// </summary>
        public String adminId { get; set; }

        /// <summary>
        /// 관리자 이름
        /// </summary>
        public String adminName { get; set; }

        /// <summary>
        /// 관리자 등급
        /// </summary>
        public Int16 adminGrade { get; set; }

        /// <summary>
        /// 로그인 여부
        /// </summary>
        public Boolean isLogin { get; set; }

        public ManagerLoginEntity()
        {
            adminSeq = 0;
            adminId = String.Empty;
            adminName = String.Empty;
            adminGrade = 0;
            isLogin = false;
        }
        ~ManagerLoginEntity()
        {
            adminSeq = 0;
            adminId = String.Empty;
            adminName = String.Empty;
            adminGrade = 0;
            isLogin = false;
        }

    }
    #endregion


    #region // !++ ManagerLoginFormEntity
    /// <summary>
    /// 로그인 Form
    /// </summary>
    [Serializable]
    public class ManagerLoginFormEntity
    {

        /// <summary>
        /// 계정
        /// </summary>
        public String vcManagerID { get; set; }

        /// <summary>
        /// 비밀번호
        /// </summary>
        public String vcPassword { get; set; }

        /// <summary>
        /// 접속IP
        /// </summary>
        // public String vcIP { get; set; }

        public ManagerLoginFormEntity()
        {
            vcManagerID = String.Empty;
            vcPassword = String.Empty;
            // vcIP = String.Empty;
        }
        ~ManagerLoginFormEntity()
        {
            vcManagerID = String.Empty;
            vcPassword = String.Empty;
            // vcIP = String.Empty;
        }

    }
    #endregion


    #region // !++ ManagerLoginTokenEntity
    /// <summary>
    /// 매니저 토큰 정보
    /// </summary>
    [Serializable]
    public class ManagerLoginTokenEntity
    {

        /// <summary>
        /// Token 정보
        /// </summary>
        public String Token { get; set; }

        /// <summary>
        /// Token 만료일
        /// </summary>
        public DateTime? ExpiredDate { get; set; }

        public ManagerLoginTokenEntity()
        {
            Token = String.Empty;
            ExpiredDate = null;
        }
        ~ManagerLoginTokenEntity()
        {
            Token = String.Empty;
            ExpiredDate = null;
        }

    }
    #endregion

}
