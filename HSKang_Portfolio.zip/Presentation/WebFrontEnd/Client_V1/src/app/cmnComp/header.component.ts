import { Component } from '@angular/core';
import { MemberService } from '../service';

@Component({
    selector: 'app-home-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss']
})
export class HeaderComponent 
{
    isLogin:boolean = false;

    constructor(private memberService:MemberService)
    {
        this.isLogin = memberService.isLoginStatus();
        //TODO
        //this.isLogin = true;
    }

    logout():void {
        this.memberService.logout();
        //TODO
        //this.isLogin = false;
    }
}