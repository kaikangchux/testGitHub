import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import * as CryptoJS from 'crypto-js';
import base64url from 'base64url';
import * as jwt_decode from 'jwt-decode';

import { CommonService } from './common.service';
import { ConfigService } from '../config';
import { MemberModel, MemberContainer, MemberLoginModel, MemberLoginFormModel } from '../model';

@Injectable({
    providedIn: 'root'
})
export class MemberService
{
    loginInfo:MemberModel = null;//TODO check to need

    constructor(private router:Router,
                private cmnService:CommonService,
                private http:HttpClient){ }

    login(logonForm:MemberLoginFormModel):void
    {
        // console.log(logonForm);
        const url = this.cmnService.requestUrl(`/api/login/login`);
        this.http.post<any>(url, logonForm)
                     .subscribe((response) => this.loginProc(response));
    }

    loginProc(res:any):void
    {
        if(!res.success){
            alert(res.msg);
            this.logout();
            return;
        }

        let data = ((res.data.token)).split('.');
        var signature = base64url.fromBase64((CryptoJS.HmacSHA256(data[0] + "." + data[1], ConfigService.CRYPT_KEY).toString(CryptoJS.enc.Base64)));

        if(data[2] != signature){
            //TODO 에러 코드나 메세지가 정의되면 alert 추가
            this.logout();
            return;
        }

        localStorage.setItem(ConfigService.USER_LOCAL_STORAGE_NAME, res.data.token);
        this.router.navigate(['']);
    }

    isLoginStatus():boolean {
        let tmp =  localStorage.getItem(ConfigService.USER_LOCAL_STORAGE_NAME);
        return (tmp === undefined || tmp === null) ? false : true;
    }

    getLoginUserInfo():MemberLoginModel
    {
        let token = localStorage.getItem(ConfigService.USER_LOCAL_STORAGE_NAME);

        if(!token){
            return null;
        }

        let payload = jwt_decode(token);
        return JSON.parse(payload.UserInfo); //TODO response property 확인 필요
    }

    logout(route:boolean=true):void
    {
        localStorage.removeItem(ConfigService.USER_LOCAL_STORAGE_NAME);
        if(route === true){
            this.router.navigate(['']);
        }
    }

    registerMember(member:MemberModel):Observable<any>
    {
        // console.log(member);
        const url = this.cmnService.requestUrl('/api/account/MemberRegist');
        return this.http.post(url, member);
    }

    registerOrganization(member:MemberContainer):Observable<any>
    {
        // console.log(member);
        const url = this.cmnService.requestUrl('/api/account/MemberOrganizationRegist');
        return this.http.post(url, member);
    }

    approvalEmail(key:string):Observable<any>
    {
        const url = this.cmnService.requestUrl('/api/account/emailapproval');
        const data = {authkey:key};
        return this.http.post<any>(url, data, {headers:new HttpHeaders().set('Content-Type', 'application/json')});
    }
}