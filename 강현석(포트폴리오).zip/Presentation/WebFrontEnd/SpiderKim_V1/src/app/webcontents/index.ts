export * from './home.component';
export * from './company.component';