// 제품문의답변
export class InquiryAnswerModel
{

  biInquirySeq: number;
  iManagerSeq: number;
  tiStatus: number;
  tDescription: string;
  dtRegDate: string;

  constructor() {
    this.biInquirySeq = 0;
    this.iManagerSeq = 0;
    this.tiStatus = 0;
    this.tDescription = '';
    this.dtRegDate = '';
  }
}
