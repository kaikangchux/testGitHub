// 회사조직구성원
export class CompanyPeopleModel
{

  iSeq: number;
  iCompanyGroupSeq: number;
  vcName: string;
  vcPosition: string;
  tDescription: string;
  vcFolder: string;
  vcImage: string;
  iManagerSeq: number;
  dtRegDate: string;

  constructor() {
    this.iSeq = 0;
    this.iCompanyGroupSeq = 0;
    this.vcName = '';
    this.vcPosition = '';
    this.tDescription = '';
    this.vcFolder = '';
    this.vcImage = '';
    this.iManagerSeq = 0;
    this.dtRegDate = '';
  }

}
