// 금지어
export class ProhibitWordsModel
{

  vcProhibitWords: string;
  vcNote: string;
  iManagerSeq: number;
  dtRegDate: string;

  constructor() {
    this.vcProhibitWords = '';
    this.vcNote = '';
    this.iManagerSeq = 0;
    this.dtRegDate = '';
  }
}
