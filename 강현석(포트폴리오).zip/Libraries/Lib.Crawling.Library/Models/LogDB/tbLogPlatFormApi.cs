﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.LogDB
{

    #region // !++ tbLogPlatFormApi
    /// <summary>
    /// 플랫폼API
    /// </summary>
    [Table("tbLogPlatFormApi")]
    public class tbLogPlatFormApi
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        /// <summary>
        /// 파티션 키(월별)
        /// </summary>
        public Int32 iPartKeyMonth { get; set; }

        [Index(1), Required]
        /// <summary>
        /// 트랜잭션ID
        /// </summary>
        public Int64 biTXIDX { get; set; }

        [Index(2), Required]
        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        [Required]
        /// <summary>
        /// 고유번호
        /// </summary>
        public Int32 iSeq { get; set; }

        [Required]
        /// <summary>
        /// 플랫폼 고유번호
        /// </summary>
        public Int32 iPlatFormSeq { get; set; }

        [Required, MinLength(2), MaxLength(128)]
        /// <summary>
        /// API경로(URL)
        /// </summary>
        public String vcApiUrl { get; set; }

        [Required, MinLength(2), MaxLength(128)]
        /// <summary>
        /// API계정
        /// </summary>
        public String vcID { get; set; }

        [Required, MinLength(2), MaxLength(256)]
        /// <summary>
        /// API보안키
        /// </summary>
        public String vcVerifyKey { get; set; }

        [Required]
        /// <summary>
        /// 사용여부(1:사용, 2:대기, 3:삭제)
        /// </summary>
        public Int16 tiStatus { get; set; }

        [Required]
        /// <summary>
        /// 로그분류(1:등록, 2:수정, 3:삭제)
        /// </summary>
        public Int16 tiType { get; set; }

        /// <summary>
        /// IP
        /// </summary>
        public String vcIP { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// UTC등록일시
        /// </summary>
        public DateTime dtUtcRegDate { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
