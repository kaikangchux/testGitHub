// 언어(다국어)코드
export class LanguageCodeModel
{

  vcLanguageCode: string;
  vcLanguageName: string;
  tiStatus: number;
  iManagerSeq: number;
  dtRegDate: string;

  constructor() {
    this.vcLanguageCode = '';
    this.vcLanguageName = '';
    this.tiStatus = 0;
    this.iManagerSeq = 0;
    this.dtRegDate = '';
  }
}
