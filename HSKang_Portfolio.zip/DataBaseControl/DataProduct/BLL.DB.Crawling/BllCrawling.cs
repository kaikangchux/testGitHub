﻿using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Data;

using Lib.Crawling.Library.Enum;
using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Account;
using Lib.Crawling.Library.Entities.Crawling;
using Lib.Crawling.Library.Entities.LogDB;
using Lib.Crawling.Library.DataContainers;
using Lib.Crawling.Library.Log;
using Lib.Crawling.Library.Models.CrawlingDB;

using BLL.DB.LogData;

namespace BLL.DB.Crawling
{

    #region // !++ BllCrawling
    /// <summary>
    /// BllCrawling
    /// </summary>
    public class BllCrawling : DataProvider.DataProvider
    {


        #region // !++ DataBaseControl => DataProduct => BllLogData
        /// <summary>
        /// BllLogData
        /// </summary>
        protected BllLogData bllLogData = new BllLogData();
        #endregion


        #region // !++ BLL_Board_Sel (게시판 목록 조회)
        /// <summary>
        /// 게시판 계정 목록 조회
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<BoardEntity>>> BLL_Board_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<BoardEntity>>();
            var dataList = new List<BoardEntity>();

            try
            {
                //+ DAL_Board_Sel
                using (var ds = await dalCrawling.DAL_Board_Sel(dbConnectionEntity, pageDBEntity))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var boardEntity = new BoardEntity()
                                {
                                    biSeq = Int64.Parse(dt.Rows[i]["biSeq"].ToString()),
                                    vcAccount = dt.Rows[i]["vcAccount"].ToString(),
                                    vcName = dt.Rows[i]["vcName"].ToString(),
                                    vcTitle = dt.Rows[i]["vcTitle"].ToString(),
                                    iRead = Int32.Parse(dt.Rows[i]["iRead"].ToString()),
                                    iCommentCnt = Int32.Parse(dt.Rows[i]["iCommentCnt"].ToString()),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(boardEntity);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_Board_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_Board_Ins (게시판 등록)
        /// <summary>
        /// 게시판 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="boardEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_Board_Ins(DBConnectionEntity dbConnectionEntity, BoardEntity boardEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbBoard()
                {
                    biMemberSeq = boardEntity.biMemberSeq,
                    vcAccount = boardEntity.vcAccount,
                    vcName = boardEntity.vcName,
                    vcTitle = boardEntity.vcTitle,
                    tDescription = boardEntity.tDescription,
                    vcIP = boardEntity.vcIP
                };
                #endregion
                result = await dalCrawling.DAL_Board_Ins(dbConnectionEntity, dbData);

                // DAL_Board_Ins 확인
                if (result.result < 1)
                {
                    // DAL_Board_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_Board_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_Board_Ins : \n [DBConnectionEntity:{0}], \n [BoardEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(boardEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_Board_Detail_Sel (게시판 상세정보)
        /// <summary>
        /// 게시판 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="boardEntity"></param>
        /// <returns></returns>
        public async Task<BoardEntity> BLL_Board_Detail_Sel(DBConnectionEntity dbConnectionEntity, BoardEntity boardEntity)
        {

            var getResult = new ResultEntity<BoardEntity>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbBoard()
                {
                    biSeq = boardEntity.biSeq
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalCrawling.DAL_Board_Detail_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ 게시판 상세정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            getResult.gClass = null;
                        }
                        else
                        {
                            var boardData = new BoardEntity()
                            {
                                vcAccount = dt.Rows[0]["vcAccount"].ToString(),
                                vcName = dt.Rows[0]["vcName"].ToString(),
                                vcTitle = dt.Rows[0]["vcTitle"].ToString(),
                                tDescription = dt.Rows[0]["tDescription"].ToString(),
                                iRead = Int32.Parse(dt.Rows[0]["iRead"].ToString()),
                                iCommentCnt = Int32.Parse(dt.Rows[0]["iCommentCnt"].ToString()),
                                dtRegDate = DateTime.Parse(dt.Rows[0]["dtRegDate"].ToString())
                            };
                            getResult.gClass = boardData;
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_Board_Detail_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_Board_Detail_Sel : \n [DBConnectionEntity:{0}], \n [BoardEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(boardEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;

        }
        #endregion


        #region // !++ BLL_Board_Read_Upd (게시판 정보 조회수 수정)
        /// <summary>
        /// 게시판 정보 조회수 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="boardEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_Board_Read_Upd(DBConnectionEntity dbConnectionEntity, BoardEntity boardEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbBoard()
                {
                    biSeq = boardEntity.biSeq
                };
                #endregion
                result = await dalCrawling.DAL_Board_Read_Upd(dbConnectionEntity, dbData);

                // DAL_Board_Read_Upd 확인
                if (result.result < 1)
                {
                    // DAL_Board_Read_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_Board_Read_Upd 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_Board_Read_Upd : \n [DBConnectionEntity:{0}], \n [BoardEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(boardEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_Board_Upd (게시판 정보 수정)
        /// <summary>
        /// 게시판 정보 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="boardEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_Board_Upd(DBConnectionEntity dbConnectionEntity, BoardEntity boardEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbBoard()
                {
                    biSeq = boardEntity.biSeq,
                    biMemberSeq = boardEntity.biMemberSeq,
                    vcTitle = boardEntity.vcTitle,
                    tDescription = boardEntity.tDescription
                };
                #endregion
                result = await dalCrawling.DAL_Board_Upd(dbConnectionEntity, dbData);

                // DAL_Board_Upd 확인
                if (result.result < 1)
                {
                    // DAL_Board_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_Board_Upd 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_Board_Upd : \n [DBConnectionEntity:{0}], \n [BoardEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(boardEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_Board_Del (게시판 정보 삭제)
        /// <summary>
        /// 게시판 정보 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="boardEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_Board_Del(DBConnectionEntity dbConnectionEntity, BoardEntity boardEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbBoard()
                {
                    biSeq = boardEntity.biSeq,
                    biMemberSeq = boardEntity.biMemberSeq
                };
                #endregion
                result = await dalCrawling.DAL_Board_Del(dbConnectionEntity, dbData);

                // DAL_Board_Del 확인
                if (result.result < 1)
                {
                    // DAL_Board_Del 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_Board_Del 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_Board_Del : \n [DBConnectionEntity:{0}], \n [BoardEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(boardEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_BoardComment_Ins (게시판 댓글 등록)
        /// <summary>
        /// 게시판 댓글 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="boardCommentEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_BoardComment_Ins(DBConnectionEntity dbConnectionEntity, BoardCommentEntity boardCommentEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbBoardComment()
                {
                    biBoardSeq = boardCommentEntity.biBoardSeq,
                    biMemberSeq = boardCommentEntity.biMemberSeq,
                    vcAccount = boardCommentEntity.vcAccount,
                    vcName = boardCommentEntity.vcName,
                    tDescription = boardCommentEntity.tDescription,
                    vcIP = boardCommentEntity.vcIP
                };
                #endregion
                result = await dalCrawling.DAL_BoardComment_Ins(dbConnectionEntity, dbData);

                // DAL_BoardComment_Ins 확인
                if (result.result < 1)
                {
                    // DAL_BoardComment_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_BoardComment_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_BoardComment_Ins : \n [DBConnectionEntity:{0}], \n [BoardCommentEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(boardCommentEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_BoardComment_Sel (게시판 댓글 목록정보)
        /// <summary>
        /// 게시판 댓글 목록정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="boardCommentEntity"></param>
        /// <returns></returns>
        public async Task<List<BoardCommentEntity>> BLL_BoardComment_Sel(DBConnectionEntity dbConnectionEntity, BoardCommentEntity boardCommentEntity)
        {

            var getResult = new ResultEntity<List<BoardCommentEntity>>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbBoardComment()
                {
                    biBoardSeq = boardCommentEntity.biBoardSeq
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalCrawling.DAL_BoardComment_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ 게시판 댓글 목록정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            getResult.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var boardCommentData = new BoardCommentEntity()
                                {
                                    biSeq = Int64.Parse(dt.Rows[i]["biSeq"].ToString()),
                                    vcAccount = dt.Rows[i]["vcAccount"].ToString(),
                                    vcName = dt.Rows[i]["vcName"].ToString(),
                                    tDescription = dt.Rows[i]["tDescription"].ToString(),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                getResult.gClass.Add(boardCommentData);
                            }
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_BoardComment_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_BoardComment_Sel : \n [DBConnectionEntity:{0}], \n [BoardCommentEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(boardCommentEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;

        }
        #endregion


        #region // !++ BLL_BoardComment_Upd (게시판 댓글 수정)
        /// <summary>
        /// 게시판 댓글 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="boardCommentEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_BoardComment_Upd(DBConnectionEntity dbConnectionEntity, BoardCommentEntity boardCommentEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbBoardComment()
                {
                    biSeq = boardCommentEntity.biSeq,
                    biBoardSeq = boardCommentEntity.biBoardSeq,
                    biMemberSeq = boardCommentEntity.biMemberSeq,
                    tDescription = boardCommentEntity.tDescription
                };
                #endregion
                result = await dalCrawling.DAL_BoardComment_Upd(dbConnectionEntity, dbData);

                // DAL_BoardComment_Upd 확인
                if (result.result < 1)
                {
                    // DAL_BoardComment_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_BoardComment_Upd 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_BoardComment_Upd : \n [DBConnectionEntity:{0}], \n [BoardCommentEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(boardCommentEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_BoardComment_Del (게시판 댓글 삭제)
        /// <summary>
        /// 게시판 댓글 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="boardCommentEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_BoardComment_Del(DBConnectionEntity dbConnectionEntity, BoardCommentEntity boardCommentEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbBoardComment()
                {
                    biSeq = boardCommentEntity.biSeq,
                    biBoardSeq = boardCommentEntity.biBoardSeq,
                    biMemberSeq = boardCommentEntity.biMemberSeq
                };
                #endregion
                result = await dalCrawling.DAL_BoardComment_Del(dbConnectionEntity, dbData);

                // DAL_BoardComment_Del 확인
                if (result.result < 1)
                {
                    // DAL_BoardComment_Del 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_BoardComment_Del 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_BoardComment_Del : \n [DBConnectionEntity:{0}], \n [BoardCommentEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(boardCommentEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_Inquiry_Sel (제품문의 목록 조회)
        /// <summary>
        /// 제품문의 계정 목록 조회
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="memberLoginEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<InquiryEntity>>> BLL_Inquiry_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, MemberLoginEntity memberLoginEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<InquiryEntity>>();
            var dataList = new List<InquiryEntity>();

            try
            {
                //+ DAL_Inquiry_Sel
                using (var ds = await dalCrawling.DAL_Inquiry_Sel(dbConnectionEntity, pageDBEntity, memberLoginEntity))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var inquiryEntity = new InquiryEntity()
                                {
                                    biSeq = Int64.Parse(dt.Rows[i]["biSeq"].ToString()),
                                    tiType = Int16.Parse(dt.Rows[i]["tiType"].ToString()),
                                    vcBusiness = dt.Rows[i]["vcBusiness"].ToString(),
                                    vcCompany = dt.Rows[i]["vcCompany"].ToString(),
                                    vcName = dt.Rows[i]["vcName"].ToString(),
                                    vcTitle = dt.Rows[i]["vcTitle"].ToString(),
                                    tiStatus = Int16.Parse(dt.Rows[i]["tiStatus"].ToString()),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(inquiryEntity);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_Inquiry_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n [MemberLoginEntity:{2}], \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), libUtility.ToJson(memberLoginEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_Inquiry_Ins (제품문의 등록)
        /// <summary>
        /// 제품문의 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="inquiryEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_Inquiry_Ins(DBConnectionEntity dbConnectionEntity, InquiryEntity inquiryEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbInquiry()
                {
                    tiType = inquiryEntity.tiType,
                    biMemberSeq = inquiryEntity.biMemberSeq,
                    vcOrganizationSerial = inquiryEntity.vcOrganizationSerial,
                    vcBusiness = inquiryEntity.vcBusiness,
                    vcCompany = inquiryEntity.vcCompany,
                    vcName = inquiryEntity.vcName,
                    vcPhone = inquiryEntity.vcPhone,
                    vcTitle = inquiryEntity.vcTitle,
                    tDescription = inquiryEntity.tDescription,
                    tiAgree = inquiryEntity.tiAgree,
                    vcIP = inquiryEntity.vcIP
                };
                #endregion
                result = await dalCrawling.DAL_Inquiry_Ins(dbConnectionEntity, dbData);

                // DAL_Inquiry_Ins 확인
                if (result.result < 1)
                {
                    // DAL_Inquiry_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_Inquiry_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_Inquiry_Ins : \n [DBConnectionEntity:{0}], \n [InquiryEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(inquiryEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_Inquiry_Detail_Sel (제품문의 상세정보)
        /// <summary>
        /// 제품문의 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="inquiryEntity"></param>
        /// <returns></returns>
        public async Task<InquiryEntity> BLL_Inquiry_Detail_Sel(DBConnectionEntity dbConnectionEntity, InquiryEntity inquiryEntity)
        {

            var getResult = new ResultEntity<InquiryEntity>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbInquiry()
                {
                    biSeq = inquiryEntity.biSeq,
                    biMemberSeq = inquiryEntity.biMemberSeq
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalCrawling.DAL_Inquiry_Detail_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ 제품문의 상세정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            getResult.gClass = null;
                        }
                        else
                        {
                            var inquiryData = new InquiryEntity()
                            {
                                biSeq = Int64.Parse(dt.Rows[0]["biSeq"].ToString()),
                                tiType = Int16.Parse(dt.Rows[0]["tiType"].ToString()),
                                vcOrganizationSerial = dt.Rows[0]["vcOrganizationSerial"].ToString(),
                                vcBusiness = dt.Rows[0]["vcBusiness"].ToString(),
                                vcCompany = dt.Rows[0]["vcCompany"].ToString(),
                                vcName = dt.Rows[0]["vcName"].ToString(),
                                vcPhone = dt.Rows[0]["vcPhone"].ToString(),
                                vcTitle = dt.Rows[0]["vcTitle"].ToString(),
                                tDescription = dt.Rows[0]["tDescription"].ToString(),
                                tiStatus = Int16.Parse(dt.Rows[0]["tiStatus"].ToString()),
                                dtRegDate = DateTime.Parse(dt.Rows[0]["dtRegDate"].ToString())
                            };
                            getResult.gClass = inquiryData;
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_Inquiry_Detail_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_Inquiry_Detail_Sel : \n [DBConnectionEntity:{0}], \n [InquiryEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(inquiryEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;

        }
        #endregion


        #region // !++ BLL_Inquiry_Upd (제품문의 수정)
        /// <summary>
        /// 제품문의 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="inquiryEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_Inquiry_Upd(DBConnectionEntity dbConnectionEntity, InquiryEntity inquiryEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbInquiry()
                {
                    biSeq = inquiryEntity.biSeq,
                    biMemberSeq = inquiryEntity.biMemberSeq,
                    vcTitle = inquiryEntity.vcTitle,
                    tDescription = inquiryEntity.tDescription
                };
                #endregion
                result = await dalCrawling.DAL_Inquiry_Upd(dbConnectionEntity, dbData);

                // DAL_Inquiry_Upd 확인
                if (result.result < 1)
                {
                    // DAL_Inquiry_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_Inquiry_Upd 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_Inquiry_Upd : \n [DBConnectionEntity:{0}], \n [InquiryEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(inquiryEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_Inquiry_Del (제품문의 삭제)
        /// <summary>
        /// 제품문의 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="inquiryEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_Inquiry_Del(DBConnectionEntity dbConnectionEntity, InquiryEntity inquiryEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbInquiry()
                {
                    biSeq = inquiryEntity.biSeq,
                    biMemberSeq = inquiryEntity.biMemberSeq
                };
                #endregion
                result = await dalCrawling.DAL_Inquiry_Del(dbConnectionEntity, dbData);

                // DAL_Inquiry_Del 확인
                if (result.result < 1)
                {
                    // DAL_Inquiry_Del 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_Inquiry_Del 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_Inquiry_Del : \n [DBConnectionEntity:{0}], \n [InquiryEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(inquiryEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_InquiryAnswer_Sel (제품문의 답변 정보)
        /// <summary>
        /// 제품문의 답변 정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="inquiryAnswerEntity"></param>
        /// <returns></returns>
        public async Task<InquiryAnswerEntity> BLL_InquiryAnswer_Sel(DBConnectionEntity dbConnectionEntity, InquiryAnswerEntity inquiryAnswerEntity)
        {

            var getResult = new ResultEntity<InquiryAnswerEntity>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbInquiryAnswer()
                {
                    biInquirySeq = inquiryAnswerEntity.biInquirySeq
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalCrawling.DAL_InquiryAnswer_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ 제품문의 답변정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            getResult.gClass = null;
                        }
                        else
                        {
                            var inquiryAnswerData = new InquiryAnswerEntity()
                            {
                                tDescription = dt.Rows[0]["tDescription"].ToString(),
                                dtRegDate = DateTime.Parse(dt.Rows[0]["dtRegDate"].ToString())
                            };
                            getResult.gClass = inquiryAnswerData;
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_InquiryAnswer_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_InquiryAnswer_Sel : \n [DBConnectionEntity:{0}], \n [InquiryAnswerEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(inquiryAnswerEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;

        }
        #endregion


        #region // !++ BLL_CrawlerRecord_Sel (크롤링 성공 & 실패 정보)
        /// <summary>
        /// 크롤링 성공 & 실패 정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="crawlerRecordEntity"></param>
        /// <returns></returns>
        public async Task<CrawlerRecordEntity> BLL_CrawlerRecord_Sel(DBConnectionEntity dbConnectionEntity, CrawlerRecordEntity crawlerRecordEntity)
        {

            var getResult = new ResultEntity<CrawlerRecordEntity>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbCrawlerRecord()
                {
                    biMemberSeq = crawlerRecordEntity.biMemberSeq
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalCrawling.DAL_CrawlerRecord_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ 크롤링 성공 & 실패 정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            getResult.gClass = null;
                        }
                        else
                        {
                            var crawlerRecordData = new CrawlerRecordEntity()
                            {
                                iSuccess = Int32.Parse(dt.Rows[0]["iSuccess"].ToString()),
                                iFail = Int32.Parse(dt.Rows[0]["iFail"].ToString())
                            };
                            getResult.gClass = crawlerRecordData;
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_CrawlerRecord_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_CrawlerRecord_Sel : \n [DBConnectionEntity:{0}], \n [CrawlerRecordEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(crawlerRecordEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;

        }
        #endregion


        #region // !++ BLL_CrawlerRecord_Execute (크롤링 성공 & 실패 여부 등록 및 수정)
        /// <summary>
        /// 크롤링 성공 & 실패 여부 등록 및 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="crawlerRecordEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_CrawlerRecord_Execute(DBConnectionEntity dbConnectionEntity, CrawlerRecordEntity crawlerRecordEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbCrawlerRecord()
                {
                    biMemberSeq = crawlerRecordEntity.biMemberSeq,
                    iSuccess = crawlerRecordEntity.iSuccess,
                    iFail = crawlerRecordEntity.iFail
                };
                #endregion
                result = await dalCrawling.DAL_CrawlerRecord_Execute(dbConnectionEntity, dbData);

                // DAL_CrawlerRecord_Execute 확인
                if (result.result < 1)
                {
                    // DAL_CrawlerRecord_Execute 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_CrawlerRecord_Execute 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_CrawlerRecord_Execute : \n [DBConnectionEntity:{0}], \n [CrawlerRecordEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(crawlerRecordEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_CrawlerHistory_Sel (데이터 수집내역 목록)
        /// <summary>
        /// 데이터 수집내역 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="memberLoginEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<CrawlerHistoryEntity>>> BLL_CrawlerHistory_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, MemberLoginEntity memberLoginEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<CrawlerHistoryEntity>>();
            var dataList = new List<CrawlerHistoryEntity>();

            try
            {
                //+ DAL_CrawlerHistory_Sel
                using (var ds = await dalCrawling.DAL_CrawlerHistory_Sel(dbConnectionEntity, pageDBEntity, memberLoginEntity))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var crawlerHistoryEntity = new CrawlerHistoryEntity()
                                {
                                    biSeq = Int64.Parse(dt.Rows[i]["biSeq"].ToString()),
                                    vcTargetUrl = dt.Rows[i]["vcTargetUrl"].ToString(),
                                    tiStatus = Int16.Parse(dt.Rows[i]["tiStatus"].ToString()),
                                    iRecord = Int32.Parse(dt.Rows[i]["iRecord"].ToString()),
                                    biMillisecond = Int64.Parse(dt.Rows[i]["biMillisecond"].ToString()),
                                    biCrawlerScheduleSeq = Int64.Parse(dt.Rows[i]["biCrawlerScheduleSeq"].ToString()),
                                    iNumber = Int32.Parse(dt.Rows[i]["iNumber"].ToString()),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString()),
                                    dtEndDate = DateTime.Parse(dt.Rows[i]["dtEndDate"].ToString())
                                };
                                dataList.Add(crawlerHistoryEntity);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_CrawlerHistory_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n [MemberLoginEntity:{2}], \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), libUtility.ToJson(memberLoginEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_CrawlerHistory_Detail_Sel (데이터 수집내역 상세정보)
        /// <summary>
        /// 데이터 수집내역 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="crawlerHistoryEntity"></param>
        /// <returns></returns>
        public async Task<CrawlerHistoryEntity> BLL_CrawlerHistory_Detail_Sel(DBConnectionEntity dbConnectionEntity, CrawlerHistoryEntity crawlerHistoryEntity)
        {

            var getResult = new ResultEntity<CrawlerHistoryEntity>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbCrawlerHistory()
                {
                    biSeq = crawlerHistoryEntity.biSeq,
                    biMemberSeq = crawlerHistoryEntity.biMemberSeq
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalCrawling.DAL_CrawlerHistory_Detail_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ 제품문의 상세정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            getResult.gClass = null;
                        }
                        else
                        {
                            var crawlerHistoryData = new CrawlerHistoryEntity()
                            {
                                vcTargetUrl = dt.Rows[0]["vcTargetUrl"].ToString(),
                                tiStatus = Int16.Parse(dt.Rows[0]["tiStatus"].ToString()),
                                iRecord = Int32.Parse(dt.Rows[0]["iRecord"].ToString()),
                                biMillisecond = Int64.Parse(dt.Rows[0]["biMillisecond"].ToString()),
                                biCrawlerScheduleSeq = Int64.Parse(dt.Rows[0]["biCrawlerScheduleSeq"].ToString()),
                                iNumber = Int32.Parse(dt.Rows[0]["iNumber"].ToString()),
                                dtRegDate = DateTime.Parse(dt.Rows[0]["dtRegDate"].ToString()),
                                dtEndDate = DateTime.Parse(dt.Rows[0]["dtEndDate"].ToString())
                            };
                            getResult.gClass = crawlerHistoryData;
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_CrawlerHistory_Detail_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_CrawlerHistory_Detail_Sel : \n [DBConnectionEntity:{0}], \n [CrawlerHistoryEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(crawlerHistoryEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;

        }
        #endregion


        #region // !++ BLL_CrawlerHistory_Ins (데이터 수집내역 등록)
        /// <summary>
        /// 데이터 수집내역 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="crawlerHistoryEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_CrawlerHistory_Ins(DBConnectionEntity dbConnectionEntity, CrawlerHistoryEntity crawlerHistoryEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbCrawlerHistory()
                {
                    biMemberSeq = crawlerHistoryEntity.biMemberSeq,
                    vcTargetUrl = crawlerHistoryEntity.vcTargetUrl,
                    tiStatus = crawlerHistoryEntity.tiStatus,
                    iRecord = crawlerHistoryEntity.iRecord,
                    biMillisecond = crawlerHistoryEntity.biMillisecond,
                    biCrawlerScheduleSeq = crawlerHistoryEntity.biCrawlerScheduleSeq,
                    iNumber = crawlerHistoryEntity.iNumber,
                    dtRegDate = crawlerHistoryEntity.dtRegDate,
                    dtEndDate = crawlerHistoryEntity.dtEndDate
                };
                #endregion
                result = await dalCrawling.DAL_CrawlerHistory_Ins(dbConnectionEntity, dbData);

                // DAL_CrawlerHistory_Ins 확인
                if (result.result < 1)
                {
                    // DAL_CrawlerHistory_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_CrawlerHistory_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_CrawlerHistory_Ins : \n [DBConnectionEntity:{0}], \n [CrawlerHistoryEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(crawlerHistoryEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_CrawlerSchedule_Sel (크롤링 스케줄 목록)
        /// <summary>
        /// 크롤링 스케줄 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="memberLoginEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<CrawlerScheduleEntity>>> BLL_CrawlerSchedule_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, MemberLoginEntity memberLoginEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<CrawlerScheduleEntity>>();
            var dataList = new List<CrawlerScheduleEntity>();

            try
            {
                //+ DAL_CrawlerSchedule_Sel
                using (var ds = await dalCrawling.DAL_CrawlerSchedule_Sel(dbConnectionEntity, pageDBEntity, memberLoginEntity))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var crawlerScheduleEntity = new CrawlerScheduleEntity()
                                {
                                    biSeq = Int64.Parse(dt.Rows[i]["biSeq"].ToString()),
                                    vcTargetUrl = dt.Rows[i]["vcTargetUrl"].ToString(),
                                    iRepeat = Int32.Parse(dt.Rows[i]["iRepeat"].ToString()),
                                    tiStatus = Int16.Parse(dt.Rows[i]["tiStatus"].ToString()),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(crawlerScheduleEntity);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_CrawlerSchedule_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n [MemberLoginEntity:{2}], \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), libUtility.ToJson(memberLoginEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_CrawlerSchedule_Detail_Sel (크롤링 스케줄 상세정보)
        /// <summary>
        /// 크롤링 스케줄 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="crawlerScheduleEntity"></param>
        /// <returns></returns>
        public async Task<CrawlerScheduleEntity> BLL_CrawlerSchedule_Detail_Sel(DBConnectionEntity dbConnectionEntity, CrawlerScheduleEntity crawlerScheduleEntity)
        {

            var getResult = new ResultEntity<CrawlerScheduleEntity>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbCrawlerSchedule()
                {
                    biSeq = crawlerScheduleEntity.biSeq,
                    biMemberSeq = crawlerScheduleEntity.biMemberSeq
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalCrawling.DAL_CrawlerSchedule_Detail_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ 크롤링 스케줄 상세정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            getResult.gClass = null;
                        }
                        else
                        {
                            var crawlerScheduleData = new CrawlerScheduleEntity()
                            {
                                vcTargetUrl = dt.Rows[0]["vcTargetUrl"].ToString(),
                                iRepeat = Int32.Parse(dt.Rows[0]["iRepeat"].ToString()),
                                tiStatus = Int16.Parse(dt.Rows[0]["tiStatus"].ToString()),
                                dtRegDate = DateTime.Parse(dt.Rows[0]["dtRegDate"].ToString())
                            };
                            getResult.gClass = crawlerScheduleData;
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_CrawlerSchedule_Detail_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_CrawlerSchedule_Detail_Sel : \n [DBConnectionEntity:{0}], \n [CrawlerScheduleEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(crawlerScheduleEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;

        }
        #endregion


        #region // !++ BLL_CrawlerSchedule_Ins (크롤링 스케줄 등록)
        /// <summary>
        /// 크롤링 스케줄 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="crawlerScheduleEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_CrawlerSchedule_Ins(DBConnectionEntity dbConnectionEntity, CrawlerScheduleEntity crawlerScheduleEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbCrawlerSchedule()
                {
                    biMemberSeq = crawlerScheduleEntity.biMemberSeq,
                    vcTargetUrl = crawlerScheduleEntity.vcTargetUrl,
                    iRepeat = crawlerScheduleEntity.iRepeat
                };
                #endregion
                result = await dalCrawling.DAL_CrawlerSchedule_Ins(dbConnectionEntity, dbData);

                // DAL_CrawlerSchedule_Ins 확인
                if (result.result < 1)
                {
                    // DAL_CrawlerSchedule_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_CrawlerSchedule_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_CrawlerSchedule_Ins : \n [DBConnectionEntity:{0}], \n [CrawlerScheduleEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(crawlerScheduleEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_CrawlerSchedule_Upd (크롤링 스케줄 수정)
        /// <summary>
        /// 크롤링 스케줄 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="crawlerScheduleEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_CrawlerSchedule_Upd(DBConnectionEntity dbConnectionEntity, CrawlerScheduleEntity crawlerScheduleEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbCrawlerSchedule()
                {
                    biSeq = crawlerScheduleEntity.biSeq,
                    biMemberSeq = crawlerScheduleEntity.biMemberSeq,
                    vcTargetUrl = crawlerScheduleEntity.vcTargetUrl,
                    iRepeat = crawlerScheduleEntity.iRepeat
                };
                #endregion
                result = await dalCrawling.DAL_CrawlerSchedule_Upd(dbConnectionEntity, dbData);

                // DAL_CrawlerSchedule_Upd 확인
                if (result.result < 1)
                {
                    // DAL_CrawlerSchedule_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_CrawlerSchedule_Upd 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_CrawlerSchedule_Upd : \n [DBConnectionEntity:{0}], \n [CrawlerScheduleEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(crawlerScheduleEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_CrawlerSchedule_Del (크롤링 스케줄 삭제)
        /// <summary>
        /// 크롤링 스케줄 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="crawlerScheduleEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_CrawlerSchedule_Del(DBConnectionEntity dbConnectionEntity, CrawlerScheduleEntity crawlerScheduleEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbCrawlerSchedule()
                {
                    biSeq = crawlerScheduleEntity.biSeq,
                    biMemberSeq = crawlerScheduleEntity.biMemberSeq
                };
                #endregion
                result = await dalCrawling.DAL_CrawlerSchedule_Del(dbConnectionEntity, dbData);

                // DAL_CrawlerSchedule_Del 확인
                if (result.result < 1)
                {
                    // DAL_CrawlerSchedule_Del 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_CrawlerSchedule_Del 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_CrawlerSchedule_Del : \n [DBConnectionEntity:{0}], \n [CrawlerScheduleEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(crawlerScheduleEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_CrawlerScheduleTime_Sel (크롤링 스케줄 시간 목록)
        /// <summary>
        /// 크롤링 스케줄 시간 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="memberLoginEntity"></param>
        /// <param name="crawlerScheduleTimeEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<CrawlerScheduleTimeEntity>>> BLL_CrawlerScheduleTime_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, MemberLoginEntity memberLoginEntity, CrawlerScheduleTimeEntity crawlerScheduleTimeEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<CrawlerScheduleTimeEntity>>();
            var dataList = new List<CrawlerScheduleTimeEntity>();

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbCrawlerScheduleTime()
                {
                    biCrawlerScheduleSeq = crawlerScheduleTimeEntity.biCrawlerScheduleSeq
                };
                #endregion

                //+ DAL_CrawlerScheduleTime_Sel
                using (var ds = await dalCrawling.DAL_CrawlerScheduleTime_Sel(dbConnectionEntity, pageDBEntity, memberLoginEntity, dbData))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var crawlerScheduleTimeData = new CrawlerScheduleTimeEntity()
                                {
                                    biSeq = Int64.Parse(dt.Rows[i]["biSeq"].ToString()),
                                    iNumber = Int32.Parse(dt.Rows[i]["iNumber"].ToString()),
                                    biMillisecond = Int64.Parse(dt.Rows[i]["biMillisecond"].ToString()),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(crawlerScheduleTimeData);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_CrawlerScheduleTime_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n [MemberLoginEntity:{2}], \n [CrawlerScheduleTimeEntity:{3}], \n {4}, \n {5}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), libUtility.ToJson(memberLoginEntity), libUtility.ToJson(crawlerScheduleTimeEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_CrawlerScheduleTime_Detail_Sel (크롤링 스케줄 시간 상세정보)
        /// <summary>
        /// 크롤링 스케줄 시간 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="crawlerScheduleEntity"></param>
        /// <returns></returns>
        public async Task<CrawlerScheduleTimeEntity> BLL_CrawlerScheduleTime_Detail_Sel(DBConnectionEntity dbConnectionEntity, CrawlerScheduleTimeEntity crawlerScheduleTimeEntity)
        {

            var getResult = new ResultEntity<CrawlerScheduleTimeEntity>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbCrawlerScheduleTime()
                {
                    biSeq = crawlerScheduleTimeEntity.biSeq,
                    biMemberSeq = crawlerScheduleTimeEntity.biMemberSeq,
                    biCrawlerScheduleSeq = crawlerScheduleTimeEntity.biCrawlerScheduleSeq
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalCrawling.DAL_CrawlerScheduleTime_Detail_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ 크롤링 스케줄 시간 상세정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            getResult.gClass = null;
                        }
                        else
                        {
                            var crawlerScheduleTimeData = new CrawlerScheduleTimeEntity()
                            {
                                iNumber = Int32.Parse(dt.Rows[0]["iNumber"].ToString()),
                                biMillisecond = Int64.Parse(dt.Rows[0]["biMillisecond"].ToString()),
                                dtRegDate = DateTime.Parse(dt.Rows[0]["dtRegDate"].ToString())
                            };
                            getResult.gClass = crawlerScheduleTimeData;
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_CrawlerScheduleTime_Detail_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_CrawlerScheduleTime_Detail_Sel : \n [DBConnectionEntity:{0}], \n [CrawlerScheduleTimeEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(crawlerScheduleTimeEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;

        }
        #endregion





        //******************************************************
        // 관리자(운영툴)
        //******************************************************


        #region // !++ BLL_FAQCode_Sel (FAQ코드 목록)
        /// <summary>
        /// FAQ코드 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<FAQCodeEntity>>> BLL_FAQCode_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<FAQCodeEntity>>();
            var dataList = new List<FAQCodeEntity>();

            try
            {

                //+ DAL_FAQCode_Sel
                using (var ds = await dalCrawling.DAL_FAQCode_Sel(dbConnectionEntity, pageDBEntity))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var faqCodeData = new FAQCodeEntity()
                                {
                                    iSeq = Int32.Parse(dt.Rows[i]["iSeq"].ToString()),
                                    vcTitle = dt.Rows[i]["vcTitle"].ToString(),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(faqCodeData);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_FAQCode_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_FAQCode_Detail_Sel (FAQ코드 상세정보)
        /// <summary>
        /// FAQ코드 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="faqCodeEntity"></param>
        /// <returns></returns>
        public async Task<FAQCodeEntity> BLL_FAQCode_Detail_Sel(DBConnectionEntity dbConnectionEntity, FAQCodeEntity faqCodeEntity)
        {

            var getResult = new ResultEntity<FAQCodeEntity>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbFAQCode()
                {
                    iSeq = faqCodeEntity.iSeq,
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalCrawling.DAL_FAQCode_Detail_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ FAQ코드 상세정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            getResult.gClass = null;
                        }
                        else
                        {
                            var faqCodeData = new FAQCodeEntity()
                            {
                                iSeq = faqCodeEntity.iSeq,
                                vcTitle = dt.Rows[0]["vcTitle"].ToString(),
                                dtRegDate = DateTime.Parse(dt.Rows[0]["dtRegDate"].ToString())
                            };
                            getResult.gClass = faqCodeData;
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_FAQCode_Detail_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_FAQCode_Detail_Sel : \n [DBConnectionEntity:{0}], \n [FAQCodeEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(faqCodeEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;

        }
        #endregion


        #region // !++ BLL_FAQCode_Ins (FAQ코드 등록)
        /// <summary>
        /// FAQ코드 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="faqCodeEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_FAQCode_Ins(DBConnectionEntity dbConnectionEntity, FAQCodeEntity faqCodeEntity)
        {
            var result = new ResultEntity<FAQCodeEntity>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbFAQCode()
                {
                    vcTitle = faqCodeEntity.vcTitle,
                    iManagerSeq = faqCodeEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_FAQCode_Ins(dbConnectionEntity, dbData);

                // DAL_FAQCode_Ins 확인
                if (result.result < 1)
                {
                    // DAL_FAQCode_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogFAQCodeEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = faqCodeEntity.iManagerSeq,
                    iSeq = result.gClass.iSeq,
                    vcTitle = faqCodeEntity.vcTitle,
                    tiType = LogActionType.Insert,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogFAQCode_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_FAQCode_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_FAQCode_Ins : \n [DBConnectionEntity:{0}], \n [FAQCodeEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(faqCodeEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_FAQCode_Upd (FAQ코드 수정)
        /// <summary>
        /// FAQ코드 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="faqCodeEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_FAQCode_Upd(DBConnectionEntity dbConnectionEntity, FAQCodeEntity faqCodeEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbFAQCode()
                {
                    iSeq = faqCodeEntity.iSeq,
                    vcTitle = faqCodeEntity.vcTitle,
                    iManagerSeq = faqCodeEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_FAQCode_Upd(dbConnectionEntity, dbData);

                // DAL_FAQCode_Upd 확인
                if (result.result < 1)
                {
                    // DAL_FAQCode_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogFAQCodeEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = faqCodeEntity.iManagerSeq,
                    iSeq = faqCodeEntity.iSeq,
                    vcTitle = faqCodeEntity.vcTitle,
                    tiType = LogActionType.Update,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogFAQCode_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_FAQCode_Upd 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_FAQCode_Upd : \n [DBConnectionEntity:{0}], \n [FAQCodeEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(faqCodeEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_FAQCode_Del (FAQ코드 삭제)
        /// <summary>
        /// FAQ코드 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="faqCodeEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_FAQCode_Del(DBConnectionEntity dbConnectionEntity, FAQCodeEntity faqCodeEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbFAQCode()
                {
                    iSeq = faqCodeEntity.iSeq,
                    iManagerSeq = faqCodeEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_FAQCode_Del(dbConnectionEntity, dbData);

                // DAL_FAQCode_Del 확인
                if (result.result < 1)
                {
                    // DAL_FAQCode_Del 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogFAQCodeEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = faqCodeEntity.iManagerSeq,
                    iSeq = faqCodeEntity.iSeq,
                    vcTitle = String.Empty,
                    tiType = LogActionType.Delete,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogFAQCode_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_FAQCode_Del 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_FAQCode_Del : \n [DBConnectionEntity:{0}], \n [FAQCodeEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(faqCodeEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_FAQ_Sel (FAQ 목록)
        /// <summary>
        /// FAQ 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<FAQEntity>>> BLL_FAQ_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<FAQEntity>>();
            var dataList = new List<FAQEntity>();

            try
            {

                //+ DAL_FAQ_Sel
                using (var ds = await dalCrawling.DAL_FAQ_Sel(dbConnectionEntity, pageDBEntity))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var faqData = new FAQEntity()
                                {
                                    iSeq = Int32.Parse(dt.Rows[i]["iSeq"].ToString()),
                                    iFaqCodeSeq = Int32.Parse(dt.Rows[i]["iFaqCodeSeq"].ToString()),
                                    vcTitleKeyText = dt.Rows[i]["vcTitleKeyText"].ToString(),
                                    tiMain = Int16.Parse(dt.Rows[i]["tiMain"].ToString()),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(faqData);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_FAQ_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_FAQ_Detail_Sel (FAQ 상세정보)
        /// <summary>
        /// FAQ 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="faqEntity"></param>
        /// <returns></returns>
        public async Task<FAQEntity> BLL_FAQ_Detail_Sel(DBConnectionEntity dbConnectionEntity, FAQEntity faqEntity)
        {

            var getResult = new ResultEntity<FAQEntity>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbFAQ()
                {
                    iSeq = faqEntity.iSeq,
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalCrawling.DAL_FAQ_Detail_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ FAQ 상세정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            getResult.gClass = null;
                        }
                        else
                        {
                            var faqData = new FAQEntity()
                            {
                                iSeq = faqEntity.iSeq,
                                iFaqCodeSeq = Int32.Parse(dt.Rows[0]["iFaqCodeSeq"].ToString()),
                                vcTitleKeyText = dt.Rows[0]["vcTitleKeyText"].ToString(),
                                vcDescriptKeyText = dt.Rows[0]["vcDescriptKeyText"].ToString(),
                                tiMain = Int16.Parse(dt.Rows[0]["tiMain"].ToString()),
                                dtRegDate = DateTime.Parse(dt.Rows[0]["dtRegDate"].ToString())
                            };
                            getResult.gClass = faqData;
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_FAQ_Detail_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_FAQ_Detail_Sel : \n [DBConnectionEntity:{0}], \n [FAQEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(faqEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;

        }
        #endregion


        #region // !++ BLL_FAQ_Ins (FAQ 등록)
        /// <summary>
        /// FAQ 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="faqEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_FAQ_Ins(DBConnectionEntity dbConnectionEntity, FAQEntity faqEntity)
        {
            var result = new ResultEntity<FAQEntity>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbFAQ()
                {
                    iFaqCodeSeq = faqEntity.iFaqCodeSeq,
                    vcTitleKeyText = faqEntity.vcTitleKeyText,
                    vcDescriptKeyText = faqEntity.vcDescriptKeyText,
                    tiMain = faqEntity.tiMain,
                    iManagerSeq = faqEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_FAQ_Ins(dbConnectionEntity, dbData);

                // DAL_FAQ_Ins 확인
                if (result.result < 1)
                {
                    // DAL_FAQ_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogFAQEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = faqEntity.iManagerSeq,
                    iSeq = result.gClass.iSeq,
                    iFaqCodeSeq = faqEntity.iFaqCodeSeq,
                    vcTitleKeyText = faqEntity.vcTitleKeyText,
                    vcDescriptKeyText = faqEntity.vcDescriptKeyText,
                    tiMain = faqEntity.tiMain,
                    tiType = LogActionType.Insert,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogFAQ_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_FAQ_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_FAQ_Ins : \n [DBConnectionEntity:{0}], \n [FAQEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(faqEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_FAQ_Upd (FAQ 수정)
        /// <summary>
        /// FAQ 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="faqEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_FAQ_Upd(DBConnectionEntity dbConnectionEntity, FAQEntity faqEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbFAQ()
                {
                    iSeq = faqEntity.iSeq,
                    iFaqCodeSeq = faqEntity.iFaqCodeSeq,
                    vcTitleKeyText = faqEntity.vcTitleKeyText,
                    vcDescriptKeyText = faqEntity.vcDescriptKeyText,
                    tiMain = faqEntity.tiMain,
                    iManagerSeq = faqEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_FAQ_Upd(dbConnectionEntity, dbData);

                // DAL_FAQ_Upd 확인
                if (result.result < 1)
                {
                    // DAL_FAQ_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogFAQEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = faqEntity.iManagerSeq,
                    iSeq = faqEntity.iSeq,
                    iFaqCodeSeq = faqEntity.iFaqCodeSeq,
                    vcTitleKeyText = faqEntity.vcTitleKeyText,
                    vcDescriptKeyText = faqEntity.vcDescriptKeyText,
                    tiMain = faqEntity.tiMain,
                    tiType = LogActionType.Update,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogFAQ_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_FAQ_Upd 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_FAQ_Upd : \n [DBConnectionEntity:{0}], \n [FAQEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(faqEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_FAQ_Del (FAQ 삭제)
        /// <summary>
        /// FAQ 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="faqEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_FAQ_Del(DBConnectionEntity dbConnectionEntity, FAQEntity faqEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbFAQ()
                {
                    iSeq = faqEntity.iSeq,
                    iFaqCodeSeq = faqEntity.iFaqCodeSeq,
                    iManagerSeq = faqEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_FAQ_Del(dbConnectionEntity, dbData);

                // DAL_FAQ_Del 확인
                if (result.result < 1)
                {
                    // DAL_FAQ_Del 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogFAQEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = faqEntity.iManagerSeq,
                    iSeq = faqEntity.iSeq,
                    iFaqCodeSeq = faqEntity.iFaqCodeSeq,
                    vcTitleKeyText = String.Empty,
                    vcDescriptKeyText = String.Empty,
                    tiMain = 0,
                    tiType = LogActionType.Delete,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogFAQ_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_FAQ_Del 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_FAQ_Del : \n [DBConnectionEntity:{0}], \n [FAQEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(faqEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_PlatForm_Sel (플랫폼 목록)
        /// <summary>
        /// 플랫폼 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<PlatFormEntity>>> BLL_PlatForm_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<PlatFormEntity>>();
            var dataList = new List<PlatFormEntity>();

            try
            {

                //+ DAL_PlatForm_Sel
                using (var ds = await dalCrawling.DAL_PlatForm_Sel(dbConnectionEntity, pageDBEntity))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var platFormData = new PlatFormEntity()
                                {
                                    iSeq = Int32.Parse(dt.Rows[i]["iSeq"].ToString()),
                                    vcName = dt.Rows[i]["vcName"].ToString(),
                                    vcKeyText = dt.Rows[i]["vcKeyText"].ToString(),
                                    vcKeyImage = dt.Rows[i]["vcKeyImage"].ToString(),
                                    tiStatus = Int16.Parse(dt.Rows[i]["tiStatus"].ToString()),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(platFormData);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_PlatForm_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_PlatForm_Detail_Sel (플랫폼 상세정보)
        /// <summary>
        /// 플랫폼 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="platFormEntity"></param>
        /// <returns></returns>
        public async Task<PlatFormEntity> BLL_PlatForm_Detail_Sel(DBConnectionEntity dbConnectionEntity, PlatFormEntity platFormEntity)
        {

            var getResult = new ResultEntity<PlatFormEntity>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbPlatForm()
                {
                    iSeq = platFormEntity.iSeq,
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalCrawling.DAL_PlatForm_Detail_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ 플랫폼 상세정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            getResult.gClass = null;
                        }
                        else
                        {
                            var platFormData = new PlatFormEntity()
                            {
                                iSeq = platFormEntity.iSeq,
                                vcName = dt.Rows[0]["vcName"].ToString(),
                                vcKeyText = dt.Rows[0]["vcKeyText"].ToString(),
                                vcKeyImage = dt.Rows[0]["vcKeyImage"].ToString(),
                                tiStatus = Int16.Parse(dt.Rows[0]["tiStatus"].ToString()),
                                dtRegDate = DateTime.Parse(dt.Rows[0]["dtRegDate"].ToString())
                            };
                            getResult.gClass = platFormData;
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_PlatForm_Detail_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_PlatForm_Detail_Sel : \n [DBConnectionEntity:{0}], \n [PlatFormEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(platFormEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;

        }
        #endregion


        #region // !++ BLL_PlatForm_Ins (플랫폼 등록)
        /// <summary>
        /// 플랫폼 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="platFormEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_PlatForm_Ins(DBConnectionEntity dbConnectionEntity, PlatFormEntity platFormEntity)
        {
            var result = new ResultEntity<PlatFormEntity>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbPlatForm()
                {
                    vcName = platFormEntity.vcName,
                    vcKeyText = platFormEntity.vcKeyText,
                    vcKeyImage = platFormEntity.vcKeyImage,
                    tiStatus = platFormEntity.tiStatus,
                    iManagerSeq = platFormEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_PlatForm_Ins(dbConnectionEntity, dbData);

                // DAL_PlatForm_Ins 확인
                if (result.result < 1)
                {
                    // DAL_PlatForm_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogPlatFormEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = platFormEntity.iManagerSeq,
                    iSeq = result.gClass.iSeq,
                    vcName = platFormEntity.vcName,
                    vcKeyText = platFormEntity.vcKeyText,
                    vcKeyImage = platFormEntity.vcKeyImage,
                    tiStatus = platFormEntity.tiStatus,
                    tiType = LogActionType.Insert,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogPlatForm_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_PlatForm_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_PlatForm_Ins : \n [DBConnectionEntity:{0}], \n [PlatFormEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(platFormEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_PlatForm_Upd (플랫폼 수정)
        /// <summary>
        /// 플랫폼 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="platFormEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_PlatForm_Upd(DBConnectionEntity dbConnectionEntity, PlatFormEntity platFormEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbPlatForm()
                {
                    iSeq = platFormEntity.iSeq,
                    vcName = platFormEntity.vcName,
                    vcKeyText = platFormEntity.vcKeyText,
                    vcKeyImage = platFormEntity.vcKeyImage,
                    tiStatus = platFormEntity.tiStatus,
                    iManagerSeq = platFormEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_PlatForm_Upd(dbConnectionEntity, dbData);

                // DAL_PlatForm_Upd 확인
                if (result.result < 1)
                {
                    // DAL_PlatForm_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogPlatFormEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = platFormEntity.iManagerSeq,
                    iSeq = platFormEntity.iSeq,
                    vcName = platFormEntity.vcName,
                    vcKeyText = platFormEntity.vcKeyText,
                    vcKeyImage = platFormEntity.vcKeyImage,
                    tiStatus = platFormEntity.tiStatus,
                    tiType = LogActionType.Update,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogPlatForm_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_PlatForm_Upd 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_PlatForm_Upd : \n [DBConnectionEntity:{0}], \n [PlatFormEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(platFormEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_PlatForm_Del (플랫폼 삭제)
        /// <summary>
        /// 플랫폼 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="platFormEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_PlatForm_Del(DBConnectionEntity dbConnectionEntity, PlatFormEntity platFormEntity)
        {
            var result = new ResultEntity<DataSet>();
            EResultCode eResultCode = 0;
            var platFomApiDataList = new List<LogPlatFormApiEntity>();

            try
            {
                #region // !++ 데이터 Struct 변경
                // 원본 데이터
                var dbData = new tbPlatForm()
                {
                    iSeq = platFormEntity.iSeq,
                    iManagerSeq = platFormEntity.iManagerSeq
                };

                // 로그 데이터 Struct 변경
                var logData = new LogPlatFormEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = platFormEntity.iManagerSeq,
                    iSeq = platFormEntity.iSeq,
                    vcName = String.Empty,
                    vcKeyText = String.Empty,
                    vcKeyImage = String.Empty,
                    tiStatus = 0,
                    tiType = LogActionType.Delete,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion
                result = await dalCrawling.DAL_PlatForm_Del(dbConnectionEntity, dbData);

                #region // !++ DataSet 
                if (result.gClass == null)
                {
                    // DAL_PlatForm_Del 실패. 오류 발생!
                    eResultCode = EResultCode.Error_DB_Exception;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }
                else
                {
                    #region // !++ 데이터 축출
                    using (var ds = result.gClass)
                    {
                        #region // !++ 하위정보(Platform API)
                        using (var dt = ds.Tables[0])
                        {
                            if (dt.Rows.Count > 0)
                            {
                                for (int i = 0; i < dt.Rows.Count; i++)
                                {
                                    var platFomApiData = new LogPlatFormApiEntity()
                                    {
                                        biTXIDX = logData.biTXIDX,
                                        iManagerSeq = logData.iManagerSeq,
                                        iSeq = Int32.Parse(dt.Rows[i]["iSeq"].ToString()),
                                        iPlatFormSeq = logData.iSeq,
                                        vcApiUrl = dt.Rows[i]["vcApiUrl"].ToString(),
                                        vcID = dt.Rows[i]["vcID"].ToString(),
                                        vcVerifyKey = dt.Rows[i]["vcVerifyKey"].ToString(),
                                        tiStatus = Int16.Parse(dt.Rows[i]["tiStatus"].ToString()),
                                        tiType = LogActionType.Delete,
                                        vcIP = String.Empty
                                    };
                                    platFomApiDataList.Add(platFomApiData);
                                }
                            }
                        }
                        #endregion

                        #region // !++ Error code
                        using (var dt = ds.Tables[1])
                        {
                            if (dt.Rows.Count == 0)
                            {
                                // DAL_PlatForm_Del 실패. 오류 발생!
                                eResultCode = EResultCode.Error_DB_Exception;
                                result.ErrorMsg = eResultCode.ToString();
                                return result.result;
                            }
                            else
                            {
                                result.result = Int32.Parse(dt.Rows[0]["Result"].ToString());
                                result.ErrorMsg = dt.Rows[0]["Msg"].ToString();
                            }
                        }
                        #endregion
                    }
                    #endregion
                }
                #endregion

                // DAL_PlatForm_Del 확인
                if (result.result < 1)
                {
                    // DAL_PlatForm_Del 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogPlatForm_Ins(dbConnectionEntity, logData);
                #endregion

                #region // !++ 하위(PlatformApi) 삭제정보
                // 데이터 존재 시 만 실행됨
                if (platFomApiDataList != null)
                {
                    if (platFomApiDataList.Count > 0)
                    {
                        for (int i = 0; i < platFomApiDataList.Count; i++)
                        {
                            // Log 데이터 실행
                            await bllLogData.BLL_LogPlatFormApi_Ins(dbConnectionEntity, platFomApiDataList[i]);
                        }
                    }
                }
                #endregion

                #endregion

            }
            catch (Exception exc)
            {
                // DAL_PlatForm_Del 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_PlatForm_Del : \n [DBConnectionEntity:{0}], \n [PlatFormEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(platFormEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_PlatFormApi_Sel (플랫폼 API 목록)
        /// <summary>
        /// 플랫폼 API 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<PlatFormApiEntity>>> BLL_PlatFormApi_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<PlatFormApiEntity>>();
            var dataList = new List<PlatFormApiEntity>();

            try
            {

                //+ DAL_PlatFormApi_Sel
                using (var ds = await dalCrawling.DAL_PlatFormApi_Sel(dbConnectionEntity, pageDBEntity))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var platFormApiData = new PlatFormApiEntity()
                                {
                                    iSeq = Int32.Parse(dt.Rows[i]["iSeq"].ToString()),
                                    iPlatFormSeq = Int32.Parse(dt.Rows[i]["iPlatFormSeq"].ToString()),
                                    vcApiUrl = dt.Rows[i]["vcApiUrl"].ToString(),
                                    vcID = dt.Rows[i]["vcID"].ToString(),
                                    vcVerifyKey = dt.Rows[i]["vcVerifyKey"].ToString(),
                                    tiStatus = Int16.Parse(dt.Rows[i]["tiStatus"].ToString()),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(platFormApiData);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_PlatFormApi_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_PlatFormApi_Detail_Sel (플랫폼 API 상세정보)
        /// <summary>
        /// 플랫폼 API 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="platFormApiEntity"></param>
        /// <returns></returns>
        public async Task<PlatFormApiEntity> BLL_PlatFormApi_Detail_Sel(DBConnectionEntity dbConnectionEntity, PlatFormApiEntity platFormApiEntity)
        {

            var getResult = new ResultEntity<PlatFormApiEntity>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbPlatFormApi()
                {
                    iSeq = platFormApiEntity.iSeq,
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalCrawling.DAL_PlatFormApi_Detail_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ 플랫폼 API 상세정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            getResult.gClass = null;
                        }
                        else
                        {
                            var platFormApiData = new PlatFormApiEntity()
                            {
                                iSeq = platFormApiEntity.iSeq,
                                iPlatFormSeq = Int32.Parse(dt.Rows[0]["iPlatFormSeq"].ToString()),
                                vcApiUrl = dt.Rows[0]["vcApiUrl"].ToString(),
                                vcID = dt.Rows[0]["vcID"].ToString(),
                                vcVerifyKey = dt.Rows[0]["vcVerifyKey"].ToString(),
                                tiStatus = Int16.Parse(dt.Rows[0]["tiStatus"].ToString()),
                                dtRegDate = DateTime.Parse(dt.Rows[0]["dtRegDate"].ToString())
                            };
                            getResult.gClass = platFormApiData;
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_PlatFormApi_Detail_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_PlatFormApi_Detail_Sel : \n [DBConnectionEntity:{0}], \n [PlatFormApiEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(platFormApiEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;

        }
        #endregion


        #region // !++ BLL_PlatFormApi_Ins (플랫폼 API 등록)
        /// <summary>
        /// 플랫폼 API 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="platFormApiEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_PlatFormApi_Ins(DBConnectionEntity dbConnectionEntity, PlatFormApiEntity platFormApiEntity)
        {
            var result = new ResultEntity<PlatFormApiEntity>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbPlatFormApi()
                {
                    iPlatFormSeq = platFormApiEntity.iPlatFormSeq,
                    vcApiUrl = platFormApiEntity.vcApiUrl,
                    vcID = platFormApiEntity.vcID,
                    vcVerifyKey = platFormApiEntity.vcVerifyKey,
                    tiStatus = platFormApiEntity.tiStatus,
                    iManagerSeq = platFormApiEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_PlatFormApi_Ins(dbConnectionEntity, dbData);

                // DAL_PlatFormApi_Ins 확인
                if (result.result < 1)
                {
                    // DAL_PlatFormApi_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogPlatFormApiEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = platFormApiEntity.iManagerSeq,
                    iSeq = result.gClass.iSeq,
                    iPlatFormSeq = platFormApiEntity.iPlatFormSeq,
                    vcApiUrl = platFormApiEntity.vcApiUrl,
                    vcID = platFormApiEntity.vcID,
                    vcVerifyKey = platFormApiEntity.vcVerifyKey,
                    tiStatus = platFormApiEntity.tiStatus,
                    tiType = LogActionType.Insert,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogPlatFormApi_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_PlatFormApi_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_PlatFormApi_Ins : \n [DBConnectionEntity:{0}], \n [PlatFormApiEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(platFormApiEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_PlatFormApi_Upd (플랫폼 API 수정)
        /// <summary>
        /// 플랫폼 API 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="platFormApiEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_PlatFormApi_Upd(DBConnectionEntity dbConnectionEntity, PlatFormApiEntity platFormApiEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbPlatFormApi()
                {
                    iSeq = platFormApiEntity.iSeq,
                    iPlatFormSeq = platFormApiEntity.iPlatFormSeq,
                    vcApiUrl = platFormApiEntity.vcApiUrl,
                    vcID = platFormApiEntity.vcID,
                    vcVerifyKey = platFormApiEntity.vcVerifyKey,
                    tiStatus = platFormApiEntity.tiStatus,
                    iManagerSeq = platFormApiEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_PlatFormApi_Upd(dbConnectionEntity, dbData);

                // DAL_PlatFormApi_Upd 확인
                if (result.result < 1)
                {
                    // DAL_PlatFormApi_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogPlatFormApiEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = platFormApiEntity.iManagerSeq,
                    iSeq = platFormApiEntity.iSeq,
                    iPlatFormSeq = platFormApiEntity.iPlatFormSeq,
                    vcApiUrl = platFormApiEntity.vcApiUrl,
                    vcID = platFormApiEntity.vcID,
                    vcVerifyKey = platFormApiEntity.vcVerifyKey,
                    tiStatus = platFormApiEntity.tiStatus,
                    tiType = LogActionType.Update,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogPlatFormApi_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_PlatFormApi_Upd 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_PlatFormApi_Upd : \n [DBConnectionEntity:{0}], \n [PlatFormApiEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(platFormApiEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_PlatFormApi_Del (플랫폼 API 삭제)
        /// <summary>
        /// 플랫폼 API 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="platFormApiEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_PlatFormApi_Del(DBConnectionEntity dbConnectionEntity, PlatFormApiEntity platFormApiEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbPlatFormApi()
                {
                    iSeq = platFormApiEntity.iSeq,
                    iPlatFormSeq = platFormApiEntity.iPlatFormSeq,
                    iManagerSeq = platFormApiEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_PlatFormApi_Del(dbConnectionEntity, dbData);

                // DAL_PlatFormApi_Del 확인
                if (result.result < 1)
                {
                    // DAL_PlatFormApi_Del 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogPlatFormApiEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = platFormApiEntity.iManagerSeq,
                    iSeq = platFormApiEntity.iSeq,
                    iPlatFormSeq = platFormApiEntity.iPlatFormSeq,
                    vcApiUrl = String.Empty,
                    vcID = String.Empty,
                    vcVerifyKey = String.Empty,
                    tiStatus = 0,
                    tiType = LogActionType.Delete,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogPlatFormApi_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_PlatFormApi_Del 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_PlatFormApi_Del : \n [DBConnectionEntity:{0}], \n [PlatFormApiEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(platFormApiEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_LanguageCode_Sel (언어[다국어]코드 목록)
        /// <summary>
        /// 언어[다국어]코드 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<LanguageCodeEntity>>> BLL_LanguageCode_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<LanguageCodeEntity>>();
            var dataList = new List<LanguageCodeEntity>();

            try
            {

                //+ DAL_LanguageCode_Sel
                using (var ds = await dalCrawling.DAL_LanguageCode_Sel(dbConnectionEntity, pageDBEntity))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var languageCodeData = new LanguageCodeEntity()
                                {
                                    vcLanguageCode = dt.Rows[i]["vcLanguageCode"].ToString(),
                                    vcLanguageName = dt.Rows[i]["vcLanguageName"].ToString(),
                                    tiStatus = Int16.Parse(dt.Rows[i]["tiStatus"].ToString()),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(languageCodeData);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_LanguageCode_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_LanguageCode_Detail_Sel (언어[다국어]코드 상세정보)
        /// <summary>
        /// 언어[다국어]코드 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="languageCodeEntity"></param>
        /// <returns></returns>
        public async Task<LanguageCodeEntity> BLL_LanguageCode_Detail_Sel(DBConnectionEntity dbConnectionEntity, LanguageCodeEntity languageCodeEntity)
        {

            var getResult = new ResultEntity<LanguageCodeEntity>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbLanguageCode()
                {
                    vcLanguageCode = languageCodeEntity.vcLanguageCode,
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalCrawling.DAL_LanguageCode_Detail_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ 언어[다국어]코드 상세정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            getResult.gClass = null;
                        }
                        else
                        {
                            var languageCodeData = new LanguageCodeEntity()
                            {
                                vcLanguageName = dt.Rows[0]["vcLanguageName"].ToString(),
                                tiStatus = Int16.Parse(dt.Rows[0]["tiStatus"].ToString()),
                                dtRegDate = DateTime.Parse(dt.Rows[0]["dtRegDate"].ToString())
                            };
                            getResult.gClass = languageCodeData;
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_LanguageCode_Detail_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_LanguageCode_Detail_Sel : \n [DBConnectionEntity:{0}], \n [LanguageCodeEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(languageCodeEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;

        }
        #endregion


        #region // !++ BLL_LanguageCode_Ins (언어[다국어]코드 등록)
        /// <summary>
        /// 언어[다국어]코드 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="languageCodeEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_LanguageCode_Ins(DBConnectionEntity dbConnectionEntity, LanguageCodeEntity languageCodeEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLanguageCode()
                {
                    vcLanguageCode = languageCodeEntity.vcLanguageCode,
                    vcLanguageName = languageCodeEntity.vcLanguageName,
                    tiStatus = languageCodeEntity.tiStatus,
                    iManagerSeq = languageCodeEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_LanguageCode_Ins(dbConnectionEntity, dbData);

                // DAL_LanguageCode_Ins 확인
                if (result.result < 1)
                {
                    // DAL_LanguageCode_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogLanguageCodeEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = languageCodeEntity.iManagerSeq,
                    vcLanguageCode = languageCodeEntity.vcLanguageCode,
                    vcLanguageName = languageCodeEntity.vcLanguageName,
                    tiStatus = languageCodeEntity.tiStatus,
                    tiType = LogActionType.Insert,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogLanguageCode_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_LanguageCode_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LanguageCode_Ins : \n [DBConnectionEntity:{0}], \n [LanguageCodeEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(languageCodeEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_LanguageCode_Upd (언어[다국어]코드 수정)
        /// <summary>
        /// 언어[다국어]코드 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="languageCodeEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_LanguageCode_Upd(DBConnectionEntity dbConnectionEntity, LanguageCodeEntity languageCodeEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLanguageCode()
                {
                    vcLanguageCode = languageCodeEntity.vcLanguageCode,
                    vcLanguageName = languageCodeEntity.vcLanguageName,
                    tiStatus = languageCodeEntity.tiStatus,
                    iManagerSeq = languageCodeEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_LanguageCode_Upd(dbConnectionEntity, dbData);

                // DAL_LanguageCode_Upd 확인
                if (result.result < 1)
                {
                    // DAL_LanguageCode_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogLanguageCodeEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = languageCodeEntity.iManagerSeq,
                    vcLanguageCode = languageCodeEntity.vcLanguageCode,
                    vcLanguageName = languageCodeEntity.vcLanguageName,
                    tiStatus = languageCodeEntity.tiStatus,
                    tiType = LogActionType.Update,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogLanguageCode_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_LanguageCode_Upd 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LanguageCode_Upd : \n [DBConnectionEntity:{0}], \n [LanguageCodeEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(languageCodeEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_LanguageCode_Del (언어[다국어]코드 삭제)
        /// <summary>
        /// 언어[다국어]코드 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="languageCodeEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_LanguageCode_Del(DBConnectionEntity dbConnectionEntity, LanguageCodeEntity languageCodeEntity)
        {
            var result = new ResultEntity<DataSet>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLanguageCode()
                {
                    vcLanguageCode = languageCodeEntity.vcLanguageCode,
                    iManagerSeq = languageCodeEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_LanguageCode_Del(dbConnectionEntity, dbData);

                // DAL_LanguageCode_Del 확인
                if (result.result < 1)
                {
                    // DAL_LanguageCode_Del 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogLanguageCodeEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = languageCodeEntity.iManagerSeq,
                    vcLanguageCode = languageCodeEntity.vcLanguageCode,
                    vcLanguageName = String.Empty,
                    tiStatus = 0,
                    tiType = LogActionType.Delete,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogLanguageCode_Ins(dbConnectionEntity, logData);
                #endregion

                #region // !++ 하위(Language, LanguageImage) 삭제정보
                if (result.gClass != null)
                {
                    using (var ds = result.gClass)
                    {
                        #region // !++ 데이터 축출 및 Log 등록

                        #region // !++ Language 정보
                        using (var dt = ds.Tables[0])
                        {
                            if (dt.Rows.Count > 0)
                            {
                                for (int i = 0; i < dt.Rows.Count; i++)
                                {
                                    var languageData = new LogLanguageEntity()
                                    {
                                        biTXIDX = logData.biTXIDX,
                                        iManagerSeq = logData.iManagerSeq,
                                        vcLanguageCode = dt.Rows[i]["vcLanguageCode"].ToString(),
                                        vcKeyText = dt.Rows[i]["vcKeyText"].ToString(),
                                        tiAbbreviated = Int16.Parse(dt.Rows[i]["tiAbbreviated"].ToString()),
                                        vcText = dt.Rows[i]["vcText"].ToString(),
                                        tiStatus = Int16.Parse(dt.Rows[i]["tiStatus"].ToString()),
                                        tiType = LogActionType.Delete,
                                        vcIP = String.Empty
                                    };
                                    // Log 데이터 실행
                                    await bllLogData.BLL_LogLanguage_Ins(dbConnectionEntity, languageData);
                                }
                            }
                        }
                        #endregion

                        #region // !++ LanguageImage 정보
                        using (var dt = ds.Tables[1])
                        {
                            if (dt.Rows.Count > 0)
                            {
                                for (int i = 0; i < dt.Rows.Count; i++)
                                {
                                    var languageImageData = new LogLanguageImageEntity()
                                    {
                                        biTXIDX = logData.biTXIDX,
                                        iManagerSeq = logData.iManagerSeq,
                                        vcLanguageCode = dt.Rows[i]["vcLanguageCode"].ToString(),
                                        vcKeyImage = dt.Rows[i]["vcKeyImage"].ToString(),
                                        vcUrl = dt.Rows[i]["vcUrl"].ToString(),
                                        vcImage = dt.Rows[i]["vcImage"].ToString(),
                                        tiStatus = Int16.Parse(dt.Rows[i]["tiStatus"].ToString()),
                                        tiType = LogActionType.Delete,
                                        vcIP = String.Empty
                                    };
                                    // Log 데이터 실행
                                    await bllLogData.BLL_LogLanguageImage_Ins(dbConnectionEntity, languageImageData);
                                }
                            }
                        }
                        #endregion

                        #endregion
                    }
                }
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_LanguageCode_Del 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LanguageCode_Del : \n [DBConnectionEntity:{0}], \n [LanguageCodeEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(languageCodeEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_Language_Sel (언어[다국어] 목록)
        /// <summary>
        /// 언어[다국어] 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="languageEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<LanguageEntity>>> BLL_Language_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, LanguageEntity languageEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<LanguageEntity>>();
            var dataList = new List<LanguageEntity>();

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbLanguage()
                {
                    vcLanguageCode = languageEntity.vcLanguageCode
                };
                #endregion

                //+ DAL_Language_Sel
                using (var ds = await dalCrawling.DAL_Language_Sel(dbConnectionEntity, pageDBEntity, dbData))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var languageData = new LanguageEntity()
                                {
                                    vcLanguageCode = dt.Rows[i]["vcLanguageCode"].ToString(),
                                    vcKeyText = dt.Rows[i]["vcKeyText"].ToString(),
                                    tiAbbreviated = Int16.Parse(dt.Rows[i]["tiAbbreviated"].ToString()),
                                    tiStatus = Int16.Parse(dt.Rows[i]["tiStatus"].ToString()),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(languageData);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_Language_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n [LanguageEntity:{2}], \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), libUtility.ToJson(languageEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_Language_Detail_Sel (언어[다국어] 상세정보)
        /// <summary>
        /// 언어[다국어] 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="languageEntity"></param>
        /// <returns></returns>
        public async Task<LanguageEntity> BLL_Language_Detail_Sel(DBConnectionEntity dbConnectionEntity, LanguageEntity languageEntity)
        {

            var getResult = new ResultEntity<LanguageEntity>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbLanguage()
                {
                    vcLanguageCode = languageEntity.vcLanguageCode,
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalCrawling.DAL_Language_Detail_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ 언어[다국어] 상세정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            getResult.gClass = null;
                        }
                        else
                        {
                            var languageData = new LanguageEntity()
                            {
                                tiAbbreviated = Int16.Parse(dt.Rows[0]["tiAbbreviated"].ToString()),
                                vcText = dt.Rows[0]["vcText"].ToString(),
                                tiStatus = Int16.Parse(dt.Rows[0]["tiStatus"].ToString()),
                                dtRegDate = DateTime.Parse(dt.Rows[0]["dtRegDate"].ToString())
                            };
                            getResult.gClass = languageData;
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_Language_Detail_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_Language_Detail_Sel : \n [DBConnectionEntity:{0}], \n [LanguageEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(languageEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;

        }
        #endregion


        #region // !++ BLL_Language_Ins (언어[다국어] 등록)
        /// <summary>
        /// 언어[다국어] 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="languageEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_Language_Ins(DBConnectionEntity dbConnectionEntity, LanguageEntity languageEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLanguage()
                {
                    vcLanguageCode = languageEntity.vcLanguageCode,
                    vcKeyText = languageEntity.vcKeyText,
                    tiAbbreviated = languageEntity.tiAbbreviated,
                    vcText = languageEntity.vcText,
                    tiStatus = languageEntity.tiStatus,
                    iManagerSeq = languageEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_Language_Ins(dbConnectionEntity, dbData);

                // DAL_Language_Ins 확인
                if (result.result < 1)
                {
                    // DAL_Language_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogLanguageEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = languageEntity.iManagerSeq,
                    vcLanguageCode = languageEntity.vcLanguageCode,
                    vcKeyText = languageEntity.vcKeyText,
                    tiAbbreviated = languageEntity.tiAbbreviated,
                    vcText = languageEntity.vcText,
                    tiStatus = languageEntity.tiStatus,
                    tiType = LogActionType.Insert,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogLanguage_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_Language_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_Language_Ins : \n [DBConnectionEntity:{0}], \n [LanguageEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(languageEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_Language_Upd (언어[다국어] 수정)
        /// <summary>
        /// 언어[다국어] 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="languageEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_Language_Upd(DBConnectionEntity dbConnectionEntity, LanguageEntity languageEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLanguage()
                {
                    vcLanguageCode = languageEntity.vcLanguageCode,
                    vcKeyText = languageEntity.vcKeyText,
                    tiAbbreviated = languageEntity.tiAbbreviated,
                    vcText = languageEntity.vcText,
                    tiStatus = languageEntity.tiStatus,
                    iManagerSeq = languageEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_Language_Upd(dbConnectionEntity, dbData);

                // DAL_Language_Upd 확인
                if (result.result < 1)
                {
                    // DAL_Language_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogLanguageEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = languageEntity.iManagerSeq,
                    vcLanguageCode = languageEntity.vcLanguageCode,
                    vcKeyText = languageEntity.vcKeyText,
                    tiAbbreviated = languageEntity.tiAbbreviated,
                    vcText = languageEntity.vcText,
                    tiStatus = languageEntity.tiStatus,
                    tiType = LogActionType.Update,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogLanguage_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_Language_Upd 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_Language_Upd : \n [DBConnectionEntity:{0}], \n [LanguageEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(languageEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_Language_Del (언어[다국어] 삭제)
        /// <summary>
        /// 언어[다국어] 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="languageEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_Language_Del(DBConnectionEntity dbConnectionEntity, LanguageEntity languageEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLanguage()
                {
                    vcLanguageCode = languageEntity.vcLanguageCode,
                    vcKeyText = languageEntity.vcKeyText,
                    tiAbbreviated = languageEntity.tiAbbreviated,
                    iManagerSeq = languageEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_Language_Del(dbConnectionEntity, dbData);

                // DAL_Language_Del 확인
                if (result.result < 1)
                {
                    // DAL_Language_Del 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogLanguageEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = languageEntity.iManagerSeq,
                    vcLanguageCode = languageEntity.vcLanguageCode,
                    vcKeyText = languageEntity.vcKeyText,
                    tiAbbreviated = languageEntity.tiAbbreviated,
                    vcText = String.Empty,
                    tiStatus = 0,
                    tiType = LogActionType.Delete,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogLanguage_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_Language_Del 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_Language_Del : \n [DBConnectionEntity:{0}], \n [LanguageEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(languageEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_LanguageImage_Sel (언어[다국어]이미지 목록)
        /// <summary>
        /// 언어[다국어]이미지 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="languageImageEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<LanguageImageEntity>>> BLL_LanguageImage_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, LanguageImageEntity languageImageEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<LanguageImageEntity>>();
            var dataList = new List<LanguageImageEntity>();

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbLanguageImage()
                {
                    vcLanguageCode = languageImageEntity.vcLanguageCode
                };
                #endregion

                //+ DAL_LanguageImage_Sel
                using (var ds = await dalCrawling.DAL_LanguageImage_Sel(dbConnectionEntity, pageDBEntity, dbData))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var languageImageData = new LanguageImageEntity()
                                {
                                    vcLanguageCode = dt.Rows[i]["vcLanguageCode"].ToString(),
                                    vcKeyImage = dt.Rows[i]["vcKeyImage"].ToString(),
                                    vcUrl = dt.Rows[i]["vcUrl"].ToString(),
                                    vcImage = dt.Rows[i]["vcImage"].ToString(),
                                    tiStatus = Int16.Parse(dt.Rows[i]["tiStatus"].ToString()),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(languageImageData);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_LanguageImage_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n [LanguageImageEntity:{2}], \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), libUtility.ToJson(languageImageEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_LanguageImage_Detail_Sel (언어[다국어]이미지 상세정보)
        /// <summary>
        /// 언어[다국어]이미지 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="languageImageEntity"></param>
        /// <returns></returns>
        public async Task<LanguageImageEntity> BLL_LanguageImage_Detail_Sel(DBConnectionEntity dbConnectionEntity, LanguageImageEntity languageImageEntity)
        {

            var getResult = new ResultEntity<LanguageImageEntity>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbLanguageImage()
                {
                    vcLanguageCode = languageImageEntity.vcLanguageCode,
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalCrawling.DAL_LanguageImage_Detail_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ 언어[다국어]이미지 상세정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            getResult.gClass = null;
                        }
                        else
                        {
                            var languageImageData = new LanguageImageEntity()
                            {
                                vcUrl = dt.Rows[0]["vcUrl"].ToString(),
                                vcImage = dt.Rows[0]["vcImage"].ToString(),
                                tiStatus = Int16.Parse(dt.Rows[0]["tiStatus"].ToString()),
                                dtRegDate = DateTime.Parse(dt.Rows[0]["dtRegDate"].ToString())
                            };
                            getResult.gClass = languageImageData;
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_LanguageImage_Detail_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_LanguageImage_Detail_Sel : \n [DBConnectionEntity:{0}], \n [LanguageImageEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(languageImageEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;

        }
        #endregion


        #region // !++ BLL_LanguageImage_Ins (언어[다국어]이미지 등록)
        /// <summary>
        /// 언어[다국어]이미지 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="languageImageEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_LanguageImage_Ins(DBConnectionEntity dbConnectionEntity, LanguageImageEntity languageImageEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLanguageImage()
                {
                    vcLanguageCode = languageImageEntity.vcLanguageCode,
                    vcKeyImage = languageImageEntity.vcKeyImage,
                    vcUrl = languageImageEntity.vcUrl,
                    vcImage = languageImageEntity.vcImage,
                    tiStatus = languageImageEntity.tiStatus,
                    iManagerSeq = languageImageEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_LanguageImage_Ins(dbConnectionEntity, dbData);

                // DAL_LanguageImage_Ins 확인
                if (result.result < 1)
                {
                    // DAL_LanguageImage_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogLanguageImageEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = languageImageEntity.iManagerSeq,
                    vcLanguageCode = languageImageEntity.vcLanguageCode,
                    vcKeyImage = languageImageEntity.vcKeyImage,
                    vcUrl = languageImageEntity.vcUrl,
                    vcImage = languageImageEntity.vcImage,
                    tiStatus = languageImageEntity.tiStatus,
                    tiType = LogActionType.Insert,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogLanguageImage_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_LanguageImage_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LanguageImage_Ins : \n [DBConnectionEntity:{0}], \n [LanguageImageEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(languageImageEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_LanguageImage_Upd (언어[다국어]이미지 수정)
        /// <summary>
        /// 언어[다국어]이미지 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="languageImageEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_LanguageImage_Upd(DBConnectionEntity dbConnectionEntity, LanguageImageEntity languageImageEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLanguageImage()
                {
                    vcLanguageCode = languageImageEntity.vcLanguageCode,
                    vcKeyImage = languageImageEntity.vcKeyImage,
                    vcUrl = languageImageEntity.vcUrl,
                    vcImage = languageImageEntity.vcImage,
                    tiStatus = languageImageEntity.tiStatus,
                    iManagerSeq = languageImageEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_LanguageImage_Upd(dbConnectionEntity, dbData);

                // DAL_LanguageImage_Upd 확인
                if (result.result < 1)
                {
                    // DAL_LanguageImage_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogLanguageImageEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = languageImageEntity.iManagerSeq,
                    vcLanguageCode = languageImageEntity.vcLanguageCode,
                    vcKeyImage = languageImageEntity.vcKeyImage,
                    vcUrl = languageImageEntity.vcUrl,
                    vcImage = languageImageEntity.vcImage,
                    tiStatus = languageImageEntity.tiStatus,
                    tiType = LogActionType.Update,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogLanguageImage_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_LanguageImage_Upd 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LanguageImage_Upd : \n [DBConnectionEntity:{0}], \n [LanguageImageEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(languageImageEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_LanguageImage_Del (언어[다국어]이미지 삭제)
        /// <summary>
        /// 언어[다국어]이미지 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="languageImageEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_LanguageImage_Del(DBConnectionEntity dbConnectionEntity, LanguageImageEntity languageImageEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLanguageImage()
                {
                    vcLanguageCode = languageImageEntity.vcLanguageCode,
                    vcKeyImage = languageImageEntity.vcKeyImage,
                    iManagerSeq = languageImageEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_LanguageImage_Del(dbConnectionEntity, dbData);

                // DAL_LanguageImage_Del 확인
                if (result.result < 1)
                {
                    // DAL_LanguageImage_Del 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogLanguageImageEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = languageImageEntity.iManagerSeq,
                    vcLanguageCode = languageImageEntity.vcLanguageCode,
                    vcKeyImage = languageImageEntity.vcKeyImage,
                    vcUrl = String.Empty,
                    vcImage = String.Empty,
                    tiStatus = 0,
                    tiType = LogActionType.Delete,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogLanguageImage_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_LanguageImage_Del 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LanguageImage_Del : \n [DBConnectionEntity:{0}], \n [LanguageImageEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(languageImageEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_PrivateBoard_Sel (공지, 뉴스 등 게시판 목록)
        /// <summary>
        /// 공지, 뉴스 등 게시판 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="privateBoardEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<PrivateBoardEntity>>> BLL_PrivateBoard_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, PrivateBoardEntity privateBoardEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<PrivateBoardEntity>>();
            var dataList = new List<PrivateBoardEntity>();

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbPrivateBoard()
                {
                    tiType = privateBoardEntity.tiType
                };
                #endregion

                //+ DAL_PrivateBoard_Sel
                using (var ds = await dalCrawling.DAL_PrivateBoard_Sel(dbConnectionEntity, pageDBEntity, dbData))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var privateBoardData = new PrivateBoardEntity()
                                {
                                    biSeq = Int64.Parse(dt.Rows[i]["biSeq"].ToString()),
                                    vcTitleKeyText = dt.Rows[i]["vcTitleKeyText"].ToString(),
                                    vcDescriptKeyText = dt.Rows[i]["vcDescriptKeyText"].ToString(),
                                    tiMain = Int16.Parse(dt.Rows[i]["tiMain"].ToString()),
                                    iRead = Int16.Parse(dt.Rows[i]["iRead"].ToString()),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(privateBoardData);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_PrivateBoard_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n [PrivateBoardEntity:{2}], \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), libUtility.ToJson(privateBoardEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_PrivateBoard_Detail_Sel (공지, 뉴스 등 게시판 상세정보)
        /// <summary>
        /// 공지, 뉴스 등 게시판 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="privateBoardEntity"></param>
        /// <returns></returns>
        public async Task<PrivateBoardEntity> BLL_PrivateBoard_Detail_Sel(DBConnectionEntity dbConnectionEntity, PrivateBoardEntity privateBoardEntity)
        {

            var getResult = new ResultEntity<PrivateBoardEntity>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbPrivateBoard()
                {
                    biSeq = privateBoardEntity.biSeq,
                    tiType = privateBoardEntity.tiType
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalCrawling.DAL_PrivateBoard_Detail_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ 공지, 뉴스 등 게시판 상세정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            getResult.gClass = null;
                        }
                        else
                        {
                            var privateBoardData = new PrivateBoardEntity()
                            {
                                vcTitleKeyText = dt.Rows[0]["vcTitleKeyText"].ToString(),
                                vcDescriptKeyText = dt.Rows[0]["vcDescriptKeyText"].ToString(),
                                tiMain = Int16.Parse(dt.Rows[0]["tiMain"].ToString()),
                                iRead = Int16.Parse(dt.Rows[0]["iRead"].ToString()),
                                dtRegDate = DateTime.Parse(dt.Rows[0]["dtRegDate"].ToString())
                            };
                            getResult.gClass = privateBoardData;
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_PrivateBoard_Detail_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_PrivateBoard_Detail_Sel : \n [DBConnectionEntity:{0}], \n [PrivateBoardEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(privateBoardEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;

        }
        #endregion


        #region // !++ BLL_PrivateBoard_Ins (공지, 뉴스 등 게시판 등록)
        /// <summary>
        /// 공지, 뉴스 등 게시판 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="privateBoardEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_PrivateBoard_Ins(DBConnectionEntity dbConnectionEntity, PrivateBoardEntity privateBoardEntity)
        {
            var result = new ResultEntity<PrivateBoardEntity>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbPrivateBoard()
                {
                    tiType = privateBoardEntity.tiType,
                    vcTitleKeyText = privateBoardEntity.vcTitleKeyText,
                    vcDescriptKeyText = privateBoardEntity.vcDescriptKeyText,
                    tiMain = privateBoardEntity.tiMain,
                    iManagerSeq = privateBoardEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_PrivateBoard_Ins(dbConnectionEntity, dbData);

                // DAL_PrivateBoard_Ins 확인
                if (result.result < 1)
                {
                    // DAL_PrivateBoard_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogPrivateBoardEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = privateBoardEntity.iManagerSeq,
                    biSeq = result.gClass.biSeq,
                    tiBoardType = privateBoardEntity.tiType,
                    vcTitleKeyText = privateBoardEntity.vcTitleKeyText,
                    vcDescriptKeyText = privateBoardEntity.vcDescriptKeyText,
                    tiMain = privateBoardEntity.tiMain,
                    tiType = LogActionType.Insert,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogPrivateBoard_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_PrivateBoard_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_PrivateBoard_Ins : \n [DBConnectionEntity:{0}], \n [PrivateBoardEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(privateBoardEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_PrivateBoard_Upd (공지, 뉴스 등 게시판 수정)
        /// <summary>
        /// 공지, 뉴스 등 게시판 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="privateBoardEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_PrivateBoard_Upd(DBConnectionEntity dbConnectionEntity, PrivateBoardEntity privateBoardEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbPrivateBoard()
                {
                    biSeq = privateBoardEntity.biSeq,
                    tiType = privateBoardEntity.tiType,
                    vcTitleKeyText = privateBoardEntity.vcTitleKeyText,
                    vcDescriptKeyText = privateBoardEntity.vcDescriptKeyText,
                    tiMain = privateBoardEntity.tiMain,
                    iManagerSeq = privateBoardEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_PrivateBoard_Upd(dbConnectionEntity, dbData);

                // DAL_PrivateBoard_Upd 확인
                if (result.result < 1)
                {
                    // DAL_PrivateBoard_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogPrivateBoardEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = privateBoardEntity.iManagerSeq,
                    biSeq = privateBoardEntity.biSeq,
                    tiBoardType = privateBoardEntity.tiType,
                    vcTitleKeyText = privateBoardEntity.vcTitleKeyText,
                    vcDescriptKeyText = privateBoardEntity.vcDescriptKeyText,
                    tiMain = privateBoardEntity.tiMain,
                    tiType = LogActionType.Update,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogPrivateBoard_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_PrivateBoard_Upd 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_PrivateBoard_Upd : \n [DBConnectionEntity:{0}], \n [PrivateBoardEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(privateBoardEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_PrivateBoard_Del (공지, 뉴스 등 게시판 삭제)
        /// <summary>
        /// 공지, 뉴스 등 게시판 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="platFormEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_PrivateBoard_Del(DBConnectionEntity dbConnectionEntity, PrivateBoardEntity privateBoardEntity)
        {
            var result = new ResultEntity<DataSet>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbPrivateBoard()
                {
                    biSeq = privateBoardEntity.biSeq,
                    tiType = privateBoardEntity.tiType,
                    iManagerSeq = privateBoardEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_PrivateBoard_Del(dbConnectionEntity, dbData);

                // DAL_PrivateBoard_Del 확인
                if (result.result < 1)
                {
                    // DAL_PrivateBoard_Del 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogPrivateBoardEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = privateBoardEntity.iManagerSeq,
                    biSeq = privateBoardEntity.biSeq,
                    tiBoardType = privateBoardEntity.tiType,
                    vcTitleKeyText = String.Empty,
                    vcDescriptKeyText = String.Empty,
                    tiMain = 0,
                    tiType = LogActionType.Delete,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogPrivateBoard_Ins(dbConnectionEntity, logData);
                #endregion

                #region // !++ 하위(PrivateBoardData) 삭제정보
                if (result.gClass != null)
                {
                    using (var ds = result.gClass)
                    {
                        #region // !++ 데이터 축출 및 Log 등록
                        using (var dt = ds.Tables[0])
                        {
                            if (dt.Rows.Count > 0)
                            {
                                var taskChild = new Task[dt.Rows.Count];
                                for (int i = 0; i < dt.Rows.Count; i++)
                                {
                                    var privateBoardDataData = new LogPrivateBoardDataEntity()
                                    {
                                        biTXIDX = logData.biTXIDX,
                                        iManagerSeq = logData.iManagerSeq,
                                        biSeq = Int64.Parse(dt.Rows[i]["biSeq"].ToString()),
                                        biPrivateBoardSeq = privateBoardEntity.biSeq,
                                        vcFileName = dt.Rows[i]["vcFileName"].ToString(),
                                        vcSaveFolder = dt.Rows[i]["vcSaveFolder"].ToString(),
                                        vcSaveName = dt.Rows[i]["vcSaveName"].ToString(),
                                        vcSaveType = dt.Rows[i]["vcSaveType"].ToString(),
                                        iSaveSize = Int32.Parse(dt.Rows[i]["iSaveSize"].ToString()),
                                        tiType = LogActionType.Delete,
                                        vcIP = String.Empty
                                    };
                                    // Log 데이터 실행
                                    // await bllLogData.BLL_LogPrivateBoardData_Ins(dbConnectionEntity, privateBoardDataData);
                                    taskChild[i] = Task.Factory.StartNew(() => bllLogData.BLL_LogPrivateBoardData_Ins(dbConnectionEntity, privateBoardDataData));
                                }
                                await Task.WhenAll(taskChild);
                            }
                        }
                        #endregion
                    }
                }
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_PrivateBoard_Del 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_PrivateBoard_Del : \n [DBConnectionEntity:{0}], \n [PrivateBoardEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(privateBoardEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_PrivateBoardData_Sel (공지, 뉴스 등 게시판 데이터 목록)
        /// <summary>
        /// 공지, 뉴스 등 게시판 데이터 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="privateBoardEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<PrivateBoardDataEntity>>> BLL_PrivateBoardData_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, PrivateBoardDataEntity privateBoardDataEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<PrivateBoardDataEntity>>();
            var dataList = new List<PrivateBoardDataEntity>();

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbPrivateBoardData()
                {
                    biPrivateBoardSeq = privateBoardDataEntity.biPrivateBoardSeq
                };
                #endregion

                //+ DAL_PrivateBoardData_Sel
                using (var ds = await dalCrawling.DAL_PrivateBoardData_Sel(dbConnectionEntity, pageDBEntity, dbData))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var privateBoardDataData = new PrivateBoardDataEntity()
                                {
                                    biSeq = Int64.Parse(dt.Rows[i]["biSeq"].ToString()),
                                    vcFileName = dt.Rows[i]["vcFileName"].ToString(),
                                    vcSaveFolder = dt.Rows[i]["vcSaveFolder"].ToString(),
                                    vcSaveName = dt.Rows[i]["vcSaveName"].ToString(),
                                    vcSaveType = dt.Rows[i]["vcSaveType"].ToString(),
                                    iSaveSize = Int32.Parse(dt.Rows[i]["iSaveSize"].ToString()),
                                    iDownLoad = Int32.Parse(dt.Rows[i]["iDownLoad"].ToString()),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(privateBoardDataData);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_PrivateBoardData_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n [PrivateBoardDataEntity:{2}], \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), libUtility.ToJson(privateBoardDataEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_PrivateBoardData_Detail_Sel (공지, 뉴스 등 게시판 데이터 상세정보)
        /// <summary>
        /// 공지, 뉴스 등 게시판 데이터 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="privateBoardDataEntity"></param>
        /// <returns></returns>
        public async Task<PrivateBoardDataEntity> BLL_PrivateBoardData_Detail_Sel(DBConnectionEntity dbConnectionEntity, PrivateBoardDataEntity privateBoardDataEntity)
        {

            var getResult = new ResultEntity<PrivateBoardDataEntity>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbPrivateBoardData()
                {
                    biSeq = privateBoardDataEntity.biSeq,
                    biPrivateBoardSeq = privateBoardDataEntity.biPrivateBoardSeq
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalCrawling.DAL_PrivateBoardData_Detail_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ 공지, 뉴스 등 게시판 데이터 상세정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            getResult.gClass = null;
                        }
                        else
                        {
                            var privateBoardDataData = new PrivateBoardDataEntity()
                            {
                                vcFileName = dt.Rows[0]["vcFileName"].ToString(),
                                vcSaveFolder = dt.Rows[0]["vcSaveFolder"].ToString(),
                                vcSaveName = dt.Rows[0]["vcSaveName"].ToString(),
                                vcSaveType = dt.Rows[0]["vcSaveType"].ToString(),
                                iSaveSize = Int32.Parse(dt.Rows[0]["iSaveSize"].ToString()),
                                iDownLoad = Int32.Parse(dt.Rows[0]["iDownLoad"].ToString()),
                                dtRegDate = DateTime.Parse(dt.Rows[0]["dtRegDate"].ToString())
                            };
                            getResult.gClass = privateBoardDataData;
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_PrivateBoardData_Detail_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_PrivateBoardData_Detail_Sel : \n [DBConnectionEntity:{0}], \n [PrivateBoardDataEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(privateBoardDataEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;

        }
        #endregion


        #region // !++ BLL_PrivateBoardData_Ins (공지, 뉴스 등 게시판 데이터 등록)
        /// <summary>
        /// 공지, 뉴스 등 게시판 데이터 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="privateBoardDataEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_PrivateBoardData_Ins(DBConnectionEntity dbConnectionEntity, PrivateBoardDataEntity privateBoardDataEntity)
        {
            var result = new ResultEntity<PrivateBoardDataEntity>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbPrivateBoardData()
                {
                    biPrivateBoardSeq = privateBoardDataEntity.biPrivateBoardSeq,
                    vcFileName = privateBoardDataEntity.vcFileName,
                    vcSaveFolder = privateBoardDataEntity.vcSaveFolder,
                    vcSaveName = privateBoardDataEntity.vcSaveName,
                    vcSaveType = privateBoardDataEntity.vcSaveType,
                    iSaveSize = privateBoardDataEntity.iSaveSize,
                    iManagerSeq = privateBoardDataEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_PrivateBoardData_Ins(dbConnectionEntity, dbData);

                // DAL_PrivateBoardData_Ins 확인
                if (result.result < 1)
                {
                    // DAL_PrivateBoardData_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogPrivateBoardDataEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = privateBoardDataEntity.iManagerSeq,
                    biSeq = result.gClass.biSeq,
                    biPrivateBoardSeq = privateBoardDataEntity.biPrivateBoardSeq,
                    vcFileName = privateBoardDataEntity.vcFileName,
                    vcSaveFolder = privateBoardDataEntity.vcSaveFolder,
                    vcSaveName = privateBoardDataEntity.vcSaveName,
                    vcSaveType = privateBoardDataEntity.vcSaveType,
                    iSaveSize = privateBoardDataEntity.iSaveSize,
                    tiType = LogActionType.Insert,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogPrivateBoardData_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_PrivateBoardData_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_PrivateBoardData_Ins : \n [DBConnectionEntity:{0}], \n [PrivateBoardDataEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(privateBoardDataEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_PrivateBoardData_Upd (공지, 뉴스 등 게시판 데이터 수정)
        /// <summary>
        /// 공지, 뉴스 등 게시판 데이터 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="privateBoardDataEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_PrivateBoardData_Upd(DBConnectionEntity dbConnectionEntity, PrivateBoardDataEntity privateBoardDataEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbPrivateBoardData()
                {
                    biSeq = privateBoardDataEntity.biSeq,
                    biPrivateBoardSeq = privateBoardDataEntity.biPrivateBoardSeq,
                    vcFileName = privateBoardDataEntity.vcFileName,
                    vcSaveFolder = privateBoardDataEntity.vcSaveFolder,
                    vcSaveName = privateBoardDataEntity.vcSaveName,
                    vcSaveType = privateBoardDataEntity.vcSaveType,
                    iSaveSize = privateBoardDataEntity.iSaveSize,
                    iManagerSeq = privateBoardDataEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_PrivateBoardData_Upd(dbConnectionEntity, dbData);

                // DAL_PrivateBoardData_Upd 확인
                if (result.result < 1)
                {
                    // DAL_PrivateBoardData_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogPrivateBoardDataEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = privateBoardDataEntity.iManagerSeq,
                    biSeq = privateBoardDataEntity.biSeq,
                    biPrivateBoardSeq = privateBoardDataEntity.biPrivateBoardSeq,
                    vcFileName = privateBoardDataEntity.vcFileName,
                    vcSaveFolder = privateBoardDataEntity.vcSaveFolder,
                    vcSaveName = privateBoardDataEntity.vcSaveName,
                    vcSaveType = privateBoardDataEntity.vcSaveType,
                    iSaveSize = privateBoardDataEntity.iSaveSize,
                    tiType = LogActionType.Update,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogPrivateBoardData_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_PrivateBoardData_Upd 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_PrivateBoardData_Upd : \n [DBConnectionEntity:{0}], \n [PrivateBoardDataEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(privateBoardDataEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_PrivateBoardData_Del (공지, 뉴스 등 게시판 데이터 삭제)
        /// <summary>
        /// 공지, 뉴스 등 게시판 데이터 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="privateBoardDataEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_PrivateBoardData_Del(DBConnectionEntity dbConnectionEntity, PrivateBoardDataEntity privateBoardDataEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbPrivateBoardData()
                {
                    biSeq = privateBoardDataEntity.biSeq,
                    biPrivateBoardSeq = privateBoardDataEntity.biPrivateBoardSeq,
                    iManagerSeq = privateBoardDataEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_PrivateBoardData_Del(dbConnectionEntity, dbData);

                // DAL_PrivateBoardData_Del 확인
                if (result.result < 1)
                {
                    // DAL_PrivateBoardData_Del 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogPrivateBoardDataEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = privateBoardDataEntity.iManagerSeq,
                    biSeq = privateBoardDataEntity.biSeq,
                    biPrivateBoardSeq = privateBoardDataEntity.biPrivateBoardSeq,
                    vcFileName = String.Empty,
                    vcSaveFolder = String.Empty,
                    vcSaveName = String.Empty,
                    vcSaveType = String.Empty,
                    iSaveSize = 0,
                    tiType = LogActionType.Delete,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogPrivateBoardData_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_PrivateBoardData_Del 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_PrivateBoardData_Del : \n [DBConnectionEntity:{0}], \n [PrivateBoardDataEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(privateBoardDataEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_CompanyGroup_Sel (회사조직[분류] 목록)
        /// <summary>
        /// 회사조직[분류] 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<CompanyGroupEntity>>> BLL_CompanyGroup_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<CompanyGroupEntity>>();
            var dataList = new List<CompanyGroupEntity>();

            try
            {

                //+ DAL_CompanyGroup_Sel
                using (var ds = await dalCrawling.DAL_CompanyGroup_Sel(dbConnectionEntity, pageDBEntity))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var companyGroupData = new CompanyGroupEntity()
                                {
                                    iSeq = Int32.Parse(dt.Rows[i]["iSeq"].ToString()),
                                    vcName = dt.Rows[i]["vcName"].ToString(),
                                    vcNameKeyText = dt.Rows[i]["vcNameKeyText"].ToString(),
                                    vcAbbreviation = dt.Rows[i]["vcAbbreviation"].ToString(),
                                    vcAbbreviationKeyText = dt.Rows[i]["vcAbbreviationKeyText"].ToString(),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(companyGroupData);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_CompanyGroup_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_CompanyGroup_Detail_Sel (회사조직[분류] 상세정보)
        /// <summary>
        /// 회사조직[분류] 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="companyGroupEntity"></param>
        /// <returns></returns>
        public async Task<CompanyGroupEntity> BLL_CompanyGroup_Detail_Sel(DBConnectionEntity dbConnectionEntity, CompanyGroupEntity companyGroupEntity)
        {

            var getResult = new ResultEntity<CompanyGroupEntity>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbCompanyGroup()
                {
                    iSeq = companyGroupEntity.iSeq
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalCrawling.DAL_CompanyGroup_Detail_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ 회사조직[분류] 상세정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            getResult.gClass = null;
                        }
                        else
                        {
                            var companyGroupData = new CompanyGroupEntity()
                            {
                                vcName = dt.Rows[0]["vcName"].ToString(),
                                vcNameKeyText = dt.Rows[0]["vcNameKeyText"].ToString(),
                                vcAbbreviation = dt.Rows[0]["vcAbbreviation"].ToString(),
                                vcAbbreviationKeyText = dt.Rows[0]["vcAbbreviationKeyText"].ToString(),
                                dtRegDate = DateTime.Parse(dt.Rows[0]["dtRegDate"].ToString())
                            };
                            getResult.gClass = companyGroupData;
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_CompanyGroup_Detail_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_CompanyGroup_Detail_Sel : \n [DBConnectionEntity:{0}], \n [CompanyGroupEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(companyGroupEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;

        }
        #endregion


        #region // !++ BLL_CompanyGroup_Ins (회사조직[분류] 등록)
        /// <summary>
        /// 회사조직[분류] 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="companyGroupEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_CompanyGroup_Ins(DBConnectionEntity dbConnectionEntity, CompanyGroupEntity companyGroupEntity)
        {
            var result = new ResultEntity<CompanyGroupEntity>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbCompanyGroup()
                {
                    vcName = companyGroupEntity.vcName,
                    vcNameKeyText = companyGroupEntity.vcNameKeyText,
                    vcAbbreviation = companyGroupEntity.vcAbbreviation,
                    vcAbbreviationKeyText = companyGroupEntity.vcAbbreviationKeyText,
                    iManagerSeq = companyGroupEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.usp_CompanyGroup_Ins(dbConnectionEntity, dbData);

                // DAL_CompanyGroup_Ins 확인
                if (result.result < 1)
                {
                    // DAL_CompanyGroup_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogCompanyGroupEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = companyGroupEntity.iManagerSeq,
                    iSeq = result.gClass.iSeq,
                    vcName = companyGroupEntity.vcName,
                    vcNameKeyText = companyGroupEntity.vcNameKeyText,
                    vcAbbreviation = companyGroupEntity.vcAbbreviation,
                    vcAbbreviationKeyText = companyGroupEntity.vcAbbreviationKeyText,
                    tiType = LogActionType.Insert,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogCompanyGroup_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_CompanyGroup_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_CompanyGroup_Ins : \n [DBConnectionEntity:{0}], \n [CompanyGroupEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(companyGroupEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_CompanyGroup_Upd (회사조직[분류] 수정)
        /// <summary>
        /// 회사조직[분류] 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="companyGroupEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_CompanyGroup_Upd(DBConnectionEntity dbConnectionEntity, CompanyGroupEntity companyGroupEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbCompanyGroup()
                {
                    iSeq = companyGroupEntity.iSeq,
                    vcName = companyGroupEntity.vcName,
                    vcNameKeyText = companyGroupEntity.vcNameKeyText,
                    vcAbbreviation = companyGroupEntity.vcAbbreviation,
                    vcAbbreviationKeyText = companyGroupEntity.vcAbbreviationKeyText,
                    iManagerSeq = companyGroupEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.usp_CompanyGroup_Upd(dbConnectionEntity, dbData);

                // usp_CompanyGroup_Upd 확인
                if (result.result < 1)
                {
                    // usp_CompanyGroup_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogCompanyGroupEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = companyGroupEntity.iManagerSeq,
                    iSeq = companyGroupEntity.iSeq,
                    vcName = companyGroupEntity.vcName,
                    vcNameKeyText = companyGroupEntity.vcNameKeyText,
                    vcAbbreviation = companyGroupEntity.vcAbbreviation,
                    vcAbbreviationKeyText = companyGroupEntity.vcAbbreviationKeyText,
                    tiType = LogActionType.Update,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogCompanyGroup_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // usp_CompanyGroup_Upd 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_CompanyGroup_Upd : \n [DBConnectionEntity:{0}], \n [CompanyGroupEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(companyGroupEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_CompanyGroup_Del (회사조직[분류] 삭제)
        /// <summary>
        /// 회사조직[분류] 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="companyGroupEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_CompanyGroup_Del(DBConnectionEntity dbConnectionEntity, CompanyGroupEntity companyGroupEntity)
        {
            var result = new ResultEntity<DataSet>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbCompanyGroup()
                {
                    iSeq = companyGroupEntity.iSeq,
                    iManagerSeq = companyGroupEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_CompanyGroup_Del(dbConnectionEntity, dbData);

                // DAL_CompanyGroup_Del 확인
                if (result.result < 1)
                {
                    // DAL_CompanyGroup_Del 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogCompanyGroupEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = companyGroupEntity.iManagerSeq,
                    iSeq = companyGroupEntity.iSeq,
                    vcName = String.Empty,
                    vcNameKeyText = String.Empty,
                    vcAbbreviation = String.Empty,
                    vcAbbreviationKeyText = String.Empty,
                    tiType = LogActionType.Delete,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogCompanyGroup_Ins(dbConnectionEntity, logData);
                #endregion

                #region // !++ 하위(PrivateBoardData) 삭제정보
                if (result.gClass != null)
                {
                    using (var ds = result.gClass)
                    {
                        #region // !++ 데이터 축출 및 Log 등록
                        using (var dt = ds.Tables[0])
                        {
                            if (dt.Rows.Count > 0)
                            {
                                var taskChild = new Task[dt.Rows.Count];
                                for (int i = 0; i < dt.Rows.Count; i++)
                                {
                                    var companyPeopleData = new LogCompanyPeopleEntity()
                                    {
                                        biTXIDX = logData.biTXIDX,
                                        iManagerSeq = logData.iManagerSeq,
                                        iSeq = Int32.Parse(dt.Rows[i]["iSeq"].ToString()),
                                        iCompanyGroupSeq = companyGroupEntity.iSeq,
                                        vcName = dt.Rows[i]["vcName"].ToString(),
                                        vcPosition = dt.Rows[i]["vcPosition"].ToString(),
                                        tDescription = dt.Rows[i]["tDescription"].ToString(),
                                        vcFolder = dt.Rows[i]["vcFolder"].ToString(),
                                        vcImage = dt.Rows[i]["vcImage"].ToString(),
                                        tiType = LogActionType.Delete,
                                        vcIP = String.Empty
                                    };
                                    // Log 데이터 실행
                                    taskChild[i] = Task.Factory.StartNew(() => bllLogData.BLL_LogCompanyPeople_Ins(dbConnectionEntity, companyPeopleData));
                                }
                                await Task.WhenAll(taskChild);
                            }
                        }
                        #endregion
                    }
                }
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_CompanyGroup_Del 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_CompanyGroup_Del : \n [DBConnectionEntity:{0}], \n [CompanyGroupEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(companyGroupEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_CompanyPeople_Sel (회사조직구성원 목록)
        /// <summary>
        /// 회사조직[분류] 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="companyPeopleEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<CompanyPeopleEntity>>> BLL_CompanyPeople_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, CompanyPeopleEntity companyPeopleEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<CompanyPeopleEntity>>();
            var dataList = new List<CompanyPeopleEntity>();

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbCompanyPeople()
                {
                    iCompanyGroupSeq = companyPeopleEntity.iCompanyGroupSeq
                };
                #endregion

                //+ DAL_CompanyPeople_Sel
                using (var ds = await dalCrawling.DAL_CompanyPeople_Sel(dbConnectionEntity, pageDBEntity, dbData))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var companyPeopleData = new CompanyPeopleEntity()
                                {
                                    iSeq = Int32.Parse(dt.Rows[i]["iSeq"].ToString()),
                                    vcName = dt.Rows[i]["vcName"].ToString(),
                                    vcPosition = dt.Rows[i]["vcPosition"].ToString(),
                                    vcFolder = dt.Rows[i]["vcFolder"].ToString(),
                                    vcImage = dt.Rows[i]["vcImage"].ToString(),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(companyPeopleData);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_CompanyPeople_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n [CompanyPeopleEntity:{2}], \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), libUtility.ToJson(companyPeopleEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_CompanyPeople_Detail_Sel (회사조직구성원 상세정보)
        /// <summary>
        /// 회사조직구성원 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="companyPeopleEntity"></param>
        /// <returns></returns>
        public async Task<CompanyPeopleEntity> BLL_CompanyPeople_Detail_Sel(DBConnectionEntity dbConnectionEntity, CompanyPeopleEntity companyPeopleEntity)
        {

            var getResult = new ResultEntity<CompanyPeopleEntity>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbCompanyPeople()
                {
                    iSeq = companyPeopleEntity.iSeq,
                    iCompanyGroupSeq = companyPeopleEntity.iCompanyGroupSeq
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalCrawling.DAL_CompanyPeople_Detail_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ 회사조직구성원 상세정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            getResult.gClass = null;
                        }
                        else
                        {
                            var companyPeopleData = new CompanyPeopleEntity()
                            {
                                vcName = dt.Rows[0]["vcName"].ToString(),
                                vcPosition = dt.Rows[0]["vcPosition"].ToString(),
                                tDescription = dt.Rows[0]["tDescription"].ToString(),
                                vcFolder = dt.Rows[0]["vcFolder"].ToString(),
                                vcImage = dt.Rows[0]["vcImage"].ToString(),
                                dtRegDate = DateTime.Parse(dt.Rows[0]["dtRegDate"].ToString())
                            };
                            getResult.gClass = companyPeopleData;
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_CompanyPeople_Detail_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_CompanyPeople_Detail_Sel : \n [DBConnectionEntity:{0}], \n [CompanyPeopleEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(companyPeopleEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;

        }
        #endregion


        #region // !++ BLL_CompanyPeople_Ins (회사조직구성원 등록)
        /// <summary>
        /// 회사조직구성원 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="companyPeopleEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_CompanyPeople_Ins(DBConnectionEntity dbConnectionEntity, CompanyPeopleEntity companyPeopleEntity)
        {
            var result = new ResultEntity<CompanyPeopleEntity>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbCompanyPeople()
                {
                    iCompanyGroupSeq = companyPeopleEntity.iCompanyGroupSeq,
                    vcName = companyPeopleEntity.vcName,
                    vcPosition = companyPeopleEntity.vcPosition,
                    tDescription = companyPeopleEntity.tDescription,
                    vcFolder = companyPeopleEntity.vcFolder,
                    vcImage = companyPeopleEntity.vcImage,
                    iManagerSeq = companyPeopleEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.usp_CompanyPeople_Ins(dbConnectionEntity, dbData);

                // DAL_CompanyPeople_Ins 확인
                if (result.result < 1)
                {
                    // DAL_CompanyPeople_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogCompanyPeopleEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = companyPeopleEntity.iManagerSeq,
                    iSeq = result.gClass.iSeq,
                    iCompanyGroupSeq = companyPeopleEntity.iCompanyGroupSeq,
                    vcName = companyPeopleEntity.vcName,
                    vcPosition = companyPeopleEntity.vcPosition,
                    tDescription = companyPeopleEntity.tDescription,
                    vcFolder = companyPeopleEntity.vcFolder,
                    vcImage = companyPeopleEntity.vcImage,
                    tiType = LogActionType.Insert,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogCompanyPeople_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_CompanyPeople_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_CompanyPeople_Ins : \n [DBConnectionEntity:{0}], \n [CompanyPeopleEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(companyPeopleEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_CompanyPeople_Upd (회사조직구성원 수정)
        /// <summary>
        /// 회사조직구성원 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="companyPeopleEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_CompanyPeople_Upd(DBConnectionEntity dbConnectionEntity, CompanyPeopleEntity companyPeopleEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbCompanyPeople()
                {
                    iSeq = companyPeopleEntity.iSeq,
                    iCompanyGroupSeq = companyPeopleEntity.iCompanyGroupSeq,
                    vcName = companyPeopleEntity.vcName,
                    vcPosition = companyPeopleEntity.vcPosition,
                    tDescription = companyPeopleEntity.tDescription,
                    vcFolder = companyPeopleEntity.vcFolder,
                    vcImage = companyPeopleEntity.vcImage,
                    iManagerSeq = companyPeopleEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.usp_CompanyPeople_Upd(dbConnectionEntity, dbData);

                // usp_CompanyPeople_Upd 확인
                if (result.result < 1)
                {
                    // usp_CompanyPeople_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogCompanyPeopleEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = companyPeopleEntity.iManagerSeq,
                    iSeq = companyPeopleEntity.iSeq,
                    iCompanyGroupSeq = companyPeopleEntity.iCompanyGroupSeq,
                    vcName = companyPeopleEntity.vcName,
                    vcPosition = companyPeopleEntity.vcPosition,
                    tDescription = companyPeopleEntity.tDescription,
                    vcFolder = companyPeopleEntity.vcFolder,
                    vcImage = companyPeopleEntity.vcImage,
                    tiType = LogActionType.Update,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogCompanyPeople_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_CompanyPeople_Upd 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_CompanyPeople_Upd : \n [DBConnectionEntity:{0}], \n [CompanyPeopleEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(companyPeopleEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_CompanyPeople_Del (회사조직구성원 삭제)
        /// <summary>
        /// 회사조직구성원 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="companyPeopleEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_CompanyPeople_Del(DBConnectionEntity dbConnectionEntity, CompanyPeopleEntity companyPeopleEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbCompanyPeople()
                {
                    iSeq = companyPeopleEntity.iSeq,
                    iCompanyGroupSeq = companyPeopleEntity.iCompanyGroupSeq
                };
                #endregion
                result = await dalCrawling.usp_CompanyPeople_Del(dbConnectionEntity, dbData);

                // usp_CompanyPeople_Del 확인
                if (result.result < 1)
                {
                    // usp_CompanyPeople_Del 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogCompanyPeopleEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = companyPeopleEntity.iManagerSeq,
                    iSeq = companyPeopleEntity.iSeq,
                    iCompanyGroupSeq = companyPeopleEntity.iCompanyGroupSeq,
                    vcName = String.Empty,
                    vcPosition = String.Empty,
                    tDescription = String.Empty,
                    vcFolder = String.Empty,
                    vcImage = String.Empty,
                    tiType = LogActionType.Delete,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogCompanyPeople_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_CompanyPeople_Del 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_CompanyPeople_Del : \n [DBConnectionEntity:{0}], \n [CompanyPeopleEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(companyPeopleEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_Blog_Sel (블로그 목록)
        /// <summary>
        /// 블로그 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<BlogEntity>>> BLL_Blog_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<BlogEntity>>();
            var dataList = new List<BlogEntity>();

            try
            {

                //+ DAL_Blog_Sel
                using (var ds = await dalCrawling.DAL_Blog_Sel(dbConnectionEntity, pageDBEntity))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var blogData = new BlogEntity()
                                {
                                    biSeq = Int64.Parse(dt.Rows[i]["biSeq"].ToString()),
                                    vcTitleFolder = dt.Rows[i]["vcTitleFolder"].ToString(),
                                    vcTitleImage = dt.Rows[i]["vcTitleImage"].ToString(),
                                    iRead = Int32.Parse(dt.Rows[i]["iRead"].ToString()),
                                    iComment = Int32.Parse(dt.Rows[i]["iComment"].ToString()),
                                    iLike = Int32.Parse(dt.Rows[i]["iLike"].ToString()),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(blogData);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_Blog_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_Blog_Detail_Sel (블로그 상세정보)
        /// <summary>
        /// 블로그 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="blogEntity"></param>
        /// <returns></returns>
        public async Task<BlogEntity> BLL_Blog_Detail_Sel(DBConnectionEntity dbConnectionEntity, BlogEntity blogEntity)
        {

            var getResult = new ResultEntity<BlogEntity>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbBlog()
                {
                    biSeq = blogEntity.biSeq
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalCrawling.DAL_Blog_Detail_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ 블로그 상세정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            getResult.gClass = null;
                        }
                        else
                        {
                            var blogData = new BlogEntity()
                            {
                                vcTitleFolder = dt.Rows[0]["vcTitleFolder"].ToString(),
                                vcTitleImage = dt.Rows[0]["vcTitleImage"].ToString(),
                                tDescription = dt.Rows[0]["tDescription"].ToString(),
                                iRead = Int32.Parse(dt.Rows[0]["iRead"].ToString()),
                                iComment = Int32.Parse(dt.Rows[0]["iComment"].ToString()),
                                iLike = Int32.Parse(dt.Rows[0]["iLike"].ToString()),
                                dtRegDate = DateTime.Parse(dt.Rows[0]["dtRegDate"].ToString())
                            };
                            getResult.gClass = blogData;
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_Blog_Detail_Sel 실패. 오류 발생!
                eResultCode = EResultCode.Error_DB_Exception;
                getResult.ErrorMsg = eResultCode.ToString();
                Logger.Log(ELogType.Fatal, "BLL_Blog_Detail_Sel : \n [DBConnectionEntity:{0}], \n [BlogEntity:{1}], \n [ResultEntity:{2}, \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(blogEntity), libUtility.ToJson(getResult), exc.Message, exc.StackTrace);
                return getResult.gClass;
            }
            return getResult.gClass;

        }
        #endregion


        #region // !++ BLL_Blog_Ins (블로그 등록)
        /// <summary>
        /// 블로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="blogEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_Blog_Ins(DBConnectionEntity dbConnectionEntity, BlogEntity blogEntity)
        {
            var result = new ResultEntity<BlogEntity>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbBlog()
                {
                    vcTitle = blogEntity.vcTitle,
                    vcTitleFolder = blogEntity.vcTitleFolder,
                    vcTitleImage = blogEntity.vcTitleImage,
                    tDescription = blogEntity.tDescription,
                    iManagerSeq = blogEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.usp_Blog_Ins(dbConnectionEntity, dbData);

                // usp_Blog_Ins 확인
                if (result.result < 1)
                {
                    // usp_Blog_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogBlogEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = blogEntity.iManagerSeq,
                    biSeq = result.gClass.biSeq,
                    vcTitle = blogEntity.vcTitle,
                    vcTitleFolder = blogEntity.vcTitleFolder,
                    vcTitleImage = blogEntity.vcTitleImage,
                    tDescription = blogEntity.tDescription,
                    tiType = LogActionType.Insert,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogBlog_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_Blog_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_Blog_Ins : \n [DBConnectionEntity:{0}], \n [BlogEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(blogEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_Blog_Upd (블로그 수정)
        /// <summary>
        /// 블로그 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="blogEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_Blog_Upd(DBConnectionEntity dbConnectionEntity, BlogEntity blogEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbBlog()
                {
                    biSeq = blogEntity.biSeq,
                    vcTitle = blogEntity.vcTitle,
                    vcTitleFolder = blogEntity.vcTitleFolder,
                    vcTitleImage = blogEntity.vcTitleImage,
                    tDescription = blogEntity.tDescription,
                    iManagerSeq = blogEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.usp_Blog_Upd(dbConnectionEntity, dbData);

                // usp_Blog_Upd 확인
                if (result.result < 1)
                {
                    // usp_Blog_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogBlogEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = blogEntity.iManagerSeq,
                    biSeq = blogEntity.biSeq,
                    vcTitle = blogEntity.vcTitle,
                    vcTitleFolder = blogEntity.vcTitleFolder,
                    vcTitleImage = blogEntity.vcTitleImage,
                    tDescription = blogEntity.tDescription,
                    tiType = LogActionType.Update,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogBlog_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_Blog_Upd 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_Blog_Upd : \n [DBConnectionEntity:{0}], \n [BlogEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(blogEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_Blog_Del (블로그 삭제)
        /// <summary>
        /// 블로그 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="blogEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_Blog_Del(DBConnectionEntity dbConnectionEntity, BlogEntity blogEntity)
        {
            var result = new ResultEntity<DataSet>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbBlog()
                {
                    biSeq = blogEntity.biSeq,
                    iManagerSeq = blogEntity.iManagerSeq
                };
                #endregion
                result = await dalCrawling.DAL_Blog_Del(dbConnectionEntity, dbData);

                // DAL_CompanyGroup_Del 확인
                if (result.result < 1)
                {
                    // DAL_CompanyGroup_Del 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogBlogEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = blogEntity.iManagerSeq,
                    biSeq = blogEntity.biSeq,
                    vcTitle = String.Empty,
                    vcTitleFolder = String.Empty,
                    vcTitleImage = String.Empty,
                    tDescription = String.Empty,
                    tiType = LogActionType.Delete,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogBlog_Ins(dbConnectionEntity, logData);
                #endregion

                #region // !++ 하위(tbLogBlogComment, tbLogBlogLike) 삭제정보
                if (result.gClass != null)
                {
                    using (var ds = result.gClass)
                    {
                        #region // !++ 첫번째 데이터 축출 및 Log 등록
                        using (var dt = ds.Tables[0])
                        {
                            if (dt.Rows.Count > 0)
                            {
                                var taskChild = new Task[dt.Rows.Count];
                                for (int i = 0; i < dt.Rows.Count; i++)
                                {
                                    var blogCommentData = new LogBlogCommentEntity()
                                    {
                                        biTXIDX = logData.biTXIDX,
                                        iManagerSeq = logData.iManagerSeq,
                                        biSeq = Int64.Parse(dt.Rows[i]["iSeq"].ToString()),
                                        biBlogSeq = blogEntity.biSeq,
                                        biMemberSeq = Int64.Parse(dt.Rows[i]["biMemberSeq"].ToString()),
                                        vcAccount = dt.Rows[i]["vcAccount"].ToString(),
                                        vcName = dt.Rows[i]["vcName"].ToString(),
                                        tDescription = dt.Rows[i]["tDescription"].ToString(),
                                        tiType = LogActionType.Delete,
                                        vcIP = dt.Rows[i]["vcIP"].ToString()
                                    };
                                    // Log 데이터 실행
                                    taskChild[i] = Task.Factory.StartNew(() => bllLogData.BLL_LogBlogComment_Ins(dbConnectionEntity, blogCommentData));
                                }
                                await Task.WhenAll(taskChild);
                            }
                        }
                        #endregion

                        #region // !++ 두번째 데이터 축출 및 Log 등록
                        using (var dt = ds.Tables[1])
                        {
                            if (dt.Rows.Count > 0)
                            {
                                var taskChild = new Task[dt.Rows.Count];
                                for (int i = 0; i < dt.Rows.Count; i++)
                                {
                                    var blogLikeData = new LogBlogLikeEntity()
                                    {
                                        biTXIDX = logData.biTXIDX,
                                        iManagerSeq = logData.iManagerSeq,
                                        biBlogSeq = blogEntity.biSeq,
                                        biMemberSeq = Int64.Parse(dt.Rows[i]["biMemberSeq"].ToString()),
                                        vcAccount = dt.Rows[i]["vcAccount"].ToString(),
                                        vcName = dt.Rows[i]["vcName"].ToString(),
                                        tiType = LogActionType.Delete,
                                        vcIP = dt.Rows[i]["vcIP"].ToString()
                                    };
                                    // Log 데이터 실행
                                    taskChild[i] = Task.Factory.StartNew(() => bllLogData.BLL_LogBlogLike_Ins(dbConnectionEntity, blogLikeData));
                                }
                                await Task.WhenAll(taskChild);
                            }
                        }
                        #endregion
                    }
                }
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_Blog_Del 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_Blog_Del : \n [DBConnectionEntity:{0}], \n [BlogEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(blogEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_BlogComment_Sel (블로그 댓글 목록)
        /// <summary>
        /// 블로그 댓글 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="blogCommentEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<BlogCommentEntity>>> BLL_BlogComment_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, BlogCommentEntity blogCommentEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<BlogCommentEntity>>();
            var dataList = new List<BlogCommentEntity>();

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbBlogComment()
                {
                    biBlogSeq = blogCommentEntity.biBlogSeq
                };
                #endregion

                //+ DAL_BlogComment_Sel
                using (var ds = await dalCrawling.DAL_BlogComment_Sel(dbConnectionEntity, pageDBEntity, dbData))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var blogCommentData = new BlogCommentEntity()
                                {
                                    biSeq = Int64.Parse(dt.Rows[i]["biSeq"].ToString()),
                                    biMemberSeq = Int64.Parse(dt.Rows[i]["biMemberSeq"].ToString()),
                                    vcAccount = dt.Rows[i]["vcAccount"].ToString(),
                                    vcName = dt.Rows[i]["vcName"].ToString(),
                                    tDescription = dt.Rows[i]["tDescription"].ToString(),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(blogCommentData);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_BlogComment_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n [BlogCommentEntity:{2}], \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), libUtility.ToJson(blogCommentEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_BlogLike_Sel (블로그 좋아요 목록)
        /// <summary>
        /// 블로그 좋아요 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="blogLikeEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<BlogLikeEntity>>> BLL_BlogLike_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, BlogLikeEntity blogLikeEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<BlogLikeEntity>>();
            var dataList = new List<BlogLikeEntity>();

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbBlogLike()
                {
                    biBlogSeq = blogLikeEntity.biBlogSeq
                };
                #endregion

                //+ DAL_BlogLike_Sel
                using (var ds = await dalCrawling.DAL_BlogLike_Sel(dbConnectionEntity, pageDBEntity, dbData))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var blogLikeData = new BlogLikeEntity()
                                {
                                    biMemberSeq = Int64.Parse(dt.Rows[i]["biMemberSeq"].ToString()),
                                    vcAccount = dt.Rows[i]["vcAccount"].ToString(),
                                    vcName = dt.Rows[i]["vcName"].ToString(),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(blogLikeData);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_BlogLike_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n [BlogLikeEntity:{2}], \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), libUtility.ToJson(blogLikeEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion



    }
    #endregion

}
