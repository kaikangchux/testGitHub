// 게시판정보
export class BoardModel
{

  biSeq: number;
  biMemberSeq: number;
  vcAccount: string;
  vcName: string;
  vcTitle: string;
  tDescription: string;
  iRead: number;
  iCommentCnt: number;
  tiNotice: number;
  vcIP: string;
  dtRegDate: string;

  constructor() {
    this.biSeq = 0;
    this.biMemberSeq = 0;
    this.vcAccount = '';
    this.vcName = '';
    this.vcTitle = '';
    this.tDescription = '';
    this.iRead = 0;
    this.iCommentCnt = 0;
    this.tiNotice = 0;
    this.vcIP = '';
    this.dtRegDate = '';
  }
}
