﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.CrawlingDB
{

    #region // !++ tbBoard
    /// <summary>
    /// 게시판
    /// </summary>
    [Table("tbBoard")]
    public class tbBoard
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        /// <summary>
        /// 게시물 고유번호(AI)
        /// </summary>
        public Int64 biSeq { get; set; }

        [Index(1), Required]
        /// <summary>
        /// 회원 고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        [Index(2), Required, MinLength(4), MaxLength(32)]
        /// <summary>
        /// 계정ID
        /// </summary>
        public String vcAccount { get; set; }

        [Required, MinLength(4), MaxLength(32)]
        /// <summary>
        /// 이름
        /// </summary>
        public String vcName { get; set; }

        [Index(3), Required, MinLength(4), MaxLength(128)]
        /// <summary>
        /// 제목
        /// </summary>
        public String vcTitle { get; set; }

        [Required, MinLength(4)]
        /// <summary>
        /// 내용
        /// </summary>
        public String tDescription { get; set; }

        /// <summary>
        /// 조회수
        /// </summary>
        public Int32 iRead { get; set; }

        /// <summary>
        /// 댓글수
        /// </summary>
        public Int32 iCommentCnt { get; set; }

        /// <summary>
        /// 공지여부(1:노출안함, 2:노출)
        /// </summary>
        public Int16 tiNotice { get; set; }

        [Required, MinLength(2), MaxLength(16)]
        /// <summary>
        /// 등록IP
        /// </summary>
        public String vcIP { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
