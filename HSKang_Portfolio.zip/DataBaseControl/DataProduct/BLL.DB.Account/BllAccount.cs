﻿using System;
using System.Threading.Tasks;
using System.Collections.Generic;

using System.Data;

using Lib.Crawling.Library.Enum;
using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Account;
using Lib.Crawling.Library.Entities.LogDB;
using Lib.Crawling.Library.DataContainers;
using Lib.Crawling.Library.Log;
using Lib.Crawling.Library.Models.AccountDB;

using BLL.DB.LogData;

namespace BLL.DB.Account
{

    #region // !++ BllAccount
    /// <summary>
    /// BllAccount
    /// </summary>
    public class BllAccount : DataProvider.DataProvider
    {

        #region // !++ DataBaseControl => DataProduct => BllLogData
        /// <summary>
        /// BllLogData
        /// </summary>
        protected BllLogData bllLogData = new BllLogData();
        #endregion


        #region // !++ BLL_Member_IDCheck_Sel (계정 중복확인)
        /// <summary>
        /// 계정 중복확인
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="memberEntity"></param>
        /// <returns></returns>
        public async Task<Int32> BLL_Member_IDCheck_Sel(DBConnectionEntity dbConnectionEntity, MemberEntity memberEntity)
        {

            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbMember()
                {
                    iPlatFormSeq = memberEntity.iPlatFormSeq,
                    vcGuid = memberEntity.vcGuid
                };
                #endregion

                result = await dalAccount.DAL_Member_IDCheck_Sel(dbConnectionEntity, dbData);

                // DAL_Member_IDCheck_Sel 확인
                if (result.result < 1)
                {
                    // DAL_Member_IDCheck_Sel 실패. 오류 발생!
                    // 이미 사용중인 계정(Error code : -5) 일 경우 예외처리 필요함!!!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }

            }
            catch (Exception exc)
            {
                // DAL_Member_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_Member_IDCheck_Sel : \n [DBConnectionEntity:{0}], \n [MemberEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(memberEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;

        }
        #endregion


        #region // !++ BLL_Member_Ins (회원[계정] 정보 등록)
        /// <summary>
        /// 회원[계정] 정보 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="memberDataContainer"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<ResultEntity<Int64>> BLL_Member_Ins(DBConnectionEntity dbConnectionEntity, MemberDataContainer memberDataContainer)
        {
            var result = new ResultEntity<Int64>();
            EResultCode eResultCode = 0;

            // 비밀번호 암호화 SHA512 (데이터 존재시)
            if (String.IsNullOrEmpty(memberDataContainer.memberPasswordEntity.vcPassword) == false)
            {
                memberDataContainer.memberPasswordEntity.vcPassword = hashWord.SHA512(hashWord.hashCode + memberDataContainer.memberPasswordEntity.vcPassword);
                memberDataContainer.memberPasswordEntity.vcPassword = libUtility.Left(memberDataContainer.memberPasswordEntity.vcPassword, 64);
            }

            try
            {
                #region // !++ 데이터 Struct 변경
                // 회원기본정보
                var TbMember = new tbMember()
                {
                    iPlatFormSeq = memberDataContainer.memberEntity.iPlatFormSeq,
                    vcGuid = libUtility.GetGuid(),
                    vcEmail = memberDataContainer.memberEntity.vcEmail,
                    vcName = memberDataContainer.memberEntity.vcName,
                    cBirthYear = memberDataContainer.memberEntity.cBirthYear,
                    cBirthMonth = memberDataContainer.memberEntity.cBirthMonth,
                    cBirthDay = memberDataContainer.memberEntity.cBirthDay,
                    tiGender = memberDataContainer.memberEntity.tiGender,
                    tiOrganization = memberDataContainer.memberEntity.tiOrganization,
                };

                // 회원상세정보
                var TbMemberDetail = new tbMemberDetail()
                {
                    siCountrySeq = memberDataContainer.memberDetailEntity.siCountrySeq,
                    vcCity = memberDataContainer.memberDetailEntity.vcCity,
                    vcZipCode = memberDataContainer.memberDetailEntity.vcZipCode,
                    vcAddressFront = memberDataContainer.memberDetailEntity.vcAddressFront,
                    vcAddressBack = memberDataContainer.memberDetailEntity.vcAddressBack,
                    tiMemberStatus = memberDataContainer.memberDetailEntity.tiMemberStatus,
                    tiEmailAgree = memberDataContainer.memberDetailEntity.tiEmailAgree,
                    tiSmsAgress = memberDataContainer.memberDetailEntity.tiSmsAgress
                };

                // 회원연락처정보
                var TbMemberContact = new tbMemberContact()
                {
                    vcPhoneCountry = memberDataContainer.memberContactEntity.vcPhoneCountry,
                    vcPhoneFirst = memberDataContainer.memberContactEntity.vcPhoneFirst,
                    vcPhoneSecond = memberDataContainer.memberContactEntity.vcPhoneSecond,
                    vcPhoneThird = memberDataContainer.memberContactEntity.vcPhoneThird,
                    vcMobileFirst = memberDataContainer.memberContactEntity.vcMobileFirst,
                    vcMobileSecond = memberDataContainer.memberContactEntity.vcMobileSecond,
                    vcMobileThird = memberDataContainer.memberContactEntity.vcMobileThird
                };

                // 회원비밀번호정보
                var TbMemberPassword = new tbMemberPassword()
                {
                    vcPassword = memberDataContainer.memberPasswordEntity.vcPassword
                };

                // 회원(단체)정보
                var TbMemberOrganization = new tbMemberOrganization()
                {
                    vcPersonName = memberDataContainer.memberOrganizationEntity.vcPersonName,
                    vcBusiness = memberDataContainer.memberOrganizationEntity.vcBusiness,
                    vcOrganizationSerial = memberDataContainer.memberOrganizationEntity.vcOrganizationSerial
                };

                // 회원Email인증
                var TbMemberEmailAuth = new tbMemberEmailAuth()
                {
                    vcAuth = memberDataContainer.memberEmailAuthEntity.vcAuth
                };

                // DataContainer 에 담기
                var dbData = new tbMemberDataContainer()
                {
                    TbMember = TbMember,
                    TbMemberDetail = TbMemberDetail,
                    TbMemberContact = TbMemberContact,
                    TbMemberPassword = TbMemberPassword,
                    TbMemberOrganization = TbMemberOrganization,
                    TbMemberEmailAuth = TbMemberEmailAuth
                };
                #endregion
                result = await dalAccount.DAL_Member_Ins(dbConnectionEntity, dbData);

                // DAL_Member_Ins 확인
                if (result.result < 1)
                {
                    // DAL_Member_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_Member_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_Member_Ins : \n [DBConnectionEntity:{0}], \n [MemberDataContainer:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(memberDataContainer), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result;
            }
            return result;
        }
        #endregion


        #region // !++ BLL_Member_Login_Sel (로그인 정보)
        /// <summary>
        /// 로그인 정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="memberEntity"></param>
        /// <param name="memberPasswordEntity"></param>
        /// <returns></returns>
        public async Task<ResultEntity<MemberLoginEntity>> BLL_Member_Login_Sel(DBConnectionEntity dbConnectionEntity, MemberEntity memberEntity, MemberPasswordEntity memberPasswordEntity)
        {

            var result = new ResultEntity<MemberLoginEntity>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 비밀번호 암호화
                memberPasswordEntity.vcPassword = hashWord.SHA512(hashWord.hashCode + memberPasswordEntity.vcPassword);
                memberPasswordEntity.vcPassword = libUtility.Left(memberPasswordEntity.vcPassword, 64);
                #endregion

                #region // !++ 데이터 Struct 변경
                var dbMember = new tbMember()
                {
                    iPlatFormSeq = memberEntity.iPlatFormSeq,
                    vcEmail = memberEntity.vcEmail
                };

                var dbMemberPassword = new tbMemberPassword()
                {
                    vcPassword = memberPasswordEntity.vcPassword
                };
                #endregion

                result = await dalAccount.DAL_Member_Login_Sel(dbConnectionEntity, dbMember, dbMemberPassword);

                // DAL_Member_Login_Sel 확인
                if (result.result < 1)
                {
                    // DAL_Member_Login_Sel 실패. 오류 발생!
                    // 이미 사용중인 계정(Error code : -5) 일 경우 예외처리 필요함!!!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    result.gClass = null;
                }

            }
            catch (Exception exc)
            {
                // DAL_Member_Login_Sel 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_Member_Login_Sel : \n [DBConnectionEntity:{0}], \n [MemberEntity:{1}], \n [MemberPasswordEntity:{2}], \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(memberEntity), libUtility.ToJson(memberPasswordEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                result.gClass = null;
                return result;
            }
            return result;

        }
        #endregion


        #region // !++ BLL_Member_Sel (회원[본인] 정보)
        /// <summary>
        /// 회원[본인] 정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="memberEntity"></param>
        /// <returns></returns>
        public async Task<MemberInfoDataContainer> BLL_Member_Sel(DBConnectionEntity dbConnectionEntity, MemberEntity memberEntity)
        {

            var resultDataContainer = new MemberInfoDataContainer();

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbMember = new tbMember()
                {
                    biSeq = memberEntity.biSeq
                };
                #endregion

                #region // !++ 데이터 가져오기
                using (var ds = await dalAccount.DAL_Member_Sel(dbConnectionEntity, dbMember))
                {

                    #region // !++ 회원기본정보
                    using (DataTable dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.memberEntity = null;
                            resultDataContainer.memberDetailEntity = null;
                            resultDataContainer.memberContactEntity = null;
                            resultDataContainer.memberPasswordEntity = null;
                        }
                        else
                        {
                            // 회원기본정보
                            var memberData = new MemberEntity()
                            {
                                iPlatFormSeq = Int32.Parse(dt.Rows[0]["iPlatFormSeq"].ToString()),
                                vcName = dt.Rows[0]["vcName"].ToString(),
                                cBirthYear = dt.Rows[0]["cBirthYear"].ToString(),
                                cBirthMonth = dt.Rows[0]["cBirthMonth"].ToString(),
                                cBirthDay = dt.Rows[0]["cBirthDay"].ToString(),
                                tiGender = Int16.Parse(dt.Rows[0]["tiGender"].ToString()),
                                tiOrganization = Int16.Parse(dt.Rows[0]["tiOrganization"].ToString()),
                                dtRegDate = DateTime.Parse(dt.Rows[0]["dtRegDate"].ToString()),
                            };
                            resultDataContainer.memberEntity = memberData;

                            // 회원상세정보
                            var memberDetailData = new MemberDetailEntity()
                            {
                                siCountrySeq = Int16.Parse(dt.Rows[0]["siCountrySeq"].ToString()),
                                vcCity = dt.Rows[0]["vcCity"].ToString(),
                                vcZipCode = dt.Rows[0]["vcZipCode"].ToString(),
                                vcAddressFront = dt.Rows[0]["vcAddressFront"].ToString(),
                                vcAddressBack = dt.Rows[0]["vcAddressBack"].ToString(),
                                tiMemberGrade = Int16.Parse(dt.Rows[0]["tiMemberGrade"].ToString()),
                                tiMemberStatus = Int16.Parse(dt.Rows[0]["tiMemberStatus"].ToString()),
                                tiEmailAgree = Int16.Parse(dt.Rows[0]["tiEmailAgree"].ToString()),
                                tiSmsAgress = Int16.Parse(dt.Rows[0]["tiSmsAgress"].ToString())
                            };
                            resultDataContainer.memberDetailEntity = memberDetailData;

                            // 회원연락처정보
                            var memberContactData = new MemberContactEntity()
                            {
                                vcPhoneCountry = dt.Rows[0]["vcPhoneCountry"].ToString(),
                                vcPhoneFirst = dt.Rows[0]["vcPhoneFirst"].ToString(),
                                vcPhoneSecond = dt.Rows[0]["vcPhoneSecond"].ToString(),
                                vcPhoneThird = dt.Rows[0]["vcPhoneThird"].ToString(),
                                vcMobileFirst = dt.Rows[0]["vcMobileFirst"].ToString(),
                                vcMobileSecond = dt.Rows[0]["vcMobileSecond"].ToString(),
                                vcMobileThird = dt.Rows[0]["vcMobileThird"].ToString()
                            };
                            resultDataContainer.memberContactEntity = memberContactData;

                            // 회원비밀번호정보
                            var memberPasswordData = new MemberPasswordEntity()
                            {
                                dtLoginDate = DateTime.Parse(dt.Rows[0]["dtLoginDate"].ToString())
                            };
                            resultDataContainer.memberPasswordEntity = memberPasswordData;
                        }
                    }
                    #endregion

                    #region // !++ 회원(단체)정보
                    using (DataTable dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.memberOrganizationEntity = null;
                        }
                        else
                        {
                            // 회원(단체)정보
                            var memberOrganizationData = new MemberOrganizationEntity()
                            {
                                vcPersonName = dt.Rows[0]["vcPersonName"].ToString(),
                                vcBusiness = dt.Rows[0]["vcBusiness"].ToString(),
                                vcOrganizationSerial = dt.Rows[0]["vcOrganizationSerial"].ToString()
                            };
                            resultDataContainer.memberOrganizationEntity = memberOrganizationData;
                        }
                    }
                    #endregion

                }
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_Member_Login_Sel 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_Member_Sel : \n [DBConnectionEntity:{0}], \n [MemberEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(memberEntity), exc.Message, exc.StackTrace);
                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_MemberEmailAuth_Upd (회원 E-mail 인증)
        /// <summary>
        /// 회원 E-mail 인증
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="authEmailEntity"></param>
        /// <returns></returns>
        public async Task<ResultEntity<String>> BLL_MemberEmailAuth_Upd(DBConnectionEntity dbConnectionEntity, AuthEmailEntity authEmailEntity)
        {

            var result = new ResultEntity<String>();
            EResultCode eResultCode = 0;

            try
            {

                #region // !++ 데이터 Struct 변경
                var model = new MemberEmailApprovalEntity()
                {
                    biMemberSeq = authEmailEntity.biMemberSeq,
                    vcEmail = authEmailEntity.vcEmail,
                    vcAuth = authEmailEntity.vcAuth,
                    tiMemberStatus = 1
                };
                #endregion

                result = await dalAccount.DAL_MemberEmailAuth_Upd(dbConnectionEntity, model);

                // DAL_MemberEmailAuth_Upd 확인
                if (result.result < 1)
                {
                    // DAL_MemberEmailAuth_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }

            }
            catch (Exception exc)
            {
                // DAL_MemberEmailAuth_Upd 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_MemberEmailAuth_Upd : \n [DBConnectionEntity:{0}], \n [AuthEmailEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(authEmailEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result;
            }
            return result;

        }
        #endregion








        //******************************************************
        // 관리자(운영툴)
        //******************************************************


        #region // !++ BLL_ProhibitWords_Sel (금지어 정보)
        /// <summary>
        /// 금지어 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<ProhibitWordsEntity>>> BLL_ProhibitWords_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<ProhibitWordsEntity>>();
            var dataList = new List<ProhibitWordsEntity>();

            try
            {

                //+ DAL_ProhibitWords_Sel
                using (var ds = await dalAccount.DAL_ProhibitWords_Sel(dbConnectionEntity, pageDBEntity))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var prohibitWordsData = new ProhibitWordsEntity()
                                {
                                    vcProhibitWords = dt.Rows[i]["vcProhibitWords"].ToString(),
                                    vcNote = dt.Rows[i]["vcNote"].ToString(),
                                    tiStatus = Int16.Parse(dt.Rows[i]["tiStatus"].ToString()),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(prohibitWordsData);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_ProhibitWords_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_ProhibitWords_Ins (금지어 등록)
        /// <summary>
        /// 금지어 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="prohibitWordsEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_ProhibitWords_Ins(DBConnectionEntity dbConnectionEntity, ProhibitWordsEntity prohibitWordsEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbProhibitWords()
                {
                    vcProhibitWords = prohibitWordsEntity.vcProhibitWords,
                    vcNote = prohibitWordsEntity.vcNote,
                    tiStatus = prohibitWordsEntity.tiStatus,
                    iManagerSeq = prohibitWordsEntity.iManagerSeq
                };
                #endregion
                result = await dalAccount.DAL_ProhibitWords_Ins(dbConnectionEntity, dbData);

                // DAL_ProhibitWords_Ins 확인
                if (result.result < 1)
                {
                    // DAL_ProhibitWords_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogProhibitWordsEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = prohibitWordsEntity.iManagerSeq,
                    vcProhibitWords = prohibitWordsEntity.vcProhibitWords,
                    vcNote = prohibitWordsEntity.vcNote,
                    tiStatus = prohibitWordsEntity.tiStatus,
                    tiType = LogActionType.Insert,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogProhibitWords_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_ProhibitWords_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_ProhibitWords_Ins : \n [DBConnectionEntity:{0}], \n [ProhibitWordsEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(prohibitWordsEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_ProhibitWords_Upd (금지어 수정)
        /// <summary>
        /// 금지어 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="prohibitWordsEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_ProhibitWords_Upd(DBConnectionEntity dbConnectionEntity, ProhibitWordsEntity prohibitWordsEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbProhibitWords()
                {
                    vcProhibitWords = prohibitWordsEntity.vcProhibitWords,
                    vcNote = prohibitWordsEntity.vcNote,
                    tiStatus = prohibitWordsEntity.tiStatus,
                    iManagerSeq = prohibitWordsEntity.iManagerSeq
                };
                #endregion
                result = await dalAccount.DAL_ProhibitWords_Upd(dbConnectionEntity, dbData);

                // DAL_ProhibitWords_Upd 확인
                if (result.result < 1)
                {
                    // DAL_ProhibitWords_Upd 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogProhibitWordsEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = prohibitWordsEntity.iManagerSeq,
                    vcProhibitWords = prohibitWordsEntity.vcProhibitWords,
                    vcNote = prohibitWordsEntity.vcNote,
                    tiStatus = prohibitWordsEntity.tiStatus,
                    tiType = LogActionType.Update,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogProhibitWords_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_ProhibitWords_Upd 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_ProhibitWords_Upd : \n [DBConnectionEntity:{0}], \n [ProhibitWordsEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(prohibitWordsEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_ProhibitWords_Del (금지어 삭제)
        /// <summary>
        /// 금지어 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="prohibitWordsEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task<Int32> BLL_ProhibitWords_Del(DBConnectionEntity dbConnectionEntity, ProhibitWordsEntity prohibitWordsEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbProhibitWords()
                {
                    vcProhibitWords = prohibitWordsEntity.vcProhibitWords,
                    iManagerSeq = prohibitWordsEntity.iManagerSeq
                };
                #endregion
                result = await dalAccount.DAL_ProhibitWords_Del(dbConnectionEntity, dbData);

                // DAL_ProhibitWords_Del 확인
                if (result.result < 1)
                {
                    // DAL_ProhibitWords_Del 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                    return result.result;
                }

                #region // !++ LOG 저장
                #region // !++ 데이터 Struct 변경
                var logData = new LogProhibitWordsEntity()
                {
                    biTXIDX = libUtility.UnixTimeToLong(),
                    iManagerSeq = prohibitWordsEntity.iManagerSeq,
                    vcProhibitWords = prohibitWordsEntity.vcProhibitWords,
                    vcNote = String.Empty,
                    tiStatus = 0,
                    tiType = LogActionType.Delete,
                    vcIP = String.Empty             // IP 수정 예정
                };
                #endregion

                #region // !++ Log 정보 실행
                // Log는 Void 형태!!!
                await bllLogData.BLL_LogProhibitWords_Ins(dbConnectionEntity, logData);
                #endregion
                #endregion

            }
            catch (Exception exc)
            {
                // DAL_ProhibitWords_Del 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_ProhibitWords_Del : \n [DBConnectionEntity:{0}], \n [ProhibitWordsEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(prohibitWordsEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
                return result.result;
            }
            return result.result;
        }
        #endregion


        #region // !++ BLL_Manager_Member_Sel (관리툴 => 회원 정보)
        /// <summary>
        /// 관리툴 => 회원 정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<ListPageDataContainer<List<MemberEntity>>> BLL_Manager_Member_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<MemberEntity>>();
            var dataList = new List<MemberEntity>();

            try
            {

                //+ DAL_Manager_Member_Sel
                using (var ds = await dalAccount.DAL_Manager_Member_Sel(dbConnectionEntity, pageDBEntity))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.gClass = null;
                        }
                        else
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var memberData = new MemberEntity()
                                {
                                    biSeq = Int64.Parse(dt.Rows[i]["biSeq"].ToString()),
                                    iPlatFormSeq = Int32.Parse(dt.Rows[i]["iPlatFormSeq"].ToString()),
                                    vcEmail = dt.Rows[i]["vcEmail"].ToString(),
                                    vcName = dt.Rows[i]["vcName"].ToString(),
                                    tiOrganization = Int16.Parse(dt.Rows[i]["tiOrganization"].ToString()),
                                    dtRegDate = DateTime.Parse(dt.Rows[i]["dtRegDate"].ToString())
                                };
                                dataList.Add(memberData);
                            }
                            resultDataContainer.gClass = dataList;
                        }
                    }
                    #endregion


                    #region // !++ 레코드 수
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.totalRecord = 0;
                        }
                        else
                        {
                            resultDataContainer.totalRecord = Int32.Parse(dt.Rows[0]["totCount"].ToString());
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_Manager_Member_Sel : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ BLL_Manager_Member_Detail_Sel (관리툴 => 회원 상세 정보)
        /// <summary>
        /// 관리툴 => 회원 상세 정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="memberEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_StoredProcedureFail (-7): 프로시저 실패
        /// </returns>
        public async Task<MemberDataContainer> BLL_Manager_Member_Detail_Sel(DBConnectionEntity dbConnectionEntity, MemberEntity memberEntity)
        {

            var resultDataContainer = new MemberDataContainer();

            try
            {

                #region // !++ 데이터 Struct 변경
                var dbData = new tbMember()
                {
                    biSeq = memberEntity.biSeq
                };
                #endregion

                //+ DAL_Manager_Member_Detail_Sel
                using (var ds = await dalAccount.DAL_Manager_Member_Detail_Sel(dbConnectionEntity, dbData))
                {

                    #region // !++ 데이터 정보
                    using (var dt = ds.Tables[0])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer = null;
                        }
                        else
                        {
                            // 회원기본정보
                            var memberData = new MemberEntity()
                            {
                                biSeq = memberEntity.biSeq,
                                iPlatFormSeq = Int32.Parse(dt.Rows[0]["iPlatFormSeq"].ToString()),
                                vcGuid = dt.Rows[0]["vcGuid"].ToString(),
                                vcEmail = dt.Rows[0]["vcEmail"].ToString(),
                                vcName = dt.Rows[0]["vcName"].ToString(),
                                cBirthYear = dt.Rows[0]["cBirthYear"].ToString(),
                                cBirthMonth = dt.Rows[0]["cBirthMonth"].ToString(),
                                cBirthDay = dt.Rows[0]["cBirthDay"].ToString(),
                                tiGender = Int16.Parse(dt.Rows[0]["tiGender"].ToString()),
                                tiOrganization = Int16.Parse(dt.Rows[0]["tiOrganization"].ToString()),
                                dtRegDate = DateTime.Parse(dt.Rows[0]["dtRegDate"].ToString())
                            };
                            resultDataContainer.memberEntity = memberData;

                            // 회원상세정보
                            var memberDetailData = new MemberDetailEntity()
                            {
                                siCountrySeq = Int16.Parse(dt.Rows[0]["siCountrySeq"].ToString()),
                                vcCity = dt.Rows[0]["vcCity"].ToString(),
                                vcZipCode = dt.Rows[0]["vcZipCode"].ToString(),
                                vcAddressFront = dt.Rows[0]["vcAddressFront"].ToString(),
                                vcAddressBack = dt.Rows[0]["vcAddressBack"].ToString(),
                                tiMemberGrade = Int16.Parse(dt.Rows[0]["tiMemberGrade"].ToString()),
                                tiMemberStatus = Int16.Parse(dt.Rows[0]["tiMemberStatus"].ToString()),
                                tiEmailAgree = Int16.Parse(dt.Rows[0]["tiEmailAgree"].ToString()),
                                tiSmsAgress = Int16.Parse(dt.Rows[0]["tiSmsAgress"].ToString())
                            };
                            resultDataContainer.memberDetailEntity = memberDetailData;

                            // 회원연락처정보
                            var memberContactData = new MemberContactEntity()
                            {
                                vcPhoneCountry = dt.Rows[0]["vcCity"].ToString(),
                                vcPhoneFirst = dt.Rows[0]["vcCity"].ToString(),
                                vcPhoneSecond = dt.Rows[0]["vcCity"].ToString(),
                                vcPhoneThird = String.Empty,
                                vcMobileFirst = String.Empty,
                                vcMobileSecond = String.Empty,
                                vcMobileThird = String.Empty
                            };
                            resultDataContainer.memberContactEntity = memberContactData;

                            // 회원비밀번호
                            var memberPasswordData = new MemberPasswordEntity()
                            {
                                dtLoginDate = DateTime.Parse(dt.Rows[0]["dtLoginDate"].ToString())
                            };
                            resultDataContainer.memberPasswordEntity = memberPasswordData;
                        }
                    }
                    #endregion


                    #region // !++ 회원 기업(단체) 정보
                    using (var dt = ds.Tables[1])
                    {
                        if (dt.Rows.Count == 0)
                        {
                            resultDataContainer.memberOrganizationEntity = null;
                        }
                        else
                        {
                            var memberOrganizationData = new MemberOrganizationEntity
                            {

                            };
                            resultDataContainer.memberOrganizationEntity = memberOrganizationData;
                        }
                    }
                    #endregion

                }
            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "BLL_Manager_Member_Detail_Sel : \n [DBConnectionEntity:{0}], \n [MemberEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(memberEntity), exc.Message, exc.StackTrace);

                resultDataContainer = null;
                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion




    }
    #endregion

}
