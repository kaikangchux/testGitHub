﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Account;
using Lib.Crawling.Library.Utilities;
using Lib.Crawling.Library.Log;
using Lib.Crawling.Library.DataContainers;

using WebApi_SpiderKim_V1.Handlers;
using WebApi_SpiderKim_V1.WebUtilities;

namespace WebApi_SpiderKim_V1.Controllers
{

    #region // !++ LoginController
    /// <summary>
    /// LoginController
    /// </summary>
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {

        #region // !++ Event handler(funtions)
        /// <summary>
        /// StaticDataHandler
        /// </summary>
        public StaticDataHandler staticDataHandler = new StaticDataHandler();

        /// <summary>
        /// LibUtility
        /// </summary>
        public LibUtility libUtility = new LibUtility();

        /// <summary>
        /// LibWebUtility
        /// </summary>
        public LibWebUtility libWebUtility = new LibWebUtility();

        /// <summary>
        /// LibraryController
        /// </summary>
        public LibraryController libraryController = new LibraryController();
        #endregion


        #region // !++ Class 상속
        private readonly IConfiguration _configuration;

        public LoginController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        #endregion


        #region // !++ SetCreateToken (JWT Token 만들기)
        /// <summary>
        /// JWT Token 만들기
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        private MemberLoginTokenEntity SetCreateToken(MemberLoginEntity model)
        {

            try
            {

                #region // !++ [1] 보안키 생성
                var key = _configuration.GetSection("SymmetricSecurityKey").Value;
                var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
                var signingCredentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
                #endregion

                #region // !++ [2] 클레임 생성
                var claims = new Claim[]
                {
                    new Claim(ClaimTypes.Role, "SpiderKim"),                     // Role
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),  // Random GUID
                    new Claim(JwtRegisteredClaimNames.Website, _configuration.GetSection("SpiderKimSettings").GetSection("DomainUrl").Value),    // Site
                    new Claim("MemberInfo", libUtility.ToJson(model))                  // Manager Json info
                };
                #endregion

                #region // !++ [3] 토큰 생성하기
                var token = new JwtSecurityToken(
                        claims: claims,
                        signingCredentials: signingCredentials,
                        issuer: _configuration.GetSection("SpiderKimSettings").GetSection("Issuer").Value,
                        audience: _configuration.GetSection("SpiderKimSettings").GetSection("Audience").Value,
                        // expires: DateTime.Now.AddMinutes(Int32.Parse(_configuration.GetSection("SpiderKimSettings").GetSection("ExpiredDays").Value))
                        expires: DateTime.Now.AddDays(Int32.Parse(_configuration.GetSection("SpiderKimSettings").GetSection("ExpiredDays").Value))
                    );
                var resultToken = new JwtSecurityTokenHandler().WriteToken(token);
                #endregion

                #region // !++ [4] Return value
                var retunDate = new MemberLoginTokenEntity()
                {
                    Token = resultToken,
                    ExpiredDate = token.ValidTo
                };
                #endregion

                // [!] 토큰 반환
                return retunDate;
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API SetCreateToken : \n [MemberLoginEntity:{0}], \n {1}, \n {2}",
                                        libUtility.ToJson(model), exc.Message, exc.StackTrace);

                return null;
            }
        }
        #endregion


        #region // !++ GetLogin (회원 로그인[자체])
        /// <summary>
        /// 회원 로그인[자체]
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        [HttpPost("Login")]
        [Produces("application/json", Type = typeof(MemberLoginFormEntity))]
        [AllowAnonymous]    // 인증되지 않은 사용자도 접근 가능
        public async Task<IActionResult> GetLogin([FromBody] MemberLoginFormEntity loginModel)
        {

            // Return message
            var resultClient = new ResultClientEntity<MemberLoginTokenEntity>();

            try
            {

                #region // !++ Value check
                if (String.IsNullOrEmpty(loginModel.vcEmail) || String.IsNullOrEmpty(loginModel.vcPassword))
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "계정 또는 암호가 없습니다.";
                    resultClient.error = "계정 또는 암호가 없습니다.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }

                if (libUtility.GetEmailParamValue(loginModel.vcEmail) == false)
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "The e-mail format is not correct.";
                    resultClient.error = "The e-mail format is not correct.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ Handler 호출
                var model = new MemberEntity()
                {
                    iPlatFormSeq = loginModel.iPlatFormSeq,
                    vcEmail = loginModel.vcEmail
                };
                // 비밀번호
                var passwordModel = new MemberPasswordEntity()
                {
                    vcPassword = loginModel.vcPassword
                };
                // Handler
                var resultData = await AccountHandler.GetMemberLogin(dbConnectionEntity, model, passwordModel);
                #endregion

                #region // !++ 예외처리
                if (resultData.bresult == false)
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "일치하는 정보가 없습니다.";
                    resultClient.error = "일치하는 정보가 없습니다.";
                    resultClient.data = null;
                    #endregion
                }
                else
                {

                    #region // !++ JWT Token 생성
                    var resultToken = Task.Run(() => SetCreateToken(resultData.gClass)).Result;
                    #endregion

                    #region // !++ Token 예외처리
                    if (resultToken == null)
                    {
                        #region // !++ Client message
                        resultClient.success = false;
                        resultClient.msg = "Access token failed";
                        resultClient.error = "Access token failed";
                        resultClient.data = null;
                        #endregion
                    }
                    else
                    {
                        #region // !++ Client message
                        resultClient.success = true;
                        resultClient.msg = null;
                        resultClient.error = null;
                        resultClient.data = resultToken;
                        #endregion
                    }
                    #endregion

                }
                #endregion

                return Ok(resultClient);

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API GetLogin : \n [MemberLoginFormEntity:{0}], \n {1}, \n {2}",
                                        libUtility.ToJson(loginModel), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }

        }
        #endregion

    }
    #endregion

}