﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.ManagerDB
{

    #region // !++ tbDataBase
    /// <summary>
    /// tbDataBase
    /// </summary>
    [Table("tbDataBase")]
    public class tbDataBase
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        /// <summary>
        /// 고유번호
        /// </summary>
        public Int32 iSeq { get; set; }

        [Required]
        /// <summary>
        /// DB타입(1:MySQL, 2:MongoDB, 3:Redis)
        /// </summary>
        public Int16 tiDBType { get; set; }

        /// <summary>
        /// DB 간단설명(또는 이름)
        /// </summary>
        public String vcName { get; set; }

        [Required, MinLength(4), MaxLength(32)]
        /// <summary>
        /// DB IP
        /// </summary>
        public String vcAddress { get; set; }

        [Required]
        /// <summary>
        /// DB PORT
        /// </summary>
        public Int32 iPort { get; set; }

        [Required, MinLength(4), MaxLength(32)]
        /// <summary>
        /// DB 계정
        /// </summary>
        public String vcAccount { get; set; }

        [Required, MinLength(4), MaxLength(64)]
        /// <summary>
        /// DB 비밀번호
        /// </summary>
        public String vcPassword { get; set; }

        [Required, MinLength(4), MaxLength(32)]
        /// <summary>
        /// DB 명
        /// </summary>
        public String vcDataBase { get; set; }

        [Required]
        /// <summary>
        /// 사용여부(1:사용, 2:삭제)
        /// </summary>
        public Int16 tiUse { get; set; }

        [Required]
        /// <summary>
        /// 관리자고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        [Index(2), Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
