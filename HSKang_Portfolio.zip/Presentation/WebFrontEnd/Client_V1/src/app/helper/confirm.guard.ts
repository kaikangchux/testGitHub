import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { MemberService } from '../service';

@Injectable({providedIn: 'root'})

export class ConfirmGuard implements CanActivate
{
    naviData:any;

    constructor(private router: Router, private memberService:MemberService){
        this.naviData = this.router.getCurrentNavigation();
    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot)
    {
        if(this.naviData.extras && this.naviData.extras.state){
            return true;
        }

        this.router.navigate(['']);
        return false;
    }
}