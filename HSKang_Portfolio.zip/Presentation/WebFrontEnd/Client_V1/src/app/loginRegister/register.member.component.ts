import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MemberService, CommonService } from '../service';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { MemberModel } from '../model';

@Component({
    selector: 'app-register-member',
    templateUrl: './register.member.component.html',
    styleUrls: ['./register.member.component.scss']
})

export class RegisterMemberComponent implements OnInit
{
    birthdayYYYY:string[] = [];
    birthdayMM:string[] = [];
    birthdayDD:string[] = [];

    memberRegisterForm:FormGroup;

    constructor(private fb:FormBuilder, 
                private spinnerService:NgxSpinnerService,
                private memberService:MemberService,
                private cmnService:CommonService,
                private router:Router){

        let thisYear = new Date().getFullYear() - 13;
        let startYear = thisYear - 80;
        for(let y=thisYear; y>=startYear; y--){
            this.birthdayYYYY.push(y.toString());
        }

        for(let m=1; m<=12; m++){
            this.birthdayMM.push(m.toString());
        }
    }

    ngOnInit():void
    {
        this.memberRegisterForm = this.fb.group({
            vcEmailID : ['', Validators.required],
            vcEmailAddress : ['', Validators.required],
            vcPassword : ['', Validators.required],
            vcPassword_confirm : ['', Validators.required],
            vcName : ['', Validators.required],
            //vcPhone : ['', Validators.required],
            cBirthYear : ['', Validators.required],
            cBirthMonth : ['', Validators.required],
            cBirthDay : ['', Validators.required],
            tiGender : ['', Validators.required],
            terms_agree_all : [false],
            terms_agree_age : [false, Validators.requiredTrue],
            terms_agree_usage : [false, Validators.requiredTrue],
            terms_agree_privacy : [false, Validators.requiredTrue],
            vcEmail: [],
            iPlatFormSeq: [],
            tiOrganization: []
        },
            {validator: this.passwordMatch('vcPassword', 'vcPassword_confirm')}
        );
    }

    passwordMatch(controlName: string, matchingControlName: string):any
    {
        return (formGroup: FormGroup) => {
            const control = formGroup.controls[controlName];
            const matchingControl = formGroup.controls[matchingControlName];

            if(!matchingControl){
                return;
            }
    
            if(matchingControl.errors && !matchingControl.errors.passwordNotMatch){
                //이미 다른 에러가 있을 경우에는 return
                return;
            }
    
            if(control.value !== matchingControl.value){
                matchingControl.setErrors({ passwordNotMatch: true });
            }else{
                matchingControl.setErrors(null);
            }
        }
    }

    //TODO 이용약관, 개인정보수집/이용 약관
    onClickTermsView(param:string):void {
        alert("TODO");
    }

    onChangeYYYYMM(e:any):void
    {
        let yyyy = this.memberRegisterForm.get('cBirthYear').value;
        let mm = this.memberRegisterForm.get('cBirthMonth').value;

        if(!yyyy || !mm){
            this.birthdayDD = [];
            return;
        }

        let dd = this.cmnService.getLasyDay(parseInt(yyyy), parseInt(mm));
        this.birthdayDD = [];

        for(let d=1; d<=dd; d++){
            this.birthdayDD.push(d.toString());
        }
    }

    changeEmailAddr(emailAddr:string):void
    {
        if(!emailAddr)
            return;

        this.memberRegisterForm.patchValue({vcEmailAddress: emailAddr});
    }

    changeTermsCheckAll():void
    {
        this.memberRegisterForm.patchValue({terms_agree_age: !this.memberRegisterForm.get('terms_agree_age').value});
        this.memberRegisterForm.patchValue({terms_agree_usage: !this.memberRegisterForm.get('terms_agree_usage').value});
        this.memberRegisterForm.patchValue({terms_agree_privacy: !this.memberRegisterForm.get('terms_agree_privacy').value});
    }

    checkTerms():void
    {
        const ageTermCheck = this.memberRegisterForm.get('terms_agree_age').value;
        const usageTermCheck = this.memberRegisterForm.get('terms_agree_usage').value;
        const privacyTermCheck = this.memberRegisterForm.get('terms_agree_privacy').value;

        if(ageTermCheck === true && usageTermCheck === true && privacyTermCheck === true){
            this.memberRegisterForm.patchValue({terms_agree_all: true});
        }else{
            this.memberRegisterForm.patchValue({terms_agree_all: false});
        }
    }

    onSubmit():void
    {
        this.spinnerService.show();
        //Debugging 폼 데이터에 에러가 있을 경우 console.log 확인함
        // Object.keys(this.memberRegisterForm.controls).forEach(key => 
        //     {
        //         const controlErrors: ValidationErrors = this.memberRegisterForm.get(key).errors;
        //         if (controlErrors != null) {
        //             Object.keys(controlErrors).forEach(keyError => {console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);});
        //         }
        //     }
        // );

        event.preventDefault(); //서브밋 버튼 동작에 따른 리로드 방지

        this.memberRegisterForm.patchValue({tiOrganization: 1});
        this.memberRegisterForm.patchValue({iPlatFormSeq: 1}); //1:직접 가입
        this.memberRegisterForm.patchValue({vcEmail: this.memberRegisterForm.get('vcEmailID').value + '@' + this.memberRegisterForm.get('vcEmailAddress').value})

        //불필요한 폼 컨트롤 제거
        this.memberRegisterForm.removeControl('vcEmailID');
        this.memberRegisterForm.removeControl('vcEmailAddress');
        this.memberRegisterForm.removeControl('vcPassword_confirm');
        this.memberRegisterForm.removeControl('terms_agree_all');
        this.memberRegisterForm.removeControl('terms_agree_age');
        this.memberRegisterForm.removeControl('terms_agree_usage');
        this.memberRegisterForm.removeControl('terms_agree_privacy');

        // 회원정보(개인)
        let memberModel = new MemberModel();
        memberModel.iPlatFormSeq = this.memberRegisterForm.get('iPlatFormSeq').value;
        memberModel.vcEmail = this.memberRegisterForm.get('vcEmail').value;
        memberModel.vcPassword = this.memberRegisterForm.get('vcPassword').value;
        memberModel.vcName = this.memberRegisterForm.get('vcName').value;
        memberModel.cBirthYear = this.memberRegisterForm.get('cBirthYear').value;
        memberModel.cBirthMonth = this.memberRegisterForm.get('cBirthMonth').value;
        memberModel.cBirthDay = this.memberRegisterForm.get('cBirthDay').value;
        memberModel.tiGender = this.memberRegisterForm.get('tiGender').value;
        memberModel.tiOrganization = this.memberRegisterForm.get('tiOrganization').value;

        this.memberService.registerMember(memberModel).subscribe(
            (res) => {
                if(!res.success){
                    alert(res.msg);
                    this.memberService.logout();
                    return;
                }
                //this.router.navigate(['./register/completed'], {queryParams: {'email': res.data.email}, skipLocationChange: false});
                this.router.navigate(['./register/confirm'], {state: {data: {email:res.data.email, name:res.data.name}}});
            },
            (err) => {this.spinnerService.hide(); console.log(err);},
            () => this.spinnerService.hide()
        );
    }
}