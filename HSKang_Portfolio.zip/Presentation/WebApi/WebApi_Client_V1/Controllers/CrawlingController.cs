﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Account;
using Lib.Crawling.Library.Entities.Crawling;
using Lib.Crawling.Library.Utilities;
using Lib.Crawling.Library.Log;
using Lib.Crawling.Library.DataContainers;

using WebApi_SpiderKim_V1.Handlers;
using WebApi_SpiderKim_V1.WebUtilities;

namespace WebApi_SpiderKim_V1.Controllers
{

    #region // !++ CrawlingController
    /// <summary>
    /// 
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class CrawlingController : ControllerBase
    {

        #region // !++ Event handler(funtions)
        /// <summary>
        /// StaticDataHandler
        /// </summary>
        public StaticDataHandler staticDataHandler = new StaticDataHandler();

        /// <summary>
        /// LibUtility
        /// </summary>
        public LibUtility libUtility = new LibUtility();

        /// <summary>
        /// LibWebUtility
        /// </summary>
        public LibWebUtility libWebUtility = new LibWebUtility();

        /// <summary>
        /// KeyGenerator
        /// </summary>
        public KeyGenerator keyGenerator = new KeyGenerator();

        /// <summary>
        /// LibraryController
        /// </summary>
        public LibraryController libraryController = new LibraryController();
        #endregion


        #region // !++ GetCrawlingTargetUrl (크롤링 타겟 사이트)
        /// <summary>
        /// 크롤링 타겟 사이트
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("targeturi")]
        [Produces("application/json", Type = typeof(WebCrawerlingTargetEntity))]
        [AllowAnonymous]    // 인증되지 않은 사용자도 접근 가능
        public async Task<IActionResult> GetCrawlingTargetUrl([FromBody] WebCrawerlingTargetEntity model)
        {

            // Return message
            var resultClient = new ResultClientEntity<String>();

            try
            {

                #region // !++ Parameter value check
                if (String.IsNullOrEmpty(model.targetUrl))
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "invalid parameter value.";
                    resultClient.error = "invalid parametervalue.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }

                if (libWebUtility.OnHttpOrHttps(model.targetUrl) == false)
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "This is not valid information.";
                    resultClient.error = "This is not valid information.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }

                if (libWebUtility.OnDomailValue(model.targetUrl) == false)
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "This is not valid domain.";
                    resultClient.error = "This is not valid domain.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ Handler 호출
                var resultData = await CrawlingHandler.CrawlingTargetUrlExecute(dbConnectionEntity, model);
                #endregion

                #region // !++ Client message
                if (resultData.result == 1)
                {

                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = resultData.gClass;

                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion


                return Ok(resultClient);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API GetCrawlingTargetUrl : \n [WebCrawerlingTargetEntity:{0}], \n {1}, \n {2}",
                                        libUtility.ToJson(model), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }

        }
        #endregion


        #region // !++ GetCrawlingTargetUrlDetail (크롤링 타겟 사이트 상세정보)
        /// <summary>
        /// 크롤링 타겟 사이트 상세정보
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("targetdetailuri")]
        [Produces("application/json", Type = typeof(WebCrawerlingTargetDetailEntity))]
        [AllowAnonymous]    // 인증되지 않은 사용자도 접근 가능
        public async Task<IActionResult> GetCrawlingTargetUrlDetail([FromBody] WebCrawerlingTargetDetailEntity model)
        {

            // Return message
            var resultClient = new ResultClientEntity<String>();

            try
            {

                #region // !++ Parameter value check
                if (String.IsNullOrEmpty(model.targetUrl))
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "invalid url parameter value.";
                    resultClient.error = "invalid url parameter value.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }

                if (libWebUtility.OnHttpOrHttps(model.targetUrl) == false)
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "This is not valid information.";
                    resultClient.error = "This is not valid information.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }

                if (libWebUtility.OnDomailValue(model.targetUrl) == false)
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "This is not valid domain.";
                    resultClient.error = "This is not valid domain.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }

                if (String.IsNullOrEmpty(model.targetElement))
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "invalid element parameter value.";
                    resultClient.error = "invalid element parameter value.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ Handler 호출
                var resultData = await CrawlingHandler.CrawlingTargetUrlDetailExecute(dbConnectionEntity, model);
                #endregion

                #region // !++ Client message
                if (resultData.result == 1)
                {

                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = resultData.gClass;

                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion


                return Ok(resultClient);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API GetCrawlingTargetUrlDetail : \n [WebCrawerlingTargetDetailEntity:{0}], \n {1}, \n {2}",
                                        libUtility.ToJson(model), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }

        }
        #endregion



    }
    #endregion

}