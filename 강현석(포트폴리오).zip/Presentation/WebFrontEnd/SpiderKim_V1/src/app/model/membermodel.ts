// 회원기본정보
export class MemberModel
{
    iPlatFormSeq: number;
    vcEmail: string;
    vcName: string;
    vcPassword: string;
    vcPhone: string;
    cBirthYear: string;
    cBirthMonth: string;
    cBirthDay: string;
    tiGender: number;
    tiOrganization: number;

    constructor() {
        this.iPlatFormSeq = 0;
        this.vcEmail = '';
        this.vcName = '';
        this.cBirthYear = '';
        this.cBirthMonth = '';
        this.cBirthDay = '';
        this.tiGender = 0;
        this.tiOrganization = 0;
    }
}