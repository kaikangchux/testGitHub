﻿using System;
using System.Security.Claims;

using Microsoft.AspNetCore.Mvc;

using Lib.Crawling.Library.Utilities;
using Lib.Crawling.Library.Log;
using Lib.Crawling.Library.Entities.Manager;

using WebApi_SpiderKim_Manager_V1.WebUtilities;

namespace WebApi_SpiderKim_Manager_V1.Controllers
{

    #region // !++ Library
    /// <summary>
    /// Library
    /// </summary>
    public class LibraryController : ControllerBase
    {

        #region // !++ Event handler(funtions)
        /// <summary>
        /// LibUtility
        /// </summary>
        public LibUtility libUtility = new LibUtility();

        /// <summary>
        /// LibWebUtility
        /// </summary>
        public LibWebUtility libWebUtility = new LibWebUtility();
        #endregion


        #region // !++ GetManagerLoginInfo (관리자 로그인 정보)
        /// <summary>
        /// 관리자 로그인 정보
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public ManagerLoginEntity GetManagerLoginInfo(ClaimsPrincipal obj)
        {

            var resultLoginData = new ManagerLoginEntity();

            try
            {

                #region // !++ JWT Token 정보 축출
                var objString = obj.FindFirst("ManagerInfo").Value;

                resultLoginData = libUtility.FromJson<ManagerLoginEntity>(objString);
                #endregion

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetManagerLoginInfo : \n [ClaimsPrincipal:{0}], \n {1}, \n {2}",
                                        libUtility.ToJson(obj), exc.Message, exc.StackTrace);

                return null;
            }

            return resultLoginData;

        }
        #endregion

    }
    #endregion

}