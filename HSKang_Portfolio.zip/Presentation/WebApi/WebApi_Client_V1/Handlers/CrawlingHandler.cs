﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.IO;
using System.Reflection;

using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Crawling;
using Lib.Crawling.Library.DataContainers;
using Lib.Crawling.Library.Log;

namespace WebApi_SpiderKim_V1.Handlers
{

    #region // !++ CrawlingHandler
    /// <summary>
    /// CrawlingHandler
    /// </summary>
    public class CrawlingHandler : Handler
    {


        #region // !++ CrawlingTargetUrlExecute (크롤링 타겟 사이트 조회 및 등록)
        /// <summary>
        /// 크롤링 타겟 사이트 조회 및 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="webCrawerlingTargetEntity"></param>
        /// <returns></returns>
        public static async Task<ResultEntity<String>> CrawlingTargetUrlExecute(DBConnectionEntity dbConnectionEntity, WebCrawerlingTargetEntity webCrawerlingTargetEntity)
        {

            var result = new ResultEntity<String>();

            try
            {

                #region // !++ 타겟 사이트 정보 가져오기
                using (IWebDriver driver = new ChromeDriver(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)))
                {
                    driver.Navigate().GoToUrl(webCrawerlingTargetEntity.targetUrl);
                    result.gClass = driver.PageSource;
                }
                #endregion

                #region // !++ 타겟 사이트 정보 등록
                // result = await bllAccount.BLL_MemberEmailAuth_Upd(dbConnectionEntity, webCrawerlingTargetEntity);
                #endregion

                result.result = 1;

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "CrawlingTargetUrlExecute : \n [DBConnectionEntity:{0}], \n [WebCrawerlingTargetEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(webCrawerlingTargetEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


        #region // !++ CrawlingTargetUrlDetailExecute (크롤링 타겟 사이트 상세정보[Detail] 가져오기)
        /// <summary>
        /// 크롤링 타겟 사이트 상세정보[Detail] 가져오기
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="webCrawerlingTargetDetailEntity"></param>
        /// <returns></returns>
        public static async Task<ResultEntity<String>> CrawlingTargetUrlDetailExecute(DBConnectionEntity dbConnectionEntity, WebCrawerlingTargetDetailEntity webCrawerlingTargetDetailEntity)
        {

            var result = new ResultEntity<String>();

            try
            {

                #region // !++ 타겟 사이트 정보 가져오기
                using (var driver = new ChromeDriver(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)))
                {
                    driver.Navigate().GoToUrl(webCrawerlingTargetDetailEntity.targetUrl);

                    #region // !++ 상세정보 Element 정보 가져오기
                    // CssSelector 로 상세페이지 정보 가져오기
                    var webElement = driver.FindElement(By.CssSelector(webCrawerlingTargetDetailEntity.targetElement));
                    // 페이지 이동
                    webElement.Click();

                    // Thread Delay
                    await Task.Delay(2000);

                    // POPUP 창으로 나오는 사이트 예외처리
                    // 여러창이 뜨면 두번째 팝업으로 정보 전달
                    var windowsPop = driver.WindowHandles;

                    if (windowsPop.Count == 2)
                    {
                        driver.SwitchTo().Window(windowsPop[1]);

                        // Thread Delay
                        await Task.Delay(2000);

                        result.gClass = driver.PageSource;
                    }
                    else
                    {
                        driver.SwitchTo().Window(windowsPop[0]);

                        // Thread Delay
                        await Task.Delay(2000);

                        result.gClass = driver.PageSource;
                    }
                    #endregion
                    
                }
                #endregion

                #region // !++ 타겟 사이트 정보 등록
                // result = await bllAccount.BLL_MemberEmailAuth_Upd(dbConnectionEntity, webCrawerlingTargetEntity);
                #endregion

                result.result = 1;

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "CrawlingTargetUrlDetailExecute : \n [DBConnectionEntity:{0}], \n [WebCrawerlingTargetDetailEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(webCrawerlingTargetDetailEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


    }
    #endregion

}
