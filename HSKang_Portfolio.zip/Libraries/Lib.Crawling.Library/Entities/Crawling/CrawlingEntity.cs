﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lib.Crawling.Library.Entities.Crawling
{

    #region // !++ BoardEntity
    /// <summary>
    /// 게시판
    /// </summary>
    [Serializable]
    public class BoardEntity
    {

        /// <summary>
        /// 게시물 고유번호(AI)
        /// </summary>
        public Int64 biSeq { get; set; }

        /// <summary>
        /// 회원 고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// 계정ID
        /// </summary>
        public String vcAccount { get; set; }

        /// <summary>
        /// 이름
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 제목
        /// </summary>
        public String vcTitle { get; set; }

        /// <summary>
        /// 내용
        /// </summary>
        public String tDescription { get; set; }

        /// <summary>
        /// 조회수
        /// </summary>
        public Int32 iRead { get; set; }

        /// <summary>
        /// 댓글수
        /// </summary>
        public Int32 iCommentCnt { get; set; }

        /// <summary>
        /// 공지여부(1:노출안함, 2:노출)
        /// </summary>
        public Int16 tiNotice { get; set; }

        /// <summary>
        /// 등록IP
        /// </summary>
        public String vcIP { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public BoardEntity()
        {
            biSeq = 0;
            biMemberSeq = 0;
            vcAccount = String.Empty;
            vcName = String.Empty;
            vcTitle = String.Empty;
            tDescription = String.Empty;
            iRead = 0;
            iCommentCnt = 0;
            tiNotice = 1;
            vcIP = String.Empty;
            dtRegDate = DateTime.MinValue;
        }
        ~BoardEntity()
        {
            biSeq = 0;
            biMemberSeq = 0;
            vcAccount = String.Empty;
            vcName = String.Empty;
            vcTitle = String.Empty;
            tDescription = String.Empty;
            iRead = 0;
            iCommentCnt = 0;
            tiNotice = 1;
            vcIP = String.Empty;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ BoardCommentEntity
    /// <summary>
    /// 게시판댓글
    /// </summary>
    [Serializable]
    public class BoardCommentEntity
    {

        /// <summary>
        /// 고유번호(AI)
        /// </summary>
        public Int64 biSeq { get; set; }

        /// <summary>
        /// 게시판 고유번호
        /// </summary>
        public Int64 biBoardSeq { get; set; }

        /// <summary>
        /// 회원고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// 계정ID
        /// </summary>
        public String vcAccount { get; set; }

        /// <summary>
        /// 이름
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 내용
        /// </summary>
        public String tDescription { get; set; }

        /// <summary>
        /// 등록IP
        /// </summary>
        public String vcIP { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public BoardCommentEntity()
        {
            biSeq = 0;
            biBoardSeq = 0;
            biMemberSeq = 0;
            vcAccount = String.Empty;
            vcName = String.Empty;
            tDescription = String.Empty;
            vcIP = String.Empty;
            dtRegDate = DateTime.MinValue;
        }
        ~BoardCommentEntity()
        {
            biSeq = 0;
            biBoardSeq = 0;
            biMemberSeq = 0;
            vcAccount = String.Empty;
            vcName = String.Empty;
            tDescription = String.Empty;
            vcIP = String.Empty;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ CountryEntity
    /// <summary>
    /// 국가
    /// </summary>
    [Serializable]
    public class CountryEntity
    {

        /// <summary>
        /// 고유번호(AI)
        /// </summary>
        public Int16 siSeq { get; set; }

        /// <summary>
        /// 국가명
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 국가코드
        /// </summary>
        public String vcCountryCode { get; set; }

        /// <summary>
        /// 언어ID
        /// </summary>
        public String vcKeyText { get; set; }

        /// <summary>
        /// 사용여부(1:사용, 2:대기, 3:삭제)
        /// </summary>
        public Int16 tiStatus { get; set; }

        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public CountryEntity()
        {
            siSeq = 0;
            vcName = String.Empty;
            vcCountryCode = String.Empty;
            vcKeyText = String.Empty;
            tiStatus = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }
        ~CountryEntity()
        {
            siSeq = 0;
            vcName = String.Empty;
            vcCountryCode = String.Empty;
            vcKeyText = String.Empty;
            tiStatus = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ FAQCodeEntity
    /// <summary>
    /// FAQ 코드관리
    /// </summary>
    [Serializable]
    public class FAQCodeEntity
    {

        /// <summary>
        /// 고유번호(AI)
        /// </summary>
        public Int32 iSeq { get; set; }

        /// <summary>
        /// 제목
        /// </summary>
        public String vcTitle { get; set; }

        /// <summary>
        /// 관리자고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public FAQCodeEntity()
        {
            iSeq = 0;
            vcTitle = String.Empty;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }
        ~FAQCodeEntity()
        {
            iSeq = 0;
            vcTitle = String.Empty;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ FAQEntity
    /// <summary>
    /// FAQ
    /// </summary>
    [Serializable]
    public class FAQEntity
    {

        /// <summary>
        /// 고유번호(AI)
        /// </summary>
        public Int32 iSeq { get; set; }

        /// <summary>
        /// FAQ 분류고유번호
        /// </summary>
        public Int32 iFaqCodeSeq { get; set; }

        /// <summary>
        /// 제목(언어ID)
        /// </summary>
        public String vcTitleKeyText { get; set; }

        /// <summary>
        /// 내용(언어ID)
        /// </summary>
        public String vcDescriptKeyText { get; set; }

        /// <summary>
        /// Main등록여부(1:노출안함, 2:노출)
        /// </summary>
        public Int16 tiMain { get; set; }

        /// <summary>
        /// 관리자고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public FAQEntity()
        {
            iSeq = 0;
            iFaqCodeSeq = 0;
            vcTitleKeyText = String.Empty;
            vcDescriptKeyText = String.Empty;
            tiMain = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }
        ~FAQEntity()
        {
            iSeq = 0;
            iFaqCodeSeq = 0;
            vcTitleKeyText = String.Empty;
            vcDescriptKeyText = String.Empty;
            tiMain = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ InquiryEntity
    /// <summary>
    /// 제품문의
    /// </summary>
    [Serializable]
    public class InquiryEntity
    {

        /// <summary>
        /// 고유번호(AI)
        /// </summary>
        public Int64 biSeq { get; set; }

        /// <summary>
        /// 문의유형(1:수집의뢰, 2:제휴문의, 3:상담신청, 4:기타문의)
        /// </summary>
        public Int16 tiType { get; set; }

        /// <summary>
        /// 회원고유번호(0:단체, 0>개인)
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// 사업자번호
        /// </summary>
        public String vcOrganizationSerial { get; set; }

        /// <summary>
        /// 업종
        /// </summary>
        public String vcBusiness { get; set; }

        /// <summary>
        /// 업체명
        /// </summary>
        public String vcCompany { get; set; }

        /// <summary>
        /// 담당자명
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 연락처
        /// </summary>
        public String vcPhone { get; set; }

        /// <summary>
        /// 제목
        /// </summary>
        public String vcTitle { get; set; }

        /// <summary>
        /// 내용
        /// </summary>
        public String tDescription { get; set; }

        /// <summary>
        /// 개인정보동의여부(1:동의)
        /// </summary>
        public Int16 tiAgree { get; set; }

        /// <summary>
        /// 상태(1:접수, 2:확인, 3:답변완료)
        /// </summary>
        public Int16 tiStatus { get; set; }

        /// <summary>
        /// 등록IP
        /// </summary>
        public String vcIP { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public InquiryEntity()
        {
            biSeq = 0;
            tiType = 0;
            biMemberSeq = 0;
            vcOrganizationSerial = String.Empty;
            vcBusiness = String.Empty;
            vcCompany = String.Empty;
            vcName = String.Empty;
            vcPhone = String.Empty;
            vcTitle = String.Empty;
            tDescription = String.Empty;
            tiAgree = 0;
            tiStatus = 0;
            vcIP = String.Empty;
            dtRegDate = DateTime.MinValue;
        }
        ~InquiryEntity()
        {
            biSeq = 0;
            tiType = 0;
            biMemberSeq = 0;
            vcOrganizationSerial = String.Empty;
            vcBusiness = String.Empty;
            vcCompany = String.Empty;
            vcName = String.Empty;
            vcPhone = String.Empty;
            vcTitle = String.Empty;
            tDescription = String.Empty;
            tiAgree = 0;
            tiStatus = 0;
            vcIP = String.Empty;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ InquiryAnswerEntity
    /// <summary>
    /// 제품문의답변
    /// </summary>
    [Serializable]
    public class InquiryAnswerEntity
    {

        /// <summary>
        /// 제품문의 고유번호
        /// </summary>
        public Int64 biInquirySeq { get; set; }

        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        /// <summary>
        /// 상태(1:확인, 2:진행, 3:완료)
        /// </summary>
        public Int16 tiStatus { get; set; }

        /// <summary>
        /// 답변내용
        /// </summary>
        public String tDescription { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public InquiryAnswerEntity()
        {
            biInquirySeq = 0;
            iManagerSeq = 0;
            tiStatus = 0;
            tDescription = String.Empty;
            dtRegDate = DateTime.MinValue;
        }
        ~InquiryAnswerEntity()
        {
            biInquirySeq = 0;
            iManagerSeq = 0;
            tiStatus = 0;
            tDescription = String.Empty;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ LanguageCodeEntity
    /// <summary>
    /// 언어(다국어) 코드
    /// </summary>
    [Serializable]
    public class LanguageCodeEntity
    {

        /// <summary>
        /// 언어코드
        /// </summary>
        public String vcLanguageCode { get; set; }

        /// <summary>
        /// 언어명
        /// </summary>
        public String vcLanguageName { get; set; }

        /// <summary>
        /// 사용여부(1:사용, 2:대기, 3:삭제)
        /// </summary>
        public Int16 tiStatus { get; set; }

        /// <summary>
        /// 관리자고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public LanguageCodeEntity()
        {
            vcLanguageCode = String.Empty;
            vcLanguageName = String.Empty;
            tiStatus = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }
        ~LanguageCodeEntity()
        {
            vcLanguageCode = String.Empty;
            vcLanguageName = String.Empty;
            tiStatus = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ LanguageEntity
    /// <summary>
    /// 언어(다국어)
    /// </summary>
    [Serializable]
    public class LanguageEntity
    {

        /// <summary>
        /// 언어코드
        /// </summary>
        public String vcLanguageCode { get; set; }

        /// <summary>
        /// 언어ID(고유키)
        /// </summary>
        public String vcKeyText { get; set; }

        /// <summary>
        /// 약어여부(1:Full Text, 2:약어)
        /// </summary>
        public Int16 tiAbbreviated { get; set; }

        /// <summary>
        /// 데이터(내용)
        /// </summary>
        public String vcText { get; set; }

        /// <summary>
        /// 사용여부(1:사용, 2:대기, 3:삭제)
        /// </summary>
        public Int16 tiStatus { get; set; }

        /// <summary>
        /// 관리자고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        /// <summary>
        /// 승인일시
        /// </summary>
        public DateTime dtApprovalDate { get; set; }

        public LanguageEntity()
        {
            vcLanguageCode = String.Empty;
            vcKeyText = String.Empty;
            tiAbbreviated = 0;
            vcText = String.Empty;
            tiStatus = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
            dtApprovalDate = DateTime.MinValue;
        }
        ~LanguageEntity()
        {
            vcLanguageCode = String.Empty;
            vcKeyText = String.Empty;
            tiAbbreviated = 0;
            vcText = String.Empty;
            tiStatus = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
            dtApprovalDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ LanguageImageEntity
    /// <summary>
    /// 언어(다국어) 이미지
    /// </summary>
    [Serializable]
    public class LanguageImageEntity
    {

        /// <summary>
        /// 언어코드
        /// </summary>
        public String vcLanguageCode { get; set; }

        /// <summary>
        /// 언어ID(고유키)
        /// </summary>
        public String vcKeyImage { get; set; }

        /// <summary>
        /// 파일경로
        /// </summary>
        public String vcUrl { get; set; }

        /// <summary>
        /// 이미지명
        /// </summary>
        public String vcImage { get; set; }

        /// <summary>
        /// 사용여부(1:사용, 2:대기, 3:삭제)
        /// </summary>
        public Int16 tiStatus { get; set; }

        /// <summary>
        /// 관리자고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        /// <summary>
        /// 승인일시
        /// </summary>
        public DateTime dtApprovalDate { get; set; }

        public LanguageImageEntity()
        {
            vcLanguageCode = String.Empty;
            vcKeyImage = String.Empty;
            vcUrl = String.Empty;
            vcImage = String.Empty;
            tiStatus = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
            dtApprovalDate = DateTime.MinValue;
        }
        ~LanguageImageEntity()
        {
            vcLanguageCode = String.Empty;
            vcKeyImage = String.Empty;
            vcUrl = String.Empty;
            vcImage = String.Empty;
            tiStatus = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
            dtApprovalDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ PlatFormEntity
    /// <summary>
    /// 플랫폼정보
    /// </summary>
    [Serializable]
    public class PlatFormEntity
    {

        /// <summary>
        /// 고유번호(AI)
        /// </summary>
        public Int32 iSeq { get; set; }

        /// <summary>
        /// 플랫폼명(페이스북, 네이버, 카카오 등)
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 언어ID
        /// </summary>
        public String vcKeyText { get; set; }

        /// <summary>
        /// 이미지(언어ID)
        /// </summary>
        public String vcKeyImage { get; set; }

        /// <summary>
        /// 사용여부(1:사용, 2:대기, 3:삭제)
        /// </summary>
        public Int16 tiStatus { get; set; }

        /// <summary>
        /// 관리자고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public PlatFormEntity()
        {
            iSeq = 0;
            vcName = String.Empty;
            vcKeyText = String.Empty;
            vcKeyImage = String.Empty;
            tiStatus = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }
        ~PlatFormEntity()
        {
            iSeq = 0;
            vcName = String.Empty;
            vcKeyText = String.Empty;
            vcKeyImage = String.Empty;
            tiStatus = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ PlatFormApiEntity
    /// <summary>
    /// 플랫폼API
    /// </summary>
    [Serializable]
    public class PlatFormApiEntity
    {

        /// <summary>
        /// 고유번호(AI)
        /// </summary>
        public Int32 iSeq { get; set; }

        /// <summary>
        /// 플랫폼고유번호
        /// </summary>
        public Int32 iPlatFormSeq { get; set; }

        /// <summary>
        /// API경로(URL)
        /// </summary>
        public String vcApiUrl { get; set; }

        /// <summary>
        /// API계정
        /// </summary>
        public String vcID { get; set; }

        /// <summary>
        /// API보안키
        /// </summary>
        public String vcVerifyKey { get; set; }

        /// <summary>
        /// 사용여부(1:사용, 2:대기, 3:삭제)
        /// </summary>
        public Int16 tiStatus { get; set; }

        /// <summary>
        /// 관리자고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public PlatFormApiEntity()
        {
            iSeq = 0;
            iPlatFormSeq = 0;
            vcApiUrl = String.Empty;
            vcID = String.Empty;
            vcVerifyKey = String.Empty;
            tiStatus = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }
        ~PlatFormApiEntity()
        {
            iSeq = 0;
            iPlatFormSeq = 0;
            vcApiUrl = String.Empty;
            vcID = String.Empty;
            vcVerifyKey = String.Empty;
            tiStatus = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ PrivateBoardEntity
    /// <summary>
    /// 공지, 뉴스 등 게시판
    /// </summary>
    [Serializable]
    public class PrivateBoardEntity
    {

        /// <summary>
        /// 고유번호(AI)
        /// </summary>
        public Int64 biSeq { get; set; }

        /// <summary>
        /// 게시판타입(1:공지사항, 2:뉴스, 3:..)
        /// </summary>
        public Int16 tiType { get; set; }

        /// <summary>
        /// 제목(언어ID)
        /// </summary>
        public String vcTitleKeyText { get; set; }

        /// <summary>
        /// 내용(언어ID)
        /// </summary>
        public String vcDescriptKeyText { get; set; }

        /// <summary>
        /// Main등록여부(1:노출안함, 2:노출)
        /// </summary>
        public Int16 tiMain { get; set; }

        /// <summary>
        /// 조회수
        /// </summary>
        public Int32 iRead { get; set; }

        /// <summary>
        /// 관리자고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public PrivateBoardEntity()
        {
            biSeq = 0;
            tiType = 0;
            vcTitleKeyText = String.Empty;
            vcDescriptKeyText = String.Empty;
            tiMain = 0;
            iRead = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }
        ~PrivateBoardEntity()
        {
            biSeq = 0;
            tiType = 0;
            vcTitleKeyText = String.Empty;
            vcDescriptKeyText = String.Empty;
            tiMain = 0;
            iRead = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ PrivateBoardDataEntity
    /// <summary>
    /// 공지, 뉴스 등 게시판 데이터
    /// </summary>
    [Serializable]
    public class PrivateBoardDataEntity
    {

        /// <summary>
        /// 고유번호(AI)
        /// </summary>
        public Int64 biSeq { get; set; }

        /// <summary>
        /// 게시판고유번호
        /// </summary>
        public Int64 biPrivateBoardSeq { get; set; }

        /// <summary>
        /// 원본파일명
        /// </summary>
        public String vcFileName { get; set; }

        /// <summary>
        /// 저장경로
        /// </summary>
        public String vcSaveFolder { get; set; }

        /// <summary>
        /// 저장파일명
        /// </summary>
        public String vcSaveName { get; set; }

        /// <summary>
        /// 파일형식(확장자)
        /// </summary>
        public String vcSaveType { get; set; }

        /// <summary>
        /// 파일크기
        /// </summary>
        public Int32 iSaveSize { get; set; }

        /// <summary>
        /// 다운로드 수
        /// </summary>
        public Int32 iDownLoad { get; set; }

        /// <summary>
        /// 관리자고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public PrivateBoardDataEntity()
        {
            biSeq = 0;
            biPrivateBoardSeq = 0;
            vcFileName = String.Empty;
            vcSaveFolder = String.Empty;
            vcSaveName = String.Empty;
            vcSaveType = String.Empty;
            iSaveSize = 0;
            iDownLoad = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }
        ~PrivateBoardDataEntity()
        {
            biSeq = 0;
            biPrivateBoardSeq = 0;
            vcFileName = String.Empty;
            vcSaveFolder = String.Empty;
            vcSaveName = String.Empty;
            vcSaveType = String.Empty;
            iSaveSize = 0;
            iDownLoad = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ CrawlerRecordEntity
    /// <summary>
    /// 클로링 성공여부
    /// </summary>
    [Serializable]
    public class CrawlerRecordEntity
    {

        /// <summary>
        /// 회원 고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// 데이터수집 성공 수
        /// </summary>
        public Int32 iSuccess { get; set; }

        /// <summary>
        /// 데이터수집 실패 수
        /// </summary>
        public Int32 iFail { get; set; }

        public CrawlerRecordEntity()
        {
            biMemberSeq = 0;
            iSuccess = 0;
            iFail = 0;
        }
        ~CrawlerRecordEntity()
        {
            biMemberSeq = 0;
            iSuccess = 0;
            iFail = 0;
        }

    }
    #endregion


    #region // !++ CrawlerHistoryEntity
    /// <summary>
    /// 데이터 수집내역
    /// </summary>
    [Serializable]
    public class CrawlerHistoryEntity
    {

        /// <summary>
        /// 고유번호
        /// </summary>
        public Int64 biSeq { get; set; }

        /// <summary>
        /// 회원 고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// 대상사이트URL
        /// </summary>
        public String vcTargetUrl { get; set; }

        /// <summary>
        /// 데이터수집 상태(0:없음, 1:성공, 2:실패)
        /// </summary>
        public Int16 tiStatus { get; set; }

        /// <summary>
        /// 수집레코드 수
        /// </summary>
        public Int32 iRecord { get; set; }

        /// <summary>
        /// 작업시간(밀리세컨)
        /// </summary>
        public Int64 biMillisecond { get; set; }

        /// <summary>
        /// 크롤링스케줄 고유번호(0:등록스케줄없음, 0>등록스케줄고유번호)
        /// </summary>
        public Int64 biCrawlerScheduleSeq { get; set; }

        /// <summary>
        /// 스케줄러 실행횟차 번호
        /// </summary>
        public Int32 iNumber { get; set; }

        /// <summary>
        /// 등록(시작)일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        /// <summary>
        /// 종료일시
        /// </summary>
        public DateTime dtEndDate { get; set; }

        public CrawlerHistoryEntity()
        {
            biSeq = 0;
            biMemberSeq = 0;
            vcTargetUrl = String.Empty;
            tiStatus = 0;
            iRecord = 0;
            biMillisecond = 0;
            biCrawlerScheduleSeq = 0;
            iNumber = 0;
            dtRegDate = DateTime.MinValue;
            dtEndDate = DateTime.MinValue;
        }
        ~CrawlerHistoryEntity()
        {
            biSeq = 0;
            biMemberSeq = 0;
            vcTargetUrl = String.Empty;
            tiStatus = 0;
            iRecord = 0;
            biMillisecond = 0;
            biCrawlerScheduleSeq = 0;
            iNumber = 0;
            dtRegDate = DateTime.MinValue;
            dtEndDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ CrawlerScheduleEntity
    /// <summary>
    /// 크롤링 스케줄
    /// </summary>
    [Serializable]
    public class CrawlerScheduleEntity
    {

        /// <summary>
        /// 고유번호
        /// </summary>
        public Int64 biSeq { get; set; }

        /// <summary>
        /// 회원 고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// 대상사이트URL
        /// </summary>
        public String vcTargetUrl { get; set; }

        /// <summary>
        /// 일일횟수
        /// </summary>
        public Int32 iRepeat { get; set; }

        /// <summary>
        /// 상태(0:대기(생성시-초기화 시간 필요), 1:수집진행, 2:완료)
        /// </summary>
        public Int16 tiStatus { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public CrawlerScheduleEntity()
        {
            biSeq = 0;
            biMemberSeq = 0;
            vcTargetUrl = String.Empty;
            iRepeat = 0;
            tiStatus = 0;
            dtRegDate = DateTime.MinValue;
        }
        ~CrawlerScheduleEntity()
        {
            biSeq = 0;
            biMemberSeq = 0;
            vcTargetUrl = String.Empty;
            iRepeat = 0;
            tiStatus = 0;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ CrawlerScheduleTimeEntity
    /// <summary>
    /// 크롤링 스케줄 시간
    /// </summary>
    [Serializable]
    public class CrawlerScheduleTimeEntity
    {

        /// <summary>
        /// 고유번호
        /// </summary>
        public Int64 biSeq { get; set; }

        /// <summary>
        /// 회원 고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// 크롤링 스케줄 고유번호
        /// </summary>
        public Int64 biCrawlerScheduleSeq { get; set; }

        /// <summary>
        /// 회차(횟수) 번호
        /// </summary>
        public Int32 iNumber { get; set; }

        /// <summary>
        /// 실행시간(밀리세컨)
        /// </summary>
        public Int64 biMillisecond { get; set; }

        /// <summary>
        /// 등록일시(스케줄완료일시)
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public CrawlerScheduleTimeEntity()
        {
            biSeq = 0;
            biMemberSeq = 0;
            biCrawlerScheduleSeq = 0;
            iNumber = 0;
            biMillisecond = 0;
            dtRegDate = DateTime.MinValue;
        }
        ~CrawlerScheduleTimeEntity()
        {
            biSeq = 0;
            biMemberSeq = 0;
            biCrawlerScheduleSeq = 0;
            iNumber = 0;
            biMillisecond = 0;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ CompanyGroupEntity
    /// <summary>
    /// 회사조직(분류)
    /// </summary>
    [Serializable]
    public class CompanyGroupEntity
    {

        /// <summary>
        /// 고유번호
        /// </summary>
        public Int32 iSeq { get; set; }

        /// <summary>
        /// 그룹명
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 그룹명(언어ID)
        /// </summary>
        public String vcNameKeyText { get; set; }

        /// <summary>
        /// 그룹약어(간단소개)
        /// </summary>
        public String vcAbbreviation { get; set; }

        /// <summary>
        /// 그룹약어(언어ID)
        /// </summary>
        public String vcAbbreviationKeyText { get; set; }

        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public CompanyGroupEntity()
        {
            iSeq = 0;
            vcName = String.Empty;
            vcNameKeyText = String.Empty;
            vcAbbreviation = String.Empty;
            vcAbbreviationKeyText = String.Empty;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }
        ~CompanyGroupEntity()
        {
            iSeq = 0;
            vcName = String.Empty;
            vcNameKeyText = String.Empty;
            vcAbbreviation = String.Empty;
            vcAbbreviationKeyText = String.Empty;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ CompanyPeopleEntity
    /// <summary>
    /// 회사조직구성원
    /// </summary>
    [Serializable]
    public class CompanyPeopleEntity
    {

        /// <summary>
        /// 고유번호
        /// </summary>
        public Int32 iSeq { get; set; }

        /// <summary>
        /// 회사조직고유번호
        /// </summary>
        public Int32 iCompanyGroupSeq { get; set; }

        /// <summary>
        /// 이름
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 직급
        /// </summary>
        public String vcPosition { get; set; }

        /// <summary>
        /// 내용
        /// </summary>
        public String tDescription { get; set; }

        /// <summary>
        /// 이미지경로
        /// </summary>
        public String vcFolder { get; set; }

        /// <summary>
        /// 이미지파일명
        /// </summary>
        public String vcImage { get; set; }

        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public CompanyPeopleEntity()
        {
            iSeq = 0;
            iCompanyGroupSeq = 0;
            vcName = String.Empty;
            vcPosition = String.Empty;
            tDescription = String.Empty;
            vcFolder = String.Empty;
            vcImage = String.Empty;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }
        ~CompanyPeopleEntity()
        {
            iSeq = 0;
            iCompanyGroupSeq = 0;
            vcName = String.Empty;
            vcPosition = String.Empty;
            tDescription = String.Empty;
            vcFolder = String.Empty;
            vcImage = String.Empty;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ BlogEntity
    /// <summary>
    /// 블로그
    /// </summary>
    [Serializable]
    public class BlogEntity
    {

        /// <summary>
        /// 고유번호
        /// </summary>
        public Int64 biSeq { get; set; }

        /// <summary>
        /// 제목
        /// </summary>
        public String vcTitle { get; set; }

        /// <summary>
        /// 제목이미지경로
        /// </summary>
        public String vcTitleFolder { get; set; }

        /// <summary>
        /// 제목이미지파일명
        /// </summary>
        public String vcTitleImage { get; set; }

        /// <summary>
        /// 내용
        /// </summary>
        public String tDescription { get; set; }

        /// <summary>
        /// 조회수
        /// </summary>
        public Int32 iRead { get; set; }

        /// <summary>
        /// 댓글수
        /// </summary>
        public Int32 iComment { get; set; }

        /// <summary>
        /// 좋아요수
        /// </summary>
        public Int32 iLike { get; set; }

        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public BlogEntity()
        {
            biSeq = 0;
            vcTitle = String.Empty;
            vcTitleFolder = String.Empty;
            vcTitleImage = String.Empty;
            tDescription = String.Empty;
            iRead = 0;
            iComment = 0;
            iLike = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }
        ~BlogEntity()
        {
            biSeq = 0;
            vcTitle = String.Empty;
            vcTitleFolder = String.Empty;
            vcTitleImage = String.Empty;
            tDescription = String.Empty;
            iRead = 0;
            iComment = 0;
            iLike = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ BlogCommentEntity
    /// <summary>
    /// 블로그 댓글
    /// </summary>
    [Serializable]
    public class BlogCommentEntity
    {

        /// <summary>
        /// 고유번호
        /// </summary>
        public Int64 biSeq { get; set; }

        /// <summary>
        /// 블로그 고유번호
        /// </summary>
        public Int64 biBlogSeq { get; set; }

        /// <summary>
        /// 회원고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// 계정ID
        /// </summary>
        public String vcAccount { get; set; }

        /// <summary>
        /// 이름
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 내용
        /// </summary>
        public String tDescription { get; set; }

        /// <summary>
        /// 등록IP
        /// </summary>
        public String vcIP { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public BlogCommentEntity()
        {
            biSeq = 0;
            biBlogSeq = 0;
            biMemberSeq = 0;
            vcAccount = String.Empty;
            vcName = String.Empty;
            tDescription = String.Empty;
            vcIP = String.Empty;
            dtRegDate = DateTime.MinValue;
        }
        ~BlogCommentEntity()
        {
            biSeq = 0;
            biBlogSeq = 0;
            biMemberSeq = 0;
            vcAccount = String.Empty;
            vcName = String.Empty;
            tDescription = String.Empty;
            vcIP = String.Empty;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ BlogLikeEntity
    /// <summary>
    /// 블로그 좋아요
    /// </summary>
    [Serializable]
    public class BlogLikeEntity
    {

        /// <summary>
        /// 블로그 고유번호
        /// </summary>
        public Int64 biBlogSeq { get; set; }

        /// <summary>
        /// 회원고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// 계정ID
        /// </summary>
        public String vcAccount { get; set; }

        /// <summary>
        /// 이름
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 등록IP
        /// </summary>
        public String vcIP { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public BlogLikeEntity()
        {
            biBlogSeq = 0;
            biMemberSeq = 0;
            vcAccount = String.Empty;
            vcName = String.Empty;
            vcIP = String.Empty;
            dtRegDate = DateTime.MinValue;
        }
        ~BlogLikeEntity()
        {
            biBlogSeq = 0;
            biMemberSeq = 0;
            vcAccount = String.Empty;
            vcName = String.Empty;
            vcIP = String.Empty;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ GoodsEntity
    /// <summary>
    /// 상품정보
    /// </summary>
    [Serializable]
    public class GoodsEntity
    {

        /// <summary>
        /// 고유번호
        /// </summary>
        public Int32 iSeq { get; set; }

        /// <summary>
        /// 상품명
        /// </summary>
        public String vcGoods { get; set; }

        /// <summary>
        /// 상품명(언어ID)
        /// </summary>
        public String vcKeyText { get; set; }

        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public GoodsEntity()
        {
            iSeq = 0;
            vcGoods = String.Empty;
            vcKeyText = String.Empty;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }
        ~GoodsEntity()
        {
            iSeq = 0;
            vcGoods = String.Empty;
            vcKeyText = String.Empty;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion

}
