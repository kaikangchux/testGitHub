﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.LogDB
{

    #region // !++ tbLogPrivateBoardData
    /// <summary>
    /// LOG 공지, 뉴스 등 게시판 데이터
    /// </summary>
    [Table("tbLogPrivateBoardData")]
    public class tbLogPrivateBoardData
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        /// <summary>
        /// 파티션 키(월별)
        /// </summary>
        public Int32 iPartKeyMonth { get; set; }

        [Index(1), Required]
        /// <summary>
        /// 트랜잭션ID
        /// </summary>
        public Int64 biTXIDX { get; set; }

        [Index(2), Required]
        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        [Required]
        /// <summary>
        /// 고유번호
        /// </summary>
        public Int64 biSeq { get; set; }

        [Required]
        /// <summary>
        /// 게시판고유번호
        /// </summary>
        public Int64 biPrivateBoardSeq { get; set; }

        [Required, MinLength(2), MaxLength(32)]
        /// <summary>
        /// 원본파일명
        /// </summary>
        public String vcFileName { get; set; }

        [Required, MinLength(2), MaxLength(128)]
        /// <summary>
        /// 저장경로
        /// </summary>
        public String vcSaveFolder { get; set; }

        [Required, MinLength(2), MaxLength(32)]
        /// <summary>
        /// 저장파일명
        /// </summary>
        public String vcSaveName { get; set; }

        [Required, MinLength(2), MaxLength(8)]
        /// <summary>
        /// 파일형식(확장자)
        /// </summary>
        public String vcSaveType { get; set; }

        [Required]
        /// <summary>
        /// 파일크기
        /// </summary>
        public Int32 iSaveSize { get; set; }

        [Required]
        /// <summary>
        /// 로그분류(1:등록, 2:수정, 3:삭제)
        /// </summary>
        public Int16 tiType { get; set; }

        /// <summary>
        /// IP
        /// </summary>
        public String vcIP { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// UTC등록일시
        /// </summary>
        public DateTime dtUtcRegDate { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
