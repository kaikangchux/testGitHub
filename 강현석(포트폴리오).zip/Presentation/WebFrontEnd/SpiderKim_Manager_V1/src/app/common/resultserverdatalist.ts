export class ResultServerDatalist<T>
{
    totalRecord: number;
    gClass:T[];

    constructor()
    {
        this.totalRecord = 0;
        this.gClass = null;
    }
}