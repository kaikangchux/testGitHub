// 언어(다국어)이미지
export class LanguageImageModel
{

  vcLanguageCode: string;
  vcKeyImage: string;
  vcUrl: string;
  vcImage: string;
  tiStatus: number;
  iManagerSeq: number;
  dtRegDate: string;
  dtApprovalDate: string;

  constructor() {
    this.vcLanguageCode = '';
    this.vcKeyImage = '';
    this.vcUrl = '';
    this.vcImage = '';
    this.tiStatus = 0;
    this.iManagerSeq = 0;
    this.dtRegDate = '';
    this.dtApprovalDate = '';
  }
}
