//2019.09.04 jwt, localstorage 사용으로 CookieManageService는 사용하지 않음

import { Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import * as CryptoJS from 'crypto-js'; 

import { ConfigService } from '../config';
import { ManagerLoginInfo } from '../model';

@Injectable({
    providedIn: 'root'
})

export class CookieManageService
{
    interval:any;

    constructor(private cookieService:CookieService){}

    getCookie():ManagerLoginInfo
    {
        //console.log(this.cookieService.get('ManagerTool'));
        // console.log(this.cookieService.get('spiderkim'));
        
        //return { iSeq: 2, vcManagerID: 'kang', vcName: '강현석', tiGrade: 'super', isLogin: true };

        let cookieData = this.cookieService.get('spiderkim');
        let data:string;
        if(typeof data != 'undefined' && data !== null){
            data = CryptoJS.AES.decrypt(cookieData.trim(), ConfigService.CRYPT_KEY.trim()).toString(CryptoJS.enc.Utf8);
            return JSON.parse(data);
        }

        return null;
    }

    deleteCookie():void{
        this.cookieService.delete('spiderkim');
    }
}