﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.CrawlingDB
{

    #region // !++ tbCrawlerHistory
    /// <summary>
    /// 데이터수집내역
    /// </summary>
    [Table("tbCrawlerHistory")]
    public class tbCrawlerHistory
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        /// <summary>
        /// 고유번호
        /// </summary>
        public Int64 biSeq { get; set; }

        [Index(1), Required]
        /// <summary>
        /// 회원 고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        [Required, MinLength(4), MaxLength(256)]
        /// <summary>
        /// 대상사이트URL
        /// </summary>
        public String vcTargetUrl { get; set; }

        /// <summary>
        /// 데이터수집 상태(0:없음, 1:성공, 2:실패)
        /// </summary>
        public Int16 tiStatus { get; set; }

        /// <summary>
        /// 수집레코드 수
        /// </summary>
        public Int32 iRecord { get; set; }

        /// <summary>
        /// 작업시간(밀리세컨)
        /// </summary>
        public Int64 biMillisecond { get; set; }

        /// <summary>
        /// 크롤링스케줄 고유번호(0:등록스케줄없음, 0>등록스케줄고유번호)
        /// </summary>
        public Int64 biCrawlerScheduleSeq { get; set; }

        /// <summary>
        /// 스케줄러 실행횟차 번호
        /// </summary>
        public Int32 iNumber { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록(시작)일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 종료일시
        /// </summary>
        public DateTime dtEndDate { get; set; }

    }
    #endregion

}
