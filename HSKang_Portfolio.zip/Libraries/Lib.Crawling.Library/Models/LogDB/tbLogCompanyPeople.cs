﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.LogDB
{

    #region // !++ tbLogCompanyPeople
    /// <summary>
    /// LOG 회사조직구성원
    /// </summary>
    [Table("tbLogCompanyPeople")]
    public class tbLogCompanyPeople
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        /// <summary>
        /// 파티션 키(월별)
        /// </summary>
        public Int32 iPartKeyMonth { get; set; }

        [Index(1), Required]
        /// <summary>
        /// 트랜잭션ID
        /// </summary>
        public Int64 biTXIDX { get; set; }

        [Index(2), Required]
        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        [Required]
        /// <summary>
        /// 고유번호
        /// </summary>
        public Int32 iSeq { get; set; }

        [Required]
        /// <summary>
        /// 회사조직고유번호
        /// </summary>
        public Int32 iCompanyGroupSeq { get; set; }

        [Required, MinLength(2), MaxLength(32)]
        /// <summary>
        /// 이름
        /// </summary>
        public String vcName { get; set; }

        [Required, MinLength(2), MaxLength(64)]
        /// <summary>
        /// 직급
        /// </summary>
        public String vcPosition { get; set; }

        /// <summary>
        /// 내용
        /// </summary>
        public String tDescription { get; set; }

        /// <summary>
        /// 이미지경로
        /// </summary>
        public String vcFolder { get; set; }

        /// <summary>
        /// 이미지파일명
        /// </summary>
        public String vcImage { get; set; }

        [Required]
        /// <summary>
        /// 로그분류(1:등록, 2:수정, 3:삭제)
        /// </summary>
        public Int16 tiType { get; set; }

        /// <summary>
        /// IP
        /// </summary>
        public String vcIP { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// UTC등록일시
        /// </summary>
        public DateTime dtUtcRegDate { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
