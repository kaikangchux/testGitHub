﻿using System;
using System.Collections.Generic;
using System.Text;

using Lib.Crawling.Library.Enum;

namespace Lib.Crawling.Library.Entities.LogDB
{

    #region // !++ LogActionDefaultEntity
    /// <summary>
    /// LOG 기본정보
    /// </summary>
    [Serializable]
    public class LogActionDefaultEntity
    {

        /// <summary>
        /// 트랜잭션ID
        /// </summary>
        public Int64 biTXIDX { get; set; }

        /// <summary>
        /// IP
        /// </summary>
        public String vcIP { get; set; }

        /// <summary>
        /// 로그분류
        /// </summary>
        public LogActionType tiType { get; set; }

        public LogActionDefaultEntity()
        {
            biTXIDX = 0;
            vcIP = String.Empty;
        }
        ~LogActionDefaultEntity()
        {
            biTXIDX = 0;
            vcIP = String.Empty;
        }

    }
    #endregion


    #region // !++ LogActionManagerEntity
    /// <summary>
    /// 매니저 로그 정보
    /// </summary>
    [Serializable]
    public class LogActionManagerEntity
    {

        /// <summary>
        /// 트랜잭션ID
        /// </summary>
        public Int64 biTXIDX { get; set; }

        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        /// <summary>
        /// IP
        /// </summary>
        public String vcIP { get; set; }

        /// <summary>
        /// 로그분류
        /// </summary>
        public LogActionType tiType { get; set; }

        public LogActionManagerEntity()
        {
            biTXIDX = 0;
            iManagerSeq = 0;
            vcIP = String.Empty;
        }
        ~LogActionManagerEntity()
        {
            biTXIDX = 0;
            iManagerSeq = 0;
            vcIP = String.Empty;
        }
    }
    #endregion


    #region // !++ LogActionMemberEntity
    /// <summary>
    /// 유저 로그 정보
    /// </summary>
    [Serializable]
    public class LogActionMemberEntity
    {

        /// <summary>
        /// 트랜잭션ID
        /// </summary>
        public Int64 biTXIDX { get; set; }

        /// <summary>
        /// 회원 고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// IP
        /// </summary>
        public String vcIP { get; set; }

        /// <summary>
        /// 로그분류
        /// </summary>
        public LogActionType tiType { get; set; }

        public LogActionMemberEntity()
        {
            biTXIDX = 0;
            biMemberSeq = 0;
            vcIP = String.Empty;
        }
        ~LogActionMemberEntity()
        {
            biTXIDX = 0;
            biMemberSeq = 0;
            vcIP = String.Empty;
        }
    }
    #endregion


    #region // !++ LogFAQCodeEntity
    /// <summary>
    /// FAQ코드 로그
    /// </summary>
    [Serializable]
    public class LogFAQCodeEntity : LogActionManagerEntity
    {


        /// <summary>
        /// FAQ코드 고유번호
        /// </summary>
        public Int32 iSeq { get; set; }

        /// <summary>
        /// 분류(제목)
        /// </summary>
        public String vcTitle { get; set; }


        public LogFAQCodeEntity()
        {
            iSeq = 0;
            vcTitle = String.Empty;
        }
        ~LogFAQCodeEntity()
        {
            iSeq = 0;
            vcTitle = String.Empty;
        }

    }
    #endregion


    #region // !++ LogFAQEntity
    /// <summary>
    /// FAQ 로그
    /// </summary>
    [Serializable]
    public class LogFAQEntity : LogActionManagerEntity
    {

        /// <summary>
        /// 고유번호
        /// </summary>
        public Int32 iSeq { get; set; }

        /// <summary>
        /// FAQ분류고유번호
        /// </summary>
        public Int32 iFaqCodeSeq { get; set; }

        /// <summary>
        /// 제목(언어ID)
        /// </summary>
        public String vcTitleKeyText { get; set; }

        /// <summary>
        /// 내용(언어ID)
        /// </summary>
        public String vcDescriptKeyText { get; set; }

        /// <summary>
        /// Main등록여부(1:노출안함, 2:노출)
        /// </summary>
        public Int16 tiMain { get; set; }

        public LogFAQEntity()
        {
            iSeq = 0;
            iFaqCodeSeq = 0;
            vcTitleKeyText = String.Empty;
            vcDescriptKeyText = String.Empty;
            tiMain = 0;
        }
        ~LogFAQEntity()
        {
            iSeq = 0;
            iFaqCodeSeq = 0;
            vcTitleKeyText = String.Empty;
            vcDescriptKeyText = String.Empty;
            tiMain = 0;
        }

    }
    #endregion


    #region // !++ LogPlatFormEntity
    /// <summary>
    /// 플랫폼정보 로그
    /// </summary>
    [Serializable]
    public class LogPlatFormEntity : LogActionManagerEntity
    {

        /// <summary>
        /// 고유번호
        /// </summary>
        public Int32 iSeq { get; set; }

        /// <summary>
        /// 플랫폼명(페이스북, 네이버, 카카오 등)
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 언어ID
        /// </summary>
        public String vcKeyText { get; set; }

        /// <summary>
        /// 이미지(언어ID)
        /// </summary>
        public String vcKeyImage { get; set; }

        /// <summary>
        /// 사용여부(1:사용, 2:대기, 3:삭제)
        /// </summary>
        public Int16 tiStatus { get; set; }

        public LogPlatFormEntity()
        {
            iSeq = 0;
            vcName = String.Empty;
            vcKeyText = String.Empty;
            vcKeyImage = String.Empty;
            tiStatus = 0;
        }
        ~LogPlatFormEntity()
        {
            iSeq = 0;
            vcName = String.Empty;
            vcKeyText = String.Empty;
            vcKeyImage = String.Empty;
            tiStatus = 0;
        }

    }
    #endregion


    #region // !++ LogPlatFormApiEntity
    /// <summary>
    /// 플랫폼API 로그
    /// </summary>
    [Serializable]
    public class LogPlatFormApiEntity : LogActionManagerEntity
    {

        /// <summary>
        /// 고유번호
        /// </summary>
        public Int32 iSeq { get; set; }

        /// <summary>
        /// 플랫폼 고유번호
        /// </summary>
        public Int32 iPlatFormSeq { get; set; }

        /// <summary>
        /// API경로(URL)
        /// </summary>
        public String vcApiUrl { get; set; }

        /// <summary>
        /// API계정
        /// </summary>
        public String vcID { get; set; }

        /// <summary>
        /// API보안키
        /// </summary>
        public String vcVerifyKey { get; set; }

        /// <summary>
        /// 사용여부(1:사용, 2:대기, 3:삭제)
        /// </summary>
        public Int16 tiStatus { get; set; }

        public LogPlatFormApiEntity()
        {
            iSeq = 0;
            iPlatFormSeq = 0;
            vcApiUrl = String.Empty;
            vcID = String.Empty;
            vcVerifyKey = String.Empty;
        }
        ~LogPlatFormApiEntity()
        {
            iSeq = 0;
            iPlatFormSeq = 0;
            vcApiUrl = String.Empty;
            vcID = String.Empty;
            vcVerifyKey = String.Empty;
        }

    }
    #endregion


    #region // !++ LogLanguageCodeEntity
    /// <summary>
    /// 언어(다국어)코드 로그
    /// </summary>
    [Serializable]
    public class LogLanguageCodeEntity : LogActionManagerEntity
    {

        /// <summary>
        /// 언어코드
        /// </summary>
        public String vcLanguageCode { get; set; }

        /// <summary>
        /// 언어명
        /// </summary>
        public String vcLanguageName { get; set; }

        /// <summary>
        /// 사용여부(1:사용, 2:대기, 3:삭제)
        /// </summary>
        public Int16 tiStatus { get; set; }

        public LogLanguageCodeEntity()
        {
            vcLanguageCode = String.Empty;
            vcLanguageName = String.Empty;
            tiStatus = 0;
        }
        ~LogLanguageCodeEntity()
        {
            vcLanguageCode = String.Empty;
            vcLanguageName = String.Empty;
            tiStatus = 0;
        }

    }
    #endregion


    #region // !++ LogLanguageEntity
    /// <summary>
    /// 언어(다국어) 로그
    /// </summary>
    [Serializable]
    public class LogLanguageEntity : LogActionManagerEntity
    {

        /// <summary>
        /// 언어코드
        /// </summary>
        public String vcLanguageCode { get; set; }

        /// <summary>
        /// 언어ID(고유키)
        /// </summary>
        public String vcKeyText { get; set; }

        /// <summary>
        /// 약어여부(1:Full Text, 2:약어)
        /// </summary>
        public Int16 tiAbbreviated { get; set; }

        /// <summary>
        /// 데이터
        /// </summary>
        public String vcText { get; set; }

        /// <summary>
        /// 사용여부(1:사용, 2:대기, 3:삭제)
        /// </summary>
        public Int16 tiStatus { get; set; }

        public LogLanguageEntity()
        {
            vcLanguageCode = String.Empty;
            vcKeyText = String.Empty;
            tiAbbreviated = 0;
            vcText = String.Empty;
            tiStatus = 0;
        }
        ~LogLanguageEntity()
        {
            vcLanguageCode = String.Empty;
            vcKeyText = String.Empty;
            tiAbbreviated = 0;
            vcText = String.Empty;
            tiStatus = 0;
        }

    }
    #endregion


    #region // !++ LogLanguageImageEntity
    /// <summary>
    /// 언어(다국어)이미지 로그
    /// </summary>
    [Serializable]
    public class LogLanguageImageEntity : LogActionManagerEntity
    {

        /// <summary>
        /// 언어코드
        /// </summary>
        public String vcLanguageCode { get; set; }

        /// <summary>
        /// 언어ID(고유키)
        /// </summary>
        public String vcKeyImage { get; set; }

        /// <summary>
        /// 파일경로
        /// </summary>
        public String vcUrl { get; set; }

        /// <summary>
        /// 이미지명
        /// </summary>
        public String vcImage { get; set; }

        /// <summary>
        /// 사용여부(1:사용, 2:대기, 3:삭제)
        /// </summary>
        public Int16 tiStatus { get; set; }

        public LogLanguageImageEntity()
        {
            vcLanguageCode = String.Empty;
            vcKeyImage = String.Empty;
            vcUrl = String.Empty;
            vcImage = String.Empty;
            tiStatus = 0;
        }
        ~LogLanguageImageEntity()
        {
            vcLanguageCode = String.Empty;
            vcKeyImage = String.Empty;
            vcUrl = String.Empty;
            vcImage = String.Empty;
            tiStatus = 0;
        }

    }
    #endregion


    #region // !++ LogProhibitWordsEntity
    /// <summary>
    /// 금지어 로그
    /// </summary>
    [Serializable]
    public class LogProhibitWordsEntity : LogActionManagerEntity
    {

        /// <summary>
        /// 사용불가문자
        /// </summary>
        public String vcProhibitWords { get; set; }

        /// <summary>
        /// 비고(노트)
        /// </summary>
        public String vcNote { get; set; }

        /// <summary>
        /// 사용여부(1:사용, 2:대기)
        /// </summary>
        public Int16 tiStatus { get; set; }

        public LogProhibitWordsEntity()
        {
            vcProhibitWords = String.Empty;
            vcNote = String.Empty;
            tiStatus = 0;
        }
        ~LogProhibitWordsEntity()
        {
            vcProhibitWords = String.Empty;
            vcNote = String.Empty;
            tiStatus = 0;
        }

    }
    #endregion


    #region // !++ LogManagerEntity
    /// <summary>
    /// 관리자 등록및수정 로그
    /// </summary>
    [Serializable]
    public class LogManagerEntity : LogActionManagerEntity
    {

        /// <summary>
        /// 계정 고유번호
        /// </summary>
        public Int32 iSeq { get; set; }

        /// <summary>
        /// 계정
        /// </summary>
        public String vcManagerID { get; set; }

        /// <summary>
        /// 이름
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 비밀번호
        /// </summary>
        public String vcPassword { get; set; }

        /// <summary>
        /// E-mail ID
        /// </summary>
        public String vcEmailID { get; set; }

        /// <summary>
        /// E-mail address
        /// </summary>
        public String vcEmailAddress { get; set; }

        /// <summary>
        /// 연락처
        /// </summary>
        public String vcPhone { get; set; }

        /// <summary>
        /// 등급(팀- 10:프로그램, 20:기획)
        /// </summary>
        public Int16 tiGrade { get; set; }

        public LogManagerEntity()
        {
            iSeq = 0;
            vcManagerID = String.Empty;
            vcName = String.Empty;
            vcPassword = String.Empty;
            vcEmailID = String.Empty;
            vcEmailAddress = String.Empty;
            vcPhone = String.Empty;
            tiGrade = 0;
        }
        ~LogManagerEntity()
        {
            iSeq = 0;
            vcManagerID = String.Empty;
            vcName = String.Empty;
            vcPassword = String.Empty;
            vcEmailID = String.Empty;
            vcEmailAddress = String.Empty;
            vcPhone = String.Empty;
            tiGrade = 0;
        }

    }
    #endregion


    #region // !++ LogManagerConnectionEntity
    /// <summary>
    /// 관리자 접속 로그
    /// </summary>
    [Serializable]
    public class LogManagerConnectionEntity : LogActionManagerEntity
    {

        /// <summary>
        /// 계정
        /// </summary>
        public String vcManagerID { get; set; }

        /// <summary>
        /// 비밀번호
        /// </summary>
        public String vcPassword { get; set; }

        /// <summary>
        /// 접속결과(0:Empty, 1:인증완료, 2:없는계정, 3:비밀번호오류, 4:오류[Exception])
        /// </summary>
        public Int16 tiResult { get; set; }

        /// <summary>
        /// 상태(1:로그인, 2:로그아웃)
        /// </summary>
        public Int16 tiStatus { get; set; }

        public LogManagerConnectionEntity()
        {
            vcManagerID = String.Empty;
            vcPassword = String.Empty;
            tiResult = 0;
            tiStatus = 0;
        }
        ~LogManagerConnectionEntity()
        {
            vcManagerID = String.Empty;
            vcPassword = String.Empty;
            tiResult = 0;
            tiStatus = 0;
        }

    }
    #endregion


    #region // !++ LogPrivateBoardEntity
    /// <summary>
    /// 공지, 뉴스 등 게시판 로그
    /// </summary>
    [Serializable]
    public class LogPrivateBoardEntity : LogActionManagerEntity
    {

        /// <summary>
        /// 고유번호
        /// </summary>
        public Int64 biSeq { get; set; }

        /// <summary>
        /// 게시판타입(1:공지사항, 2:뉴스, 3:..)
        /// </summary>
        public Int16 tiBoardType { get; set; }

        /// <summary>
        /// 제목(언어ID)
        /// </summary>
        public String vcTitleKeyText { get; set; }

        /// <summary>
        /// 내용(언어ID)
        /// </summary>
        public String vcDescriptKeyText { get; set; }

        /// <summary>
        /// Main등록여부(1:노출안함, 2:노출)
        /// </summary>
        public Int16 tiMain { get; set; }

        public LogPrivateBoardEntity()
        {
            biSeq = 0;
            tiBoardType = 0;
            vcTitleKeyText = String.Empty;
            vcDescriptKeyText = String.Empty;
            tiMain = 0;
        }
        ~LogPrivateBoardEntity()
        {
            biSeq = 0;
            tiBoardType = 0;
            vcTitleKeyText = String.Empty;
            vcDescriptKeyText = String.Empty;
            tiMain = 0;
        }

    }
    #endregion


    #region // !++ LogPrivateBoardDataEntity
    /// <summary>
    /// 공지, 뉴스 등 게시판 데이터 로그
    /// </summary>
    [Serializable]
    public class LogPrivateBoardDataEntity : LogActionManagerEntity
    {

        /// <summary>
        /// 고유번호(AI)
        /// </summary>
        public Int64 biSeq { get; set; }

        /// <summary>
        /// 게시판고유번호
        /// </summary>
        public Int64 biPrivateBoardSeq { get; set; }

        /// <summary>
        /// 원본파일명
        /// </summary>
        public String vcFileName { get; set; }

        /// <summary>
        /// 저장경로
        /// </summary>
        public String vcSaveFolder { get; set; }

        /// <summary>
        /// 저장파일명
        /// </summary>
        public String vcSaveName { get; set; }

        /// <summary>
        /// 파일형식(확장자)
        /// </summary>
        public String vcSaveType { get; set; }

        /// <summary>
        /// 파일크기
        /// </summary>
        public Int32 iSaveSize { get; set; }

        public LogPrivateBoardDataEntity()
        {
            biSeq = 0;
            biPrivateBoardSeq = 0;
            vcFileName = String.Empty;
            vcSaveFolder = String.Empty;
            vcSaveName = String.Empty;
            vcSaveType = String.Empty;
            iSaveSize = 0;
        }
        ~LogPrivateBoardDataEntity()
        {
            biSeq = 0;
            biPrivateBoardSeq = 0;
            vcFileName = String.Empty;
            vcSaveFolder = String.Empty;
            vcSaveName = String.Empty;
            vcSaveType = String.Empty;
            iSaveSize = 0;
        }

    }
    #endregion


    #region // !++ LogCompanyGroupEntity
    /// <summary>
    /// 회사조직(분류) 로그
    /// </summary>
    [Serializable]
    public class LogCompanyGroupEntity : LogActionManagerEntity
    {

        /// <summary>
        /// 고유번호
        /// </summary>
        public Int32 iSeq { get; set; }

        /// <summary>
        /// 그룹명
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 그룹명(언어ID)
        /// </summary>
        public String vcNameKeyText { get; set; }

        /// <summary>
        /// 그룹약어(간단소개)
        /// </summary>
        public String vcAbbreviation { get; set; }

        /// <summary>
        /// 그룹약어(언어ID)
        /// </summary>
        public String vcAbbreviationKeyText { get; set; }

        public LogCompanyGroupEntity()
        {
            iSeq = 0;
            vcName = String.Empty;
            vcNameKeyText = String.Empty;
            vcAbbreviation = String.Empty;
            vcAbbreviationKeyText = String.Empty;
        }
        ~LogCompanyGroupEntity()
        {
            iSeq = 0;
            vcName = String.Empty;
            vcNameKeyText = String.Empty;
            vcAbbreviation = String.Empty;
            vcAbbreviationKeyText = String.Empty;
        }
    }
    #endregion


    #region // !++ LogCompanyPeopleEntity
    /// <summary>
    /// 회사조직구성원 로그
    /// </summary>
    [Serializable]
    public class LogCompanyPeopleEntity : LogActionManagerEntity
    {

        /// <summary>
        /// 고유번호
        /// </summary>
        public Int32 iSeq { get; set; }

        /// <summary>
        /// 회사조직고유번호
        /// </summary>
        public Int32 iCompanyGroupSeq { get; set; }

        /// <summary>
        /// 이름
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 직급
        /// </summary>
        public String vcPosition { get; set; }

        /// <summary>
        /// 내용
        /// </summary>
        public String tDescription { get; set; }

        /// <summary>
        /// 이미지경로
        /// </summary>
        public String vcFolder { get; set; }

        /// <summary>
        /// 이미지파일명
        /// </summary>
        public String vcImage { get; set; }

        public LogCompanyPeopleEntity()
        {
            iSeq = 0;
            iCompanyGroupSeq = 0;
            vcName = String.Empty;
            vcPosition = String.Empty;
            tDescription = String.Empty;
            vcFolder = String.Empty;
            vcImage = String.Empty;
        }
        ~LogCompanyPeopleEntity()
        {
            iSeq = 0;
            iCompanyGroupSeq = 0;
            vcName = String.Empty;
            vcPosition = String.Empty;
            tDescription = String.Empty;
            vcFolder = String.Empty;
            vcImage = String.Empty;
        }

    }
    #endregion


    #region // !++ LogBlogEntity
    /// <summary>
    /// 블로그 로그
    /// </summary>
    [Serializable]
    public class LogBlogEntity : LogActionManagerEntity
    {

        /// <summary>
        /// 고유번호
        /// </summary>
        public Int64 biSeq { get; set; }

        /// <summary>
        /// 제목
        /// </summary>
        public String vcTitle { get; set; }

        /// <summary>
        /// 제목이미지경로
        /// </summary>
        public String vcTitleFolder { get; set; }

        /// <summary>
        /// 제목이미지파일명
        /// </summary>
        public String vcTitleImage { get; set; }

        /// <summary>
        /// 내용
        /// </summary>
        public String tDescription { get; set; }

        public LogBlogEntity()
        {
            biSeq = 0;
            vcTitle = String.Empty;
            vcTitleFolder = String.Empty;
            vcTitleImage = String.Empty;
            tDescription = String.Empty;
        }
        ~LogBlogEntity()
        {
            biSeq = 0;
            vcTitle = String.Empty;
            vcTitleFolder = String.Empty;
            vcTitleImage = String.Empty;
            tDescription = String.Empty;
        }

    }
    #endregion


    #region // !++ LogBlogCommentEntity
    /// <summary>
    /// 블로그 댓글 로그
    /// </summary>
    [Serializable]
    public class LogBlogCommentEntity : LogActionManagerEntity
    {

        /// <summary>
        /// 고유번호
        /// </summary>
        public Int64 biSeq { get; set; }

        /// <summary>
        /// 블로그 고유번호
        /// </summary>
        public Int64 biBlogSeq { get; set; }

        /// <summary>
        /// 회원고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// 계정ID
        /// </summary>
        public String vcAccount { get; set; }

        /// <summary>
        /// 이름
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 내용
        /// </summary>
        public String tDescription { get; set; }

        public LogBlogCommentEntity()
        {
            biSeq = 0;
            biBlogSeq = 0;
            biMemberSeq = 0;
            vcAccount = String.Empty;
            vcName = String.Empty;
            tDescription = String.Empty;
        }
        ~LogBlogCommentEntity()
        {
            biSeq = 0;
            biBlogSeq = 0;
            biMemberSeq = 0;
            vcAccount = String.Empty;
            vcName = String.Empty;
            tDescription = String.Empty;
        }

    }
    #endregion


    #region // !++ LogBlogLikeEntity
    /// <summary>
    /// 블로그 좋아요 로그
    /// </summary>
    [Serializable]
    public class LogBlogLikeEntity : LogActionManagerEntity
    {

        /// <summary>
        /// 블로그 고유번호
        /// </summary>
        public Int64 biBlogSeq { get; set; }

        /// <summary>
        /// 회원고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// 계정ID
        /// </summary>
        public String vcAccount { get; set; }

        /// <summary>
        /// 이름
        /// </summary>
        public String vcName { get; set; }

        public LogBlogLikeEntity()
        {
            biBlogSeq = 0;
            biMemberSeq = 0;
            vcAccount = String.Empty;
            vcName = String.Empty;
        }
        ~LogBlogLikeEntity()
        {
            biBlogSeq = 0;
            biMemberSeq = 0;
            vcAccount = String.Empty;
            vcName = String.Empty;
        }

    }
    #endregion


    #region // !++ LogGoodsEntity
    /// <summary>
    /// 상품정보 로그
    /// </summary>
    [Serializable]
    public class LogGoodsEntity : LogActionManagerEntity
    {

        /// <summary>
        /// 고유번호
        /// </summary>
        public Int32 iSeq { get; set; }

        /// <summary>
        /// 상품명
        /// </summary>
        public String vcGoods { get; set; }

        /// <summary>
        /// 상품명(언어ID)
        /// </summary>
        public String vcKeyText { get; set; }

        public LogGoodsEntity()
        {
            iSeq = 0;
            vcGoods = String.Empty;
            vcKeyText = String.Empty;
        }
        ~LogGoodsEntity()
        {
            iSeq = 0;
            vcGoods = String.Empty;
            vcKeyText = String.Empty;
        }

    }
    #endregion

}
