﻿import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

import { TranslationLoaderService } from './service';

import { locale as localeEnglish } from './i18n/en';
import { locale as localeKorea } from './i18n/kr';


@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})

export class AppComponent
{
    constructor(private translate: TranslateService, private translationLoader: TranslationLoaderService, )
    {
        // Add languages
        this.translate.addLangs(['en', 'kr']);

        // Set the default language
        this.translate.setDefaultLang('kr');
        this.translationLoader.loadTranslations(localeEnglish, localeKorea);

        // Use a language
        this.translate.use('kr');
    }
}