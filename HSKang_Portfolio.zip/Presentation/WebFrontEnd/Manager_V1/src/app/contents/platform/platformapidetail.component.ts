import { Component, OnInit, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { FormGroup, FormBuilder, Validators, ValidationErrors } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { NgxSpinnerService } from "ngx-spinner";

import { CommonService, PlatFormService } from '../../service';
import { PlatFormModel, PlatFormApiModel } from '../../model';

@Component({ 
    selector: 'app-popup',
    templateUrl: './platformapidetail.component.html', 
    styleUrls: ['../scss/regEdit.component.scss']
})

export class PlatFormApiDetailComponent implements OnInit
{
    mSeq:number;
    mPlatFormApi:PlatFormApiModel = null;
    mPlatForm:PlatFormModel = null;

    constructor(private mService:PlatFormService,
                private cmnService:CommonService,
                private translate:TranslateService,
                private spinnerService:NgxSpinnerService,
                public dialogRef: MatDialogRef<PlatFormApiDetailComponent>, 
                @Inject(MAT_DIALOG_DATA) public data:any,
                private fb:FormBuilder){

        this.mSeq = (data.iSeq === null) ? -1 : data.iSeq;
    }

    ngOnInit():void
    {
        // PlatForm api 상세정보 호출
        this.onDetail(this.mSeq);
    }

    // PlatForm api 상세정보
    onDetail(mSeq:number):void
    {
        setTimeout(() => this.spinnerService.show(), 0);

        this.mService.getPlatFormApiDetail(mSeq).subscribe(
            detailData => {
                this.spinnerService.hide();
                this.mPlatFormApi = detailData.data;
                
                // PlatForm 상세정보 호출(FAQ 정보 셋팅 먼저)
                this.getPlatFormDetail(this.mPlatFormApi.iPlatFormSeq);
            },
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

    // popup close
    onClose(param:any):void{
        this.dialogRef.close(param);
    }

    // PlatForm 상세정보
    getPlatFormDetail(iSeq:number):void
    {
        setTimeout(() => this.spinnerService.show(), 0);

        this.mService.getPlatFormDetail(iSeq).subscribe(
            detailData => {
                this.spinnerService.hide();
                this.mPlatForm = detailData.data;
            },
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

}