import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ActivatedRoute } from '@angular/router';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { MemberService } from '../service';

@Component({
    selector: 'app-register-complete',
    templateUrl: './register.complete.component.html',
    styleUrls: ['./register.complete.component.scss']
})

export class RegisterCompleteComponent implements OnInit
{
    guide:SafeHtml;
    email:string;
    key:string;

    constructor(private translate:TranslateService,
                private route: ActivatedRoute,
                private sanitized: DomSanitizer,
                private memberService:MemberService){
    }

    ngOnInit() {
        // 라우트 파라미터 값의 취득
        this.route.queryParams
          .subscribe(params => {
                //this.email = params['email'];
                this.key = params['key'];

                this.memberService.approvalEmail(this.key).subscribe(
                    (res) => {
                        if(!res.success){
                            alert(res.msg);
                            this.memberService.logout();
                            return;
                        }

                        this.email = res.data.vcEmail;
                        let tmp = this.translate.instant('REGISTER.COMPLETED_GUIDE');
                        this.guide = this.sanitized.bypassSecurityTrustHtml(tmp.replace(/#/gi, `<span class='color'>${this.email}</span>`));
                    },
                    (err) => {console.log(err);}
                );
            }
        );
    }
}