﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.LogDB
{

    #region // !++ tbLogFAQCode
    /// <summary>
    /// LOG FAQCode
    /// </summary>
    [Table("tbLogFAQCode")]
    public class tbLogFAQCode
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        /// <summary>
        /// 파티션 키(월별)
        /// </summary>
        public Int32 iPartKeyMonth { get; set; }

        [Index(1), Required]
        /// <summary>
        /// 트랜잭션ID
        /// </summary>
        public Int64 biTXIDX { get; set; }

        [Index(2), Required]
        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        [Required]
        /// <summary>
        /// FAQ코드 고유번호
        /// </summary>
        public Int32 iSeq { get; set; }

        [Required]
        /// <summary>
        /// FAQ분류고유번호
        /// </summary>
        public Int32 iFaqCodeSeq { get; set; }

        [Required, MinLength(2), MaxLength(128)]
        /// <summary>
        /// 분류(제목)
        /// </summary>
        public String vcTitle { get; set; }

        [Required]
        /// <summary>
        /// 로그분류(1:등록, 2:수정, 3:삭제)
        /// </summary>
        public Int16 tiType { get; set; }

        /// <summary>
        /// IP
        /// </summary>
        public String vcIP { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// UTC등록일시
        /// </summary>
        public DateTime dtUtcRegDate { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
