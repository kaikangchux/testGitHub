export * from './list.component';
export * from './view.component';
export * from './regEdit.component';