﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Manager;
using Lib.Crawling.Library.DataContainers;
using Lib.Crawling.Library.Log;

namespace WebApi_SpiderKim_Manager_V1.Handlers
{

    #region // !++ ManagerHandler
    /// <summary>
    /// ManagerHandler
    /// </summary>
    public class ManagerHandler : Handler
    {

        #region // !++ GetManagerLogin (관리자 로그인)
        /// <summary>
        /// GetManagerLogin
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="managerEntity"></param>
        /// <returns></returns>
        public static async Task<ResultEntity<ManagerLoginEntity>> GetManagerLogin(DBConnectionEntity dbConnectionEntity, ManagerEntity managerEntity)
        {

            // Return value
            var resultDataContainer = new ResultEntity<ManagerLoginEntity>();

            try
            {

                var resultData = await bllManager.BLL_Manager_Login_Sel(dbConnectionEntity, managerEntity);
                if (resultData == null || resultData.result < 1)
                {
                    resultDataContainer.result = -99;
                }
                else
                {
                    // 로그인 struct 변경
                    var managerCookie = new ManagerLoginEntity()
                    {
                        adminSeq = resultData.gClass.iSeq,
                        adminId = resultData.gClass.vcManagerID,
                        adminName = resultData.gClass.vcName,
                        adminGrade = resultData.gClass.tiGrade,
                        isLogin = true
                    };
                    resultDataContainer.bresult = true;
                    resultDataContainer.result = resultData.result;
                    resultDataContainer.gClass = managerCookie;
                }

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetManagerLogin : \n [DBConnectionEntity:{0}], \n [ManagerEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(managerEntity), exc.Message, exc.StackTrace);

                return resultDataContainer;
            }

            return resultDataContainer;

        }
        #endregion


        #region // !++ GetManagerList (관리자 목록조회)
        /// <summary>
        /// 관리자 목록조회
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns></returns>
        public static async Task<ListPageDataContainer<List<ManagerEntity>>> GetManagerList(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<ManagerEntity>>();

            try
            {
                // DB호출
                resultDataContainer = await bllManager.BLL_Manager_Sel(dbConnectionEntity, pageDBEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetManagerList : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), exc.Message, exc.StackTrace);

                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ GetManagerInfo (관리자 상세정보)
        /// <summary>
        /// 관리자 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="managerEntity"></param>
        /// <returns></returns>
        public static async Task<ManagerEntity> GetManagerInfo(DBConnectionEntity dbConnectionEntity, ManagerEntity managerEntity)
        {

            var result = new ManagerEntity();

            try
            {
                result = await bllManager.BLL_Manager_Detail_Sel(dbConnectionEntity, managerEntity);
                if (result == null)
                {
                    result.vcManagerID = String.Empty;
                    result.vcName = String.Empty;
                    result.vcEmailID = String.Empty;
                    result.vcEmailAddress = String.Empty;
                    result.vcPhone = String.Empty;
                    result.tiGrade = 0;
                    result.dtRegDate = DateTime.MinValue;
                }
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetManagerInfo : \n [DBConnectionEntity:{0}], \n [ManagerEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(managerEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;
        }
        #endregion


        #region // !++ GetManagerIDCheck (관리자 계정 중복조회)
        /// <summary>
        /// 관리자 계정 중복조회
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="managerEntity"></param>
        /// <returns></returns>
        public static async Task<Int32> GetManagerIDCheck(DBConnectionEntity dbConnectionEntity, ManagerEntity managerEntity)
        {

            var result = 0;

            try
            {

                if (managerEntity.vcManagerID.Length < 4)
                {
                    return -1;
                }
                // 계정 소문자로 변경
                managerEntity.vcManagerID = managerEntity.vcManagerID.ToLower();
                // DB호출
                result = await bllManager.BLL_Manager_IDCheck_Sel(dbConnectionEntity, managerEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetManagerIDCheck : \n [DBConnectionEntity:{0}], \n [ManagerEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(managerEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


        #region // !++ SetManagerRegist (관리자 등록)
        /// <summary>
        /// 관리자 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="managerEntity"></param>
        /// <returns></returns>
        public static async Task<Int32> SetManagerRegist(DBConnectionEntity dbConnectionEntity, ManagerEntity managerEntity, ManagerLoginEntity managerLoginEntity)
        {

            var result = 0;

            try
            {
                result = await bllManager.BLL_Manager_Ins(dbConnectionEntity, managerEntity, managerLoginEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetManagerRegist : \n [DBConnectionEntity:{0}], \n [ManagerEntity:{1}], \n [ManagerLoginEntity:{2}], \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(managerEntity), libUtility.ToJson(managerLoginEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


        #region // !++ SetManagerInfoModify (관리자 개인정보 수정)
        /// <summary>
        /// 관리자 개인정보 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="managerEntity"></param>
        /// <returns></returns>
        public static async Task<Int32> SetManagerInfoModify(DBConnectionEntity dbConnectionEntity, ManagerEntity managerEntity)
        {

            var result = 0;

            try
            {
                result = await bllManager.BLL_Manager_Upd(dbConnectionEntity, managerEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetManagerInfoModify : \n [DBConnectionEntity:{0}], \n [ManagerEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(managerEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


        #region // !++ SetManagerGradeModify (관리자 권한 수정)
        /// <summary>
        /// 관리자 권한 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="managerEntity"></param>
        /// <param name="managerLoginEntity"></param>
        /// <returns></returns>
        public static async Task<Int32> SetManagerGradeModify(DBConnectionEntity dbConnectionEntity, ManagerEntity managerEntity, ManagerLoginEntity managerLoginEntity)
        {

            var result = 0;

            try
            {
                result = await bllManager.BLL_Manager_Grade_Upd(dbConnectionEntity, managerEntity, managerLoginEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetManagerGradeModify : \n [DBConnectionEntity:{0}], \n [ManagerEntity:{1}], \n [ManagerLoginEntity:{2}], \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(managerEntity), libUtility.ToJson(managerLoginEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


        #region // !++ SetManagerDelete (관리자 삭제)
        /// <summary>
        /// 관리자 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="managerEntity"></param>
        /// <returns></returns>
        public static async Task<Int32> SetManagerDelete(DBConnectionEntity dbConnectionEntity, ManagerEntity managerEntity, ManagerLoginEntity managerLoginEntity)
        {

            var result = 0;

            try
            {
                result = await bllManager.BLL_Manager_Del(dbConnectionEntity, managerEntity, managerLoginEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetManagerDelete : \n [DBConnectionEntity:{0}], \n [ManagerEntity:{1}], \n [ManagerLoginEntity:{2}], \n {3}, \n {4}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(managerEntity), libUtility.ToJson(managerLoginEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion

    }
    #endregion

}
