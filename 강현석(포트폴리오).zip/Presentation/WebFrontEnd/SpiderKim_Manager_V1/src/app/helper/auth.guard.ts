import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { ManagerService } from '../service/manager.service';

@Injectable({providedIn: 'root'})

export class AuthGuard implements CanActivate
{
    constructor(private router: Router, 
                private mService:ManagerService){ }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot)
    {
        if(this.mService.getLoginMUserInfo()){
            return true;
        }

        this.router.navigate(['']);
        return false;
    }
}