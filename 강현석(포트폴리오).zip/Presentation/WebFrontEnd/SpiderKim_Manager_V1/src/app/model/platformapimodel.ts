// 플랫폼API정보
export class PlatFormApiModel
{

  iSeq: number;
  iPlatFormSeq: number;
  vcApiUrl: string;
  vcID: string;
  vcVerifyKey: string;
  tiStatus: number;
  iManagerSeq: number;
  dtRegDate: string;

  constructor() {
    this.iSeq = 0;
    this.iPlatFormSeq = 0;
    this.vcApiUrl = '';
    this.vcID = '';
    this.vcVerifyKey = '';
    this.tiStatus = 0;
    this.iManagerSeq = 0;
    this.dtRegDate = '';
  }
}
