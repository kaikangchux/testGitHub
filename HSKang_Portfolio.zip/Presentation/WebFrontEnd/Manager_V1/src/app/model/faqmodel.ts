// FAQ
export class FaqModel
{

  iSeq: number;
  iFaqCodeSeq: number;
  vcTitleKeyText: string;
  vcDescriptKeyText: string;
  tiMain: number;
  iManagerSeq: number;
  dtRegDate: string;

  constructor() {
    this.iSeq = 0;
    this.iFaqCodeSeq = 0;
    this.vcTitleKeyText = '';
    this.vcDescriptKeyText = '';
    this.tiMain = 0;
    this.iManagerSeq = 0;
    this.dtRegDate = '';
  }
}
