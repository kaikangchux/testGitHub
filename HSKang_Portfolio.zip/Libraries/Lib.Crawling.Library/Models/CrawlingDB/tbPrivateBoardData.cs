﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.CrawlingDB
{

    #region // !++ tbPrivateBoardData
    /// <summary>
    /// tbPrivateBoardData
    /// </summary>
    [Table("tbPrivateBoardData")]
    public class tbPrivateBoardData
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        /// <summary>
        /// 고유번호(AI)
        /// </summary>
        public Int64 biSeq { get; set; }

        [Key, Required]
        /// <summary>
        /// 게시판고유번호
        /// </summary>
        public Int64 biPrivateBoardSeq { get; set; }

        [Required, MinLength(2), MaxLength(32)]
        /// <summary>
        /// 원본파일명
        /// </summary>
        public String vcFileName { get; set; }

        [Required, MinLength(2), MaxLength(128)]
        /// <summary>
        /// 저장경로
        /// </summary>
        public String vcSaveFolder { get; set; }

        [Required, MinLength(2), MaxLength(32)]
        /// <summary>
        /// 저장파일명
        /// </summary>
        public String vcSaveName { get; set; }

        [Required, MinLength(2), MaxLength(8)]
        /// <summary>
        /// 파일형식(확장자)
        /// </summary>
        public String vcSaveType { get; set; }

        /// <summary>
        /// 파일크기
        /// </summary>
        public Int32 iSaveSize { get; set; }

        /// <summary>
        /// 다운로드 수
        /// </summary>
        public Int32 iDownLoad { get; set; }

        /// <summary>
        /// 관리자고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
