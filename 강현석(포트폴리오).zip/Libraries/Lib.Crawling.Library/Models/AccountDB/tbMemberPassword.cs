﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.AccountDB
{

    #region // !++ tbMemberPassword
    /// <summary>
    /// tbMemberPassword (회원비밀번호)
    /// </summary>
    [Table("tbMemberPassword")]
    public class tbMemberPassword
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        /// <summary>
        /// 회원고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        [Required, MinLength(4), MaxLength(64)]
        /// <summary>
        /// 비밀번호(Hash암호화)
        /// </summary>
        public String vcPassword { get; set; }

        [Index(1), Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 최근접속일시
        /// </summary>
        public DateTime dtLoginDate { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 정보수정일
        /// </summary>
        public DateTime dtModifyDate { get; set; }

    }
    #endregion

}
