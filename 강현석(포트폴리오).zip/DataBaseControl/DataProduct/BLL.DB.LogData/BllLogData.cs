﻿using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Data;

using Lib.Crawling.Library.Enum;
using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.LogDB;
using Lib.Crawling.Library.DataContainers;
using Lib.Crawling.Library.Log;
using Lib.Crawling.Library.Models.LogDB;

namespace BLL.DB.LogData
{

    #region // !+ BllLogData
    /// <summary>
    /// BllLogData
    /// </summary>
    public class BllLogData : DataProvider.DataProvider
    {

        #region // !++ BLL_LogFAQCode_Ins (FAQ코드 로그 등록)
        /// <summary>
        /// FAQ코드 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="logFAQCodeEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task BLL_LogFAQCode_Ins(DBConnectionEntity dbConnectionEntity, LogFAQCodeEntity logFAQCodeEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLogFAQCode()
                {
                    biTXIDX = logFAQCodeEntity.biTXIDX,
                    iManagerSeq = logFAQCodeEntity.iManagerSeq,
                    iSeq = logFAQCodeEntity.iSeq,
                    vcTitle = logFAQCodeEntity.vcTitle,
                    tiType = (Int16)logFAQCodeEntity.tiType,
                    vcIP = logFAQCodeEntity.vcIP
                };
                #endregion
                result = await dalLogData.DAL_LogFAQCode_Ins(dbConnectionEntity, dbData);

                // DAL_LogFAQCode_Ins 확인
                if (result.result < 1)
                {
                    // DAL_LogFAQCode_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_LogFAQCode_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LogFAQCode_Ins : \n [DBConnectionEntity:{0}], \n [LogFAQCodeEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(logFAQCodeEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
            }
        }
        #endregion


        #region // !++ BLL_LogFAQ_Ins (FAQ 로그 등록)
        /// <summary>
        /// FAQ 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="logFAQEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task BLL_LogFAQ_Ins(DBConnectionEntity dbConnectionEntity, LogFAQEntity logFAQEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLogFAQ()
                {
                    biTXIDX = logFAQEntity.biTXIDX,
                    iManagerSeq = logFAQEntity.iManagerSeq,
                    iSeq = logFAQEntity.iSeq,
                    iFaqCodeSeq = logFAQEntity.iFaqCodeSeq,
                    vcTitleKeyText = logFAQEntity.vcTitleKeyText,
                    vcDescriptKeyText = logFAQEntity.vcDescriptKeyText,
                    tiMain = logFAQEntity.tiMain,
                    tiType = (Int16)logFAQEntity.tiType,
                    vcIP = logFAQEntity.vcIP
                };
                #endregion
                result = await dalLogData.DAL_LogFAQ_Ins(dbConnectionEntity, dbData);

                // DAL_LogFAQ_Ins 확인
                if (result.result < 1)
                {
                    // DAL_LogFAQ_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_LogFAQ_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LogFAQ_Ins : \n [DBConnectionEntity:{0}], \n [LogFAQEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(logFAQEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
            }
        }
        #endregion


        #region // !++ BLL_LogPlatForm_Ins (플랫폼정보 로그 등록)
        /// <summary>
        /// 플랫폼정보 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="logPlatFormEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task BLL_LogPlatForm_Ins(DBConnectionEntity dbConnectionEntity, LogPlatFormEntity logPlatFormEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLogPlatForm()
                {
                    biTXIDX = logPlatFormEntity.biTXIDX,
                    iManagerSeq = logPlatFormEntity.iManagerSeq,
                    iSeq = logPlatFormEntity.iSeq,
                    vcName = logPlatFormEntity.vcName,
                    vcKeyText = logPlatFormEntity.vcKeyText,
                    vcKeyImage = logPlatFormEntity.vcKeyImage,
                    tiStatus = logPlatFormEntity.tiStatus,
                    tiType = (Int16)logPlatFormEntity.tiType,
                    vcIP = logPlatFormEntity.vcIP
                };
                #endregion
                result = await dalLogData.DAL_LogPlatForm_Ins(dbConnectionEntity, dbData);

                // DAL_LogPlatForm_Ins 확인
                if (result.result < 1)
                {
                    // DAL_LogPlatForm_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_LogPlatForm_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LogPlatForm_Ins : \n [DBConnectionEntity:{0}], \n [LogPlatFormEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(logPlatFormEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
            }
        }
        #endregion


        #region // !++ BLL_LogPlatFormApi_Ins (플랫폼API정보 로그 등록)
        /// <summary>
        /// 플랫폼API정보 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="logPlatFormApiEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task BLL_LogPlatFormApi_Ins(DBConnectionEntity dbConnectionEntity, LogPlatFormApiEntity logPlatFormApiEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLogPlatFormApi()
                {
                    biTXIDX = logPlatFormApiEntity.biTXIDX,
                    iManagerSeq = logPlatFormApiEntity.iManagerSeq,
                    iSeq = logPlatFormApiEntity.iSeq,
                    iPlatFormSeq = logPlatFormApiEntity.iPlatFormSeq,
                    vcApiUrl = logPlatFormApiEntity.vcApiUrl,
                    vcID = logPlatFormApiEntity.vcID,
                    vcVerifyKey = logPlatFormApiEntity.vcVerifyKey,
                    tiStatus = logPlatFormApiEntity.tiStatus,
                    tiType = (Int16)logPlatFormApiEntity.tiType,
                    vcIP = logPlatFormApiEntity.vcIP
                };
                #endregion
                result = await dalLogData.DAL_LogPlatFormApi_Ins(dbConnectionEntity, dbData);

                // DAL_LogPlatFormApi_Ins 확인
                if (result.result < 1)
                {
                    // DAL_LogPlatFormApi_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_LogPlatFormApi_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LogPlatFormApi_Ins : \n [DBConnectionEntity:{0}], \n [LogPlatFormApiEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(logPlatFormApiEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
            }
        }
        #endregion


        #region // !++ BLL_LogLanguageCode_Ins (언어[다국어]코드 로그 등록)
        /// <summary>
        /// 언어[다국어]코드 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="logLanguageCodeEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task BLL_LogLanguageCode_Ins(DBConnectionEntity dbConnectionEntity, LogLanguageCodeEntity logLanguageCodeEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLogLanguageCode()
                {
                    biTXIDX = logLanguageCodeEntity.biTXIDX,
                    iManagerSeq = logLanguageCodeEntity.iManagerSeq,
                    vcLanguageCode = logLanguageCodeEntity.vcLanguageCode,
                    vcLanguageName = logLanguageCodeEntity.vcLanguageName,
                    tiStatus = logLanguageCodeEntity.tiStatus,
                    tiType = (Int16)logLanguageCodeEntity.tiType,
                    vcIP = logLanguageCodeEntity.vcIP
                };
                #endregion
                result = await dalLogData.DAL_LogLanguageCode_Ins(dbConnectionEntity, dbData);

                // DAL_LogLanguageCode_Ins 확인
                if (result.result < 1)
                {
                    // DAL_LogLanguageCode_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_LogLanguageCode_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LogLanguageCode_Ins : \n [DBConnectionEntity:{0}], \n [LogLanguageCodeEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(logLanguageCodeEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
            }
        }
        #endregion


        #region // !++ BLL_LogLanguage_Ins (언어[다국어] 로그 등록)
        /// <summary>
        /// 언어[다국어] 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="logLanguageEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task BLL_LogLanguage_Ins(DBConnectionEntity dbConnectionEntity, LogLanguageEntity logLanguageEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLogLanguage()
                {
                    biTXIDX = logLanguageEntity.biTXIDX,
                    iManagerSeq = logLanguageEntity.iManagerSeq,
                    vcLanguageCode = logLanguageEntity.vcLanguageCode,
                    vcKeyText = logLanguageEntity.vcKeyText,
                    tiAbbreviated = logLanguageEntity.tiAbbreviated,
                    vcText = logLanguageEntity.vcText,
                    tiStatus = logLanguageEntity.tiStatus,
                    tiType = (Int16)logLanguageEntity.tiType,
                    vcIP = logLanguageEntity.vcIP
                };
                #endregion
                result = await dalLogData.DAL_LogLanguage_Ins(dbConnectionEntity, dbData);

                // DAL_LogLanguage_Ins 확인
                if (result.result < 1)
                {
                    // DAL_LogLanguage_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_LogLanguage_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LogLanguage_Ins : \n [DBConnectionEntity:{0}], \n [LogLanguageEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(logLanguageEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
            }
        }
        #endregion


        #region // !++ BLL_LogLanguageImage_Ins (언어[다국어]이미지 로그 등록)
        /// <summary>
        /// 언어[다국어]이미지 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="logLanguageImageEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task BLL_LogLanguageImage_Ins(DBConnectionEntity dbConnectionEntity, LogLanguageImageEntity logLanguageImageEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLogLanguageImage()
                {
                    biTXIDX = logLanguageImageEntity.biTXIDX,
                    iManagerSeq = logLanguageImageEntity.iManagerSeq,
                    vcLanguageCode = logLanguageImageEntity.vcLanguageCode,
                    vcKeyImage = logLanguageImageEntity.vcKeyImage,
                    vcUrl = logLanguageImageEntity.vcUrl,
                    vcImage = logLanguageImageEntity.vcImage,
                    tiStatus = logLanguageImageEntity.tiStatus,
                    tiType = (Int16)logLanguageImageEntity.tiType,
                    vcIP = logLanguageImageEntity.vcIP
                };
                #endregion
                result = await dalLogData.DAL_LogLanguageImage_Ins(dbConnectionEntity, dbData);

                // DAL_LogLanguageImage_Ins 확인
                if (result.result < 1)
                {
                    // DAL_LogLanguageImage_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_LogLanguageImage_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LogLanguageImage_Ins : \n [DBConnectionEntity:{0}], \n [LogLanguageImageEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(logLanguageImageEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
            }
        }
        #endregion


        #region // !++ BLL_LogProhibitWords_Ins (금지어 로그 등록)
        /// <summary>
        /// 금지어 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="logProhibitWordsEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task BLL_LogProhibitWords_Ins(DBConnectionEntity dbConnectionEntity, LogProhibitWordsEntity logProhibitWordsEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLogProhibitWords()
                {
                    biTXIDX = logProhibitWordsEntity.biTXIDX,
                    iManagerSeq = logProhibitWordsEntity.iManagerSeq,
                    vcProhibitWords = logProhibitWordsEntity.vcProhibitWords,
                    vcNote = logProhibitWordsEntity.vcNote,
                    tiStatus = logProhibitWordsEntity.tiStatus,
                    tiType = (Int16)logProhibitWordsEntity.tiType,
                    vcIP = logProhibitWordsEntity.vcIP
                };
                #endregion
                result = await dalLogData.DAL_LogProhibitWords_Ins(dbConnectionEntity, dbData);

                // DAL_LogProhibitWords_Ins 확인
                if (result.result < 1)
                {
                    // DAL_LogProhibitWords_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_LogProhibitWords_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LogProhibitWords_Ins : \n [DBConnectionEntity:{0}], \n [LogProhibitWordsEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(logProhibitWordsEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
            }
        }
        #endregion


        #region // !++ BLL_LogManager_Ins (관리자 등록및수정 로그 등록)
        /// <summary>
        /// 관리자 등록및수정 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="logManagerEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task BLL_LogManager_Ins(DBConnectionEntity dbConnectionEntity, LogManagerEntity logManagerEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLogManager()
                {
                    biTXIDX = logManagerEntity.biTXIDX,
                    iSeq = logManagerEntity.iSeq,
                    vcManagerID = logManagerEntity.vcManagerID,
                    vcName = logManagerEntity.vcName,
                    vcPassword = logManagerEntity.vcPassword,
                    vcEmailID = logManagerEntity.vcEmailID,
                    vcEmailAddress = logManagerEntity.vcEmailAddress,
                    vcPhone = logManagerEntity.vcPhone,
                    tiGrade = logManagerEntity.tiGrade,
                    iManagerSeq = logManagerEntity.iManagerSeq,
                    tiType = (Int16)logManagerEntity.tiType,
                    vcIP = logManagerEntity.vcIP
                };
                #endregion
                result = await dalLogData.DAL_LogManager_Ins(dbConnectionEntity, dbData);

                // DAL_LogManager_Ins 확인
                if (result.result < 1)
                {
                    // DAL_LogManager_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_LogManager_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LogManager_Ins : \n [DBConnectionEntity:{0}], \n [LogManagerEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(logManagerEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
            }
        }
        #endregion


        #region // !++ BLL_LogManagerConnection_Ins (관리자 접속 로그 등록)
        /// <summary>
        /// 관리자 접속 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="logManagerConnectionEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task BLL_LogManagerConnection_Ins(DBConnectionEntity dbConnectionEntity, LogManagerConnectionEntity logManagerConnectionEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLogManagerConnection()
                {
                    biTXIDX = logManagerConnectionEntity.biTXIDX,
                    iManagerSeq = logManagerConnectionEntity.iManagerSeq,
                    vcManagerID = logManagerConnectionEntity.vcManagerID,
                    vcPassword = logManagerConnectionEntity.vcPassword,
                    tiResult = logManagerConnectionEntity.tiResult,
                    tiStatus = logManagerConnectionEntity.tiStatus,
                    tiType = (Int16)logManagerConnectionEntity.tiType,
                    vcIP = logManagerConnectionEntity.vcIP
                };
                #endregion
                result = await dalLogData.DAL_LogManagerConnection_Ins(dbConnectionEntity, dbData);

                // DAL_LogManagerConnection_Ins 확인
                if (result.result < 1)
                {
                    // DAL_LogManagerConnection_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_LogManagerConnection_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LogManagerConnection_Ins : \n [DBConnectionEntity:{0}], \n [LogManagerConnectionEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(logManagerConnectionEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
            }
        }
        #endregion


        #region // !++ BLL_LogPrivateBoard_Ins (공지, 뉴스 등 게시판 로그 등록)
        /// <summary>
        /// 공지, 뉴스 등 게시판 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="logPrivateBoardEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task BLL_LogPrivateBoard_Ins(DBConnectionEntity dbConnectionEntity, LogPrivateBoardEntity logPrivateBoardEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLogPrivateBoard()
                {
                    biTXIDX = logPrivateBoardEntity.biTXIDX,
                    iManagerSeq = logPrivateBoardEntity.iManagerSeq,
                    biSeq = logPrivateBoardEntity.biSeq,
                    tiBoardType = logPrivateBoardEntity.tiBoardType,
                    vcTitleKeyText = logPrivateBoardEntity.vcTitleKeyText,
                    vcDescriptKeyText = logPrivateBoardEntity.vcDescriptKeyText,
                    tiMain = logPrivateBoardEntity.tiMain,
                    tiType = (Int16)logPrivateBoardEntity.tiType,
                    vcIP = logPrivateBoardEntity.vcIP
                };
                #endregion
                result = await dalLogData.DAL_LogPrivateBoard_Ins(dbConnectionEntity, dbData);

                // DAL_LogPrivateBoard_Ins 확인
                if (result.result < 1)
                {
                    // DAL_LogPrivateBoard_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_LogPrivateBoard_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LogPrivateBoard_Ins : \n [DBConnectionEntity:{0}], \n [LogPrivateBoardEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(logPrivateBoardEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
            }
        }
        #endregion


        #region // !++ BLL_LogPrivateBoardData_Ins (공지, 뉴스 등 게시판 데이터 로그 등록)
        /// <summary>
        /// 공지, 뉴스 등 게시판 데이터 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="logPrivateBoardDataEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task BLL_LogPrivateBoardData_Ins(DBConnectionEntity dbConnectionEntity, LogPrivateBoardDataEntity logPrivateBoardDataEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLogPrivateBoardData()
                {
                    biTXIDX = logPrivateBoardDataEntity.biTXIDX,
                    iManagerSeq = logPrivateBoardDataEntity.iManagerSeq,
                    biSeq = logPrivateBoardDataEntity.biSeq,
                    biPrivateBoardSeq = logPrivateBoardDataEntity.biPrivateBoardSeq,
                    vcFileName = logPrivateBoardDataEntity.vcFileName,
                    vcSaveFolder = logPrivateBoardDataEntity.vcSaveFolder,
                    vcSaveName = logPrivateBoardDataEntity.vcSaveName,
                    vcSaveType = logPrivateBoardDataEntity.vcSaveType,
                    iSaveSize = logPrivateBoardDataEntity.iSaveSize,
                    tiType = (Int16)logPrivateBoardDataEntity.tiType,
                    vcIP = logPrivateBoardDataEntity.vcIP
                };
                #endregion
                result = await dalLogData.DAL_LogPrivateBoardData_Ins(dbConnectionEntity, dbData);

                // DAL_LogPrivateBoardData_Ins 확인
                if (result.result < 1)
                {
                    // DAL_LogPrivateBoardData_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_LogPrivateBoardData_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LogPrivateBoardData_Ins : \n [DBConnectionEntity:{0}], \n [LogPrivateBoardDataEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(logPrivateBoardDataEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
            }
        }
        #endregion


        #region // !++ BLL_LogCompanyGroup_Ins (회사조직[분류] 로그 등록)
        /// <summary>
        /// 회사조직[분류] 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="logCompanyGroupEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task BLL_LogCompanyGroup_Ins(DBConnectionEntity dbConnectionEntity, LogCompanyGroupEntity logCompanyGroupEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLogCompanyGroup()
                {
                    biTXIDX = logCompanyGroupEntity.biTXIDX,
                    iManagerSeq = logCompanyGroupEntity.iManagerSeq,
                    iSeq = logCompanyGroupEntity.iSeq,
                    vcName = logCompanyGroupEntity.vcName,
                    vcNameKeyText = logCompanyGroupEntity.vcNameKeyText,
                    vcAbbreviation = logCompanyGroupEntity.vcAbbreviation,
                    vcAbbreviationKeyText = logCompanyGroupEntity.vcAbbreviationKeyText,
                    tiType = (Int16)logCompanyGroupEntity.tiType,
                    vcIP = logCompanyGroupEntity.vcIP
                };
                #endregion
                result = await dalLogData.DAL_LogCompanyGroup_Ins(dbConnectionEntity, dbData);

                // DAL_LogCompanyGroup_Ins 확인
                if (result.result < 1)
                {
                    // DAL_LogCompanyGroup_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_LogCompanyGroup_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LogCompanyGroup_Ins : \n [DBConnectionEntity:{0}], \n [LogCompanyGroupEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(logCompanyGroupEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
            }
        }
        #endregion


        #region // !++ BLL_LogCompanyPeople_Ins (회사조직구성원 로그 등록)
        /// <summary>
        /// 회사조직구성원 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="logCompanyPeopleEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task BLL_LogCompanyPeople_Ins(DBConnectionEntity dbConnectionEntity, LogCompanyPeopleEntity logCompanyPeopleEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLogCompanyPeople()
                {
                    biTXIDX = logCompanyPeopleEntity.biTXIDX,
                    iManagerSeq = logCompanyPeopleEntity.iManagerSeq,
                    iSeq = logCompanyPeopleEntity.iSeq,
                    iCompanyGroupSeq = logCompanyPeopleEntity.iCompanyGroupSeq,
                    vcName = logCompanyPeopleEntity.vcName,
                    vcPosition = logCompanyPeopleEntity.vcPosition,
                    tDescription = logCompanyPeopleEntity.tDescription,
                    vcFolder = logCompanyPeopleEntity.vcFolder,
                    vcImage = logCompanyPeopleEntity.vcImage,
                    tiType = (Int16)logCompanyPeopleEntity.tiType,
                    vcIP = logCompanyPeopleEntity.vcIP
                };
                #endregion
                result = await dalLogData.DAL_LogCompanyPeople_Ins(dbConnectionEntity, dbData);

                // DAL_LogCompanyPeople_Ins 확인
                if (result.result < 1)
                {
                    // DAL_LogCompanyPeople_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_LogCompanyPeople_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LogCompanyPeople_Ins : \n [DBConnectionEntity:{0}], \n [LogCompanyPeopleEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(logCompanyPeopleEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
            }
        }
        #endregion


        #region // !++ BLL_LogBlog_Ins (블로그 로그 등록)
        /// <summary>
        /// 블로그 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="logBlogEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task BLL_LogBlog_Ins(DBConnectionEntity dbConnectionEntity, LogBlogEntity logBlogEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLogBlog()
                {
                    biTXIDX = logBlogEntity.biTXIDX,
                    iManagerSeq = logBlogEntity.iManagerSeq,
                    biSeq = logBlogEntity.biSeq,
                    vcTitle = logBlogEntity.vcTitle,
                    vcTitleFolder = logBlogEntity.vcTitleFolder,
                    vcTitleImage = logBlogEntity.vcTitleImage,
                    tDescription = logBlogEntity.tDescription,
                    tiType = (Int16)logBlogEntity.tiType,
                    vcIP = logBlogEntity.vcIP
                };
                #endregion
                result = await dalLogData.DAL_LogBlog_Ins(dbConnectionEntity, dbData);

                // DAL_LogBlog_Ins 확인
                if (result.result < 1)
                {
                    // DAL_LogBlog_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_LogBlog_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LogBlog_Ins : \n [DBConnectionEntity:{0}], \n [LogBlogEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(logBlogEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
            }
        }
        #endregion


        #region // !++ BLL_LogBlogComment_Ins (블로그 댓글 로그 등록)
        /// <summary>
        /// 블로그 댓글 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="logBlogCommentEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task BLL_LogBlogComment_Ins(DBConnectionEntity dbConnectionEntity, LogBlogCommentEntity logBlogCommentEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLogBlogComment()
                {
                    biTXIDX = logBlogCommentEntity.biTXIDX,
                    iManagerSeq = logBlogCommentEntity.iManagerSeq,
                    biSeq = logBlogCommentEntity.biSeq,
                    biBlogSeq = logBlogCommentEntity.biBlogSeq,
                    biMemberSeq = logBlogCommentEntity.biMemberSeq,
                    vcAccount = logBlogCommentEntity.vcAccount,
                    vcName = logBlogCommentEntity.vcName,
                    tDescription = logBlogCommentEntity.tDescription,
                    tiType = (Int16)logBlogCommentEntity.tiType,
                    vcIP = logBlogCommentEntity.vcIP
                };
                #endregion
                result = await dalLogData.DAL_LogBlogComment_Ins(dbConnectionEntity, dbData);

                // DAL_LogBlogComment_Ins 확인
                if (result.result < 1)
                {
                    // DAL_LogBlogComment_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_LogBlogComment_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LogBlogComment_Ins : \n [DBConnectionEntity:{0}], \n [LogBlogCommentEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(logBlogCommentEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
            }
        }
        #endregion


        #region // !++ BLL_LogBlogLike_Ins (블로그 좋아요 로그 등록)
        /// <summary>
        /// 블로그 좋아요 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="logBlogLikeEntity"></param>
        /// <returns>
        /// Success_DB_Normal            ( 1): 성공,
        /// Error_DB_Exception           (-2): 예외 발생,
        /// Error_DB_NoData              (-4): 데이터 없음,
        /// Error_DB_AlreadyUsing        (-5): 이미 사용중,
        /// Error_DB_TransactionRollback (-6): 트랜젝션 롤백
        /// </returns>
        public async Task BLL_LogBlogLike_Ins(DBConnectionEntity dbConnectionEntity, LogBlogLikeEntity logBlogLikeEntity)
        {
            var result = new ResultEntity<Int32>();
            EResultCode eResultCode = 0;

            try
            {
                #region // !++ 데이터 Struct 변경
                var dbData = new tbLogBlogLike()
                {
                    biTXIDX = logBlogLikeEntity.biTXIDX,
                    iManagerSeq = logBlogLikeEntity.iManagerSeq,
                    biBlogSeq = logBlogLikeEntity.biBlogSeq,
                    biMemberSeq = logBlogLikeEntity.biMemberSeq,
                    vcAccount = logBlogLikeEntity.vcAccount,
                    vcName = logBlogLikeEntity.vcName,
                    tiType = (Int16)logBlogLikeEntity.tiType,
                    vcIP = logBlogLikeEntity.vcIP
                };
                #endregion
                result = await dalLogData.DAL_LogBlogLike_Ins(dbConnectionEntity, dbData);

                // DAL_LogBlogLike_Ins 확인
                if (result.result < 1)
                {
                    // DAL_LogBlogLike_Ins 실패. 오류 발생!
                    eResultCode = (EResultCode)result.result;
                    result.ErrorMsg = eResultCode.ToString();
                }
            }
            catch (Exception exc)
            {
                // DAL_LogBlogLike_Ins 실패. 오류 발생!
                Logger.Log(ELogType.Fatal, "BLL_LogBlogLike_Ins : \n [DBConnectionEntity:{0}], \n [LogBlogLikeEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(logBlogLikeEntity), exc.Message, exc.StackTrace);
                result.result = (Int32)EResultCode.Error_DB_Exception;
            }
        }
        #endregion


    }
    #endregion

}
