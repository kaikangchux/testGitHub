﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using BLL.DB.Manager;
using BLL.DB.Account;
using BLL.DB.Crawling;

using Lib.Crawling.Library.Utilities;

namespace WebApi_SpiderKim_Manager_V1.Handlers
{

    #region // !++ Handler
    /// <summary>
    /// Handler
    /// </summary>
    public class Handler
    {

        #region // !++ Utility
        /// <summary>
        /// LibUtility
        /// </summary>
        protected static LibUtility libUtility = new LibUtility();

        /// <summary>
        /// BulkUtility
        /// </summary>
        protected static BulkUtility bulkUtility = new BulkUtility();

        /// <summary>
        /// KeyGenerator
        /// </summary>
        protected static KeyGenerator keyGenerator = new KeyGenerator();

        /// <summary>
        /// Security
        /// </summary>
        protected static Security security = new Security();

        /// <summary>
        /// HashWord
        /// </summary>
        protected static HashWord hashWord = new HashWord();
        #endregion


        #region // !++ BLL.DB
        /// <summary>
        /// BllManager
        /// </summary>
        protected static BllManager bllManager = new BllManager();

        /// <summary>
        /// BllAccount
        /// </summary>
        protected static BllAccount bllAccount = new BllAccount();

        /// <summary>
        /// BllCrawling
        /// </summary>
        protected static BllCrawling bllCrawling = new BllCrawling();

        /// <summary>
        /// DataBaseStaticInfo
        /// </summary>
        protected static DataBaseStaticInfo dbStaticInfo = new DataBaseStaticInfo();
        #endregion

    }
    #endregion

}
