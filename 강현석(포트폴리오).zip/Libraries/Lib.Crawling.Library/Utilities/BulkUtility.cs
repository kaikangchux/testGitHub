﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Data;

using MySql.Data.MySqlClient;

using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Log;

namespace Lib.Crawling.Library.Utilities
{

    #region // !++ BulkUtility
    /// <summary>
    /// 
    /// </summary>
    public class BulkUtility
    {

        /// <summary>
        /// 
        /// </summary>
        private static LibUtility libUtility = new LibUtility();


        #region CSV 데이터 DB BulkCopy
        /// <summary>
        /// CSV 데이터 DB BulkCopy
        /// </summary>
        /// <param name="bulkCopyExcelEntity">BulkCopy 정보</param>
        /// <param name="dtExcelTable">엑셀데이터</param>
        /// <param name="dbConnection">DB Connection</param>
        /// <returns></returns>
        public async Task<Int32> MySqlExcelBulkCopy(BulkCopyExcelEntity bulkCopyExcelEntity, DataTable dtExcelTable, String dbConnection)
        {

            try
            {
                // Excel 파일 생성
                using (var dt = dtExcelTable)
                {
                    if (dt.Rows.Count == 0)
                    {
                        bulkCopyExcelEntity.bulkCopyResult = -1; // 정보없음
                        return bulkCopyExcelEntity.bulkCopyResult;
                    }
                    else
                    {
                        using (var fs = File.Create(bulkCopyExcelEntity.bulkCopyFileName))
                        {
                            using (var sw = new StreamWriter(fs, Encoding.UTF8))
                            {
                                libUtility.WriteToStream(sw, dtExcelTable, true, false);
                            }
                        }
                    }
                }

                // Bulkcopy
                using (var connection = new MySqlConnection(dbConnection))
                {
                    var bulkCopy = new MySqlBulkLoader(connection)
                    {
                        TableName = bulkCopyExcelEntity.bulkCopyTableName,
                        FieldTerminator = bulkCopyExcelEntity.bulkCopyFieldTerminator,
                        LineTerminator = bulkCopyExcelEntity.bulkCopyLineTerminator,
                        FileName = bulkCopyExcelEntity.bulkCopyFileName,
                        CharacterSet = bulkCopyExcelEntity.bulkCopyCharacterSet,
                        NumberOfLinesToSkip = bulkCopyExcelEntity.bulkCopyNumberOfLinesToSkip
                    };
                    bulkCopyExcelEntity.bulkCopyResult = bulkCopy.Load();

                    await connection.OpenAsync();
                    await connection.CloseAsync();
                    if (bulkCopyExcelEntity.bulkCopyResult >= 0)
                        bulkCopyExcelEntity.bulkCopyResult = 1;
                }
            }
            catch (Exception exc)
            {
                // string ErrMsg = exc.Message;
                Logger.Log(ELogType.Fatal, "MySqlExcelBulkCopy : \n [BulkCopyExcelEntity:{0}], \n [DataTable:{1}], \n [DBConnection:{2}], \n {3}, \n {4}",
                                        libUtility.ToJson(bulkCopyExcelEntity), libUtility.ToJson(dtExcelTable), dbConnection, exc.Message, exc.StackTrace);
            }

            return bulkCopyExcelEntity.bulkCopyResult;
        }
        #endregion

    }
    #endregion

}
