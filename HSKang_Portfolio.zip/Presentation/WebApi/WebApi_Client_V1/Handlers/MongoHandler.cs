﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Mongo;
using Lib.Crawling.Library.DataContainers;
using Lib.Crawling.Library.Log;

namespace WebApi_SpiderKim_V1.Handlers
{

    #region // !++ MongoHandler
    /// <summary>
    /// MongoHandler
    /// </summary>
    public class MongoHandler : Handler
    {



    }
    #endregion

}
