//https://stackblitz.com/edit/angular-resizable

import { Directive, ElementRef, OnInit, Input } from '@angular/core';

@Directive({
  selector: '[appResizable]' // Attribute selector
})

export class ResizableDirective implements OnInit {

    @Input() resizableGrabHeight = 8;
    @Input() resizableMinHeight = 100;

    dragging = false;

    constructor(private el: ElementRef) {
        //const self = this;
        //const EventListenerMode = { capture: true };

        function preventGlobalMouseEvents() {
            document.body.style['pointer-events'] = 'none';
        }

        function restoreGlobalMouseEvents() {
            document.body.style['pointer-events'] = 'auto';
        }

        const newHeight = (h:number) => {
            const newHeight = h + this.el.nativeElement.clientHeight;
            if(newHeight < this.resizableMinHeight){
                return;
            }
            el.nativeElement.style.height = (newHeight) + "px";
        }

        const mouseMoveG = (evt:any) => {
            if (!this.dragging) {
                return;
            }
            newHeight((evt.clientY - 50) - el.nativeElement.offsetHeight);
            evt.stopPropagation();
        };

        // const dragMoveG = (evt) => {
        //     if (!this.dragging) {
        //         return;
        //     }
        //     const newWidth = Math.max(this.resizableMinHeight, (evt.clientY - el.nativeElement.offsetHeight)) + "px";
        //     el.nativeElement.style.height = (evt.clientY - el.nativeElement.offsetHeight) + "px";
        //     evt.stopPropagation();
        // };

        const mouseUpG = (evt) => {
            if (!this.dragging) {
                return;
            }
            restoreGlobalMouseEvents();
            this.dragging = false;
            evt.stopPropagation();
        };

        const mouseDown = (evt) => {
            if (this.inDragRegion(evt)) {
                this.dragging = true;
                preventGlobalMouseEvents();
                evt.stopPropagation();
            }
        };

        const mouseMove = (evt) => {
            if (this.inDragRegion(evt) || this.dragging) {
                el.nativeElement.style.cursor = "row-resize";
            } else {
                el.nativeElement.style.cursor = "default";
            }
        }

        document.addEventListener('mousemove', mouseMoveG, true);
        document.addEventListener('mouseup', mouseUpG, true);
        el.nativeElement.addEventListener('mousedown', mouseDown, true);
        el.nativeElement.addEventListener('mousemove', mouseMove, true);
    } 

    ngOnInit(): void {
        this.el.nativeElement.style["border-bottom"] = this.resizableGrabHeight + "px solid darkgrey";
    }

    inDragRegion(evt:any) {
      return (this.el.nativeElement.clientHeight + this.resizableGrabHeight) - (evt.clientY - 50) < this.resizableGrabHeight;
    }
}