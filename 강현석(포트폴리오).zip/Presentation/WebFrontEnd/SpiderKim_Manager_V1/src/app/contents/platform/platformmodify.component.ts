import { Component, OnInit, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { FormGroup, FormBuilder, Validators, ValidationErrors } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { NgxSpinnerService } from "ngx-spinner";

import { CommonService, PlatFormService } from '../../service';
import { PlatFormModel } from '../../model';

@Component({ 
    selector: 'app-popup',
    templateUrl: './platformmodify.component.html', 
    styleUrls: ['../scss/regEdit.component.scss']
})

export class PlatFormModifyComponent implements OnInit
{
    mSeq:number;
    mPlatForm:PlatFormModel = null;
    modifyForm:FormGroup;

    constructor(private mService:PlatFormService,
                private cmnService:CommonService,
                private translate:TranslateService,
                private spinnerService:NgxSpinnerService,
                public dialogRef: MatDialogRef<PlatFormModifyComponent>, 
                @Inject(MAT_DIALOG_DATA) public data:any,
                private fb:FormBuilder){
            
        this.mSeq = (data.iSeq === null) ? -1 : data.iSeq;
    }

    ngOnInit():void
    {
        this.modifyForm = this.fb.group({
            iSeq:[this.mSeq, Validators.required],
            vcName:['', Validators.required],
            vcKeyText:['', Validators.required],
            vcKeyImage:['', Validators.required],
            tiStatus:[0, Validators.required]
        });

        // PlatForm 상세정보 호출
        this.onDetail(this.mSeq);
    }

    // PlatForm 상세정보
    onDetail(mSeq:number):void
    {
        setTimeout(() => this.spinnerService.show(), 0);

        this.mService.getPlatFormDetail(mSeq).subscribe(
            detailData => {
                this.spinnerService.hide();
                this.mPlatForm = detailData.data;
                
                // Form value 셋팅
                this.modifyForm.patchValue ({iSeq: this.mPlatForm.iSeq});
                this.modifyForm.patchValue ({vcName: this.mPlatForm.vcName});
                this.modifyForm.patchValue ({vcKeyText: this.mPlatForm.vcKeyText});
                this.modifyForm.patchValue ({vcKeyImage: this.mPlatForm.vcKeyImage});
                this.modifyForm.patchValue ({tiStatus: this.mPlatForm.tiStatus});
            },
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

    // Action
    onModify():void
    {
        this.mService.regEditPlatForm(this.modifyForm.value, false).subscribe(
            (res) => this.onClose(true),
            (err) => { this.onClose(false); console.log(err);}
        );
    }

    // Reset
    onReset():void
    {
        this.modifyForm.patchValue ({vcTitleKeyText: ''});
        this.modifyForm.patchValue ({vcDescriptKeyText: ''});
        this.modifyForm.patchValue ({tiMain: 2});
    }

    // popup close
    onClose(param:any):void{
        this.dialogRef.close(param);
    }

}