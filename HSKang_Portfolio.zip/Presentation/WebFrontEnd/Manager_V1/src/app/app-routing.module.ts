﻿import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuard } from './helper';
import { LoginComponent } from './contents/login.component';

// Manager
import { ManagerListComponent, ManagerViewComponent } from './contents/manager';

// FAQ
import { FaqCodeListComponent, FaqListComponent } from './contents/faq';

// PlatForm
import { PlatFormListComponent, PlatFormApiListComponent } from './contents/platform';

// Member
import { AccountListComponent } from './contents/account';

const routes: Routes = [
    { path: '', component: LoginComponent },
    { path: 'list', component: ManagerListComponent, canActivate: [AuthGuard] },
    { path: 'view/:id', component: ManagerViewComponent, canActivate: [AuthGuard] },
    { path: 'faqcodelist', component: FaqCodeListComponent, canActivate: [AuthGuard] },
    { path: 'faqlist', component: FaqListComponent, canActivate: [AuthGuard] },
    { path: 'platformlist', component: PlatFormListComponent, canActivate: [AuthGuard] },
    { path: 'platformapilist', component: PlatFormApiListComponent, canActivate: [AuthGuard] },
    { path: 'memberlist', component: AccountListComponent, canActivate: [AuthGuard] },
    
];

@NgModule({
    imports: [RouterModule.forRoot(routes, { onSameUrlNavigation: 'reload' })],
    exports: [RouterModule]
})

export class AppRoutingModule { }