﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace Lib.Crawling.Library.Models.AccountDB
{

    #region // !++ tbMemberDataContainer
    /// <summary>
    /// 회원정보
    /// </summary>
    [Serializable]
    public class tbMemberDataContainer
    {

        /// <summary>
        /// 회원기본정보
        /// </summary>
        public tbMember TbMember { get; set; }

        /// <summary>
        /// 회원상세정보
        /// </summary>
        public tbMemberDetail TbMemberDetail { get; set; }

        /// <summary>
        /// 회원연락처
        /// </summary>
        public tbMemberContact TbMemberContact { get; set; }

        /// <summary>
        /// 회원비밀번호
        /// </summary>
        public tbMemberPassword TbMemberPassword { get; set; }

        /// <summary>
        /// 회원(단체)정보
        /// </summary>
        public tbMemberOrganization TbMemberOrganization { get; set; }

        /// <summary>
        /// 회원Email인증정보
        /// </summary>
        public tbMemberEmailAuth TbMemberEmailAuth { get; set; }

        public tbMemberDataContainer()
        {
            TbMember = null;
            TbMemberDetail = null;
            TbMemberContact = null;
            TbMemberPassword = null;
            TbMemberOrganization = null;
            TbMemberEmailAuth = null;
        }
        ~tbMemberDataContainer()
        {
            TbMember = null;
            TbMemberDetail = null;
            TbMemberContact = null;
            TbMemberPassword = null;
            TbMemberOrganization = null;
            TbMemberEmailAuth = null;
        }

    }
    #endregion

}
