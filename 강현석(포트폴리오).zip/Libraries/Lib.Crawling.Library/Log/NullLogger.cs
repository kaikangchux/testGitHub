﻿using System;
using System.Collections.Generic;
using System.Text;

using log4net.Appender;

namespace Lib.Crawling.Library.Log
{

    #region // !++ NullLogger
    /// <summary>
    /// 
    /// </summary>
    public class NullLogger : LoggerBase
    {
        public override void Init() { }
        public override IAppender GetAppender() { return null; }

        public override void Log(ELogType eLogType, string logMsg) { }
        public override void Log(ELogType eLogType, string logFormat, params object[] paramArray) { }
        public override void Log(ELogType eLogType, string logMsg, Exception exc) { }
        public override void Log(ELogType eLogType, Exception exc) { }
    }
    #endregion

}
