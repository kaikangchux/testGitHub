import { MemberModel } from './membermodel';
import { MemberOrganizationModel } from './memberorganizationmodel';

// 회원기본정보
export class MemberContainer
{
    tbMember:MemberModel;
    tbMemberOrganization:MemberOrganizationModel;

    constructor() {
        this.tbMember = null;
        this.tbMemberOrganization = null;
    }
}