﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lib.Crawling.Library.Entities.Crawling
{

    #region // !++ WebCrawerlingTargetEntity
    /// <summary>
    /// 크롤링 URL
    /// </summary>
    [Serializable]
    public class WebCrawerlingTargetEntity
    {

        /// <summary>
        /// 크롤링 URL
        /// </summary>
        public String targetUrl { get; set; }

        public WebCrawerlingTargetEntity()
        {
            targetUrl = String.Empty;
        }
        ~WebCrawerlingTargetEntity()
        {
            targetUrl = String.Empty;
        }

    }
    #endregion


    #region // !++ WebCrawerlingTargetDetailEntity
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    public class WebCrawerlingTargetDetailEntity
    {

        /// <summary>
        /// 크롤링 URL
        /// </summary>
        public String targetUrl { get; set; }

        /// <summary>
        /// 엘리멘트
        /// </summary>
        public String targetElement { get; set; }

        public WebCrawerlingTargetDetailEntity()
        {
            targetUrl = String.Empty;
            targetElement = String.Empty;
        }
        ~WebCrawerlingTargetDetailEntity()
        {
            targetUrl = String.Empty;
            targetElement = String.Empty;
        }

    }
    #endregion

}
