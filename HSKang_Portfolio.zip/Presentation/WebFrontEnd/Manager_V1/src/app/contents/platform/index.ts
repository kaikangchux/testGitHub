export * from './platformlist.component';
export * from './platformdetail.component';
export * from './platformregist.component';
export * from './platformmodify.component';

export * from './platformapilist.component';
export * from './platformapidetail.component';
export * from './platformapiregist.component';
export * from './platformapimodify.component';