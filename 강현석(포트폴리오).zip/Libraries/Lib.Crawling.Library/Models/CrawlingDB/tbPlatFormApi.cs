﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.CrawlingDB
{

    #region // !++ tbPlatFormApi
    /// <summary>
    /// tbPlatFormApi
    /// </summary>
    [Table("tbPlatFormApi")]
    public class tbPlatFormApi
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        /// <summary>
        /// 고유번호(AI)
        /// </summary>
        public Int32 iSeq { get; set; }

        [Key, Required]
        /// <summary>
        /// 플랫폼고유번호
        /// </summary>
        public Int32 iPlatFormSeq { get; set; }

        [Required, MinLength(2), MaxLength(128)]
        /// <summary>
        /// API경로(URL)
        /// </summary>
        public String vcApiUrl { get; set; }

        [Required, MinLength(2), MaxLength(128)]
        /// <summary>
        /// API계정
        /// </summary>
        public String vcID { get; set; }

        [Required, MinLength(2), MaxLength(256)]
        /// <summary>
        /// API보안키
        /// </summary>
        public String vcVerifyKey { get; set; }

        /// <summary>
        /// 사용여부(1:사용, 2:대기, 3:삭제)
        /// </summary>
        public Int16 tiStatus { get; set; }

        /// <summary>
        /// 관리자고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
