﻿using System;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Account;
using Lib.Crawling.Library.Entities.Crawling;
using Lib.Crawling.Library.Models.CrawlingDB;

using MySql.Data.MySqlClient;

namespace DAL.Crawling.Crawling
{

    #region // !++ DalCrawling
    /// <summary>
    /// DalCrawling
    /// </summary>
    public class DalCrawling
    {

        #region // !++ DAL_Board_Sel (게시판 목록)
        /// <summary>
        /// 게시판 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_Board_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_Board_Sel(?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[2];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Board_Ins (게시판 등록)
        /// <summary>
        /// 게시판 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbBaord"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_Board_Ins(DBConnectionEntity dbConnectionEntity, tbBoard dbBaord)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_Board_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biMemberSeq", MySqlDbType.Int64).Value = dbBaord.biMemberSeq;
                    command.Parameters.Add("@p_vcAccount", MySqlDbType.VarChar, 32).Value = dbBaord.vcAccount;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 32).Value = dbBaord.vcName;
                    command.Parameters.Add("@p_vcTitle", MySqlDbType.VarChar, 128).Value = dbBaord.vcTitle;
                    command.Parameters.Add("@p_tDescription", MySqlDbType.Text).Value = dbBaord.tDescription;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbBaord.vcIP;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Board_Detail_Sel (게시판 상세정보)
        /// <summary>
        /// 게시판 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbBoard"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_Board_Detail_Sel(DBConnectionEntity dbConnectionEntity, tbBoard dbBoard)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_Board_Sel(?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[1];
                paramArray[0] = new MySqlParameter("@p_biSeq", MySqlDbType.Int64)
                {
                    Value = dbBoard.biSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Board_Read_Upd (게시판 정보 조회수 수정)
        /// <summary>
        /// 게시판 정보 조회수 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbBaord"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_Board_Read_Upd(DBConnectionEntity dbConnectionEntity, tbBoard dbBaord)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_Board_Read_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Value = dbBaord.biSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Board_Upd (게시판 정보 수정)
        /// <summary>
        /// 게시판 정보 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbBaord"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_Board_Upd(DBConnectionEntity dbConnectionEntity, tbBoard dbBaord)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_Board_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Value = dbBaord.biSeq;
                    command.Parameters.Add("@p_biMemberSeq", MySqlDbType.Int64).Value = dbBaord.biMemberSeq;
                    command.Parameters.Add("@p_vcTitle", MySqlDbType.VarChar, 128).Value = dbBaord.vcTitle;
                    command.Parameters.Add("@p_tDescription", MySqlDbType.Text).Value = dbBaord.tDescription;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Board_Del (게시판 정보 삭제)
        /// <summary>
        /// 게시판 정보 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbBaord"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_Board_Del(DBConnectionEntity dbConnectionEntity, tbBoard dbBaord)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_Board_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Value = dbBaord.biSeq;
                    command.Parameters.Add("@p_biMemberSeq", MySqlDbType.Int64).Value = dbBaord.biMemberSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_BoardComment_Ins (게시판 댓글 등록)
        /// <summary>
        /// 게시판 댓글 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbBaordComment"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_BoardComment_Ins(DBConnectionEntity dbConnectionEntity, tbBoardComment dbBaordComment)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_BoardComment_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biBoardSeq", MySqlDbType.Int64).Value = dbBaordComment.biBoardSeq;
                    command.Parameters.Add("@p_biMemberSeq", MySqlDbType.Int64).Value = dbBaordComment.biMemberSeq;
                    command.Parameters.Add("@p_vcAccount", MySqlDbType.VarChar, 32).Value = dbBaordComment.vcAccount;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 32).Value = dbBaordComment.vcName;
                    command.Parameters.Add("@p_tDescription", MySqlDbType.Text).Value = dbBaordComment.tDescription;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbBaordComment.vcIP;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_BoardComment_Sel (게시판 댓글 목록정보)
        /// <summary>
        /// 게시판 댓글 목록정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbBoardComment"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_BoardComment_Sel(DBConnectionEntity dbConnectionEntity, tbBoardComment dbBoardComment)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_BoardComment_Sel(?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[1];
                paramArray[0] = new MySqlParameter("@p_biSeq", MySqlDbType.Int64)
                {
                    Value = dbBoardComment.biBoardSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_BoardComment_Upd (게시판 댓글 수정)
        /// <summary>
        /// 게시판 댓글 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbBaordComment"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_BoardComment_Upd(DBConnectionEntity dbConnectionEntity, tbBoardComment dbBaordComment)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_BoardComment_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Value = dbBaordComment.biSeq;
                    command.Parameters.Add("@p_biBoardSeq", MySqlDbType.Int64).Value = dbBaordComment.biBoardSeq;
                    command.Parameters.Add("@p_biMemberSeq", MySqlDbType.Int64).Value = dbBaordComment.biMemberSeq;
                    command.Parameters.Add("@p_tDescription", MySqlDbType.Text).Value = dbBaordComment.tDescription;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_BoardComment_Del (게시판 댓글 삭제)
        /// <summary>
        /// 게시판 댓글 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbBaordComment"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_BoardComment_Del(DBConnectionEntity dbConnectionEntity, tbBoardComment dbBaordComment)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_BoardComment_Del";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Value = dbBaordComment.biSeq;
                    command.Parameters.Add("@p_biBoardSeq", MySqlDbType.Int64).Value = dbBaordComment.biBoardSeq;
                    command.Parameters.Add("@p_biMemberSeq", MySqlDbType.Int64).Value = dbBaordComment.biMemberSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Inquiry_Sel (제품문의 목록)
        /// <summary>
        /// 제품문의 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="memberLoginEntity"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_Inquiry_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, MemberLoginEntity memberLoginEntity)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_Inquiry_Sel(?, ? ,?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[3];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                paramArray[2] = new MySqlParameter("@p_biMemberSeq", MySqlDbType.Int64)
                {
                    Value = memberLoginEntity.biMemberSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Inquiry_Ins (제품문의 등록)
        /// <summary>
        /// 제품문의 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbInquiry"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_Inquiry_Ins(DBConnectionEntity dbConnectionEntity, tbInquiry dbInquiry)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_Board_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_tiType", MySqlDbType.Bit).Value = dbInquiry.tiType;
                    command.Parameters.Add("@p_biMemberSeq", MySqlDbType.Int64).Value = dbInquiry.biMemberSeq;
                    command.Parameters.Add("@p_vcOrganizationSerial", MySqlDbType.VarChar, 32).Value = dbInquiry.vcOrganizationSerial;
                    command.Parameters.Add("@p_vcBusiness", MySqlDbType.VarChar, 32).Value = dbInquiry.vcBusiness;
                    command.Parameters.Add("@p_vcCompany", MySqlDbType.VarChar, 32).Value = dbInquiry.vcCompany;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 32).Value = dbInquiry.vcName;
                    command.Parameters.Add("@p_vcPhone", MySqlDbType.VarChar, 32).Value = dbInquiry.vcPhone;
                    command.Parameters.Add("@p_vcTitle", MySqlDbType.VarChar, 128).Value = dbInquiry.vcTitle;
                    command.Parameters.Add("@p_tDescription", MySqlDbType.Text).Value = dbInquiry.tDescription;
                    command.Parameters.Add("@p_tiAgree", MySqlDbType.Bit).Value = dbInquiry.tiAgree;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbInquiry.vcIP;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Inquiry_Detail_Sel (제품문의 상세정보)
        /// <summary>
        /// 제품문의 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbInquiry"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_Inquiry_Detail_Sel(DBConnectionEntity dbConnectionEntity, tbInquiry dbInquiry)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_Inquiry_Detail_Sel(?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[2];
                paramArray[0] = new MySqlParameter("@p_biSeq", MySqlDbType.Int64)
                {
                    Value = dbInquiry.biSeq
                };
                paramArray[1] = new MySqlParameter("@p_biMemberSeq", MySqlDbType.Int64)
                {
                    Value = dbInquiry.biMemberSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Inquiry_Upd (제품문의 수정)
        /// <summary>
        /// 제품문의 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbInquiry"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_Inquiry_Upd(DBConnectionEntity dbConnectionEntity, tbInquiry dbInquiry)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_Inquiry_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Value = dbInquiry.biSeq;
                    command.Parameters.Add("@p_biMemberSeq", MySqlDbType.Int64).Value = dbInquiry.biMemberSeq;
                    command.Parameters.Add("@p_vcTitle", MySqlDbType.VarChar, 128).Value = dbInquiry.vcTitle;
                    command.Parameters.Add("@p_tDescription", MySqlDbType.Text).Value = dbInquiry.tDescription;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Inquiry_Del (제품문의 삭제)
        /// <summary>
        /// 제품문의 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbInquiry"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_Inquiry_Del(DBConnectionEntity dbConnectionEntity, tbInquiry dbInquiry)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_Inquiry_Del";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Value = dbInquiry.biSeq;
                    command.Parameters.Add("@p_biMemberSeq", MySqlDbType.Int64).Value = dbInquiry.biMemberSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_InquiryAnswer_Sel (제품문의 답변 정보)
        /// <summary>
        /// 제품문의 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbInquiryAnswer"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_InquiryAnswer_Sel(DBConnectionEntity dbConnectionEntity, tbInquiryAnswer dbInquiryAnswer)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_InquiryAnswer_Sel(?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[1];
                paramArray[0] = new MySqlParameter("@p_biInquirySeq", MySqlDbType.Int32)
                {
                    Value = dbInquiryAnswer.biInquirySeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_CrawlerRecord_Sel (크롤링 성공 & 실패 정보)
        /// <summary>
        /// 크롤링 성공 & 실패 정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbCrawlerRecord"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_CrawlerRecord_Sel(DBConnectionEntity dbConnectionEntity, tbCrawlerRecord dbCrawlerRecord)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_CrawlerRecord_Sel(?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[1];
                paramArray[0] = new MySqlParameter("@p_biMemberSeq", MySqlDbType.Int32)
                {
                    Value = dbCrawlerRecord.biMemberSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_CrawlerRecord_Execute (크롤링 성공 & 실패 여부 등록 및 수정)
        /// <summary>
        /// 크롤링 성공 & 실패 여부 등록 및 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbCrawlerRecord"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_CrawlerRecord_Execute(DBConnectionEntity dbConnectionEntity, tbCrawlerRecord dbCrawlerRecord)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_CrawlerRecord_Execute";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biMemberSeq", MySqlDbType.Int64).Value = dbCrawlerRecord.biMemberSeq;
                    command.Parameters.Add("@p_iSuccess", MySqlDbType.Int32).Value = dbCrawlerRecord.iSuccess;
                    command.Parameters.Add("@p_iFail", MySqlDbType.Int32).Value = dbCrawlerRecord.iFail;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_CrawlerHistory_Sel (데이터 수집내역 목록)
        /// <summary>
        /// 데이터 수집내역 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="memberLoginEntity"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_CrawlerHistory_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, MemberLoginEntity memberLoginEntity)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_CrawlerHistory_Sel(?, ? ,?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[3];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                paramArray[2] = new MySqlParameter("@p_biMemberSeq", MySqlDbType.Int64)
                {
                    Value = memberLoginEntity.biMemberSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_CrawlerHistory_Detail_Sel (데이터 수집내역 상세정보)
        /// <summary>
        /// 데이터 수집내역 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbCrawlerHistory"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_CrawlerHistory_Detail_Sel(DBConnectionEntity dbConnectionEntity, tbCrawlerHistory dbCrawlerHistory)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_CrawlerHistory_Detail_Sel(?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[2];
                paramArray[0] = new MySqlParameter("@p_biSeq", MySqlDbType.Int64)
                {
                    Value = dbCrawlerHistory.biSeq
                };
                paramArray[1] = new MySqlParameter("@p_biMemberSeq", MySqlDbType.Int64)
                {
                    Value = dbCrawlerHistory.biMemberSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_CrawlerHistory_Ins (데이터 수집내역 등록)
        /// <summary>
        /// 데이터 수집내역 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbCrawlerHistory"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_CrawlerHistory_Ins(DBConnectionEntity dbConnectionEntity, tbCrawlerHistory dbCrawlerHistory)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_CrawlerHistory_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biMemberSeq", MySqlDbType.Int64).Value = dbCrawlerHistory.biMemberSeq;
                    command.Parameters.Add("@p_vcTargetUrl", MySqlDbType.VarChar, 256).Value = dbCrawlerHistory.vcTargetUrl;
                    command.Parameters.Add("@p_tiStatus", MySqlDbType.Bit).Value = dbCrawlerHistory.tiStatus;
                    command.Parameters.Add("@p_iRecord", MySqlDbType.Int32).Value = dbCrawlerHistory.iRecord;
                    command.Parameters.Add("@p_biMillisecond", MySqlDbType.Int64).Value = dbCrawlerHistory.biMillisecond;
                    command.Parameters.Add("@p_biCrawlerScheduleSeq", MySqlDbType.Int64).Value = dbCrawlerHistory.biCrawlerScheduleSeq;
                    command.Parameters.Add("@p_iNumber", MySqlDbType.Int32).Value = dbCrawlerHistory.iNumber;
                    command.Parameters.Add("@p_dtRegDate", MySqlDbType.DateTime).Value = dbCrawlerHistory.dtRegDate;
                    command.Parameters.Add("@p_dtEndDate", MySqlDbType.DateTime).Value = dbCrawlerHistory.dtEndDate;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_CrawlerSchedule_Sel (크롤링 스케줄 목록)
        /// <summary>
        /// 크롤링 스케줄 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="memberLoginEntity"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_CrawlerSchedule_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, MemberLoginEntity memberLoginEntity)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_CrawlerSchedule_Sel(?, ? ,?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[3];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                paramArray[2] = new MySqlParameter("@p_biMemberSeq", MySqlDbType.Int64)
                {
                    Value = memberLoginEntity.biMemberSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_CrawlerSchedule_Detail_Sel (크롤링 스케줄 상세정보)
        /// <summary>
        /// 크롤링 스케줄 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbCrawlerSchedule"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_CrawlerSchedule_Detail_Sel(DBConnectionEntity dbConnectionEntity, tbCrawlerSchedule dbCrawlerSchedule)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_CrawlerSchedule_Detail_Sel(?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[2];
                paramArray[0] = new MySqlParameter("@p_biSeq", MySqlDbType.Int64)
                {
                    Value = dbCrawlerSchedule.biSeq
                };
                paramArray[1] = new MySqlParameter("@p_biMemberSeq", MySqlDbType.Int64)
                {
                    Value = dbCrawlerSchedule.biMemberSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_CrawlerSchedule_Ins (크롤링 스케줄 등록)
        /// <summary>
        /// 크롤링 스케줄 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbCrawlerSchedule"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_CrawlerSchedule_Ins(DBConnectionEntity dbConnectionEntity, tbCrawlerSchedule dbCrawlerSchedule)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_CrawlerSchedule_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biMemberSeq", MySqlDbType.Int64).Value = dbCrawlerSchedule.biMemberSeq;
                    command.Parameters.Add("@p_vcTargetUrl", MySqlDbType.VarChar, 256).Value = dbCrawlerSchedule.vcTargetUrl;
                    command.Parameters.Add("@p_iRepeat", MySqlDbType.Int32).Value = dbCrawlerSchedule.iRepeat;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_CrawlerSchedule_Upd (크롤링 스케줄 수정)
        /// <summary>
        /// 크롤링 스케줄 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbCrawlerSchedule"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_CrawlerSchedule_Upd(DBConnectionEntity dbConnectionEntity, tbCrawlerSchedule dbCrawlerSchedule)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_CrawlerSchedule_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Value = dbCrawlerSchedule.biSeq;
                    command.Parameters.Add("@p_biMemberSeq", MySqlDbType.Int64).Value = dbCrawlerSchedule.biMemberSeq;
                    command.Parameters.Add("@p_vcTargetUrl", MySqlDbType.VarChar, 256).Value = dbCrawlerSchedule.vcTargetUrl;
                    command.Parameters.Add("@p_iRepeat", MySqlDbType.Int32).Value = dbCrawlerSchedule.iRepeat;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_CrawlerSchedule_Del (크롤링 스케줄 삭제)
        /// <summary>
        /// 크롤링 스케줄 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbCrawlerSchedule"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_CrawlerSchedule_Del(DBConnectionEntity dbConnectionEntity, tbCrawlerSchedule dbCrawlerSchedule)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_CrawlerSchedule_Del";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Value = dbCrawlerSchedule.biSeq;
                    command.Parameters.Add("@p_biMemberSeq", MySqlDbType.Int64).Value = dbCrawlerSchedule.biMemberSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_CrawlerScheduleTime_Sel (크롤링 스케줄 시간 목록)
        /// <summary>
        /// 크롤링 스케줄 시간 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="memberLoginEntity"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_CrawlerScheduleTime_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, MemberLoginEntity memberLoginEntity, tbCrawlerScheduleTime dbCrawlerScheduleTime)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_CrawlerScheduleTime_Sel(?, ? ,?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[4];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                paramArray[2] = new MySqlParameter("@p_biMemberSeq", MySqlDbType.Int64)
                {
                    Value = memberLoginEntity.biMemberSeq
                };
                paramArray[3] = new MySqlParameter("@p_biCrawlerScheduleSeq", MySqlDbType.Int64)
                {
                    Value = dbCrawlerScheduleTime.biCrawlerScheduleSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_CrawlerScheduleTime_Detail_Sel (크롤링 스케줄 시간 상세정보)
        /// <summary>
        /// 크롤링 스케줄 시간 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbCrawlerScheduleTime"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_CrawlerScheduleTime_Detail_Sel(DBConnectionEntity dbConnectionEntity, tbCrawlerScheduleTime dbCrawlerScheduleTime)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_CrawlerScheduleTime_Detail_Sel(?, ?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[3];
                paramArray[0] = new MySqlParameter("@p_biSeq", MySqlDbType.Int64)
                {
                    Value = dbCrawlerScheduleTime.biSeq
                };
                paramArray[1] = new MySqlParameter("@p_biMemberSeq", MySqlDbType.Int64)
                {
                    Value = dbCrawlerScheduleTime.biMemberSeq
                };
                paramArray[2] = new MySqlParameter("@p_biCrawlerScheduleSeq", MySqlDbType.Int64)
                {
                    Value = dbCrawlerScheduleTime.biCrawlerScheduleSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion





        //******************************************************
        // 관리자(운영툴)
        //******************************************************

            
        #region // !++ DAL_FAQCode_Sel (FAQ코드 목록)
        /// <summary>
        /// FAQ코드 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_FAQCode_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_FAQCode_Sel(?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[2];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_FAQCode_Detail_Sel (FAQ코드 상세정보)
        /// <summary>
        /// FAQ코드 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbFAQCode"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_FAQCode_Detail_Sel(DBConnectionEntity dbConnectionEntity, tbFAQCode dbFAQCode)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_FAQCode_Detail_Sel(?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[1];
                paramArray[0] = new MySqlParameter("@p_iSeq", MySqlDbType.Int32)
                {
                    Value = dbFAQCode.iSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_FAQCode_Ins (FAQ코드 등록)
        /// <summary>
        /// FAQ코드 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbFAQCode"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<FAQCodeEntity>> DAL_FAQCode_Ins(DBConnectionEntity dbConnectionEntity, tbFAQCode dbFAQCode)
        {
            var getResult = new ResultEntity<FAQCodeEntity>();
            var storedProcedure = "usp_FAQCode_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_vcTitle", MySqlDbType.VarChar, 128).Value = dbFAQCode.vcTitle;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbFAQCode.iManagerSeq;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    var resultEntity = new FAQCodeEntity()
                    {
                        iSeq = Int32.Parse(command.Parameters["@p_iSeq"].Value.ToString())
                    };
                    getResult.gClass = resultEntity;
                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_FAQCode_Upd (FAQ코드 수정)
        /// <summary>
        /// FAQ코드 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbFAQCode"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_FAQCode_Upd(DBConnectionEntity dbConnectionEntity, tbFAQCode dbFAQCode)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_FAQCode_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbFAQCode.iSeq;
                    command.Parameters.Add("@p_vcTitle", MySqlDbType.VarChar, 128).Value = dbFAQCode.vcTitle;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbFAQCode.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_FAQCode_Del (FAQ코드 삭제)
        /// <summary>
        /// FAQ코드 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbFAQCode"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_FAQCode_Del(DBConnectionEntity dbConnectionEntity, tbFAQCode dbFAQCode)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_FAQCode_Del";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbFAQCode.iSeq;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbFAQCode.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_FAQ_Sel (FAQ 목록)
        /// <summary>
        /// FAQ 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_FAQ_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_FAQ_Sel(?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[2];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_FAQ_Detail_Sel (FAQ 상세정보)
        /// <summary>
        /// FAQ 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbFAQ"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_FAQ_Detail_Sel(DBConnectionEntity dbConnectionEntity, tbFAQ dbFAQ)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_FAQ_Detail_Sel(?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[1];
                paramArray[0] = new MySqlParameter("@p_iSeq", MySqlDbType.Int32)
                {
                    Value = dbFAQ.iSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_FAQ_Ins (FAQ 등록)
        /// <summary>
        /// FAQ 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbFAQ"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<FAQEntity>> DAL_FAQ_Ins(DBConnectionEntity dbConnectionEntity, tbFAQ dbFAQ)
        {
            var getResult = new ResultEntity<FAQEntity>();
            var storedProcedure = "usp_FAQ_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_iFaqCodeSeq", MySqlDbType.Int32).Value = dbFAQ.iFaqCodeSeq;
                    command.Parameters.Add("@p_vcTitleKeyText", MySqlDbType.VarChar, 64).Value = dbFAQ.vcTitleKeyText;
                    command.Parameters.Add("@p_vcDescriptKeyText", MySqlDbType.VarChar, 64).Value = dbFAQ.vcDescriptKeyText;
                    command.Parameters.Add("@p_tiMain", MySqlDbType.Bit).Value = dbFAQ.tiMain;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbFAQ.iManagerSeq;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    var resultEntity = new FAQEntity()
                    {
                        iSeq = Int32.Parse(command.Parameters["@p_iSeq"].Value.ToString())
                    };
                    getResult.gClass = resultEntity;
                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_FAQ_Upd (FAQ 수정)
        /// <summary>
        /// FAQ 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbFAQ"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_FAQ_Upd(DBConnectionEntity dbConnectionEntity, tbFAQ dbFAQ)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_FAQ_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbFAQ.iSeq;
                    command.Parameters.Add("@p_iFaqCodeSeq", MySqlDbType.Int32).Value = dbFAQ.iFaqCodeSeq;
                    command.Parameters.Add("@p_vcTitleKeyText", MySqlDbType.VarChar, 64).Value = dbFAQ.vcTitleKeyText;
                    command.Parameters.Add("@p_vcDescriptKeyText", MySqlDbType.VarChar, 64).Value = dbFAQ.vcDescriptKeyText;
                    command.Parameters.Add("@p_tiMain", MySqlDbType.Bit).Value = dbFAQ.tiMain;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbFAQ.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_FAQ_Del (FAQ 삭제)
        /// <summary>
        /// FAQ 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbFAQ"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_FAQ_Del(DBConnectionEntity dbConnectionEntity, tbFAQ dbFAQ)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_FAQ_Del";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbFAQ.iSeq;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbFAQ.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_PlatForm_Sel (플랫폼 목록)
        /// <summary>
        /// 플랫폼 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_PlatForm_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_PlatForm_Sel(?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[2];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_PlatForm_Detail_Sel (플랫폼 상세정보)
        /// <summary>
        /// 플랫폼 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbPlatForm"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_PlatForm_Detail_Sel(DBConnectionEntity dbConnectionEntity, tbPlatForm dbPlatForm)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_PlatForm_Detail_Sel(?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[1];
                paramArray[0] = new MySqlParameter("@p_iSeq", MySqlDbType.Int32)
                {
                    Value = dbPlatForm.iSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_PlatForm_Ins (플랫폼 등록)
        /// <summary>
        /// 플랫폼 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbPlatForm"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<PlatFormEntity>> DAL_PlatForm_Ins(DBConnectionEntity dbConnectionEntity, tbPlatForm dbPlatForm)
        {
            var getResult = new ResultEntity<PlatFormEntity>();
            var storedProcedure = "usp_PlatForm_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 32).Value = dbPlatForm.vcName;
                    command.Parameters.Add("@p_vcKeyText", MySqlDbType.VarChar, 64).Value = dbPlatForm.vcKeyText;
                    command.Parameters.Add("@p_vcKeyImage", MySqlDbType.VarChar, 64).Value = dbPlatForm.vcKeyImage;
                    command.Parameters.Add("@p_tiStatus", MySqlDbType.Bit).Value = dbPlatForm.tiStatus;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbPlatForm.iManagerSeq;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    var resultEntity = new PlatFormEntity()
                    {
                        iSeq = Int32.Parse(command.Parameters["@p_iSeq"].Value.ToString())
                    };
                    getResult.gClass = resultEntity;
                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_PlatForm_Upd (플랫폼 수정)
        /// <summary>
        /// 플랫폼 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbPlatForm"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_PlatForm_Upd(DBConnectionEntity dbConnectionEntity, tbPlatForm dbPlatForm)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_PlatForm_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbPlatForm.iSeq;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 32).Value = dbPlatForm.vcName;
                    command.Parameters.Add("@p_vcKeyText", MySqlDbType.VarChar, 64).Value = dbPlatForm.vcKeyText;
                    command.Parameters.Add("@p_vcKeyImage", MySqlDbType.VarChar, 64).Value = dbPlatForm.vcKeyImage;
                    command.Parameters.Add("@p_tiStatus", MySqlDbType.Bit).Value = dbPlatForm.tiStatus;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbPlatForm.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_PlatForm_Del (플랫폼 삭제)
        /// <summary>
        /// 플랫폼 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbPlatForm"></param>
        /// <returns></returns>
        public async Task<ResultEntity<DataSet>> DAL_PlatForm_Del(DBConnectionEntity dbConnectionEntity, tbPlatForm dbPlatForm)
        {
            var getResult = new ResultEntity<DataSet>();
            var storedProcedure = "Call usp_PlatForm_Del(?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[2];
                paramArray[0] = new MySqlParameter("@p_iSeq", MySqlDbType.Int32)
                {
                    Value = dbPlatForm.iSeq
                };
                paramArray[1] = new MySqlParameter("@p_iManagerSeq", MySqlDbType.Int32)
                {
                    Value = dbPlatForm.iManagerSeq
                };
                getResult.gClass = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_PlatFormApi_Sel (플랫폼 API 목록)
        /// <summary>
        /// 플랫폼 API 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_PlatFormApi_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_PlatFormApi_Sel(?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[2];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_PlatFormApi_Detail_Sel (플랫폼 API 상세정보)
        /// <summary>
        /// 플랫폼 API 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbPlatFormApi"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_PlatFormApi_Detail_Sel(DBConnectionEntity dbConnectionEntity, tbPlatFormApi dbPlatFormApi)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_PlatFormApi_Detail_Sel(?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[1];
                paramArray[0] = new MySqlParameter("@p_iSeq", MySqlDbType.Int32)
                {
                    Value = dbPlatFormApi.iSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_PlatFormApi_Ins (플랫폼 API 등록)
        /// <summary>
        /// 플랫폼 API 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbPlatFormApi"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<PlatFormApiEntity>> DAL_PlatFormApi_Ins(DBConnectionEntity dbConnectionEntity, tbPlatFormApi dbPlatFormApi)
        {
            var getResult = new ResultEntity<PlatFormApiEntity>();
            var storedProcedure = "usp_PlatFormApi_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_iPlatFormSeq", MySqlDbType.Int32).Value = dbPlatFormApi.iPlatFormSeq;
                    command.Parameters.Add("@p_vcApiUrl", MySqlDbType.VarChar, 128).Value = dbPlatFormApi.vcApiUrl;
                    command.Parameters.Add("@p_vcID", MySqlDbType.VarChar, 128).Value = dbPlatFormApi.vcID;
                    command.Parameters.Add("@p_vcVerifyKey", MySqlDbType.VarChar, 256).Value = dbPlatFormApi.vcVerifyKey;
                    command.Parameters.Add("@p_tiStatus", MySqlDbType.Bit).Value = dbPlatFormApi.tiStatus;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbPlatFormApi.iManagerSeq;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    var resultEntity = new PlatFormApiEntity()
                    {
                        iSeq = Int32.Parse(command.Parameters["@p_iSeq"].Value.ToString())
                    };
                    getResult.gClass = resultEntity;
                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_PlatFormApi_Upd (플랫폼 API 수정)
        /// <summary>
        /// 플랫폼 API 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbPlatFormApi"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_PlatFormApi_Upd(DBConnectionEntity dbConnectionEntity, tbPlatFormApi dbPlatFormApi)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_PlatFormApi_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbPlatFormApi.iSeq;
                    command.Parameters.Add("@p_iPlatFormSeq", MySqlDbType.Int32).Value = dbPlatFormApi.iPlatFormSeq;
                    command.Parameters.Add("@p_vcApiUrl", MySqlDbType.VarChar, 128).Value = dbPlatFormApi.vcApiUrl;
                    command.Parameters.Add("@p_vcID", MySqlDbType.VarChar, 128).Value = dbPlatFormApi.vcID;
                    command.Parameters.Add("@p_vcVerifyKey", MySqlDbType.VarChar, 256).Value = dbPlatFormApi.vcVerifyKey;
                    command.Parameters.Add("@p_tiStatus", MySqlDbType.Bit).Value = dbPlatFormApi.tiStatus;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbPlatFormApi.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_PlatFormApi_Del (플랫폼 API 삭제)
        /// <summary>
        /// 플랫폼 API 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbPlatFormApi"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_PlatFormApi_Del(DBConnectionEntity dbConnectionEntity, tbPlatFormApi dbPlatFormApi)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_PlatFormApi_Del";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbPlatFormApi.iSeq;
                    command.Parameters.Add("@p_iPlatFormSeq", MySqlDbType.Int32).Value = dbPlatFormApi.iPlatFormSeq;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbPlatFormApi.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LanguageCode_Sel (언어[다국어]코드 목록)
        /// <summary>
        /// 언어[다국어]코드 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_LanguageCode_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_LanguageCode_Sel(?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[2];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LanguageCode_Detail_Sel (언어[다국어]코드 상세정보)
        /// <summary>
        /// 언어[다국어]코드 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLanguageCode"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_LanguageCode_Detail_Sel(DBConnectionEntity dbConnectionEntity, tbLanguageCode dbLanguageCode)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_LanguageCode_Detail_Sel(?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[1];
                paramArray[0] = new MySqlParameter("@p_vcLanguageCode", MySqlDbType.VarChar, 8)
                {
                    Value = dbLanguageCode.vcLanguageCode
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LanguageCode_Ins (언어[다국어]코드 등록)
        /// <summary>
        /// 언어[다국어]코드 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLanguageCode"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LanguageCode_Ins(DBConnectionEntity dbConnectionEntity, tbLanguageCode dbLanguageCode)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LanguageCode_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_vcLanguageCode", MySqlDbType.VarChar, 8).Value = dbLanguageCode.vcLanguageCode;
                    command.Parameters.Add("@p_vcLanguageName", MySqlDbType.VarChar, 32).Value = dbLanguageCode.vcLanguageName;
                    command.Parameters.Add("@p_tiStatus", MySqlDbType.Bit).Value = dbLanguageCode.tiStatus;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLanguageCode.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LanguageCode_Upd (언어[다국어]코드 수정)
        /// <summary>
        /// 언어[다국어]코드 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLanguageCode"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LanguageCode_Upd(DBConnectionEntity dbConnectionEntity, tbLanguageCode dbLanguageCode)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LanguageCode_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_vcLanguageCode", MySqlDbType.VarChar, 8).Value = dbLanguageCode.vcLanguageCode;
                    command.Parameters.Add("@p_vcLanguageName", MySqlDbType.VarChar, 32).Value = dbLanguageCode.vcLanguageName;
                    command.Parameters.Add("@p_tiStatus", MySqlDbType.Bit).Value = dbLanguageCode.tiStatus;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLanguageCode.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LanguageCode_Del (언어[다국어]코드 삭제)
        /// <summary>
        /// 언어[다국어]코드 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLanguageCode"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<DataSet>> DAL_LanguageCode_Del(DBConnectionEntity dbConnectionEntity, tbLanguageCode dbLanguageCode)
        {
            var getResult = new ResultEntity<DataSet>();
            var storedProcedure = "Call usp_LanguageCode_Del(?, ?, ?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[4];
                paramArray[0] = new MySqlParameter("@p_vcLanguageCode", MySqlDbType.VarChar, 8)
                {
                    Value = dbLanguageCode.vcLanguageCode
                };
                paramArray[1] = new MySqlParameter("@p_iManagerSeq", MySqlDbType.Int32)
                {
                    Value = dbLanguageCode.iManagerSeq
                };
                paramArray[2] = new MySqlParameter("@p_Result", MySqlDbType.Int32)
                {
                    Direction = ParameterDirection.Output
                };
                paramArray[3] = new MySqlParameter("@p_Msg", MySqlDbType.Text)
                {
                    Direction = ParameterDirection.Output
                };
                getResult.gClass = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                getResult.result = Int32.Parse(paramArray[2].Value.ToString());
                getResult.ErrorMsg = paramArray[3].Value.ToString();
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Language_Sel (언어[다국어] 목록)
        /// <summary>
        /// 언어[다국어] 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="dbLanguage"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_Language_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, tbLanguage dbLanguage)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_Language_Sel(?, ?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[3];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                paramArray[2] = new MySqlParameter("@p_vcLanguageCode", MySqlDbType.VarChar, 8)
                {
                    Value = dbLanguage.vcLanguageCode
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Language_Detail_Sel (언어[다국어] 상세정보)
        /// <summary>
        /// 언어[다국어] 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLanguage"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_Language_Detail_Sel(DBConnectionEntity dbConnectionEntity, tbLanguage dbLanguage)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_Language_Detail_Sel(?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[2];
                paramArray[0] = new MySqlParameter("@p_vcLanguageCode", MySqlDbType.VarChar, 8)
                {
                    Value = dbLanguage.vcLanguageCode
                };
                paramArray[1] = new MySqlParameter("@p_vcKeyText", MySqlDbType.VarChar, 64)
                {
                    Value = dbLanguage.vcKeyText
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Language_Ins (언어[다국어] 등록)
        /// <summary>
        /// 언어[다국어] 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLanguage"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_Language_Ins(DBConnectionEntity dbConnectionEntity, tbLanguage dbLanguage)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_Language_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_vcLanguageCode", MySqlDbType.VarChar, 8).Value = dbLanguage.vcLanguageCode;
                    command.Parameters.Add("@p_vcKeyText", MySqlDbType.VarChar, 64).Value = dbLanguage.vcKeyText;
                    command.Parameters.Add("@p_tiAbbreviated", MySqlDbType.Bit).Value = dbLanguage.tiAbbreviated;
                    command.Parameters.Add("@p_vcText", MySqlDbType.VarChar, 64).Value = dbLanguage.vcText;
                    command.Parameters.Add("@p_tiStatus", MySqlDbType.Bit).Value = dbLanguage.tiStatus;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLanguage.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Language_Upd (언어[다국어] 수정)
        /// <summary>
        /// 언어[다국어] 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLanguage"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_Language_Upd(DBConnectionEntity dbConnectionEntity, tbLanguage dbLanguage)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_Language_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_vcLanguageCode", MySqlDbType.VarChar, 8).Value = dbLanguage.vcLanguageCode;
                    command.Parameters.Add("@p_vcKeyText", MySqlDbType.VarChar, 64).Value = dbLanguage.vcKeyText;
                    command.Parameters.Add("@p_tiAbbreviated", MySqlDbType.Bit).Value = dbLanguage.tiAbbreviated;
                    command.Parameters.Add("@p_vcText", MySqlDbType.VarChar, 64).Value = dbLanguage.vcText;
                    command.Parameters.Add("@p_tiStatus", MySqlDbType.Bit).Value = dbLanguage.tiStatus;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLanguage.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Language_Del (언어[다국어] 삭제)
        /// <summary>
        /// 언어[다국어] 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLanguage"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_Language_Del(DBConnectionEntity dbConnectionEntity, tbLanguage dbLanguage)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_Language_Del";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_vcLanguageCode", MySqlDbType.VarChar, 8).Value = dbLanguage.vcLanguageCode;
                    command.Parameters.Add("@p_vcKeyText", MySqlDbType.VarChar, 64).Value = dbLanguage.vcKeyText;
                    command.Parameters.Add("@p_tiAbbreviated", MySqlDbType.Bit).Value = dbLanguage.tiAbbreviated;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLanguage.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LanguageImage_Sel (언어[다국어]이미지 목록)
        /// <summary>
        /// 언어[다국어]이미지 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="dbLanguageImage"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_LanguageImage_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, tbLanguageImage dbLanguageImage)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_LanguageImage_Sel(?, ?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[3];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                paramArray[2] = new MySqlParameter("@p_vcLanguageCode", MySqlDbType.VarChar, 8)
                {
                    Value = dbLanguageImage.vcLanguageCode
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LanguageImage_Detail_Sel (언어[다국어]이미지 상세정보)
        /// <summary>
        /// 언어[다국어]이미지 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLanguageImage"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_LanguageImage_Detail_Sel(DBConnectionEntity dbConnectionEntity, tbLanguageImage dbLanguageImage)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_LanguageImage_Detail_Sel(?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[2];
                paramArray[0] = new MySqlParameter("@p_vcLanguageCode", MySqlDbType.VarChar, 8)
                {
                    Value = dbLanguageImage.vcLanguageCode
                };
                paramArray[1] = new MySqlParameter("@p_vcKeyImage", MySqlDbType.VarChar, 64)
                {
                    Value = dbLanguageImage.vcKeyImage
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LanguageImage_Ins (언어[다국어]이미지 등록)
        /// <summary>
        /// 언어[다국어]이미지 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLanguageImage"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LanguageImage_Ins(DBConnectionEntity dbConnectionEntity, tbLanguageImage dbLanguageImage)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LanguageImage_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_vcLanguageCode", MySqlDbType.VarChar, 8).Value = dbLanguageImage.vcLanguageCode;
                    command.Parameters.Add("@p_vcKeyImage", MySqlDbType.VarChar, 64).Value = dbLanguageImage.vcKeyImage;
                    command.Parameters.Add("@p_vcUrl", MySqlDbType.VarChar, 256).Value = dbLanguageImage.vcUrl;
                    command.Parameters.Add("@p_vcImage", MySqlDbType.VarChar, 128).Value = dbLanguageImage.vcImage;
                    command.Parameters.Add("@p_tiStatus", MySqlDbType.Bit).Value = dbLanguageImage.tiStatus;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLanguageImage.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LanguageImage_Upd (언어[다국어]이미지 수정)
        /// <summary>
        /// 언어[다국어]이미지 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLanguageImage"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LanguageImage_Upd(DBConnectionEntity dbConnectionEntity, tbLanguageImage dbLanguageImage)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LanguageImage_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_vcLanguageCode", MySqlDbType.VarChar, 8).Value = dbLanguageImage.vcLanguageCode;
                    command.Parameters.Add("@p_vcKeyImage", MySqlDbType.VarChar, 64).Value = dbLanguageImage.vcKeyImage;
                    command.Parameters.Add("@p_vcUrl", MySqlDbType.VarChar, 256).Value = dbLanguageImage.vcUrl;
                    command.Parameters.Add("@p_vcImage", MySqlDbType.VarChar, 128).Value = dbLanguageImage.vcImage;
                    command.Parameters.Add("@p_tiStatus", MySqlDbType.Bit).Value = dbLanguageImage.tiStatus;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLanguageImage.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LanguageImage_Del (언어[다국어]이미지 삭제)
        /// <summary>
        /// 언어[다국어]이미지 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLanguageImage"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LanguageImage_Del(DBConnectionEntity dbConnectionEntity, tbLanguageImage dbLanguageImage)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LanguageImage_Del";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_vcLanguageCode", MySqlDbType.VarChar, 8).Value = dbLanguageImage.vcLanguageCode;
                    command.Parameters.Add("@p_vcKeyImage", MySqlDbType.VarChar, 64).Value = dbLanguageImage.vcKeyImage;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLanguageImage.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_PrivateBoard_Sel (공지, 뉴스 등 게시판 목록)
        /// <summary>
        /// 공지, 뉴스 등 게시판 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="dbPrivateBoard"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_PrivateBoard_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, tbPrivateBoard dbPrivateBoard)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_PrivateBoard_Sel(?, ?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[3];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                paramArray[2] = new MySqlParameter("@p_tiType", MySqlDbType.Bit)
                {
                    Value = dbPrivateBoard.tiType
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_PrivateBoard_Detail_Sel (공지, 뉴스 등 게시판 상세정보)
        /// <summary>
        /// 공지, 뉴스 등 게시판 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbPrivateBoard"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_PrivateBoard_Detail_Sel(DBConnectionEntity dbConnectionEntity, tbPrivateBoard dbPrivateBoard)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_PrivateBoard_Detail_Sel(?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[2];
                paramArray[0] = new MySqlParameter("@p_biSeq", MySqlDbType.Int64)
                {
                    Value = dbPrivateBoard.biSeq
                };
                paramArray[1] = new MySqlParameter("@p_tiType", MySqlDbType.Bit)
                {
                    Value = dbPrivateBoard.tiType
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_PrivateBoard_Ins (공지, 뉴스 등 게시판 등록)
        /// <summary>
        /// 공지, 뉴스 등 게시판 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbPrivateBoard"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<PrivateBoardEntity>> DAL_PrivateBoard_Ins(DBConnectionEntity dbConnectionEntity, tbPrivateBoard dbPrivateBoard)
        {
            var getResult = new ResultEntity<PrivateBoardEntity>();
            var storedProcedure = "usp_PrivateBoard_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_tiType", MySqlDbType.Bit).Value = dbPrivateBoard.tiType;
                    command.Parameters.Add("@p_vcTitleKeyText", MySqlDbType.VarChar, 64).Value = dbPrivateBoard.vcTitleKeyText;
                    command.Parameters.Add("@p_vcDescriptKeyText", MySqlDbType.VarChar, 64).Value = dbPrivateBoard.vcDescriptKeyText;
                    command.Parameters.Add("@p_tiMain", MySqlDbType.Bit).Value = dbPrivateBoard.tiMain;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbPrivateBoard.iManagerSeq;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    var resultEntity = new PrivateBoardEntity()
                    {
                        biSeq = Int64.Parse(command.Parameters["@p_biSeq"].Value.ToString())
                    };
                    getResult.gClass = resultEntity;
                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_PrivateBoard_Upd (공지, 뉴스 등 게시판 수정)
        /// <summary>
        /// 공지, 뉴스 등 게시판 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbPrivateBoard"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_PrivateBoard_Upd(DBConnectionEntity dbConnectionEntity, tbPrivateBoard dbPrivateBoard)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_PrivateBoard_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Value = dbPrivateBoard.biSeq;
                    command.Parameters.Add("@p_tiType", MySqlDbType.Bit).Value = dbPrivateBoard.tiType;
                    command.Parameters.Add("@p_vcTitleKeyText", MySqlDbType.VarChar, 64).Value = dbPrivateBoard.vcTitleKeyText;
                    command.Parameters.Add("@p_vcDescriptKeyText", MySqlDbType.VarChar, 64).Value = dbPrivateBoard.vcDescriptKeyText;
                    command.Parameters.Add("@p_tiMain", MySqlDbType.Bit).Value = dbPrivateBoard.tiMain;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbPrivateBoard.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_PrivateBoard_Del (공지, 뉴스 등 게시판 삭제)
        /// <summary>
        /// 공지, 뉴스 등 게시판 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbPrivateBoard"></param>
        /// <returns></returns>
        public async Task<ResultEntity<DataSet>> DAL_PrivateBoard_Del(DBConnectionEntity dbConnectionEntity, tbPrivateBoard dbPrivateBoard)
        {
            var getResult = new ResultEntity<DataSet>();
            var storedProcedure = "Call usp_PrivateBoard_Del(?, ?, ?, ?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[5];
                paramArray[0] = new MySqlParameter("@p_biSeq", MySqlDbType.Int64)
                {
                    Value = dbPrivateBoard.biSeq
                };
                paramArray[1] = new MySqlParameter("@p_tiType", MySqlDbType.Bit)
                {
                    Value = dbPrivateBoard.tiType
                };
                paramArray[2] = new MySqlParameter("@p_iManagerSeq", MySqlDbType.Int32)
                {
                    Value = dbPrivateBoard.iManagerSeq
                };
                paramArray[3] = new MySqlParameter("@p_Result", MySqlDbType.Int32)
                {
                    Direction = ParameterDirection.Output
                };
                paramArray[4] = new MySqlParameter("@p_Msg", MySqlDbType.Text)
                {
                    Direction = ParameterDirection.Output
                };
                getResult.gClass = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                getResult.result = Int32.Parse(paramArray[3].Value.ToString());
                getResult.ErrorMsg = paramArray[4].Value.ToString();
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_PrivateBoardData_Sel (공지, 뉴스 등 게시판 데이터 목록)
        /// <summary>
        /// 공지, 뉴스 등 게시판 데이터 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="dbPrivateBoardData"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_PrivateBoardData_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, tbPrivateBoardData dbPrivateBoardData)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_PrivateBoardData_Sel(?, ?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[3];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                paramArray[2] = new MySqlParameter("@p_biPrivateBoardSeq", MySqlDbType.Int64)
                {
                    Value = dbPrivateBoardData.biPrivateBoardSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_PrivateBoardData_Detail_Sel (공지, 뉴스 등 게시판 데이터 상세정보)
        /// <summary>
        /// 공지, 뉴스 등 게시판 데이터 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbPrivateBoardData"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_PrivateBoardData_Detail_Sel(DBConnectionEntity dbConnectionEntity, tbPrivateBoardData dbPrivateBoardData)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_PrivateBoardData_Detail_Sel(?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[2];
                paramArray[0] = new MySqlParameter("@p_biSeq", MySqlDbType.Int64)
                {
                    Value = dbPrivateBoardData.biSeq
                };
                paramArray[1] = new MySqlParameter("@p_biPrivateBoardSeq", MySqlDbType.Int64)
                {
                    Value = dbPrivateBoardData.biPrivateBoardSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_PrivateBoardData_Ins (공지, 뉴스 등 게시판 데이터 등록)
        /// <summary>
        /// 공지, 뉴스 등 게시판 데이터 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbPrivateBoardData"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<PrivateBoardDataEntity>> DAL_PrivateBoardData_Ins(DBConnectionEntity dbConnectionEntity, tbPrivateBoardData dbPrivateBoardData)
        {
            var getResult = new ResultEntity<PrivateBoardDataEntity>();
            var storedProcedure = "usp_PrivateBoardData_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biPrivateBoardSeq", MySqlDbType.Int64).Value = dbPrivateBoardData.biPrivateBoardSeq;
                    command.Parameters.Add("@p_vcFileName", MySqlDbType.VarChar, 32).Value = dbPrivateBoardData.vcFileName;
                    command.Parameters.Add("@p_vcSaveFolder", MySqlDbType.VarChar, 128).Value = dbPrivateBoardData.vcSaveFolder;
                    command.Parameters.Add("@p_vcSaveName", MySqlDbType.VarChar, 32).Value = dbPrivateBoardData.vcSaveName;
                    command.Parameters.Add("@p_vcSaveType", MySqlDbType.VarChar, 8).Value = dbPrivateBoardData.vcSaveType;
                    command.Parameters.Add("@p_iSaveSize", MySqlDbType.Int32).Value = dbPrivateBoardData.iSaveSize;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbPrivateBoardData.iManagerSeq;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    var resultEntity = new PrivateBoardDataEntity()
                    {
                        biSeq = Int64.Parse(command.Parameters["@p_biSeq"].Value.ToString())
                    };
                    getResult.gClass = resultEntity;
                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_PrivateBoardData_Upd (공지, 뉴스 등 게시판 데이터 수정)
        /// <summary>
        /// 공지, 뉴스 등 게시판 데이터 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbPrivateBoardData"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_PrivateBoardData_Upd(DBConnectionEntity dbConnectionEntity, tbPrivateBoardData dbPrivateBoardData)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_PrivateBoardData_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Value = dbPrivateBoardData.biSeq;
                    command.Parameters.Add("@p_biPrivateBoardSeq", MySqlDbType.Int64).Value = dbPrivateBoardData.biPrivateBoardSeq;
                    command.Parameters.Add("@p_vcFileName", MySqlDbType.VarChar, 32).Value = dbPrivateBoardData.vcFileName;
                    command.Parameters.Add("@p_vcSaveFolder", MySqlDbType.VarChar, 128).Value = dbPrivateBoardData.vcSaveFolder;
                    command.Parameters.Add("@p_vcSaveName", MySqlDbType.VarChar, 32).Value = dbPrivateBoardData.vcSaveName;
                    command.Parameters.Add("@p_vcSaveType", MySqlDbType.VarChar, 8).Value = dbPrivateBoardData.vcSaveType;
                    command.Parameters.Add("@p_iSaveSize", MySqlDbType.Int32).Value = dbPrivateBoardData.iSaveSize;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbPrivateBoardData.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_PrivateBoardData_Del (공지, 뉴스 등 게시판 데이터 삭제)
        /// <summary>
        /// 공지, 뉴스 등 게시판 데이터 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbPrivateBoardData"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_PrivateBoardData_Del(DBConnectionEntity dbConnectionEntity, tbPrivateBoardData dbPrivateBoardData)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_PrivateBoardData_Del";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Value = dbPrivateBoardData.biSeq;
                    command.Parameters.Add("@p_biPrivateBoardSeq", MySqlDbType.Int64).Value = dbPrivateBoardData.biPrivateBoardSeq;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbPrivateBoardData.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_CompanyGroup_Sel (회사조직[분류] 목록)
        /// <summary>
        /// 회사조직[분류] 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_CompanyGroup_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_CompanyGroup_Sel(?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[2];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_CompanyGroup_Detail_Sel (회사조직[분류] 상세정보)
        /// <summary>
        /// 회사조직[분류] 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbCompanyGroup"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_CompanyGroup_Detail_Sel(DBConnectionEntity dbConnectionEntity, tbCompanyGroup dbCompanyGroup)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_CompanyGroup_Detail_Sel(?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[1];
                paramArray[0] = new MySqlParameter("@p_iSeq", MySqlDbType.Int32)
                {
                    Value = dbCompanyGroup.iSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ usp_CompanyGroup_Ins (회사조직[분류] 등록)
        /// <summary>
        /// 회사조직[분류] 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbCompanyGroup"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<CompanyGroupEntity>> usp_CompanyGroup_Ins(DBConnectionEntity dbConnectionEntity, tbCompanyGroup dbCompanyGroup)
        {
            var getResult = new ResultEntity<CompanyGroupEntity>();
            var storedProcedure = "usp_CompanyGroup_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 32).Value = dbCompanyGroup.vcName;
                    command.Parameters.Add("@p_vcNameKeyText", MySqlDbType.VarChar, 64).Value = dbCompanyGroup.vcNameKeyText;
                    command.Parameters.Add("@p_vcAbbreviation", MySqlDbType.VarChar, 128).Value = dbCompanyGroup.vcAbbreviation;
                    command.Parameters.Add("@p_vcAbbreviationKeyText", MySqlDbType.VarChar, 64).Value = dbCompanyGroup.vcAbbreviationKeyText;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbCompanyGroup.iManagerSeq;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    var resultEntity = new CompanyGroupEntity()
                    {
                        iSeq = Int32.Parse(command.Parameters["@p_iSeq"].Value.ToString())
                    };
                    getResult.gClass = resultEntity;
                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ usp_CompanyGroup_Upd (회사조직[분류] 수정)
        /// <summary>
        /// 회사조직[분류] 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbCompanyGroup"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> usp_CompanyGroup_Upd(DBConnectionEntity dbConnectionEntity, tbCompanyGroup dbCompanyGroup)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_CompanyGroup_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbCompanyGroup.iSeq;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 32).Value = dbCompanyGroup.vcName;
                    command.Parameters.Add("@p_vcNameKeyText", MySqlDbType.VarChar, 64).Value = dbCompanyGroup.vcNameKeyText;
                    command.Parameters.Add("@p_vcAbbreviation", MySqlDbType.VarChar, 128).Value = dbCompanyGroup.vcAbbreviation;
                    command.Parameters.Add("@p_vcAbbreviationKeyText", MySqlDbType.VarChar, 64).Value = dbCompanyGroup.vcAbbreviationKeyText;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbCompanyGroup.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_CompanyGroup_Del (회사조직[분류] 삭제)
        /// <summary>
        /// 회사조직[분류] 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbCompanyGroup"></param>
        /// <returns></returns>
        public async Task<ResultEntity<DataSet>> DAL_CompanyGroup_Del(DBConnectionEntity dbConnectionEntity, tbCompanyGroup dbCompanyGroup)
        {
            var getResult = new ResultEntity<DataSet>();
            var storedProcedure = "Call usp_CompanyGroup_Del(?, ?, ?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[4];
                paramArray[0] = new MySqlParameter("@p_iSeq", MySqlDbType.Int32)
                {
                    Value = dbCompanyGroup.iSeq
                };
                paramArray[1] = new MySqlParameter("@p_iManagerSeq", MySqlDbType.Int32)
                {
                    Value = dbCompanyGroup.iManagerSeq
                };
                paramArray[2] = new MySqlParameter("@p_Result", MySqlDbType.Int32)
                {
                    Direction = ParameterDirection.Output
                };
                paramArray[3] = new MySqlParameter("@p_Msg", MySqlDbType.Text)
                {
                    Direction = ParameterDirection.Output
                };
                getResult.gClass = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                getResult.result = Int32.Parse(paramArray[2].Value.ToString());
                getResult.ErrorMsg = paramArray[3].Value.ToString();
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_CompanyPeople_Sel (회사조직구성원 목록)
        /// <summary>
        /// 회사조직구성원 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="dbCompanyPeople"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_CompanyPeople_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, tbCompanyPeople dbCompanyPeople)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_CompanyPeople_Sel(?, ?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[3];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                paramArray[2] = new MySqlParameter("@p_iCompanyGroupSeq", MySqlDbType.Int32)
                {
                    Value = dbCompanyPeople.iCompanyGroupSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_CompanyPeople_Detail_Sel (회사조직구성원 상세정보)
        /// <summary>
        /// 회사조직구성원 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbCompanyPeople"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_CompanyPeople_Detail_Sel(DBConnectionEntity dbConnectionEntity, tbCompanyPeople dbCompanyPeople)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_CompanyPeople_Detail_Sel(?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[2];
                paramArray[0] = new MySqlParameter("@p_iSeq", MySqlDbType.Int32)
                {
                    Value = dbCompanyPeople.iSeq
                };
                paramArray[1] = new MySqlParameter("@p_iCompanyGroupSeq", MySqlDbType.Int32)
                {
                    Value = dbCompanyPeople.iCompanyGroupSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ usp_CompanyPeople_Ins (회사조직구성원 등록)
        /// <summary>
        /// 회사조직구성원 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbCompanyPeople"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<CompanyPeopleEntity>> usp_CompanyPeople_Ins(DBConnectionEntity dbConnectionEntity, tbCompanyPeople dbCompanyPeople)
        {
            var getResult = new ResultEntity<CompanyPeopleEntity>();
            var storedProcedure = "usp_CompanyPeople_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_iCompanyGroupSeq", MySqlDbType.Int32).Value = dbCompanyPeople.iCompanyGroupSeq;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 32).Value = dbCompanyPeople.vcName;
                    command.Parameters.Add("@p_vcPosition", MySqlDbType.VarChar, 64).Value = dbCompanyPeople.vcPosition;
                    command.Parameters.Add("@p_tDescription", MySqlDbType.Text).Value = dbCompanyPeople.tDescription;
                    command.Parameters.Add("@p_vcFolder", MySqlDbType.VarChar, 256).Value = dbCompanyPeople.vcFolder;
                    command.Parameters.Add("@p_vcImage", MySqlDbType.VarChar, 128).Value = dbCompanyPeople.vcImage;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbCompanyPeople.iManagerSeq;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    var resultEntity = new CompanyPeopleEntity()
                    {
                        iSeq = Int32.Parse(command.Parameters["@p_iSeq"].Value.ToString())
                    };
                    getResult.gClass = resultEntity;
                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ usp_CompanyPeople_Upd (회사조직구성원 수정)
        /// <summary>
        /// 회사조직구성원 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbCompanyPeople"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> usp_CompanyPeople_Upd(DBConnectionEntity dbConnectionEntity, tbCompanyPeople dbCompanyPeople)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_CompanyPeople_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbCompanyPeople.iSeq;
                    command.Parameters.Add("@p_iCompanyGroupSeq", MySqlDbType.Int32).Value = dbCompanyPeople.iCompanyGroupSeq;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 32).Value = dbCompanyPeople.vcName;
                    command.Parameters.Add("@p_vcPosition", MySqlDbType.VarChar, 64).Value = dbCompanyPeople.vcPosition;
                    command.Parameters.Add("@p_tDescription", MySqlDbType.Text).Value = dbCompanyPeople.tDescription;
                    command.Parameters.Add("@p_vcFolder", MySqlDbType.VarChar, 256).Value = dbCompanyPeople.vcFolder;
                    command.Parameters.Add("@p_vcImage", MySqlDbType.VarChar, 128).Value = dbCompanyPeople.vcImage;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbCompanyPeople.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ usp_CompanyPeople_Del (회사조직구성원 삭제)
        /// <summary>
        /// 회사조직구성원 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbCompanyPeople"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> usp_CompanyPeople_Del(DBConnectionEntity dbConnectionEntity, tbCompanyPeople dbCompanyPeople)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_CompanyPeople_Del";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbCompanyPeople.iSeq;
                    command.Parameters.Add("@p_iCompanyGroupSeq", MySqlDbType.Int32).Value = dbCompanyPeople.iCompanyGroupSeq;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbCompanyPeople.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Blog_Sel (블로그 목록)
        /// <summary>
        /// 블로그 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_Blog_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_Blog_Sel(?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[2];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Blog_Detail_Sel (블로그 상세정보)
        /// <summary>
        /// 블로그 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbBlog"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_Blog_Detail_Sel(DBConnectionEntity dbConnectionEntity, tbBlog dbBlog)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_Blog_Detail_Sel(?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[1];
                paramArray[0] = new MySqlParameter("@p_biSeq", MySqlDbType.Int64)
                {
                    Value = dbBlog.biSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ usp_Blog_Ins (블로그 등록)
        /// <summary>
        /// 블로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbBlog"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<BlogEntity>> usp_Blog_Ins(DBConnectionEntity dbConnectionEntity, tbBlog dbBlog)
        {
            var getResult = new ResultEntity<BlogEntity>();
            var storedProcedure = "usp_Blog_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_vcTitle", MySqlDbType.VarChar, 128).Value = dbBlog.vcTitle;
                    command.Parameters.Add("@p_vcTitleFolder", MySqlDbType.VarChar, 256).Value = dbBlog.vcTitleFolder;
                    command.Parameters.Add("@p_vcTitleImage", MySqlDbType.VarChar, 128).Value = dbBlog.vcTitleImage;
                    command.Parameters.Add("@p_tDescription", MySqlDbType.Text).Value = dbBlog.tDescription;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbBlog.iManagerSeq;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    var resultEntity = new BlogEntity()
                    {
                        biSeq = Int64.Parse(command.Parameters["@p_biSeq"].Value.ToString())
                    };
                    getResult.gClass = resultEntity;
                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ usp_Blog_Upd (블로그 수정)
        /// <summary>
        /// 블로그 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbBlog"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> usp_Blog_Upd(DBConnectionEntity dbConnectionEntity, tbBlog dbBlog)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_Blog_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Value = dbBlog.biSeq;
                    command.Parameters.Add("@p_vcTitle", MySqlDbType.VarChar, 128).Value = dbBlog.vcTitle;
                    command.Parameters.Add("@p_vcTitleFolder", MySqlDbType.VarChar, 256).Value = dbBlog.vcTitleFolder;
                    command.Parameters.Add("@p_vcTitleImage", MySqlDbType.VarChar, 128).Value = dbBlog.vcTitleImage;
                    command.Parameters.Add("@p_tDescription", MySqlDbType.Text).Value = dbBlog.tDescription;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbBlog.iManagerSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Blog_Del (블로그 삭제)
        /// <summary>
        /// 블로그 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbBlog"></param>
        /// <returns></returns>
        public async Task<ResultEntity<DataSet>> DAL_Blog_Del(DBConnectionEntity dbConnectionEntity, tbBlog dbBlog)
        {
            var getResult = new ResultEntity<DataSet>();
            var storedProcedure = "Call usp_Blog_Del(?, ?, ?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[4];
                paramArray[0] = new MySqlParameter("@p_biSeq", MySqlDbType.Int64)
                {
                    Value = dbBlog.biSeq
                };
                paramArray[1] = new MySqlParameter("@p_iManagerSeq", MySqlDbType.Int32)
                {
                    Value = dbBlog.iManagerSeq
                };
                paramArray[2] = new MySqlParameter("@p_Result", MySqlDbType.Int32)
                {
                    Direction = ParameterDirection.Output
                };
                paramArray[3] = new MySqlParameter("@p_Msg", MySqlDbType.Text)
                {
                    Direction = ParameterDirection.Output
                };
                getResult.gClass = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                getResult.result = Int32.Parse(paramArray[2].Value.ToString());
                getResult.ErrorMsg = paramArray[3].Value.ToString();
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_BlogComment_Sel (블로그 댓글 목록)
        /// <summary>
        /// 블로그 댓글 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="dbBlogComment"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_BlogComment_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, tbBlogComment dbBlogComment)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_BlogComment_Sel(?, ?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[3];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                paramArray[2] = new MySqlParameter("@p_biBlogSeq", MySqlDbType.Int64)
                {
                    Value = dbBlogComment.biBlogSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_BlogLike_Sel (블로그 좋아요 목록)
        /// <summary>
        /// 블로그 좋아요 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <param name="dbBlogLike"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_BlogLike_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity, tbBlogLike dbBlogLike)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_BlogLike_Sel(?, ?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.CrawlingDBConnection))
            {
                var paramArray = new MySqlParameter[3];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                paramArray[2] = new MySqlParameter("@p_biBlogSeq", MySqlDbType.Int64)
                {
                    Value = dbBlogLike.biBlogSeq
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion



    }
    #endregion

}
