import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})

export class ConfigService
{
    // 개발서버
    // static PROTOCOL = 'http';
    // static URL = '192.168.0.251';
    // static PORT = '20002';

    // 강현석PC(디버그용)
    // static PROTOCOL = 'https';
    // static URL = 'localhost';
    // static PORT = '44321';

    // 강현석PC(테스트)
    static PROTOCOL = 'http';
    static URL = '192.168.0.25';
    static PORT = '20001';
    
    static CRYPT_KEY = 'SpiderKimManager(!@#$%^&*1234567890)';
    
    uiSettings: any = {layout: {navbar: 'none'}};

    public onSettingsChange: BehaviorSubject<any>;

    constructor()
    {
        this.onSettingsChange = new BehaviorSubject(this.uiSettings);
    }

    public setSettings(settings: any)
    {
        this.uiSettings = Object.assign({}, this.uiSettings, settings);
        this.onSettingsChange.next(this.uiSettings);
    }
}
