﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lib.Crawling.Library.Entities.Account
{

    #region // !++ MemberEntity
    /// <summary>
    /// 회원기본정보
    /// </summary>
    [Serializable]
    public class MemberEntity
    {

        /// <summary>
        /// 회원 고유번호
        /// </summary>
        public Int64 biSeq { get; set; }

        /// <summary>
        /// 플랫폼 고유번호
        /// </summary>
        public Int32 iPlatFormSeq { get; set; }

        /// <summary>
        /// GUID(Globally-Unique Identifier : 플랫폼일 경우 플랫폼 고유번호, 자체일 경우 Guid.NewGuid())
        /// </summary>
        public String vcGuid { get; set; }

        /// <summary>
        /// E-mail
        /// </summary>
        public String vcEmail { get; set; }

        /// <summary>
        /// 이름(또는 회사명)
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 생년월일(년도)
        /// </summary>
        public String cBirthYear { get; set; }

        /// <summary>
        /// 생년월일(월)
        /// </summary>
        public String cBirthMonth { get; set; }

        /// <summary>
        /// 생년월일(날짜)
        /// </summary>
        public String cBirthDay { get; set; }

        /// <summary>
        /// 성별(1:남성, 2:여성, 3:모름[정보없음])
        /// </summary>
        public Int16 tiGender { get; set; }

        /// <summary>
        /// 단체여부(1:개인, 2:단체[기업])
        /// </summary>
        public Int16 tiOrganization { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public MemberEntity()
        {
            biSeq = 0;
            iPlatFormSeq = 0;
            vcGuid = String.Empty;
            vcEmail = String.Empty;
            vcName = String.Empty;
            cBirthYear = String.Empty;
            cBirthMonth = String.Empty;
            cBirthDay = String.Empty;
            tiGender = 0;
            tiOrganization = 0;
            dtRegDate = DateTime.MinValue;
        }
        ~MemberEntity()
        {
            biSeq = 0;
            iPlatFormSeq = 0;
            vcGuid = String.Empty;
            vcEmail = String.Empty;
            vcName = String.Empty;
            cBirthYear = String.Empty;
            cBirthMonth = String.Empty;
            cBirthDay = String.Empty;
            tiGender = 0;
            tiOrganization = 0;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ MemberDetailEntity
    /// <summary>
    /// 회원상세정보
    /// </summary>
    [Serializable]
    public class MemberDetailEntity
    {

        /// <summary>
        /// 회원고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// 국가코드
        /// </summary>
        public Int16 siCountrySeq { get; set; }

        /// <summary>
        /// 도시
        /// </summary>
        public String vcCity { get; set; }

        /// <summary>
        /// 우편번호
        /// </summary>
        public String vcZipCode { get; set; }

        /// <summary>
        /// 주소
        /// </summary>
        public String vcAddressFront { get; set; }

        /// <summary>
        /// 상세주소
        /// </summary>
        public String vcAddressBack { get; set; }

        /// <summary>
        /// 회원등급
        /// </summary>
        public Int16 tiMemberGrade { get; set; }

        /// <summary>
        /// 회원상태(0:미인증, 1:정상, 2:블럭, 3:...)
        /// 플랫폼 가입일 경우 1(정상)
        /// 자체 가입일 경우 미인증(인증 메일 발송)
        /// </summary>
        public Int16 tiMemberStatus { get; set; }

        /// <summary>
        /// 메일수신여부(1:동의, 2:비동의)
        /// </summary>
        public Int16 tiEmailAgree { get; set; }

        /// <summary>
        /// 문자수신여부(1:동의, 2:비동의)
        /// </summary>
        public Int16 tiSmsAgress { get; set; }

        

        public MemberDetailEntity()
        {
            biMemberSeq = 0;
            siCountrySeq = 0;
            vcCity = String.Empty;
            vcZipCode = String.Empty;
            vcAddressFront = String.Empty;
            vcAddressBack = String.Empty;
            tiMemberGrade = 0;
            tiMemberStatus = 0;
            tiEmailAgree = 0;
            tiSmsAgress = 0;
        }
        ~MemberDetailEntity()
        {
            biMemberSeq = 0;
            siCountrySeq = 0;
            vcCity = String.Empty;
            vcZipCode = String.Empty;
            vcAddressFront = String.Empty;
            vcAddressBack = String.Empty;
            tiMemberGrade = 0;
            tiMemberStatus = 0;
            tiEmailAgree = 0;
            tiSmsAgress = 0;
        }

    }
    #endregion


    #region // !++ MemberContactEntity
    /// <summary>
    /// 회원연락처
    /// </summary>
    [Serializable]
    public class MemberContactEntity
    {

        /// <summary>
        /// 회원고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// 연락처(국가코드)
        /// </summary>
        public String vcPhoneCountry { get; set; }

        /// <summary>
        /// 연락처(첫자리)
        /// </summary>
        public String vcPhoneFirst { get; set; }

        /// <summary>
        /// 연락처(가운데)
        /// </summary>
        public String vcPhoneSecond { get; set; }

        /// <summary>
        /// 연락처(마지막)
        /// </summary>
        public String vcPhoneThird { get; set; }

        /// <summary>
        /// 핸드폰(첫자리)
        /// </summary>
        public String vcMobileFirst { get; set; }

        /// <summary>
        /// 핸드폰(가운데)
        /// </summary>
        public String vcMobileSecond { get; set; }

        /// <summary>
        /// 핸드폰(마지막)
        /// </summary>
        public String vcMobileThird { get; set; }

        public MemberContactEntity()
        {
            biMemberSeq = 0;
            vcPhoneCountry = String.Empty;
            vcPhoneFirst = String.Empty;
            vcPhoneSecond = String.Empty;
            vcPhoneThird = String.Empty;
            vcMobileFirst = String.Empty;
            vcMobileSecond = String.Empty;
            vcMobileThird = String.Empty;
        }
        ~MemberContactEntity()
        {
            biMemberSeq = 0;
            vcPhoneCountry = String.Empty;
            vcPhoneFirst = String.Empty;
            vcPhoneSecond = String.Empty;
            vcPhoneThird = String.Empty;
            vcMobileFirst = String.Empty;
            vcMobileSecond = String.Empty;
            vcMobileThird = String.Empty;
        }

    }
    #endregion


    #region // !++ MemberPasswordEntity
    /// <summary>
    /// 회원비밀번호
    /// </summary>
    [Serializable]
    public class MemberPasswordEntity
    {

        /// <summary>
        /// 회원고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// 비밀번호(Hash암호화)
        /// </summary>
        public String vcPassword { get; set; }

        /// <summary>
        /// 최근접속일시
        /// </summary>
        public DateTime dtLoginDate { get; set; }

        /// <summary>
        /// 정보수정일
        /// </summary>
        public DateTime dtModifyDate { get; set; }

        public MemberPasswordEntity()
        {
            biMemberSeq = 0;
            vcPassword = String.Empty;
            dtLoginDate = DateTime.MinValue;
            dtModifyDate = DateTime.MinValue;
        }
        ~MemberPasswordEntity()
        {
            biMemberSeq = 0;
            vcPassword = String.Empty;
            dtLoginDate = DateTime.MinValue;
            dtModifyDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ MemberOrganizationEntity
    /// <summary>
    /// 회원(단체)정보
    /// </summary>
    [Serializable]
    public class MemberOrganizationEntity
    {

        /// <summary>
        /// 회원고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// 담당자명
        /// </summary>
        public String vcPersonName { get; set; }

        /// <summary>
        /// 업종
        /// </summary>
        public String vcBusiness { get; set; }

        /// <summary>
        /// 사업자번호
        /// </summary>
        public String vcOrganizationSerial { get; set; }

        public MemberOrganizationEntity()
        {
            biMemberSeq = 0;
            vcPersonName = String.Empty;
            vcBusiness = String.Empty;
            vcOrganizationSerial = String.Empty;
        }
        ~MemberOrganizationEntity()
        {
            biMemberSeq = 0;
            vcPersonName = String.Empty;
            vcBusiness = String.Empty;
            vcOrganizationSerial = String.Empty;
        }

    }
    #endregion


    #region // !++ MemberEmailAuthEntity
    /// <summary>
    /// 회원Email인증
    /// </summary>
    [Serializable]
    public class MemberEmailAuthEntity
    {

        /// <summary>
        /// 회원고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// E-mail
        /// </summary>
        public String vcEmail { get; set; }

        /// <summary>
        /// 인증정보(발송메일 인증문자)
        /// </summary>
        public String vcAuth { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        /// <summary>
        /// 인증일시
        /// </summary>
        public DateTime dtAuthDate { get; set; }

        public MemberEmailAuthEntity()
        {
            biMemberSeq = 0;
            vcEmail = String.Empty;
            vcAuth = String.Empty;
            dtRegDate = DateTime.MinValue;
            dtAuthDate = DateTime.MinValue;
        }
        ~MemberEmailAuthEntity()
        {
            biMemberSeq = 0;
            vcEmail = String.Empty;
            vcAuth = String.Empty;
            dtRegDate = DateTime.MinValue;
            dtAuthDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ MemberLoginEntity
    /// <summary>
    /// 회원 로그인 정보
    /// </summary>
    [Serializable]
    public class MemberLoginEntity
    {

        /// <summary>
        /// 회원고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// 플랫폼 고유번호
        /// </summary>
        public Int32 iPlatFormSeq { get; set; }

        /// <summary>
        /// E-mail
        /// </summary>
        public String vcEmail { get; set; }

        /// <summary>
        /// 이름(또는 회사명)
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 단체여부(1:개인, 2:단체[기업])
        /// </summary>
        public Int16 tiOrganization { get; set; }

        /// <summary>
        /// 회원등급
        /// </summary>
        public Int16 tiMemberGrade { get; set; }

        /// <summary>
        /// 회원상태
        /// </summary>
        public Int16 tiMemberStatus { get; set; }

        /// <summary>
        /// 최근접속일시
        /// </summary>
        public DateTime dtLoginDate { get; set; }

        /// <summary>
        /// 로그인 여부
        /// </summary>
        public Boolean isLogin { get; set; }

        public MemberLoginEntity()
        {
            biMemberSeq = 0;
            iPlatFormSeq = 0;
            vcEmail = String.Empty;
            vcName = String.Empty;
            tiOrganization = 0;
            tiMemberGrade = 0;
            tiMemberStatus = 0;
            dtLoginDate = DateTime.MinValue;
            isLogin = false;
        }
        ~MemberLoginEntity()
        {
            biMemberSeq = 0;
            iPlatFormSeq = 0;
            vcEmail = String.Empty;
            vcName = String.Empty;
            tiOrganization = 0;
            tiMemberGrade = 0;
            tiMemberStatus = 0;
            dtLoginDate = DateTime.MinValue;
            isLogin = false;
        }

    }
    #endregion


    #region // !++ MemberLoginFormEntity
    /// <summary>
    /// 회원 로그인 정보
    /// </summary>
    [Serializable]
    public class MemberLoginFormEntity
    {

        /// <summary>
        /// 플랫폼 고유번호
        /// </summary>
        public Int32 iPlatFormSeq { get; set; }

        /// <summary>
        /// E-mail
        /// </summary>
        public String vcEmail { get; set; }

        /// <summary>
        /// 비밀번호(Hash암호화)
        /// </summary>
        public String vcPassword { get; set; }

        public MemberLoginFormEntity()
        {
            iPlatFormSeq = 0;
            vcEmail = String.Empty;
            vcPassword = String.Empty;
        }
        ~MemberLoginFormEntity()
        {
            iPlatFormSeq = 0;
            vcEmail = String.Empty;
            vcPassword = String.Empty;
        }

    }
    #endregion


    #region // !++ MemberLoginTokenEntity
    /// <summary>
    /// 회원 로그인 토큰 정보
    /// </summary>
    [Serializable]
    public class MemberLoginTokenEntity
    {

        /// <summary>
        /// Token 정보
        /// </summary>
        public String Token { get; set; }

        /// <summary>
        /// Token 만료일
        /// </summary>
        public DateTime? ExpiredDate { get; set; }

        public MemberLoginTokenEntity()
        {
            Token = String.Empty;
            ExpiredDate = null;
        }
        ~MemberLoginTokenEntity()
        {
            Token = String.Empty;
            ExpiredDate = null;
        }

    }
    #endregion


    #region // !++ AuthEmailEntity
    /// <summary>
    /// 인증(발송) 메일 데이터
    /// </summary>
    [Serializable]
    public class AuthEmailEntity
    {

        /// <summary>
        /// 회원고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// E-mail
        /// </summary>
        public String vcEmail { get; set; }

        /// <summary>
        /// 인증정보(발송메일 인증문자)
        /// </summary>
        public String vcAuth { get; set; }

        /// <summary>
        /// 만료일시
        /// </summary>
        public DateTime dtExpireDate { get; set; }

        public AuthEmailEntity()
        {
            biMemberSeq = 0;
            vcEmail = String.Empty;
            vcAuth = String.Empty;
            dtExpireDate = DateTime.MinValue;
        }
        ~AuthEmailEntity()
        {
            biMemberSeq = 0;
            vcEmail = String.Empty;
            vcAuth = String.Empty;
            dtExpireDate = DateTime.MinValue;
        }

    }
    #endregion


    #region // !++ MemberEmailApprovalEntity
    /// <summary>
    /// 회원 E-mail 인증
    /// </summary>
    [Serializable]
    public class MemberEmailApprovalEntity
    {

        /// <summary>
        /// 회원고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// E-mail
        /// </summary>
        public String vcEmail { get; set; }

        /// <summary>
        /// 회원상태(0:미인증, 1:정상, 2:블럭, 3:...)
        /// 플랫폼 가입일 경우 1(정상)
        /// 자체 가입일 경우 미인증(인증 메일 발송)
        /// </summary>
        public Int16 tiMemberStatus { get; set; }

        /// <summary>
        /// 인증정보(발송메일 인증문자)
        /// </summary>
        public String vcAuth { get; set; }

        public MemberEmailApprovalEntity()
        {
            biMemberSeq = 0;
            vcEmail = String.Empty;
            tiMemberStatus = 0;
            vcAuth = String.Empty;
        }
        ~MemberEmailApprovalEntity()
        {
            biMemberSeq = 0;
            vcEmail = String.Empty;
            tiMemberStatus = 0;
            vcAuth = String.Empty;
        }

    }
    #endregion


    #region // !++ AuthKeyEntity
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    public class AuthKeyEntity
    {

        /// <summary>
        /// 인증코드
        /// </summary>
        public String authKey { get; set; }

        public AuthKeyEntity()
        {
            authKey = String.Empty;
        }
        ~AuthKeyEntity()
        {
            authKey = String.Empty;
        }

    }
    #endregion


    #region // !++ MemberEmailAuthApprovalEntity
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    public class MemberEmailAuthApprovalEntity
    {

        /// <summary>
        /// 회원 이름
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 회원 E-mail
        /// </summary>
        public String vcEmail { get; set; }

        public MemberEmailAuthApprovalEntity()
        {
            vcName = String.Empty;
            vcEmail = String.Empty;
        }
        ~MemberEmailAuthApprovalEntity()
        {
            vcName = String.Empty;
            vcEmail = String.Empty;
        }

    }
    #endregion


    #region // !++ MemberRegistEntity
    /// <summary>
    /// 회원가입 정보 : 개인회원
    /// </summary>
    [Serializable]
    public class MemberRegistEntity
    {

        /// <summary>
        /// 플랫폼 고유번호
        /// </summary>
        public Int32 iPlatFormSeq { get; set; }

        /// <summary>
        /// E-mail
        /// </summary>
        public String vcEmail { get; set; }

        /// <summary>
        /// 비밀번호(Hash암호화)
        /// </summary>
        public String vcPassword { get; set; }

        /// <summary>
        /// 이름(또는 회사명)
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 생년월일(년도)
        /// </summary>
        public String cBirthYear { get; set; }

        /// <summary>
        /// 생년월일(월)
        /// </summary>
        public String cBirthMonth { get; set; }

        /// <summary>
        /// 생년월일(날짜)
        /// </summary>
        public String cBirthDay { get; set; }

        /// <summary>
        /// 성별(1:남성, 2:여성, 3:모름[정보없음])
        /// </summary>
        public Int16 tiGender { get; set; }

        /// <summary>
        /// 단체여부(1:개인, 2:단체[기업])
        /// </summary>
        public Int16 tiOrganization { get; set; }

        public MemberRegistEntity()
        {
            iPlatFormSeq = 0;
            vcEmail = String.Empty;
            vcPassword = String.Empty;
            vcName = String.Empty;
            cBirthYear = String.Empty;
            cBirthMonth = String.Empty;
            cBirthDay = String.Empty;
            tiGender = 0;
            tiOrganization = 0;
        }
        ~MemberRegistEntity()
        {
            iPlatFormSeq = 0;
            vcEmail = String.Empty;
            vcPassword = String.Empty;
            vcName = String.Empty;
            cBirthYear = String.Empty;
            cBirthMonth = String.Empty;
            cBirthDay = String.Empty;
            tiGender = 0;
            tiOrganization = 0;
        }

    }
    #endregion


    #region // !++ MemberOrganizationRegistEntity
    /// <summary>
    /// 회원가입 : 기업회원 정보
    /// </summary>
    [Serializable]
    public class MemberOrganizationRegistEntity
    {

        /// <summary>
        /// 담당자명
        /// </summary>
        public String vcPersonName { get; set; }

        /// <summary>
        /// 업종
        /// </summary>
        public String vcBusiness { get; set; }

        /// <summary>
        /// 사업자번호
        /// </summary>
        public String vcOrganizationSerial { get; set; }

        public MemberOrganizationRegistEntity()
        {
            vcPersonName = String.Empty;
            vcBusiness = String.Empty;
            vcOrganizationSerial = String.Empty;
        }
        ~MemberOrganizationRegistEntity()
        {
            vcPersonName = String.Empty;
            vcBusiness = String.Empty;
            vcOrganizationSerial = String.Empty;
        }

    }
    #endregion


    #region // !++ MemberRegistSuccessEntity
    /// <summary>
    /// 회원가입 1단계 완료
    /// </summary>
    [Serializable]
    public class MemberRegistSuccessEntity
    {

        /// <summary>
        /// 이름(또는 회사명)
        /// </summary>
        public String name { get; set; }

        /// <summary>
        /// E-mail
        /// </summary>
        public String email { get; set; }

        public MemberRegistSuccessEntity()
        {
            name = String.Empty;
            email = String.Empty;
        }
        ~MemberRegistSuccessEntity()
        {
            name = String.Empty;
            email = String.Empty;
        }

    }
    #endregion


    #region // !++ ProhibitWordsEntity
    /// <summary>
    /// 금지어
    /// </summary>
    [Serializable]
    public class ProhibitWordsEntity
    {

        /// <summary>
        /// 사용불가문자
        /// </summary>
        public String vcProhibitWords { get; set; }

        /// <summary>
        /// 비고(노트)
        /// </summary>
        public String vcNote { get; set; }

        /// <summary>
        /// 사용여부(1:사용, 2:대기)
        /// </summary>
        public Int16 tiStatus { get; set; }

        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        public ProhibitWordsEntity()
        {
            vcProhibitWords = String.Empty;
            vcNote = String.Empty;
            tiStatus = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }
        ~ProhibitWordsEntity()
        {
            vcProhibitWords = String.Empty;
            vcNote = String.Empty;
            tiStatus = 0;
            iManagerSeq = 0;
            dtRegDate = DateTime.MinValue;
        }

    }
    #endregion

}
