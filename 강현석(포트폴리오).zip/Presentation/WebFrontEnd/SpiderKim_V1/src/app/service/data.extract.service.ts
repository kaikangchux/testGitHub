import { Injectable, EventEmitter, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { CommonService } from './common.service';

@Injectable({
    providedIn: 'root'
})
export class DataExtractService implements OnDestroy
{
    evtEmitterWorkflow = new EventEmitter();    
    evtEmitterWorkflowSub:Subscription;

    evtEmitterWindow = new EventEmitter(); 
    evtEmitterWindowSub:Subscription;

    activeWorkWindow:boolean = false;

    constructor(private router:Router,
                private cmnService:CommonService,
                private http:HttpClient){ }

    extractRequest(reqUrl:string):Observable<any>
    {
        const url = this.cmnService.requestUrl('/api/Crawling/targeturi');
        return this.http.post(url, {targetUrl:reqUrl});
    }

    onEventEmiteDisplayWorkflow(param:any) {
        this.evtEmitterWorkflow.emit(param);
    }

    onEventEmitActivateWorkWindow(param:any)
    {
        this.activeWorkWindow = param;
        this.evtEmitterWindow.emit(param);
    }

    ngOnDestroy():void {
        if(this.evtEmitterWorkflowSub){
            this.evtEmitterWorkflowSub.unsubscribe();
        }

        if(this.evtEmitterWindowSub){
            this.evtEmitterWindowSub.unsubscribe();
        }
    }
}