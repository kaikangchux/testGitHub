import { Component } from '@angular/core';
import { Subscription } from 'rxjs';
import { ConfigService } from '../config/config.service';

@Component({
    selector: 'app-content',
    templateUrl: './contents.component.html',
    styleUrls: []
})

export class ContentsComponent{}