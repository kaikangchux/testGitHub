import { ClientErrorDb } from './client.error.db';

describe('ClientErrorDb', () => {
  it('should create an instance', () => {
    expect(new ClientErrorDb()).toBeTruthy();
  });
});
