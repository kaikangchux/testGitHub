﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lib.Crawling.Library.Models.CrawlingDB
{

    #region // !++ tbCrawlerRecord
    /// <summary>
    /// 클로링 성공여부
    /// </summary>
    [Table("tbCrawlerRecord")]
    public class tbCrawlerRecord
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        /// <summary>
        /// 회원 고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// 데이터수집 성공 수
        /// </summary>
        public Int32 iSuccess { get; set; }

        /// <summary>
        /// 데이터수집 실패 수
        /// </summary>
        public Int32 iFail { get; set; }

    }
    #endregion

}
