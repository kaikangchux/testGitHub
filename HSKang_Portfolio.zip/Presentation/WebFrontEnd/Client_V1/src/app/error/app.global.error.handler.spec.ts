import { AppGlobalErrorhandler } from './app.global.error.handler';

describe('AppGlobalErrorhandler', () => {
  it('should create an instance', () => {
    expect(new AppGlobalErrorhandler()).toBeTruthy();
  });
});
