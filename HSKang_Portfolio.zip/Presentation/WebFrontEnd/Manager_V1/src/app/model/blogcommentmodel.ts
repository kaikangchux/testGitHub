// 블로그 댓글
export class BlogCommentModel
{

  biSeq: number;
  biBlogSeq: number;
  biMemberSeq: number;
  vcAccount: string;
  vcName: string;
  tDescription: string;
  vcIP: string;
  dtRegDate: string;

  constructor() {
    this.biSeq = 0;
    this.biBlogSeq = 0;
    this.biMemberSeq = 0;
    this.vcAccount = '';
    this.vcName = '';
    this.tDescription = '';
    this.vcIP = '';
    this.dtRegDate = '';
  }

}
