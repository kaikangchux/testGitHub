﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lib.Crawling.Library.Enum
{

    #region // !++ EResultCode
    /// <summary>
    /// 결과 코드를 값으로 가지는 Enum.
    /// 성공시 양수, 실패시 음수의 형태를 가지고 있다.
    /// 10000(일만) 초과시 Server, 미만시 DB에서 발생하는 코드이다.
    /// ※10000은 사용하지 않도록 한다.
    /// </summary>
    public enum EResultCode
    {
        /// <summary>
        /// 초기값
        /// </summary>
        None = 0,

        #region //!++ Success

        #region //!+ DB Success
        /// <summary>
        /// [DB] 일반적인 성공
        /// </summary>
        Success_DB_Normal = 1,
        #endregion //!+ End DB Success


        #region //!+ Server Success
        /// <summary>
        /// [Server] 일반적인 성공
        /// </summary>
        Success_Server_Normal = 10001,
        #endregion //!+ End Server Success

        #endregion //!++ End Success


        #region //!++ Error

        #region //!+ DB Error
        /// <summary>
        /// 알수없는 오류
        /// </summary>
        Error_DB_Unknown = -1,

        /// <summary>
        /// 예외 오류
        /// </summary>
        Error_DB_Exception = -2,

        /// <summary>
        /// DataTable.Count 오류
        /// </summary>
        Error_DB_DataTableCount = -3,

        /// <summary>
        /// 파라미터 오류
        /// </summary>
        Error_DB_ParameterEmpty = -4,

        /// <summary>
        /// 이미 사용중인 값 오류
        /// </summary>
        Error_DB_AlreadyUsing = -5,

        /// <summary>
        /// 트랜잭션 롤백 오류
        /// </summary>
        Error_DB_TransactionRollback = -6,

        /// <summary>
        /// 저장프로시저 내부 오류
        /// </summary>
        Error_DB_StoredProcedureFail = -7,

        /// <summary>
        /// 값 찾을 수 없는 오류
        /// </summary>
        Error_DB_NotFound = -8,

        /// <summary>
        /// 불일치 오류
        /// </summary>
        Error_DB_Discord = -9,

        /// <summary>
        /// 사용 거부 오류
        /// </summary>
        Error_DB_UseDeny = -10,

        /// <summary>
        /// 내부함수 오류 1~10
        /// </summary>
        Error_DB_Function_1 = -101,
        Error_DB_Function_2 = -102,
        Error_DB_Function_3 = -103,
        Error_DB_Function_4 = -104,
        Error_DB_Function_5 = -105,
        Error_DB_Function_6 = -106,
        Error_DB_Function_7 = -107,
        Error_DB_Function_8 = -108,
        Error_DB_Function_9 = -109,
        Error_DB_Function_10 = -110,
        #endregion //!+ End DB Error


        #region //!+ Server Error
        /// <summary>
        /// 알수없는 오류
        /// </summary>
        Error_Server_Unknown = -10001,

        /// <summary>
        /// 예외 오류
        /// </summary>
        Error_Server_Exception = -10002,

        /// <summary>
        /// SetDataEntity 오류
        /// </summary>
        Error_Server_SetDataEntity = -10003,

        /// <summary>
        /// 파라미터 오류
        /// </summary>
        Error_Server_ParameterEmpty = -10004,

        /// <summary>
        /// Pim 오류
        /// </summary>
        Error_Server_Pim = -10005,

        Error_Server_Serialize = -10006,
        #endregion //!+ End Server Error

        #endregion //!++ End Error

        /// <summary>
        /// 편집이 용이하도록 만든 임시 변수
        /// </summary>
        Test = -99999
    }
    #endregion


    #region // !++ LogActionType
    /// <summary>
    /// 로그 Enum
    /// </summary>
    public enum LogActionType
    {

        None = 0,
        Insert = 1,
        Update = 2,
        Delete = 3,

    }
    #endregion


    #region // !++ LogManagerLoginType
    /// <summary>
    /// 관리자 접속 타입
    /// </summary>
    public enum LogManagerLoginType
    {
        None = 0,
        Login = 1,
        Logout = 2,
    }
    #endregion

}
