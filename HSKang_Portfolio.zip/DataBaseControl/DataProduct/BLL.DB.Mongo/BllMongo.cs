﻿using System;
using System.Threading.Tasks;
using System.Collections.Generic;

using Lib.Crawling.Library.Enum;
using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Mongo;
using Lib.Crawling.Library.DataContainers;
using Lib.Crawling.Library.Log;

using MongoDB.Driver;

namespace BLL.DB.Mongo
{

    #region // !++ BllMongo
    /// <summary>
    /// BllMongo
    /// </summary>
    public class BllMongo : DataProvider.DataProvider
    {

        #region // !++ Mongo DB Init

        #region // !++ SetMongoDBConnector (MongoDB connection)
        /// <summary>
        /// MongoDB connection
        /// </summary>
        /// <param name="mongoDbConnectionEntity"></param>
        /// <returns></returns>
        public static Boolean SetMongoDBConnector(MongoDbConnectionEntity mongoDbConnectionEntity)
        {

            Boolean result;

            try
            {

                result = dalMongo.mongoConnect(mongoDbConnectionEntity);

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Error, "SetMongoDBConnector Error : \n [MongoDbConnectionEntity:{0}], \n {1}, \n {2}",
                                            libUtility.ToJson(mongoDbConnectionEntity), exc.Message, exc.StackTrace);

                result = false;
                return result;
            }

            return result;

        }


        /// <summary>
        /// MongoDB connection
        /// </summary>
        /// <param name="mongoDbConnectionEntity"></param>
        /// <returns></returns>
        public static Boolean SetMongoDBConnector(List<MongoDbConnectionDictionaryEntity> mongoConnList)
        {

            Boolean result;

            try
            {

                result = dalMongo.mongoConnect(mongoConnList);

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Error, "SetMongoDBConnector Error : \n [MongoDbConnectionDictionaryEntity:{0}], \n {1}, \n {2}",
                                                   libUtility.ToJson(mongoConnList), exc.Message, exc.StackTrace);

                result = false;
                return result;
            }

            return result;

        }
        #endregion

        #endregion


        #region // !++ GetMongoDataSearchFilter (Mongo 데잍 검색 필터)
        /// <summary>
        /// Mongo 데잍 검색 필터
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="searchList"></param>
        /// <returns></returns>
        internal static FilterDefinition<T> GetMongoDataSearchFilter<T>(List<MongoDBSearchEntity> searchList)
        {

            // Return value
            FilterDefinition<T> result = null;

            try
            {

                #region // !++ Filter 설정
                var builder = Builders<T>.Filter;
                #endregion

                #region // !++ 검색 필터
                if (searchList == null)
                {
                    result = null;
                }
                else
                {
                    if (searchList.Count == 0)
                    {
                        result = null;
                    }
                    else
                    {
                        for (int i = 0; i < searchList.Count; i++)
                        {
                            if (i == 0)
                            {
                                switch (searchList[i].fieldName)
                                {
                                    case "_i_t":
                                        result = builder.Gte(searchList[i].fieldName, Int64.Parse(searchList[i].fieldValue)) & builder.Lte(searchList[i].fieldName, Int64.Parse(searchList[i].fieldValue2));
                                        break;
                                    case "server":
                                    case "char_idx":
                                    case "party_data.char_idx":
                                    case "battle_data.char_idx":
                                    case "mon_idx":
                                        result = builder.Eq(searchList[i].fieldName, Int32.Parse(searchList[i].fieldValue));
                                        break;
                                    case "clan_id":
                                        result = builder.Eq(searchList[i].fieldName, Int64.Parse(searchList[i].fieldValue));
                                        break;
                                    default:
                                        result = builder.Eq(searchList[i].fieldName, searchList[i].fieldValue);
                                        break;
                                }
                            }
                            else
                            {
                                switch (searchList[i].fieldName)
                                {
                                    case "_i_t":
                                        result = result & builder.Gte(searchList[i].fieldName, Int64.Parse(searchList[i].fieldValue)) & builder.Lte(searchList[i].fieldName, Int64.Parse(searchList[i].fieldValue2));
                                        break;
                                    case "server":
                                    case "char_idx":
                                    case "party_data.char_idx":
                                    case "battle_data.char_idx":
                                    case "mon_idx":
                                        result = result & builder.Eq(searchList[i].fieldName, Int32.Parse(searchList[i].fieldValue));
                                        break;
                                    case "clan_id":
                                        result = result & builder.Eq(searchList[i].fieldName, Int64.Parse(searchList[i].fieldValue));
                                        break;
                                    default:
                                        result = result & builder.Eq(searchList[i].fieldName, searchList[i].fieldValue);
                                        break;
                                }
                            }
                        }
                    }
                }
                #endregion

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Error, "GetMongoDataSearchFilter Error : \n [MongoDBSearchEntity:{0}], \n {1}, \n {2}",
                                                    libUtility.ToJson(searchList), exc.Message, exc.StackTrace);

                return result;
            }

            return result;

        }
        #endregion

    }
    #endregion

}
