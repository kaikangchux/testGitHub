﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration;

using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Manager;
using Lib.Crawling.Library.Log;

namespace WebApi_SpiderKim_V1.Handlers
{

    #region // !++ StaticDataHandler
    /// <summary>
    /// StaticDataHandler
    /// </summary>
    public class StaticDataHandler : Handler
    {

        #region // !++ Default static DBConnectionString
        private readonly IConfiguration _config;
        public static String _defaultDBConnectionString;

        public StaticDataHandler()
        {

        }

        public StaticDataHandler(IConfiguration config)
        {
            _config = config;
        }

        public String GetDefaultDBConnection()
        {
            if (String.IsNullOrEmpty(_defaultDBConnectionString))
            {
                var _conn = _config.GetConnectionString("DefaultConnection");
                SetDBMSInfo(_conn);
            }
            return _defaultDBConnectionString;
        }

        public static void SetDefaultDBConnection(String dbConnection)
        {
            try
            {
                _defaultDBConnectionString = String.Empty;
                _defaultDBConnectionString = dbConnection;
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetDefaultDBConnection : \n [dbConnection:{0}], \n {1}, \n {2}",
                                        dbConnection, exc.Message, exc.StackTrace);
            }
        }

        #region // !++ GetSpiderKimManagerSettings
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public SpiderKimManagerSettings GetSpiderKimManagerSettings()
        {

            var returnData = new SpiderKimManagerSettings();

            try
            {

                returnData.DomainName = _config.GetSection("SpiderKimManagerSettings").GetSection("DomainName").Value;
                returnData.DomainUrl = _config.GetSection("SpiderKimManagerSettings").GetSection("DomainUrl").Value;
                returnData.DomainCookie = _config.GetSection("SpiderKimManagerSettings").GetSection("DomainCookie").Value;
                returnData.DomainMapPath = _config.GetSection("SpiderKimManagerSettings").GetSection("DomainMapPath").Value;

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetSpiderKimManagerSettings : \n {0}, \n {1}",
                                        exc.Message, exc.StackTrace);
                return null;
            }

            return returnData;
        }
        #endregion

        #endregion


        #region // !++ DBMS 정보 호출(생성)
        /// <summary>
        /// DBMS 정보 호출(생성)
        /// </summary>
        /// <returns></returns>
        public static void SetDBMSInfo(String dbConnection)
        {

            try
            {
                _defaultDBConnectionString = dbConnection;
                // dbStaticInfo.Initialize(dbConnection);
                Task.Run(() => dbStaticInfo.Initialize(dbConnection));
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetDBMSInfo : \n [dbConnection:{0}], \n {1}, \n {2}",
                                        dbConnection, exc.Message, exc.StackTrace);
            }

        }
        #endregion


        #region // !++ GetDataBaseConnection
        /// <summary>
        /// DB 연결문자 가져오기
        /// </summary>
        /// <param name="dbConnection"></param>
        /// <returns></returns>
        public DBConnectionEntity GetDataBaseConnection()
        {

            var dbConnection = GetDefaultDBConnection();
            var resultConnection = new DBConnectionEntity();

            try
            {
                resultConnection = dbStaticInfo.GetDataBaseConnection(dbConnection);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetDataBaseConnection : \n [dbConnection:{0}], \n {1}, \n {2}",
                                        dbConnection, exc.Message, exc.StackTrace);
                resultConnection = null;
            }
            return resultConnection;
        }
        #endregion

    }
    #endregion

}
