import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard-main',
  templateUrl: './dashboard.main.component.html',
  styleUrls: ['./dashboard.main.component.scss']
})
export class DashboardMainComponent {
    
     gaugeValues():string | number { //TODO
          return 21;
     }
}  
