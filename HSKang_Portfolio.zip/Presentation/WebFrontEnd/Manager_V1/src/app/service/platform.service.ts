import { Injectable, EventEmitter, OnDestroy } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/internal/Observable';

import { CommonService } from './common.service';
import { ResultServerData, ResultServerDatalist } from '../common';
import { PlatFormModel, PlatFormApiModel } from '../model';

@Injectable({
    providedIn: 'root'
})

export class PlatFormService implements OnDestroy
{

    // PlatForm
    platformList:PlatFormModel[] = [];
    platformDetail:PlatFormModel;

    // PlatForm Api
    platformapiList:PlatFormApiModel[] = [];
    platformapiDetail:PlatFormApiModel;

    constructor(private router:Router,
        private cmnService:CommonService,
        private http:HttpClient){}


    // PlatForm
    changePlatFormList(platformList:PlatFormModel[])
    {
        this.platformList = platformList;
    }

    // 목록
    getPlatFormList(page:number, pageSize:number):Observable<any>
    {
        const url = this.cmnService.requestUrl(`/api/PlatForm/PlatFormList?page=${page}&pageSize=${pageSize}`);
        return this.http.get<ResultServerData<ResultServerDatalist<PlatFormModel[]>>>(url);
    }

    // 상세정보
    getPlatFormDetail(iSeq:number):Observable<any>
    {
        const url = this.cmnService.requestUrl(`/api/PlatForm/PlatFormDetail/${iSeq}`);
        return this.http.get<ResultServerData<ResultServerDatalist<PlatFormModel>>>(url);
    }

    // 등록 및 수정
    regEditPlatForm(mPlatForm:PlatFormModel, isAdd:boolean):Observable<any>
    {
        const urlStr = (isAdd) ? `/api/PlatForm/PlatFormregist` : `/api/PlatForm/PlatFormmodify`;
        const url = this.cmnService.requestUrl(urlStr);

        return this.http[(isAdd) ? 'post' : 'put'](url, mPlatForm);
    }

    // 삭제
    deletePlatForm(iSeq:number):Observable<any>
    {
        const url = this.cmnService.requestUrl(`/api/PlatForm/platformdelete/${iSeq}`);
        return this.http.delete<ResultServerData<ResultServerDatalist<number>>>(url);
    }


    // PlatForm Api
    changePlatFormApi(platformapiList:PlatFormApiModel[]){
        this.platformapiList = platformapiList;
    }

    // 목록
    getPlatFormApi(page:number, pageSize:number):Observable<any>
    {
        const url = this.cmnService.requestUrl(`/api/PlatForm/PlatFormApiList?page=${page}&pageSize=${pageSize}`);
        return this.http.get<ResultServerData<ResultServerDatalist<PlatFormApiModel[]>>>(url);
    }

    // 상세정보
    getPlatFormApiDetail(iSeq:number):Observable<any>
    {
        const url = this.cmnService.requestUrl(`/api/PlatForm/PlatFormApiDetail/${iSeq}`);
        return this.http.get<ResultServerData<ResultServerDatalist<PlatFormApiModel>>>(url);
    }

    // 등록 및 수정
    regEditPlatFormApi(mFaq:PlatFormApiModel, isAdd:boolean):Observable<any>
    {
        const urlStr = (isAdd) ? `/api/PlatForm/PlatFormApiregist` : `/api/PlatForm/PlatFormApimodify`;
        const url = this.cmnService.requestUrl(urlStr);

        return this.http[(isAdd) ? 'post' : 'put'](url, mFaq);
    }

    // 삭제
    deletePlatFormApi(iSeq:number, iPlatFormSeq:number):Observable<any>
    {
        const url = this.cmnService.requestUrl(`/api/PlatForm/platformapidelete/${iSeq}/${iPlatFormSeq}`);
        return this.http.delete<ResultServerData<ResultServerDatalist<number>>>(url);
    }

    ngOnDestroy():void{
        
    }
}