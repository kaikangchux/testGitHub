import {Component, OnInit} from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TranslationLoaderService } from './service/translationLoader.service';

import { locale as localeEnglish } from './i18n/en';
import { locale as localeKorea } from './i18n/kr';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit
{
    constructor(private translate:TranslateService, 
                private translationLoader:TranslationLoaderService){

        this.translate.addLangs(['en', 'kr']);

        this.translate.setDefaultLang('kr');
        this.translationLoader.loadTranslations(localeEnglish, localeKorea);

        this.translate.use('kr');
    }

    ngOnInit():void {
        
    }
}