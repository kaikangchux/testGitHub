import { Component } from '@angular/core';

@Component({
  selector: 'app-home-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.scss']
})
export class CompanyComponent {

}  
