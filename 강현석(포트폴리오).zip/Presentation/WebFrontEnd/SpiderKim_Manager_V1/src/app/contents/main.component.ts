import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';

import { ConfigService } from '../config';
import { ManagerService } from '../service';

@Component({
    selector: 'app-main',
    templateUrl: './main.component.html',
    styleUrls: []
})

export class MainComponent
{
    settingsWatcher:Subscription;
    uiSettings: any = {
        layout: {
            navbar: 'none'
        }
    };

    constructor(private config:ConfigService,
                private mService: ManagerService){

        this.settingsWatcher = 
            this.config.onSettingsChange.subscribe((newSettings) => {
                this.uiSettings = newSettings;
            });
    }
}