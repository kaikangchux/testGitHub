import { Component, ViewChild, ElementRef, OnInit, OnDestroy } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
import { DataExtractService } from '../service';
import { DomSanitizer } from '@angular/platform-browser';
import { TranslateService } from '@ngx-translate/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard-extract-url',
  templateUrl: './dashboard.extract.url.component.html',
  styleUrls: ['./dashboard.extract.url.component.scss']
})
export class DataExtractURLComponent implements OnInit, OnDestroy
{
    url:string = 'https://www.amazon.com/s/browse?_encoding=UTF8&node=16225007011&ref_=nav_shopall-export_nav_mw_sbd_intl_computers';

    @ViewChild('iframe', {static: false}) iframe: ElementRef;

    constructor(private dataExtractService:DataExtractService, 
                private spinnerService:NgxSpinnerService,
                private sanitizer:DomSanitizer,
                private translate:TranslateService,
                private router: Router){
    }

    ngOnInit():void{
    }

    extract():void
    {
        this.spinnerService.show();

        let regEx = /^(http:\/\/|https:\/\/)/;
        var match = regEx.test(this.url);

        if(!match){
            alert(this.translate.instant('ERROR.INVALID_URL'));
            return;
        }

        this.dataExtractService.extractRequest(this.url).subscribe(
            (res) => {
                this.router.navigate(['./dashboard/extractdata'], {skipLocationChange: true, state: {data: {contents:this.sanitizer.bypassSecurityTrustHtml(res.data)}}});
            },
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        )
    }

    ngOnDestroy():void{
    }
}