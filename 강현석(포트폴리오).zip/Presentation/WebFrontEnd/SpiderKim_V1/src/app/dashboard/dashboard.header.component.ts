import { Component } from '@angular/core';
import { MemberService } from '../service';
import { TranslateService } from '@ngx-translate/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { MemberModel } from '../model';

@Component({
  selector: 'app-dashboard-header',
  templateUrl: './dashboard.header.component.html',
  styleUrls: ['./dashboard.header.component.scss']
})
export class DashboardHeaderComponent
{
    notifyServiceRemain:SafeHtml;
    memberInfo:MemberModel = new MemberModel();
    memberEmail:string;

    constructor(private memberService:MemberService, 
                private translate:TranslateService,
                private sanitized: DomSanitizer){

        let tmp = this.translate.instant('DASHBOARD.NOTIFY_SERVICE_REMAIN');
        this.notifyServiceRemain = this.sanitized.bypassSecurityTrustHtml(tmp.replace(/#/gi, `<span class='color'>${7}</span>`));//TODO
        //TODO 임시로 표시함
        this.memberInfo.vcEmail = 'abced@gmail.com';
        this.memberEmail = this.memberInfo.vcEmail;
    }

    logout():void {
        this.memberService.logout();
    }
}  
