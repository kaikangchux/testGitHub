﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Account;
using Lib.Crawling.Library.DataContainers;
using Lib.Crawling.Library.Log;

namespace WebApi_SpiderKim_Manager_V1.Handlers
{

    #region // !++ AccountHandler
    /// <summary>
    /// AccountHandler
    /// </summary>
    public class AccountHandler : Handler
    {

        #region // !++ GetMemberList (회원 정보 목록)
        /// <summary>
        /// 회원 정보 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns></returns>
        public static async Task<ListPageDataContainer<List<MemberEntity>>> GetMemberList(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<MemberEntity>>();

            try
            {
                // DB호출
                resultDataContainer = await bllAccount.BLL_Manager_Member_Sel(dbConnectionEntity, pageDBEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetMemberList : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), exc.Message, exc.StackTrace);

                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion

    }
    #endregion

}
