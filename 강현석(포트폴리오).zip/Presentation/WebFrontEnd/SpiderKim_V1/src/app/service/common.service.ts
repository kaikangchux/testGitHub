import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ConfigService } from '../config/config.service';

@Injectable({
    providedIn: 'root'
})

export class CommonService
{
    constructor(private http:HttpClient){}

    public requestUrl(url:string){
        return `${ConfigService.PROTOCOL}://${ConfigService.URL}:${ConfigService.PORT}${url}`;
    }

    public getIP():Promise<any>
    {
        return fetch('https://jsonip.com')
            .then(function(response) {
                return response.json();
            });
    }

    public getLasyDay(y:number, m:number) {
        return new Date(y, m, 0).getDate();
    }
}