﻿using System;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Query;


using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Manager;
using Lib.Crawling.Library.Models.ManagerDB;

using MySql.Data;
using MySql.Data.MySqlClient;

using Dapper;

using System.Data.Common;

namespace DAL.Crawling.Manager
{

    #region // !++ DalManager
    /// <summary>
    /// DalManager
    /// </summary>
    public class DalManager
    {


        #region // !++ EF_Manager_Login_Sel Test
        [Obsolete("테스트 함수 입니다. 다른 함수를 사용하세요.", true)]
        public async Task<ResultEntity<ManagerEntity>> EF_Manager_Login_Sel(DBConnectionEntity dbConnectionEntity, tbManager dbManager)
        {

            var param = new MySqlParameter()
            {
                ParameterName = "@p_vcManagerID",
                MySqlDbType = MySqlDbType.VarChar,
                Direction = ParameterDirection.Input,
                Size = 32,
                Value = dbManager.vcManagerID
            };

            var storedProcedure = "usp_Manager_Login_Sel";

            using (var connection = new MySqlConnection(dbConnectionEntity.ManagerDBConnection))
            {
                var para = new DynamicParameters();
                para.Add("@p_vcManagerID", dbManager.vcManagerID, DbType.String, ParameterDirection.Input, 32);
                await connection.OpenAsync();
                await connection.ExecuteAsync(storedProcedure, para, null, 0, commandType: CommandType.StoredProcedure);
                await connection.CloseAsync();

                await connection.QueryAsync<tbManager>(storedProcedure, para, null, 0, commandType: CommandType.StoredProcedure);
                connection.Query<tbManager>(storedProcedure, para, null, true, 0, commandType: CommandType.StoredProcedure).FirstOrDefault();
            }

            return null;

        }
        #endregion




        #region // !++ DAL_Manager_Login_Sel (관리자 계정 로그인)
        /// <summary>
        /// 관리자 계정 로그인
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbManager"></param>
        /// <returns></returns>
        public async Task<ResultEntity<ManagerEntity>> DAL_Manager_Login_Sel(DBConnectionEntity dbConnectionEntity, tbManager dbManager)
        {

            var getResult = new ResultEntity<ManagerEntity>();
            var storedProcedure = "usp_Manager_Login_Sel";
            using (var connection = new MySqlConnection(dbConnectionEntity.ManagerDBConnection))
            {

                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_vcManagerID", MySqlDbType.VarChar, 32).Value = dbManager.vcManagerID;
                    command.Parameters.Add("@p_vcPassword", MySqlDbType.VarChar, 64).Value = dbManager.vcPassword;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_tiGrade", MySqlDbType.Byte).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteNonQueryAsync();
                    await command.Connection.CloseAsync();

                    var gClass = new ManagerEntity()
                    {
                        iSeq = Int32.Parse(command.Parameters["@p_iSeq"].Value.ToString()),           // 관리자 고유번호
                        vcManagerID = dbManager.vcManagerID,                                      // 관리자 계정
                        vcName = command.Parameters["@p_vcName"].Value.ToString(),                    // 관리자 이름
                        tiGrade = Int16.Parse(command.Parameters["@p_tiGrade"].Value.ToString())      // 관리자 등급
                    };
                    getResult.gClass = gClass;
                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());    // Error Code
                }
            }
            return getResult;

        }
        #endregion


        #region // !++ DAL_Manager_Sel (관리자 계정 목록 조회)
        /// <summary>
        /// 관리자 계정 목록 조회
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_Manager_Sel(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_Manager_Sel(?, ?)";
            using (var connection = new MySqlConnection(dbConnectionEntity.ManagerDBConnection))
            {
                var paramArray = new MySqlParameter[2];
                paramArray[0] = new MySqlParameter("@p_Page", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.page
                };
                paramArray[1] = new MySqlParameter("@p_PageSize", MySqlDbType.Int32)
                {
                    Value = pageDBEntity.pageSize
                };
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Manager_Detail_Sel (관리자 계정 상세조회)
        /// <summary>
        /// 관리자 계정 상세조회
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbManager"></param>
        /// <returns></returns>
        public async Task<ResultEntity<ManagerEntity>> DAL_Manager_Detail_Sel(DBConnectionEntity dbConnectionEntity, tbManager dbManager)
        {
            var getResult = new ResultEntity<ManagerEntity>();
            var storedProcedure = "usp_Manager_Detail_Sel";
            using (var connection = new MySqlConnection(dbConnectionEntity.ManagerDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbManager.iSeq;
                    command.Parameters.Add("@p_vcManagerID", MySqlDbType.VarChar, 32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_vcEmailID", MySqlDbType.VarChar, 64).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_vcEmailAddress", MySqlDbType.VarChar, 128).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_vcPhone", MySqlDbType.VarChar, 16).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_tiGrade", MySqlDbType.Byte).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_dtRegDate", MySqlDbType.DateTime).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteNonQueryAsync();
                    await command.Connection.CloseAsync();

                    var managerEntities = new ManagerEntity()
                    {
                        iSeq = dbManager.iSeq,                                                            // 관리자 고유번호
                        vcManagerID = command.Parameters["@p_vcManagerID"].Value.ToString(),              // 관리자 계정
                        vcName = command.Parameters["@p_vcName"].Value.ToString(),                        // 관리자 이름
                        vcEmailID = command.Parameters["@p_vcEmailID"].Value.ToString(),                  // 관리자 E-Mail ID
                        vcEmailAddress = command.Parameters["@p_vcEmailAddress"].Value.ToString(),        // 관리자 E-Mail 주소
                        vcPhone = command.Parameters["@p_vcPhone"].Value.ToString(),                      // 관리자 연락처
                        tiGrade = Int16.Parse(command.Parameters["@p_tiGrade"].Value.ToString()),         // 관리자 등급
                        vcIP = command.Parameters["@p_vcIP"].Value.ToString(),                            // 관리자 접속IP
                        dtRegDate = DateTime.Parse(command.Parameters["@p_dtRegDate"].Value.ToString())   // 관리자 등록일
                    };
                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());      // Error Code
                    getResult.gClass = managerEntities;

                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Manager_IDCheck_Sel (관리자 계정 중복 조회)
        /// <summary>
        /// 관리자 계정 중복 조회
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbManager"></param>
        /// <returns>
        ///  1: 성공        (Success_DB_Normal),
        /// -4: 데이터 없음 (Error_DB_NoData),
        /// -5: 이미 사용중 (Error_DB_AlreadyUsing)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_Manager_IDCheck_Sel(DBConnectionEntity dbConnectionEntity, tbManager dbManager)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_Manager_IDCheck_Sel";
            using (var connection = new MySqlConnection(dbConnectionEntity.ManagerDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_vcManagerID", MySqlDbType.VarChar, 32).Value = dbManager.vcManagerID;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Manager_Ins (관리자 계정 등록)
        /// <summary>
        /// 관리자 계정 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbManager"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<ManagerEntity>> DAL_Manager_Ins(DBConnectionEntity dbConnectionEntity, tbManager dbManager)
        {
            var getResult = new ResultEntity<ManagerEntity>();
            var storedProcedure = "usp_Manager_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.ManagerDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_vcManagerID", MySqlDbType.VarChar, 32).Value = dbManager.vcManagerID;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 32).Value = dbManager.vcName;
                    command.Parameters.Add("@p_vcPassword", MySqlDbType.VarChar, 64).Value = dbManager.vcPassword;
                    command.Parameters.Add("@p_vcEmailID", MySqlDbType.VarChar, 64).Value = dbManager.vcEmailID;
                    command.Parameters.Add("@p_vcEmailAddress", MySqlDbType.VarChar, 128).Value = dbManager.vcEmailAddress;
                    command.Parameters.Add("@p_vcPhone", MySqlDbType.VarChar, 16).Value = dbManager.vcPhone;
                    command.Parameters.Add("@p_tiGrade", MySqlDbType.Byte).Value = dbManager.tiGrade;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbManager.vcIP;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    var resultEntity = new ManagerEntity()
                    {
                        iSeq = Int32.Parse(command.Parameters["@p_iSeq"].Value.ToString())
                    };
                    getResult.gClass = resultEntity;
                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Manager_Upd (관리자 계정 본인 수정)
        /// <summary>
        /// 관리자 계정 본인 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbManager"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback),
        /// -8: 찾을 수 없음  (Error_DB_NotFound)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_Manager_Upd(DBConnectionEntity dbConnectionEntity, tbManager dbManager)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_Manager_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.ManagerDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbManager.iSeq;
                    command.Parameters.Add("@p_vcPassword", MySqlDbType.VarChar, 64).Value = dbManager.vcPassword;
                    command.Parameters.Add("@p_vcEmailID", MySqlDbType.VarChar, 64).Value = dbManager.vcEmailID;
                    command.Parameters.Add("@p_vcEmailAddress", MySqlDbType.VarChar, 128).Value = dbManager.vcEmailAddress;
                    command.Parameters.Add("@p_vcPhone", MySqlDbType.VarChar, 16).Value = dbManager.vcPhone;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Manager_Grade_Upd (관리자 계정 등급 수정)
        /// <summary>
        /// 관리자 계정 등급 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbManager"></param>
        /// <returns>
        ///  1 : Success_DB_Normal
        /// -4 : Error_DB_ParameterEmpty
        /// -8 : Error_DB_NotFound
        /// -6 : Error_DB_TransactionRollback
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_Manager_Grade_Upd(DBConnectionEntity dbConnectionEntity, tbManager dbManager)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_Manager_Grade_Upd";
            using (var connection = new MySqlConnection(dbConnectionEntity.ManagerDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbManager.iSeq;
                    command.Parameters.Add("@p_tiGrade", MySqlDbType.Byte).Value = dbManager.tiGrade;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_Manager_Del (관리자 계정 삭제)
        /// <summary>
        /// 관리자 계정 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbManager"></param>
        /// <returns>
        ///  1 : Success_DB_Normal
        /// -4 : Error_DB_ParameterEmpty
        /// -6 : Error_DB_TransactionRollback
        /// -8 : Error_DB_NotFound
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_Manager_Del(DBConnectionEntity dbConnectionEntity, tbManager dbManager)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_Manager_Del";
            using (var connection = new MySqlConnection(dbConnectionEntity.ManagerDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbManager.iSeq;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_DataBase_Sel (DataBase 정보)
        /// <summary>
        /// DataBase 정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <returns></returns>
        public async Task<DataSet> DAL_DataBase_Sel(DBConnectionEntity dbConnectionEntity)
        {
            var getResult = new DataSet();
            var storedProcedure = "Call usp_DataBase_Sel";
            using (var connection = new MySqlConnection(dbConnectionEntity.ManagerDBConnection))
            {
                var paramArray = new MySqlParameter[0];
                getResult = await MySqlHelper.ExecuteDatasetAsync(connection, storedProcedure, paramArray);
                await connection.CloseAsync();
            }
            return getResult;
        }
        #endregion


    }
    #endregion

}
