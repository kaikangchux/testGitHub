// 회원기본정보
export class MemberModel
{

  biSeq: number;
  iPlatFormSeq: number;
  vcGuid: string;
  vcEmail: string;
  vcName: string;
  cBirthYear: string;
  cBirthMonth: string;
  cBirthDay: string;
  tiGender: number;
  tiOrganization: number;
  dtRegDate: string;

  constructor() {
    this.biSeq = 0;
    this.iPlatFormSeq = 0;
    this.vcGuid = '';
    this.vcEmail = '';
    this.vcName = '';
    this.cBirthYear = '';
    this.cBirthMonth = '';
    this.cBirthDay = '';
    this.tiGender = 0;
    this.tiOrganization = 0;
    this.dtRegDate = '';
  }
}
