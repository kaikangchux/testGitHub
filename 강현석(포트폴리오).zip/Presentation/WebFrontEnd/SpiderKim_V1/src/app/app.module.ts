import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';
import { HttpClientModule } from '@angular/common/http';
import { NgxSpinnerModule } from "ngx-spinner";
import { 
    MatMenuModule,
    MatButtonModule,
    MatSlideToggleModule
} from '@angular/material';
import {DragDropModule} from '@angular/cdk/drag-drop';
import { GaugeModule } from 'angular-gauge';

/**********************************************************************************/

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainComponent } from './main.component';
import { ContentsComponent } from './contents.component';
import { HeaderComponent, FooterComponent } from './cmnComp';
import { HomeComponent, CompanyComponent } from './webcontents';
import { 
    DashboardComponent, 
    DashboardHeaderComponent, 
    DashboardMainComponent, 
    DashboardNavigationComponent, 
    DataExtractURLComponent,
    DataExtractComponent,
    WorkflowHeaderComponent,
    WorkFlowMainComponent,
    WorkFlowSelfComponent,
    WorkFlowPreviewComponent,
    NodeComponent
} from './dashboard';
import { TranslationLoaderService, CookieManageService, MemberService, DataExtractService } from './service';
import { ConfigService } from './config';
import { ResizableDirective } from './helper';
import { AppGlobalErrorhandler } from './error';
import { 
    LoginComponent, 
    RegisterSelectComponent,
    RegisterCommonComponent,
    RegisterMemberComponent,
    RegisterOrganizationComponent,
    RegisterConfirmComponent,
    RegisterCompleteComponent,
} from './loginRegister';

@NgModule({
    declarations: [
        AppComponent,
        MainComponent,
        ContentsComponent,
        HeaderComponent,
        FooterComponent,
        HomeComponent,
        CompanyComponent,
        DashboardComponent,
        LoginComponent,
        RegisterSelectComponent,
        RegisterCommonComponent,
        RegisterMemberComponent,
        RegisterOrganizationComponent,
        RegisterConfirmComponent,
        RegisterCompleteComponent,
        DashboardHeaderComponent,
        DashboardMainComponent,
        DashboardNavigationComponent,
        DataExtractURLComponent,
        DataExtractComponent,
        WorkflowHeaderComponent,
        WorkFlowMainComponent,
        WorkFlowSelfComponent,
        WorkFlowPreviewComponent,
        ResizableDirective,
        NodeComponent
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        MatMenuModule,
        MatButtonModule,
        MatSlideToggleModule,
        DragDropModule,
        BrowserAnimationsModule,
        TranslateModule.forRoot(),
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        GaugeModule.forRoot(),
        NgxSpinnerModule
    ],
    exports:[
        MainComponent
    ],
    entryComponents: [ NodeComponent ],
    providers: [
        {provide:ErrorHandler, useClass:AppGlobalErrorhandler},
        TranslationLoaderService,
        ConfigService,
        CookieService,
        CookieManageService,
        MemberService,
        DataExtractService
    ],
    bootstrap: [AppComponent]
})

export class AppModule { }