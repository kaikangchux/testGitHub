export const locale = {
    lang : 'kr',
    data : {
        'TITLE' : {
            'LOGIN' : '관리자 로그인',
            'LIST'  : '관리자페이지 리스트',
            'VIEW'  : '관리자페이지 상세',
            'FAQCODE' : 'FAQ code 정보',
            'FAQ' : 'FAQ 정보',
            'PlATFORM' : 'Plat form 정보',
            'PlATFORMAPI' : 'Plat form api 정보',
            'MEMBER' : '회원 리스트'
        },
        'LOGIN' : {
            'LBL1' : 'Admin',
            'LBL2' : 'Login',
            'ID' : '아이디',
            'PW' : '비밀번호',
            'BTN' : '로그인',
            'ALT' : '스파이더킴로고'
        },
        'COMMON' : {
            'DETAIL' : 'DETAIL',
            'MODIFY' : 'MODIFY',
            'DELETE' : 'DELETE',
            'REGISTER' : 'REGISTER',
            'NODATA' : 'No data!!',
            'BUTTON' : {
                'REGIST' : 'Regist',
                'DETAIL' : 'Detail',
                'MODIFY' : 'Modify',
                'DELETE' : 'Delete',
                'RESET' : 'Reset',
                'CLOSE' : 'Close',
            },
            'UNKNOWN' : 'Unknown'
        },
        'LIST' : {
            'TITLE' : 'Management - Manager List',
            'TITLEFAQCODE' : 'Board - FAQ code list',
            'TITLEFAQ' : 'Board - FAQ list',
            'TITLEPLATFORM' : 'PlatForm - Platform list',
            'TITLEPLATFORMAPI' : 'PlatForm - Platform api list',
            'TITLEMEMBER' : 'Member List',
            'TBLCOMMAND' : {
                'HEADER': {
                    'SEQ' : 'SEQ',
                    'TITLE' : 'Title',
                    'TITLEKEYTEXT' : 'Title 언어ID',
                    'MAINCHECK' : 'Main 등록여부',
                    'REGDATE' : 'Regist date',
                    'DETAIL' : 'Detail',
                    'MAINYES' : '노출',
                    'MAINNO' : '비노출',
                    'KEYTEXT' : '언어ID',
                    'KEYIMAGE' : '언어 이미지',
                    'STATUS' : '사용여부',
                    'STATUSUSED' : '사용',
                    'STATUSSTANDBY' : '대기',
                    'STATUSDELETE' : '삭제',
                    'PERSON' : '개인',
                    'ORGANIZATION' : '기업'
                }
            },
            'TBL' : {
                'TBLHEADER' : {
                    'ID' : 'ID',
                    'GRADE' : 'Grade',
                    'NAME' : 'Name',
                    'EMAIL' : 'E-mail',
                    'PHONE' : 'Phone'
                }
            },
            'TBLFAQ' : {
                'HEADER' : {
                    'FAQCODE' : 'Faq code',
                }
            },
            'TBLPLATFORM' : {
                'HEADER' : {
                    'NAME' : '플랫폼'
                }
            },
            'TBLPLATFORMAPI' : {
                'HEADER' : {
                    'PLATFROM' : 'PlatForm SEQ',
                    'APIURL' : 'Api url',
                    'APIID' : 'Api 계정',
                    'APIKEY' : 'Api 보안키'
                }
            },
            'TBLMEMBER' : {
                'HEADER' : {
                    'PLATFORM' : 'Platform',
                    'NAME' : '이름',
                    'EMAIL' : 'E-mail',
                    'ORGCHECK' : '소속'
                }
            }
        },
        'VIEW' : {
            'TITLE' : 'Account Information',
            'TITLEFAQCODE' : 'Baord - FAQ code detail', 
            'TITLEFAQ' : 'Board - FAQ detail',
            'TITLEPLATFORM' : 'PlatForm - Platform detail',
            'TITLEPLATFORMAPI' : 'PlatForm - Platform api detail',
            'VIEWCOMMAND' : {
                'HEADER' : {
                    'SEQ' : 'SEQ',
                    'TITLE' : 'Title',
                    'TITLEKEYTEXT' : 'Title 언어ID',
                    'DESCRIPTION' : 'Description',
                    'DESCRIPTIONKEYTEXT' : 'Description 언어ID',
                    'ACCOUNT' : 'Account',
                    'MEMEBERNAME' : 'Member name',
                    'REGDATE' : 'Regist date',
                    'DETAIL' : 'Detail',
                    'MAINCHECK' : 'Main 등록여부',
                    'MAINYES' : '노출',
                    'MAINNO' : '비노출',
                    'KEYTEXT' : '언어ID',
                    'KEYIMAGE' : '언어 이미지',
                    'STATUS' : '사용여부',
                    'STATUSUSED' : '사용',
                    'STATUSSTANDBY' : '대기',
                    'STATUSDELETE' : '삭제',
                },
            },
            'VIEWFAQ':{
                'FAQCODE' : 'Faq code',
                'FAQCODETITLE' : 'Faq code title',
            },
            'VIEWPLATFORM' : {
                'NAME' : '플랫폼'
            },
            'VIEWPLATFORMAPI' : {
                'PLATFORMSEQ' : '플랫폼 SEQ',
                'NAME' : '플랫폼',
                'APIURL' : 'Api url',
                'APIID' : 'Api 계정',
                'APIKEY' : 'Api 보안키'
            }
        },
        'SIDEBAR' : {
            'MODIFY' : '변경',
            'LOGOUT' : '로그아웃'
        },
        'REGISTER' : {
            'TITLE' : 'Manager register',
            'TITLEFAQCODE' : 'Baord - FAQ code regist',
            'TITLEFAQ' : 'Board - FAQ regist',
            'TITLEPLATFORM' : 'PlatForm - Platform regist',
            'TITLEPLATFORMAPI' : 'PlatForm - Platform api regist',
            'ALT' : '닫기버튼',
            'SELECT' : '선택',
            'FAQCODE' : 'Faq code',
            'MAINCHECK' : 'Main 노출여부',
            'MAINYES' : '노출',
            'MAINNO' : '비노출',
            'PLATFORMSEQ' : '플랫폼 SEQ',
            'PLATFORMNAME' : '플랫폼',
            'STATUS' : '사용여부',
            'STATUSUSED' : '사용',
            'STATUSSTANDBY' : '대기',
            'STATUSDELETE' : '삭제',
            'PLATFORMAPISEQ' : '플랫폼 api SEQ',
            'PHONE_PLACEHOLDER' : '-없이 입력'
        },
        'MODIFY' : {
            'TITLE' : 'Manager modify',
            'TITLEFAQCODE' : 'Baord - FAQ code modify', 
            'TITLEFAQ' : 'Board - FAQ modify',
            'TITLEPLATFORM' : 'PlatForm - Platform modify',
            'TITLEPLATFORMAPI' : 'PlatForm - Platform api modify',
        },
        'DELETE' : {
            'MSG' : '삭제하시겠습니까?'
        }
    }
};
