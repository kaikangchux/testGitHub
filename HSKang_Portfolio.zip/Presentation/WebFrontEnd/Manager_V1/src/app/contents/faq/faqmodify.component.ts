import { Component, OnInit, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { FormGroup, FormBuilder, Validators, ValidationErrors } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { NgxSpinnerService } from "ngx-spinner";

import { CommonService, FaqService } from '../../service';
import { FaqCodeModel, FaqModel } from '../../model';

@Component({ 
    selector: 'app-popup',
    templateUrl: './faqmodify.component.html', 
    styleUrls: ['../scss/regEdit.component.scss']
})

export class FaqModifyComponent implements OnInit
{
    mSeq:number;
    mFaq:FaqModel = null;
    mFaqCode:FaqCodeModel = null;
    modifyForm:FormGroup;

    constructor(private mService:FaqService,
                private cmnService:CommonService,
                private translate:TranslateService,
                private spinnerService:NgxSpinnerService,
                public dialogRef: MatDialogRef<FaqModifyComponent>, 
                @Inject(MAT_DIALOG_DATA) public data:any,
                private fb:FormBuilder){
            
        this.mSeq = (data.iSeq === null) ? -1 : data.iSeq;
    }

    ngOnInit():void
    {
        this.modifyForm = this.fb.group({
            iSeq:[this.mSeq, Validators.required],
            iFaqCodeSeq:['', Validators.required],
            vcTitleKeyText:['', Validators.required],
            vcDescriptKeyText:['', Validators.required],
            tiMain:[2, Validators.required]
        });

        // FAQ 상세정보 호출
        this.onDetail(this.mSeq);
    }

    // FAQ 상세정보
    onDetail(mSeq:number):void
    {
        setTimeout(() => this.spinnerService.show(), 0);

        this.mService.getFaqDetail(mSeq).subscribe(
            detailData => {
                this.spinnerService.hide();
                this.mFaq = detailData.data;
                
                // Form value 셋팅
                this.modifyForm.patchValue ({iSeq: this.mFaq.iSeq});
                this.modifyForm.patchValue ({iFaqCodeSeq: this.mFaq.iFaqCodeSeq});
                this.modifyForm.patchValue ({vcTitleKeyText: this.mFaq.vcTitleKeyText});
                this.modifyForm.patchValue ({vcDescriptKeyText: this.mFaq.vcDescriptKeyText});
                this.modifyForm.patchValue ({tiMain: this.mFaq.tiMain});
                
                // FAQ code 상세정보 호출(FAQ 정보 셋팅 먼저)
                this.getFaqCodeDetail(this.mFaq.iFaqCodeSeq);
            },
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

    // Action
    onModify():void
    {
        this.mService.regEditFaq(this.modifyForm.value, false, this.mSeq).subscribe(
            (res) => this.onClose(true),
            (err) => { this.onClose(false); console.log(err);}
        );
    }

    // Reset
    onReset():void
    {
        this.modifyForm.patchValue ({vcTitleKeyText: ''});
        this.modifyForm.patchValue ({vcDescriptKeyText: ''});
        this.modifyForm.patchValue ({tiMain: 2});
    }

    // popup close
    onClose(param:any):void{
        this.dialogRef.close(param);
    }

    // Faq code 상세정보
    getFaqCodeDetail(iSeq:number):void
    {
        setTimeout(() => this.spinnerService.show(), 0);

        this.mService.getFaqCodeDetail(iSeq).subscribe(
            detailData => {
                this.spinnerService.hide();
                this.mFaqCode = detailData.data;
            },
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

}