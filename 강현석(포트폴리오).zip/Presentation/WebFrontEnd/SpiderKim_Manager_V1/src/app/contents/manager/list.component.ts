import { Component, OnInit, Optional} from '@angular/core';
import { Title } from "@angular/platform-browser";
import { TranslateService } from '@ngx-translate/core';
import { NgxSpinnerService } from "ngx-spinner";
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';

import { ConfigService } from '../../config';
import { CommonService, ManagerService } from '../../service';
import { ManagerModel } from '../../model';
import { ManagerRegEditComponent } from './regEdit.component';

// enum ACT {
//     GET,
//     ADD,
//     MOD,
//     DEL
// }

@Component({
    selector: 'app-list',
    templateUrl: './list.component.html',
    styleUrls: ['../scss/list.component.scss']
})

export class ManagerListComponent implements OnInit
{
    start:number = 0;
    len:number = 20;
    total:number = 0;
    managerList:ManagerModel[] = [];
    curPage:number = 1;

    constructor(private titleService:Title,
                private translate:TranslateService,
                private mService:ManagerService,
                private spinnerService:NgxSpinnerService,
                private config:ConfigService,
                private cmnService:CommonService,
                private router: Router,
                public dialog: MatDialog){

        this.titleService.setTitle(this.translate.instant('TITLE.LIST'));
        this.config.setSettings({layout: {navbar: 'show'}});
    }

    ngOnInit():void
    {
        this.getManagerList(this.curPage, this.len);

        //Sidebar의 변경 버튼 눌렀을 때 ListComponent에 있는 함수 호출함
        if(this.mService.evtEmitterSub === undefined){
            this.mService.evtEmitterSub = this.mService.evtEmitter.subscribe((param:any) => {    
                //this.openRegEdit(param.mInfo, param.idx);
            });
        }
    }

    getManagerList(curPage:number, len:number):void
    {
        //this.curPage = 1;//관리자 add, delete 후에는 첫번째 페이지로 이동
        //this.start = 0;

        this.spinnerService.show();

        this.mService.getManagerList(curPage, len).subscribe(
            list => {
                this.managerList = list.data.gClass;
                this.total = list.data.totalRecord;
                this.mService.changeManagerList(this.managerList);
            },
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

    view(info:ManagerModel):void{
        this.router.navigate([`/view/${info.iSeq}`]);
    }

    openRegEdit(mUser:ManagerModel=null, idx:number=-1):void
    {
        if(this.curPage > 1 && this.managerList.length > this.len){
            idx = (this.curPage-1) * this.len + idx;
        }

        const dialogRef = this.dialog.open(ManagerRegEditComponent, {data:{mUser:mUser, idx:idx}});

        dialogRef.afterClosed().subscribe(res => {
            if(res === true){
                if(idx < 0){
                    this.curPage = 1;
                }
                this.getManagerList(this.curPage, this.len);
            }
        });
    }

    delete(mUser:ManagerModel, idx:number):void
    {
        const result = window.confirm(this.translate.instant('DELETE.MSG'));
        if(!result){
            return;
        }

        if(this.curPage > 1 && this.managerList.length > this.len){
            idx = (this.curPage-1) * this.len + idx;
        }

        this.spinnerService.show();

        /*
        this.mService.deleteManager(mUser, idx).subscribe(
            (res) => this.getManagerList(ACT.DEL),
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
        */
    }

    pagingArr():number[]
    {
        let result = Math.ceil(this.total/this.len);
        return Array.from({length: result}, (v, k) => k+1);
    }

    pager(page:number)
    {
        if(page === this.curPage){
            return;
        }

        this.curPage = page;
        this.getManagerList(this.curPage, this.len);
    }

    isSameLoginUser(mUser:ManagerModel)
    {
        const loginUserInfo = this.mService.getLoginMUserInfo();
        return (mUser.iSeq == loginUserInfo.adminSeq);
    }
}