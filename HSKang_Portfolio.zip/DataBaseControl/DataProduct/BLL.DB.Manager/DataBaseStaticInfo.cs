﻿using System;
using System.Collections.Generic;
using System.Text;

using Lib.Crawling.Library.Enum;
using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Manager;
using Lib.Crawling.Library.Log;

namespace BLL.DB.Manager
{

    #region // !++ DataBaseStaticInfo
    /// <summary>
    /// DataBase static info
    /// </summary>
    public class DataBaseStaticInfo : DataProvider.DataProvider
    {

        #region // !++ BllManager
        private static BllManager bllManager = new BllManager();
        #endregion


        #region // !++ 데이터베이스 연결문자
        protected static DBConnectionEntity m_dbConnectionString = new DBConnectionEntity();
        #endregion


        #region // !++ Initialize
        /// <summary>
        /// Initialize
        /// </summary>
        /// <param name="dbConnection"></param>
        public void Initialize(String dbConnection)
        {

            LoadDataBaseStaticData(dbConnection);

        }
        #endregion


        #region // !++ Reinitialize
        /// <summary>
        /// Reinitialize
        /// </summary>
        /// <param name="dbConnection"></param>
        public void Reinitialize(String dbConnection)
        {

            LoadDataBaseStaticData(dbConnection);

        }
        #endregion


        #region // !++ LoadDataBaseStaticData (DB[MySQL, MongoDB, Redis] 연결문자 만들기)
        /// <summary>
        /// DB[MySQL, MongoDB, Redis] 연결문자 만들기
        /// </summary>
        protected async static void LoadDataBaseStaticData(String dbConnection)
        {

            // 초기화
            m_dbConnectionString = null;
            m_dbConnectionString = new DBConnectionEntity();

            var resultBaseList = new List<DataBaseEntity>();

            try
            {

                #region // !++ 데이터 Struct 변경
                // ManagerDB 는 Direct 등록
                m_dbConnectionString.ManagerDBConnection = dbConnection;
                #endregion

                #region // !++ DB 정보 호출
                resultBaseList = await bllManager.BLL_DataBase_Sel(m_dbConnectionString);

                #region // !++ DB 연결정보 Static 만들기
                if (resultBaseList == null)
                {
                    m_dbConnectionString = null;
                }
                else
                {
                    if (resultBaseList.Count == 0)
                    {
                        m_dbConnectionString = null;
                    }
                    else
                    {
                        for (int i = 0; i < resultBaseList.Count; i++)
                        {
                            switch (resultBaseList[i].tiDBType)
                            {
                                case 1:     // MySQL
                                    switch (resultBaseList[i].vcDataBase)
                                    {
                                        case "AccountDB":
                                            m_dbConnectionString.AccountDBConnection = String.Format("Persist Security Info=True; Server={0}; Port={1}; DataBase={2}; Uid={3}; Pwd={4}; Pooling=true; Allow User Variables=True; UseAffectedRows=False; Convert Zero Datetime=True; Connect Timeout=5; MinimumPoolSize=10; maximumpoolsize=100; Charset=utf8mb4;"
                                                                                                        , resultBaseList[i].vcAddress, resultBaseList[i].iPort, resultBaseList[i].vcDataBase, resultBaseList[i].vcAccount, resultBaseList[i].vcPassword);
                                            break;
                                        case "CrawlingDB":
                                            m_dbConnectionString.CrawlingDBConnection = String.Format("Persist Security Info=True; Server={0}; Port={1}; DataBase={2}; Uid={3}; Pwd={4}; Pooling=true; Allow User Variables=True; UseAffectedRows=False; Convert Zero Datetime=True; Connect Timeout=5; MinimumPoolSize=10; maximumpoolsize=100; Charset=utf8mb4;"
                                                                                                        , resultBaseList[i].vcAddress, resultBaseList[i].iPort, resultBaseList[i].vcDataBase, resultBaseList[i].vcAccount, resultBaseList[i].vcPassword);
                                            break;
                                        case "LogDB":
                                            m_dbConnectionString.LogDBConnection = String.Format("Persist Security Info=True; Server={0}; Port={1}; DataBase={2}; Uid={3}; Pwd={4}; Pooling=true; Allow User Variables=True; UseAffectedRows=False; Convert Zero Datetime=True; Connect Timeout=5; MinimumPoolSize=10; maximumpoolsize=100; Charset=utf8mb4;"
                                                                                                        , resultBaseList[i].vcAddress, resultBaseList[i].iPort, resultBaseList[i].vcDataBase, resultBaseList[i].vcAccount, resultBaseList[i].vcPassword);
                                            break;
                                    }
                                    break;
                                case 2:     // MongoDB

                                    break;
                                case 3:     // Redis

                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                }
                #endregion

                #endregion

            }
            catch (Exception exc)
            {
                Logger.Log(ELogType.Fatal, "LoadDataBaseStaticData : \n [dbConnection:{0}], \n {1}, \n {2}",
                                        dbConnection, exc.Message, exc.StackTrace);

            }

        }
        #endregion


        #region // !++ GetDataBaseConnection (데이터베이스 연결 문자열 가져오기)
        /// <summary>
        /// 데이터베이스 연결 문자열 가져오기
        /// </summary>
        /// <param name="dbConnection"></param>
        /// <returns></returns>
        public DBConnectionEntity GetDataBaseConnection(String dbConnection)
        {

            if (m_dbConnectionString == null)
            {
                LoadDataBaseStaticData(dbConnection);
            }
            return m_dbConnectionString;

        }
        #endregion

    }
    #endregion

}
