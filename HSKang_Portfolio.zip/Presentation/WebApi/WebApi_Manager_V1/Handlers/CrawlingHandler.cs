﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Crawling;
using Lib.Crawling.Library.DataContainers;
using Lib.Crawling.Library.Log;

namespace WebApi_SpiderKim_Manager_V1.Handlers
{

    #region // !++ CrawlingHandler
    /// <summary>
    /// CrawlingHandler
    /// </summary>
    public class CrawlingHandler : Handler
    {

        #region // !++ GetFaqCodeList (FAQ Code 목록)
        /// <summary>
        /// FAQ Code 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns></returns>
        public static async Task<ListPageDataContainer<List<FAQCodeEntity>>> GetFaqCodeList(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<FAQCodeEntity>>();

            try
            {
                // DB호출
                resultDataContainer = await bllCrawling.BLL_FAQCode_Sel(dbConnectionEntity, pageDBEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetFaqCodeList : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), exc.Message, exc.StackTrace);

                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ GetFaqCodeDetail (FAQ Code 상세정보)
        /// <summary>
        /// FAQ Code 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="fAQCodeEntity"></param>
        /// <returns></returns>
        public static async Task<FAQCodeEntity> GetFaqCodeDetail(DBConnectionEntity dbConnectionEntity, FAQCodeEntity fAQCodeEntity)
        {

            var result = new FAQCodeEntity();

            try
            {

                result = await bllCrawling.BLL_FAQCode_Detail_Sel(dbConnectionEntity, fAQCodeEntity);
                if (result == null)
                {
                    if (result.iSeq == 0)
                    {
                        var nullData = new FAQCodeEntity()
                        {
                            iSeq = 0,
                            vcTitle = String.Empty,
                            iManagerSeq = 0,
                            dtRegDate = DateTime.MinValue
                        };
                        result = nullData;
                    }
                }

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetFaqCodeDetail : \n [DBConnectionEntity:{0}], \n [FAQCodeEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(fAQCodeEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


        #region // !++ SetFaqCodeRegist (FAQ Code 등록)
        /// <summary>
        /// FAQ Code 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="fAQCodeEntity"></param>
        /// <returns></returns>
        public static async Task<Int32> SetFaqCodeRegist(DBConnectionEntity dbConnectionEntity, FAQCodeEntity fAQCodeEntity)
        {

            var result = 0;

            try
            {
                result = await bllCrawling.BLL_FAQCode_Ins(dbConnectionEntity, fAQCodeEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetFaqCodeRegist : \n [DBConnectionEntity:{0}], \n [FAQCodeEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(fAQCodeEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


        #region // !++ SetFaqCodeModify (FAQ Code 수정)
        /// <summary>
        /// FAQ Code 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="fAQCodeEntity"></param>
        /// <returns></returns>
        public static async Task<Int32> SetFaqCodeModify(DBConnectionEntity dbConnectionEntity, FAQCodeEntity fAQCodeEntity)
        {

            var result = 0;

            try
            {
                result = await bllCrawling.BLL_FAQCode_Upd(dbConnectionEntity, fAQCodeEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetFaqCodeModify : \n [DBConnectionEntity:{0}], \n [FAQCodeEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(fAQCodeEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


        #region // !++ SetFaqCodeDelete (FAQ Code 삭제)
        /// <summary>
        /// FAQ Code 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="fAQCodeEntity"></param>
        /// <returns></returns>
        public static async Task<Int32> SetFaqCodeDelete(DBConnectionEntity dbConnectionEntity, FAQCodeEntity fAQCodeEntity)
        {

            var result = 0;

            try
            {
                result = await bllCrawling.BLL_FAQCode_Del(dbConnectionEntity, fAQCodeEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetFaqCodeDelete : \n [DBConnectionEntity:{0}], \n [FAQCodeEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(fAQCodeEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


        #region // !++ GetFaqList (FAQ 목록)
        /// <summary>
        /// FAQ 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns></returns>
        public static async Task<ListPageDataContainer<List<FAQEntity>>> GetFaqList(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<FAQEntity>>();

            try
            {
                // DB호출
                resultDataContainer = await bllCrawling.BLL_FAQ_Sel(dbConnectionEntity, pageDBEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetFaqList : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), exc.Message, exc.StackTrace);

                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ GetFaqDetail (FAQ 상세정보)
        /// <summary>
        /// FAQ 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="faqEntity"></param>
        /// <returns></returns>
        public static async Task<FAQEntity> GetFaqDetail(DBConnectionEntity dbConnectionEntity, FAQEntity faqEntity)
        {

            var result = new FAQEntity();

            try
            {

                result = await bllCrawling.BLL_FAQ_Detail_Sel(dbConnectionEntity, faqEntity);
                if (result == null)
                {
                    var nullData = new FAQEntity()
                    {
                        iSeq = 0,
                        iFaqCodeSeq = 0,
                        vcTitleKeyText = String.Empty,
                        vcDescriptKeyText = String.Empty,
                        tiMain = 0,
                        iManagerSeq = 0,
                        dtRegDate = DateTime.MinValue
                    };
                    result = nullData;
                }

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetFaqDetail : \n [DBConnectionEntity:{0}], \n [FAQEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(faqEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


        #region // !++ SetFaqRegist (FAQ 등록)
        /// <summary>
        /// FAQ 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="faqEntity"></param>
        /// <returns></returns>
        public static async Task<Int32> SetFaqRegist(DBConnectionEntity dbConnectionEntity, FAQEntity faqEntity)
        {

            var result = 0;

            try
            {
                result = await bllCrawling.BLL_FAQ_Ins(dbConnectionEntity, faqEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetFaqRegist : \n [DBConnectionEntity:{0}], \n [FAQEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(faqEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


        #region // !++ SetFaqModify (FAQ 수정)
        /// <summary>
        /// FAQ 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="faqEntity"></param>
        /// <returns></returns>
        public static async Task<Int32> SetFaqModify(DBConnectionEntity dbConnectionEntity, FAQEntity faqEntity)
        {

            var result = 0;

            try
            {
                result = await bllCrawling.BLL_FAQ_Upd(dbConnectionEntity, faqEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetFaqModify : \n [DBConnectionEntity:{0}], \n [FAQEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(faqEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


        #region // !++ SetFaqDelete (FAQ 삭제)
        /// <summary>
        /// FAQ 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="faqEntity"></param>
        /// <returns></returns>
        public static async Task<Int32> SetFaqDelete(DBConnectionEntity dbConnectionEntity, FAQEntity faqEntity)
        {

            var result = 0;

            try
            {
                result = await bllCrawling.BLL_FAQ_Del(dbConnectionEntity, faqEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetFaqDelete : \n [DBConnectionEntity:{0}], \n [FAQEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(faqEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


        #region // !++ GetPlatFormList (플랫폼 목록)
        /// <summary>
        /// 플랫폼 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns></returns>
        public static async Task<ListPageDataContainer<List<PlatFormEntity>>> GetPlatFormList(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<PlatFormEntity>>();

            try
            {
                // DB호출
                resultDataContainer = await bllCrawling.BLL_PlatForm_Sel(dbConnectionEntity, pageDBEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetPlatFormList : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), exc.Message, exc.StackTrace);

                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ GetPlatFormDetail (플랫폼 상세정보)
        /// <summary>
        /// 플랫폼 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="platFormEntity"></param>
        /// <returns></returns>
        public static async Task<PlatFormEntity> GetPlatFormDetail(DBConnectionEntity dbConnectionEntity, PlatFormEntity platFormEntity)
        {

            var result = new PlatFormEntity();

            try
            {

                result = await bllCrawling.BLL_PlatForm_Detail_Sel(dbConnectionEntity, platFormEntity);
                if (result == null)
                {
                    var nullData = new PlatFormEntity()
                    {
                        iSeq = 0,
                        vcName = String.Empty,
                        vcKeyText = String.Empty,
                        vcKeyImage = String.Empty,
                        tiStatus = 0,
                        iManagerSeq = 0,
                        dtRegDate = DateTime.MinValue
                    };
                    result = nullData;
                }

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetPlatFormDetail : \n [DBConnectionEntity:{0}], \n [PlatFormEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(platFormEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


        #region // !++ SetPlatFormRegist (플랫폼 등록)
        /// <summary>
        /// 플랫폼 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="platFormEntity"></param>
        /// <returns></returns>
        public static async Task<Int32> SetPlatFormRegist(DBConnectionEntity dbConnectionEntity, PlatFormEntity platFormEntity)
        {

            var result = 0;

            try
            {
                result = await bllCrawling.BLL_PlatForm_Ins(dbConnectionEntity, platFormEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetPlatFormRegist : \n [DBConnectionEntity:{0}], \n [PlatFormEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(platFormEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


        #region // !++ SetPlatFormModify (플랫폼 수정)
        /// <summary>
        /// 플랫폼 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="platFormEntity"></param>
        /// <returns></returns>
        public static async Task<Int32> SetPlatFormModify(DBConnectionEntity dbConnectionEntity, PlatFormEntity platFormEntity)
        {

            var result = 0;

            try
            {
                result = await bllCrawling.BLL_PlatForm_Upd(dbConnectionEntity, platFormEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetPlatFormModify : \n [DBConnectionEntity:{0}], \n [PlatFormEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(platFormEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


        #region // !++ SetPlatFormDelete (플랫폼 삭제)
        /// <summary>
        /// 플랫폼 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="platFormEntity"></param>
        /// <returns></returns>
        public static async Task<Int32> SetPlatFormDelete(DBConnectionEntity dbConnectionEntity, PlatFormEntity platFormEntity)
        {

            var result = 0;

            try
            {
                result = await bllCrawling.BLL_PlatForm_Del(dbConnectionEntity, platFormEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetPlatFormDelete : \n [DBConnectionEntity:{0}], \n [PlatFormEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(platFormEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


        #region // !++ GetPlatFormApiList (플랫폼 API 목록)
        /// <summary>
        /// 플랫폼 API 목록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="pageDBEntity"></param>
        /// <returns></returns>
        public static async Task<ListPageDataContainer<List<PlatFormApiEntity>>> GetPlatFormApiList(DBConnectionEntity dbConnectionEntity, PageDBEntity pageDBEntity)
        {

            var resultDataContainer = new ListPageDataContainer<List<PlatFormApiEntity>>();

            try
            {
                // DB호출
                resultDataContainer = await bllCrawling.BLL_PlatFormApi_Sel(dbConnectionEntity, pageDBEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetPlatFormApiList : \n [DBConnectionEntity:{0}], \n [PageDBEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(pageDBEntity), exc.Message, exc.StackTrace);

                return resultDataContainer;
            }
            return resultDataContainer;

        }
        #endregion


        #region // !++ GetPlatFormApiDetail (플랫폼 API 상세정보)
        /// <summary>
        /// 플랫폼 API 상세정보
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="platFormApiEntity"></param>
        /// <returns></returns>
        public static async Task<PlatFormApiEntity> GetPlatFormApiDetail(DBConnectionEntity dbConnectionEntity, PlatFormApiEntity platFormApiEntity)
        {

            var result = new PlatFormApiEntity();

            try
            {

                result = await bllCrawling.BLL_PlatFormApi_Detail_Sel(dbConnectionEntity, platFormApiEntity);
                if (result == null)
                {
                    var nullData = new PlatFormApiEntity()
                    {
                        iSeq = 0,
                        iPlatFormSeq = 0,
                        vcApiUrl = String.Empty,
                        vcID = String.Empty,
                        vcVerifyKey = String.Empty,
                        tiStatus = 0,
                        iManagerSeq = 0,
                        dtRegDate = DateTime.MinValue
                    };
                    result = nullData;
                }

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetPlatFormApiDetail : \n [DBConnectionEntity:{0}], \n [PlatFormApiEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(platFormApiEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


        #region // !++ SetPlatFormApiRegist (플랫폼 API 등록)
        /// <summary>
        /// 플랫폼 API 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="platFormApiEntity"></param>
        /// <returns></returns>
        public static async Task<Int32> SetPlatFormApiRegist(DBConnectionEntity dbConnectionEntity, PlatFormApiEntity platFormApiEntity)
        {

            var result = 0;

            try
            {
                result = await bllCrawling.BLL_PlatFormApi_Ins(dbConnectionEntity, platFormApiEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetPlatFormApiRegist : \n [DBConnectionEntity:{0}], \n [PlatFormApiEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(platFormApiEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


        #region // !++ SetPlatFormApiModify (플랫폼 API 수정)
        /// <summary>
        /// 플랫폼 API 수정
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="platFormApiEntity"></param>
        /// <returns></returns>
        public static async Task<Int32> SetPlatFormApiModify(DBConnectionEntity dbConnectionEntity, PlatFormApiEntity platFormApiEntity)
        {

            var result = 0;

            try
            {
                result = await bllCrawling.BLL_PlatFormApi_Upd(dbConnectionEntity, platFormApiEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetPlatFormApiModify : \n [DBConnectionEntity:{0}], \n [PlatFormApiEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(platFormApiEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion


        #region // !++ SetPlatFormApiDelete (플랫폼 API 삭제)
        /// <summary>
        /// 플랫폼 API 삭제
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="platFormApiEntity"></param>
        /// <returns></returns>
        public static async Task<Int32> SetPlatFormApiDelete(DBConnectionEntity dbConnectionEntity, PlatFormApiEntity platFormApiEntity)
        {

            var result = 0;

            try
            {
                result = await bllCrawling.BLL_PlatFormApi_Del(dbConnectionEntity, platFormApiEntity);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetPlatFormApiDelete : \n [DBConnectionEntity:{0}], \n [PlatFormApiEntity:{1}], \n {2}, \n {3}",
                                        libUtility.ToJson(dbConnectionEntity), libUtility.ToJson(platFormApiEntity), exc.Message, exc.StackTrace);

                return result;
            }
            return result;

        }
        #endregion




    }
    #endregion

}
