import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd, NavigationStart } from '@angular/router';
import { MatDialog } from '@angular/material';

import { ManagerModel, ManagerLoginInfo } from '../model';
import { ManagerService } from '../service/manager.service';

@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.scss']
})

export class SideBarComponent implements OnInit
{
    mUserInfo:ManagerLoginInfo;
    mUserName:string;
    managerList:ManagerModel[] = [];
    mUserIdx:number = -1;
    routeUrl:string;

    constructor(private mService:ManagerService, public dialog: MatDialog, private router:Router)
    {
        this.mUserInfo = this.mService.getLoginMUserInfo();
        this.mUserName = this.mUserInfo.adminName;
    }

    ngOnInit():void
    {
        //로그인한 유저 정보가 수정(이름)되었을 경우 반영함
        this.mService.managerList$.subscribe(data=> {
            if(data.length > 0) {
                this.managerList = data;
                let tmpInfo = this.mService.getLoginUserInfo(this.mUserInfo.adminSeq);
                if(typeof tmpInfo.mInfo !== 'undefined'){
                    this.mUserName = tmpInfo.mInfo.vcName;
                }
            }
        });
    }

    modify():void
    {
        const result = this.mService.getLoginUserInfo(this.mUserInfo.adminSeq);
        this.mService.onEventEmite(result);
    }

    logout():void{
        this.mService.logout();
    }
}