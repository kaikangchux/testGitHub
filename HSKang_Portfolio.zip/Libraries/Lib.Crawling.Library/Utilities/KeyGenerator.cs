﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lib.Crawling.Library.Utilities
{

    #region // !++ KeyGenerator
    /// <summary>
    /// KeyGenerator
    /// </summary>
    public class KeyGenerator
    {

        private static KeyGenerator m_instance = null;
        public static KeyGenerator Instance
        {
            get
            {
                if (null == m_instance)
                {
                    m_instance = new KeyGenerator();
                }

                return m_instance;
            }
        }

        static Int64 m_orderCount = 0;
        static Int64 m_maxOrderCount = 1000;
        static Int64 m_LastDateTime = 0;
        static object m_mutex = new object();


        #region // !++ NewKey
        /// <summary>
        /// Token Key
        /// </summary>
        /// <param name="userID">문자(계정)</param>
        /// <param name="commnet">사용코멘트</param>
        /// <returns></returns>
        public Int64 NewKey(String userID, String commnet)
        {
            var dateTimeString = DateTime.Now.ToString("yyMMddhhmmss");
            var dateTime = Int64.Parse(dateTimeString);
            var sb = new StringBuilder(20);

            lock (m_mutex)
            {
                m_orderCount++;

                if (m_LastDateTime != dateTime)
                {
                    m_LastDateTime = dateTime;
                    m_orderCount = 0;
                }

                sb.Append(String.Format("01"));                         // 국가코드
                sb.Append(String.Format("01"));                         // 서버코드
                sb.Append(dateTimeString);                              // 생성시간
                sb.Append(String.Format("{0:000}", m_orderCount));      // 일련번호

                var newKey = Int64.Parse(sb.ToString());

                if (m_orderCount >= m_maxOrderCount)
                {
                    System.Threading.Thread.Sleep(1000);
                }

                return newKey;
            }
        }
        #endregion

    }
    #endregion

}
