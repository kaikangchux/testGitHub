﻿using System;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.LogDB;
using Lib.Crawling.Library.Models.LogDB;

using MySql.Data.MySqlClient;

namespace DAL.Crawling.LogData
{

    #region // !++ DalLogData
    /// <summary>
    /// MySQL Log
    /// </summary>
    public class DalLogData
    {

        #region // !++ DAL_LogFAQCode_Ins (FAQ코드 로그 등록)
        /// <summary>
        /// FAQ코드 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLogFAQCode"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LogFAQCode_Ins(DBConnectionEntity dbConnectionEntity, tbLogFAQCode dbLogFAQCode)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LogFAQCode_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.LogDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biTXIDX", MySqlDbType.Int64).Value = dbLogFAQCode.biTXIDX;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLogFAQCode.iManagerSeq;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbLogFAQCode.iSeq;
                    command.Parameters.Add("@p_vcTitle", MySqlDbType.VarChar, 128).Value = dbLogFAQCode.vcTitle;
                    command.Parameters.Add("@p_tiType", MySqlDbType.Bit).Value = dbLogFAQCode.tiType;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbLogFAQCode.vcIP;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LogFAQ_Ins (FAQ 로그 등록)
        /// <summary>
        /// FAQ 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLogFAQ"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LogFAQ_Ins(DBConnectionEntity dbConnectionEntity, tbLogFAQ dbLogFAQ)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LogFAQ_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.LogDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biTXIDX", MySqlDbType.Int64).Value = dbLogFAQ.biTXIDX;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLogFAQ.iManagerSeq;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbLogFAQ.iSeq;
                    command.Parameters.Add("@p_iFaqCodeSeq", MySqlDbType.Int32).Value = dbLogFAQ.iFaqCodeSeq;
                    command.Parameters.Add("@p_vcTitleKeyText", MySqlDbType.VarChar, 64).Value = dbLogFAQ.vcTitleKeyText;
                    command.Parameters.Add("@p_vcDescriptKeyText", MySqlDbType.VarChar, 64).Value = dbLogFAQ.vcDescriptKeyText;
                    command.Parameters.Add("@p_tiMain", MySqlDbType.Bit).Value = dbLogFAQ.tiMain;
                    command.Parameters.Add("@p_tiType", MySqlDbType.Bit).Value = dbLogFAQ.tiType;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbLogFAQ.vcIP;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LogPlatForm_Ins (플랫폼정보 로그 등록)
        /// <summary>
        /// 플랫폼정보 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLogPlatForm"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LogPlatForm_Ins(DBConnectionEntity dbConnectionEntity, tbLogPlatForm dbLogPlatForm)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LogPlatForm_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.LogDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biTXIDX", MySqlDbType.Int64).Value = dbLogPlatForm.biTXIDX;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLogPlatForm.iManagerSeq;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbLogPlatForm.iSeq;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 32).Value = dbLogPlatForm.vcName;
                    command.Parameters.Add("@p_vcKeyText", MySqlDbType.VarChar, 64).Value = dbLogPlatForm.vcKeyText;
                    command.Parameters.Add("@p_vcKeyImage", MySqlDbType.VarChar, 64).Value = dbLogPlatForm.vcKeyImage;
                    command.Parameters.Add("@p_tiStatus", MySqlDbType.Bit).Value = dbLogPlatForm.tiStatus;
                    command.Parameters.Add("@p_tiType", MySqlDbType.Bit).Value = dbLogPlatForm.tiType;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbLogPlatForm.vcIP;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LogPlatFormApi_Ins (플랫폼API정보 로그 등록)
        /// <summary>
        /// 플랫폼정보API 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLogPlatFormApi"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LogPlatFormApi_Ins(DBConnectionEntity dbConnectionEntity, tbLogPlatFormApi dbLogPlatFormApi)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LogPlatFormApi_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.LogDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biTXIDX", MySqlDbType.Int64).Value = dbLogPlatFormApi.biTXIDX;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLogPlatFormApi.iManagerSeq;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbLogPlatFormApi.iSeq;
                    command.Parameters.Add("@p_iPlatFormSeq", MySqlDbType.Int32).Value = dbLogPlatFormApi.iPlatFormSeq;
                    command.Parameters.Add("@p_vcApiUrl", MySqlDbType.VarChar, 32).Value = dbLogPlatFormApi.vcApiUrl;
                    command.Parameters.Add("@p_vcID", MySqlDbType.VarChar, 64).Value = dbLogPlatFormApi.vcID;
                    command.Parameters.Add("@p_vcVerifyKey", MySqlDbType.VarChar, 64).Value = dbLogPlatFormApi.vcVerifyKey;
                    command.Parameters.Add("@p_tiStatus", MySqlDbType.Bit).Value = dbLogPlatFormApi.tiStatus;
                    command.Parameters.Add("@p_tiType", MySqlDbType.Bit).Value = dbLogPlatFormApi.tiType;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbLogPlatFormApi.vcIP;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LogLanguageCode_Ins (언어[다국어]코드 로그 등록)
        /// <summary>
        /// 언어[다국어]코드 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLogLanguageCode"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LogLanguageCode_Ins(DBConnectionEntity dbConnectionEntity, tbLogLanguageCode dbLogLanguageCode)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LogLanguageCode_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.LogDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biTXIDX", MySqlDbType.Int64).Value = dbLogLanguageCode.biTXIDX;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLogLanguageCode.iManagerSeq;
                    command.Parameters.Add("@p_vcLanguageCode", MySqlDbType.VarChar, 8).Value = dbLogLanguageCode.vcLanguageCode;
                    command.Parameters.Add("@p_vcLanguageName", MySqlDbType.VarChar, 32).Value = dbLogLanguageCode.vcLanguageName;
                    command.Parameters.Add("@p_tiStatus", MySqlDbType.Bit).Value = dbLogLanguageCode.tiStatus;
                    command.Parameters.Add("@p_tiType", MySqlDbType.Bit).Value = dbLogLanguageCode.tiType;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbLogLanguageCode.vcIP;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LogLanguage_Ins (언어[다국어] 로그 등록)
        /// <summary>
        /// 언어[다국어] 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLogLanguage"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LogLanguage_Ins(DBConnectionEntity dbConnectionEntity, tbLogLanguage dbLogLanguage)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LogLanguage_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.LogDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biTXIDX", MySqlDbType.Int64).Value = dbLogLanguage.biTXIDX;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLogLanguage.iManagerSeq;
                    command.Parameters.Add("@p_vcLanguageCode", MySqlDbType.VarChar, 8).Value = dbLogLanguage.vcLanguageCode;
                    command.Parameters.Add("@p_vcKeyText", MySqlDbType.VarChar, 64).Value = dbLogLanguage.vcKeyText;
                    command.Parameters.Add("@p_tiAbbreviated", MySqlDbType.Bit).Value = dbLogLanguage.tiAbbreviated;
                    command.Parameters.Add("@p_vcText", MySqlDbType.VarChar, 4000).Value = dbLogLanguage.vcText;
                    command.Parameters.Add("@p_tiStatus", MySqlDbType.Bit).Value = dbLogLanguage.tiStatus;
                    command.Parameters.Add("@p_tiType", MySqlDbType.Bit).Value = dbLogLanguage.tiType;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbLogLanguage.vcIP;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LogLanguageImage_Ins (언어[다국어]이미지 로그 등록)
        /// <summary>
        /// 언어[다국어]이미지 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLogLanguageImage"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LogLanguageImage_Ins(DBConnectionEntity dbConnectionEntity, tbLogLanguageImage dbLogLanguageImage)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LogLanguageImage_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.LogDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biTXIDX", MySqlDbType.Int64).Value = dbLogLanguageImage.biTXIDX;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLogLanguageImage.iManagerSeq;
                    command.Parameters.Add("@p_vcLanguageCode", MySqlDbType.VarChar, 8).Value = dbLogLanguageImage.vcLanguageCode;
                    command.Parameters.Add("@p_vcKeyImage", MySqlDbType.VarChar, 64).Value = dbLogLanguageImage.vcKeyImage;
                    command.Parameters.Add("@p_vcUrl", MySqlDbType.VarChar, 256).Value = dbLogLanguageImage.vcUrl;
                    command.Parameters.Add("@p_vcImage", MySqlDbType.VarChar, 64).Value = dbLogLanguageImage.vcImage;
                    command.Parameters.Add("@p_tiStatus", MySqlDbType.Bit).Value = dbLogLanguageImage.tiStatus;
                    command.Parameters.Add("@p_tiType", MySqlDbType.Bit).Value = dbLogLanguageImage.tiType;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbLogLanguageImage.vcIP;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LogProhibitWords_Ins (금지어 로그 등록)
        /// <summary>
        /// 금지어 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLogProhibitWords"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LogProhibitWords_Ins(DBConnectionEntity dbConnectionEntity, tbLogProhibitWords dbLogProhibitWords)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LogProhibitWords_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.LogDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biTXIDX", MySqlDbType.Int64).Value = dbLogProhibitWords.biTXIDX;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLogProhibitWords.iManagerSeq;
                    command.Parameters.Add("@p_vcProhibitWords", MySqlDbType.VarChar, 32).Value = dbLogProhibitWords.vcProhibitWords;
                    command.Parameters.Add("@p_vcNote", MySqlDbType.VarChar, 256).Value = dbLogProhibitWords.vcNote;
                    command.Parameters.Add("@p_tiStatus", MySqlDbType.Bit).Value = dbLogProhibitWords.tiStatus;
                    command.Parameters.Add("@p_tiType", MySqlDbType.Bit).Value = dbLogProhibitWords.tiType;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbLogProhibitWords.vcIP;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LogManager_Ins (관리자 등록및수정 로그 등록)
        /// <summary>
        /// 관리자 등록및수정 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLogManager"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LogManager_Ins(DBConnectionEntity dbConnectionEntity, tbLogManager dbLogManager)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LogManager_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.LogDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biTXIDX", MySqlDbType.Int64).Value = dbLogManager.biTXIDX;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbLogManager.iSeq;
                    command.Parameters.Add("@p_vcManagerID", MySqlDbType.VarChar, 32).Value = dbLogManager.vcManagerID;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 32).Value = dbLogManager.vcName;
                    command.Parameters.Add("@p_vcPassword", MySqlDbType.VarChar, 64).Value = dbLogManager.vcPassword;
                    command.Parameters.Add("@p_vcEmailID", MySqlDbType.VarChar, 64).Value = dbLogManager.vcEmailID;
                    command.Parameters.Add("@p_vcEmailAddress", MySqlDbType.VarChar, 128).Value = dbLogManager.vcEmailAddress;
                    command.Parameters.Add("@p_vcPhone", MySqlDbType.VarChar, 16).Value = dbLogManager.vcPhone;
                    command.Parameters.Add("@p_tiGrade", MySqlDbType.Byte).Value = dbLogManager.tiGrade;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLogManager.iManagerSeq;
                    command.Parameters.Add("@p_tiType", MySqlDbType.Bit).Value = dbLogManager.tiType;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbLogManager.vcIP;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LogManagerConnection_Ins (관리자 접속 로그 등록)
        /// <summary>
        /// 관리자 접속 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLogManagerConnection"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LogManagerConnection_Ins(DBConnectionEntity dbConnectionEntity, tbLogManagerConnection dbLogManagerConnection)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LogManagerConnection_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.LogDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biTXIDX", MySqlDbType.Int64).Value = dbLogManagerConnection.biTXIDX;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLogManagerConnection.iManagerSeq;
                    command.Parameters.Add("@p_vcManagerID", MySqlDbType.VarChar, 32).Value = dbLogManagerConnection.vcManagerID;
                    command.Parameters.Add("@p_vcPassword", MySqlDbType.VarChar, 64).Value = dbLogManagerConnection.vcPassword;
                    command.Parameters.Add("@p_tiResult", MySqlDbType.Bit).Value = dbLogManagerConnection.tiResult;
                    command.Parameters.Add("@p_tiStatus", MySqlDbType.Bit).Value = dbLogManagerConnection.tiStatus;
                    command.Parameters.Add("@p_tiType", MySqlDbType.Bit).Value = dbLogManagerConnection.tiType;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbLogManagerConnection.vcIP;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LogPrivateBoard_Ins (공지, 뉴스 등 게시판 로그 등록)
        /// <summary>
        /// 공지, 뉴스 등 게시판 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLogPrivateBoard"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LogPrivateBoard_Ins(DBConnectionEntity dbConnectionEntity, tbLogPrivateBoard dbLogPrivateBoard)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LogPrivateBoard_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.LogDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biTXIDX", MySqlDbType.Int64).Value = dbLogPrivateBoard.biTXIDX;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLogPrivateBoard.iManagerSeq;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Value = dbLogPrivateBoard.biSeq;
                    command.Parameters.Add("@p_tiBoardType", MySqlDbType.Bit).Value = dbLogPrivateBoard.tiBoardType;
                    command.Parameters.Add("@p_vcTitleKeyText", MySqlDbType.VarChar, 64).Value = dbLogPrivateBoard.vcTitleKeyText;
                    command.Parameters.Add("@p_vcDescriptKeyText", MySqlDbType.VarChar, 64).Value = dbLogPrivateBoard.vcDescriptKeyText;
                    command.Parameters.Add("@p_tiMain", MySqlDbType.Bit).Value = dbLogPrivateBoard.tiMain;
                    command.Parameters.Add("@p_tiType", MySqlDbType.Bit).Value = dbLogPrivateBoard.tiType;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbLogPrivateBoard.vcIP;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LogPrivateBoardData_Ins (공지, 뉴스 등 게시판 데이터 로그 등록)
        /// <summary>
        /// 공지, 뉴스 등 게시판 데이터 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLogPrivateBoardData"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LogPrivateBoardData_Ins(DBConnectionEntity dbConnectionEntity, tbLogPrivateBoardData dbLogPrivateBoardData)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LogPrivateBoardData_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.LogDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biTXIDX", MySqlDbType.Int64).Value = dbLogPrivateBoardData.biTXIDX;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLogPrivateBoardData.iManagerSeq;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Value = dbLogPrivateBoardData.biSeq;
                    command.Parameters.Add("@p_biPrivateBoardSeq", MySqlDbType.Int64).Value = dbLogPrivateBoardData.biPrivateBoardSeq;
                    command.Parameters.Add("@p_vcFileName", MySqlDbType.VarChar, 32).Value = dbLogPrivateBoardData.vcFileName;
                    command.Parameters.Add("@p_vcSaveFolder", MySqlDbType.VarChar, 128).Value = dbLogPrivateBoardData.vcSaveFolder;
                    command.Parameters.Add("@p_vcSaveName", MySqlDbType.VarChar, 32).Value = dbLogPrivateBoardData.vcSaveName;
                    command.Parameters.Add("@p_vcSaveType", MySqlDbType.VarChar, 8).Value = dbLogPrivateBoardData.vcSaveType;
                    command.Parameters.Add("@p_iSaveSize", MySqlDbType.Int32).Value = dbLogPrivateBoardData.iSaveSize;
                    command.Parameters.Add("@p_tiType", MySqlDbType.Bit).Value = dbLogPrivateBoardData.tiType;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbLogPrivateBoardData.vcIP;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LogCompanyGroup_Ins (회사조직[분류] 로그 등록)
        /// <summary>
        /// 회사조직[분류] 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLogCompanyGroup"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LogCompanyGroup_Ins(DBConnectionEntity dbConnectionEntity, tbLogCompanyGroup dbLogCompanyGroup)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LogCompanyGroup_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.LogDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biTXIDX", MySqlDbType.Int64).Value = dbLogCompanyGroup.biTXIDX;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLogCompanyGroup.iManagerSeq;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbLogCompanyGroup.iSeq;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 32).Value = dbLogCompanyGroup.vcName;
                    command.Parameters.Add("@p_vcNameKeyText", MySqlDbType.VarChar, 64).Value = dbLogCompanyGroup.vcNameKeyText;
                    command.Parameters.Add("@p_vcAbbreviation", MySqlDbType.VarChar, 128).Value = dbLogCompanyGroup.vcAbbreviation;
                    command.Parameters.Add("@p_vcAbbreviationKeyText", MySqlDbType.VarChar, 64).Value = dbLogCompanyGroup.vcAbbreviationKeyText;
                    command.Parameters.Add("@p_tiType", MySqlDbType.Bit).Value = dbLogCompanyGroup.tiType;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbLogCompanyGroup.vcIP;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LogCompanyPeople_Ins (회사조직구성원 로그 등록)
        /// <summary>
        /// 회사조직구성원 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLogCompanyPeople"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LogCompanyPeople_Ins(DBConnectionEntity dbConnectionEntity, tbLogCompanyPeople dbLogCompanyPeople)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LogCompanyPeople_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.LogDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biTXIDX", MySqlDbType.Int64).Value = dbLogCompanyPeople.biTXIDX;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLogCompanyPeople.iManagerSeq;
                    command.Parameters.Add("@p_iSeq", MySqlDbType.Int32).Value = dbLogCompanyPeople.iSeq;
                    command.Parameters.Add("@p_iCompanyGroupSeq", MySqlDbType.Int32).Value = dbLogCompanyPeople.iCompanyGroupSeq;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 32).Value = dbLogCompanyPeople.vcName;
                    command.Parameters.Add("@p_vcPosition", MySqlDbType.VarChar, 64).Value = dbLogCompanyPeople.vcPosition;
                    command.Parameters.Add("@p_tDescription", MySqlDbType.Text).Value = dbLogCompanyPeople.tDescription;
                    command.Parameters.Add("@p_vcFolder", MySqlDbType.VarChar, 256).Value = dbLogCompanyPeople.vcFolder;
                    command.Parameters.Add("@p_vcImage", MySqlDbType.VarChar, 128).Value = dbLogCompanyPeople.vcImage;
                    command.Parameters.Add("@p_tiType", MySqlDbType.Bit).Value = dbLogCompanyPeople.tiType;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbLogCompanyPeople.vcIP;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LogBlog_Ins (블로그 로그 등록)
        /// <summary>
        /// 블로그 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLogBlog"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LogBlog_Ins(DBConnectionEntity dbConnectionEntity, tbLogBlog dbLogBlog)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LogBlog_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.LogDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biTXIDX", MySqlDbType.Int64).Value = dbLogBlog.biTXIDX;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLogBlog.iManagerSeq;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Value = dbLogBlog.biSeq;
                    command.Parameters.Add("@p_vcTitle", MySqlDbType.VarChar, 128).Value = dbLogBlog.vcTitle;
                    command.Parameters.Add("@p_vcTitleFolder", MySqlDbType.VarChar, 256).Value = dbLogBlog.vcTitleFolder;
                    command.Parameters.Add("@p_vcTitleImage", MySqlDbType.VarChar, 128).Value = dbLogBlog.vcTitleImage;
                    command.Parameters.Add("@p_tDescription", MySqlDbType.Text).Value = dbLogBlog.tDescription;
                    command.Parameters.Add("@p_tiType", MySqlDbType.Bit).Value = dbLogBlog.tiType;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbLogBlog.vcIP;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LogBlogComment_Ins (블로그 댓글 로그 등록)
        /// <summary>
        /// 블로그 댓글 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLogBlogComment"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LogBlogComment_Ins(DBConnectionEntity dbConnectionEntity, tbLogBlogComment dbLogBlogComment)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LogBlogComment_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.LogDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biTXIDX", MySqlDbType.Int64).Value = dbLogBlogComment.biTXIDX;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLogBlogComment.iManagerSeq;
                    command.Parameters.Add("@p_biSeq", MySqlDbType.Int64).Value = dbLogBlogComment.biSeq;
                    command.Parameters.Add("@p_biBlogSeq", MySqlDbType.Int64).Value = dbLogBlogComment.biBlogSeq;
                    command.Parameters.Add("@p_biMemberSeq", MySqlDbType.Int64).Value = dbLogBlogComment.biMemberSeq;
                    command.Parameters.Add("@p_vcAccount", MySqlDbType.VarChar, 32).Value = dbLogBlogComment.vcAccount;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 32).Value = dbLogBlogComment.vcName;
                    command.Parameters.Add("@p_tDescription", MySqlDbType.Text).Value = dbLogBlogComment.tDescription;
                    command.Parameters.Add("@p_tiType", MySqlDbType.Bit).Value = dbLogBlogComment.tiType;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbLogBlogComment.vcIP;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion


        #region // !++ DAL_LogBlogLike_Ins (블로그 좋아요 로그 등록)
        /// <summary>
        /// 블로그 좋아요 로그 등록
        /// </summary>
        /// <param name="dbConnectionEntity"></param>
        /// <param name="dbLogBlogLike"></param>
        /// <returns>
        ///  1: 성공          (Success_DB_Normal),
        /// -4: 데이터 없음   (Error_DB_NoData),
        /// -5: 이미 사용중   (Error_DB_AlreadyUsing),
        /// -6: 트랜젝션 롤백 (Error_DB_TransactionRollback)
        /// </returns>
        public async Task<ResultEntity<Int32>> DAL_LogBlogLike_Ins(DBConnectionEntity dbConnectionEntity, tbLogBlogLike dbLogBlogLike)
        {
            var getResult = new ResultEntity<Int32>();
            var storedProcedure = "usp_LogBlogLike_Ins";
            using (var connection = new MySqlConnection(dbConnectionEntity.LogDBConnection))
            {
                using (var command = new MySqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@p_biTXIDX", MySqlDbType.Int64).Value = dbLogBlogLike.biTXIDX;
                    command.Parameters.Add("@p_iManagerSeq", MySqlDbType.Int32).Value = dbLogBlogLike.iManagerSeq;
                    command.Parameters.Add("@p_biBlogSeq", MySqlDbType.Int64).Value = dbLogBlogLike.biBlogSeq;
                    command.Parameters.Add("@p_biMemberSeq", MySqlDbType.Int64).Value = dbLogBlogLike.biMemberSeq;
                    command.Parameters.Add("@p_vcAccount", MySqlDbType.VarChar, 32).Value = dbLogBlogLike.vcAccount;
                    command.Parameters.Add("@p_vcName", MySqlDbType.VarChar, 32).Value = dbLogBlogLike.vcName;
                    command.Parameters.Add("@p_tiType", MySqlDbType.Bit).Value = dbLogBlogLike.tiType;
                    command.Parameters.Add("@p_vcIP", MySqlDbType.VarChar, 16).Value = dbLogBlogLike.vcIP;
                    command.Parameters.Add("@p_Result", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@p_Msg", MySqlDbType.Text).Direction = ParameterDirection.Output;

                    await command.Connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                    await command.Connection.CloseAsync();

                    getResult.result = Int32.Parse(command.Parameters["@p_Result"].Value.ToString());
                    getResult.ErrorMsg = command.Parameters["@p_Msg"].Value.ToString();
                }
            }
            return getResult;
        }
        #endregion

    }
    #endregion

}
