import { Component, OnInit, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { FormGroup, FormBuilder, Validators, ValidationErrors } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { NgxSpinnerService } from "ngx-spinner";

import { CommonService, PlatFormService } from '../../service';
import { PlatFormModel } from '../../model';

@Component({ 
    selector: 'app-popup',
    templateUrl: './platformapiregist.component.html', 
    styleUrls: ['../scss/regEdit.component.scss']
})

export class PlatFormApiRegistComponent implements OnInit
{
    registForm:FormGroup;
    mPlatForm:PlatFormModel[] = [];
    mTotalFaqCode:number = 0;

    currPageFaqCode:number = 1;
    lenFaqCode:number = 100;

    constructor(private mService:PlatFormService,
                private cmnService:CommonService,
                private translate:TranslateService,
                private spinnerService:NgxSpinnerService,
                public dialogRef: MatDialogRef<PlatFormApiRegistComponent>, 
                @Inject(MAT_DIALOG_DATA) public data:any,
                private fb:FormBuilder){
    }

    ngOnInit():void
    {
        this.registForm = this.fb.group({
            iPlatFormSeq:['', Validators.required],
            vcApiUrl:['', Validators.required],
            vcID:['', Validators.required],
            vcVerifyKey:['', Validators.required],
            tiStatus:[0, Validators.required]
        });

        // PlatForm api 목록
        this.getPlatFormList(this.currPageFaqCode, this.lenFaqCode);
    }

    // Action
    onRegist():void
    {
        this.mService.regEditPlatFormApi(this.registForm.value, true).subscribe(
            (res) => this.onClose(true),
            (err) => { this.onClose(false); console.log(err);}
        );
    }

    // Reset
    onReset():void
    {
        this.registForm.patchValue ({iPlatFormSeq: ''});
        this.registForm.patchValue ({vcApiUrl: ''});
        this.registForm.patchValue ({vcID: ''});
        this.registForm.patchValue ({vcVerifyKey: ''});
        this.registForm.patchValue ({tiStatus: 0});
    }

    // popup close
    onClose(param:any):void{
        this.dialogRef.close(param);
    }

    // PlatForm list
    getPlatFormList(curPage:number, len:number):void
    {
        setTimeout(() => this.spinnerService.show(), 0);

        this.mService.getPlatFormList(curPage, len).subscribe(
            list => {
                this.mPlatForm = list.data.gClass;
                this.mTotalFaqCode = list.data.totalRecord;
            },
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

}