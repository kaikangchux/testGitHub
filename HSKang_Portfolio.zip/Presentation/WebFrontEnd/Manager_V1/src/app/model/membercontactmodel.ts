// 회원연락처정보
export class MemberContactModel
{

  biMemberSeq: number;
  vcPhoneCountry: string;
  vcPhoneFirst: string;
  vcPhoneSecond: string;
  vcPhoneThird: string;
  vcMobileFirst: string;
  vcMobileSecond: string;
  vcMobileThird: string;

  constructor() {
    this.biMemberSeq = 0;
    this.vcPhoneCountry = '';
    this.vcPhoneFirst = '';
    this.vcPhoneSecond = '';
    this.vcPhoneThird = '';
    this.vcMobileFirst = '';
    this.vcMobileSecond = '';
    this.vcMobileThird = '';
  }
}
