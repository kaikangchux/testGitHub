// 블로그
export class BlogModel
{

  biSeq: number;
  vcTitle: string;
  vcTitleFolder: string;
  vcTitleImage: string;
  tDescription: string;
  iRead: number;
  iComment: number;
  iLike: number;
  iManagerSeq: number;
  dtRegDate: string;

  constructor() {
    this.biSeq = 0;
    this.vcTitle = '';
    this.vcTitleFolder = '';
    this.vcTitleImage = '';
    this.tDescription = '';
    this.iRead = 0;
    this.iComment = 0;
    this.iLike = 0;
    this.iManagerSeq = 0;
    this.dtRegDate = '';
  }

}
