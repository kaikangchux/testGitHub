﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.CrawlingDB
{

    #region // !++ tbPrivateBoard
    /// <summary>
    /// tbPrivateBoard
    /// </summary>
    [Table("tbPrivateBoard")]
    public class tbPrivateBoard
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        /// <summary>
        /// 고유번호(AI)
        /// </summary>
        public Int64 biSeq { get; set; }

        [Key, Required]
        /// <summary>
        /// 게시판타입(1:공지사항, 2:뉴스, 3:..)
        /// </summary>
        public Int16 tiType { get; set; }

        [Required, MinLength(2), MaxLength(64)]
        /// <summary>
        /// 제목(언어ID)
        /// </summary>
        public String vcTitleKeyText { get; set; }

        [Required, MinLength(2), MaxLength(64)]
        /// <summary>
        /// 내용(언어ID)
        /// </summary>
        public String vcDescriptKeyText { get; set; }

        [Index(1), Required]
        /// <summary>
        /// Main등록여부(1:노출안함, 2:노출)
        /// </summary>
        public Int16 tiMain { get; set; }

        /// <summary>
        /// 조회수
        /// </summary>
        public Int32 iRead { get; set; }

        /// <summary>
        /// 관리자고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
