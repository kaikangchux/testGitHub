﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authentication.JwtBearer;

using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Manager;
using Lib.Crawling.Library.Entities.Account;
using Lib.Crawling.Library.Utilities;
using Lib.Crawling.Library.Log;
using Lib.Crawling.Library.DataContainers;

using WebApi_SpiderKim_Manager_V1.Handlers;
using WebApi_SpiderKim_Manager_V1.WebUtilities;

namespace WebApi_SpiderKim_Manager_V1.Controllers
{

    #region // !++ AccountController
    /// <summary>
    /// AccountController
    /// </summary>
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {


        #region // !++ Event handler(funtions)
        /// <summary>
        /// StaticDataHandler
        /// </summary>
        public StaticDataHandler staticDataHandler = new StaticDataHandler();

        /// <summary>
        /// LibUtility
        /// </summary>
        public LibUtility libUtility = new LibUtility();

        /// <summary>
        /// LibWebUtility
        /// </summary>
        public LibWebUtility libWebUtility = new LibWebUtility();

        /// <summary>
        /// LibraryController
        /// </summary>
        public LibraryController libraryController = new LibraryController();
        #endregion


        #region // !++ GetAccountList (회원 목록)
        /// <summary>
        /// 회원 목록
        /// </summary>
        /// <param name="page"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        [HttpGet("AccountList")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> GetAccountList([FromQuery] Int32 page, Int32 pageSize)
        {

            // Return message
            var resultClient = new ResultClientEntity<ListPageDataContainer<List<MemberEntity>>>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion

                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ Parameter value
                if (libUtility.IsSpace(libWebUtility.OnNullCheckInt(page.ToString()).ToString()))
                    page = 1;

                if (libUtility.IsSpace(pageSize.ToString()))
                    pageSize = 20;
                #endregion

                #region // !++ DB 정보가져오기
                var pageModel = new PageDBEntity()
                {
                    page = page,
                    pageSize = pageSize
                };
                var resultData = await AccountHandler.GetMemberList(dbConnectionEntity, pageModel);
                #endregion

                #region // !++ Client message
                resultClient.success = true;
                resultClient.msg = String.Empty;
                resultClient.error = String.Empty;
                resultClient.data = resultData;
                #endregion

                return Ok(resultClient);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API GetAccountList : \n [Page:{0}], \n [PageSize:{1}], \n {2}, \n {3}",
                                        page, pageSize, exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }

        }
        #endregion


    }
    #endregion

}