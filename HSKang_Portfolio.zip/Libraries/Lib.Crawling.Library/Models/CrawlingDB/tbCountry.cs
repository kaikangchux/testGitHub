﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.CrawlingDB
{

    #region // !++ tbCountry
    /// <summary>
    /// 국가
    /// </summary>
    [Table("tbCountry")]
    public class tbCountry
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        /// <summary>
        /// 고유번호(AI)
        /// </summary>
        public Int16 siSeq { get; set; }

        [Required, MinLength(2), MaxLength(32)]
        /// <summary>
        /// 국가명
        /// </summary>
        public String vcName { get; set; }

        [Required, MinLength(2), MaxLength(4)]
        /// <summary>
        /// 국가코드
        /// </summary>
        public String vcCountryCode { get; set; }

        [Required, MinLength(2), MaxLength(64)]
        /// <summary>
        /// 언어ID
        /// </summary>
        public String vcKeyText { get; set; }

        /// <summary>
        /// 사용여부(1:사용, 2:대기, 3:삭제)
        /// </summary>
        public Int16 tiStatus { get; set; }

        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
