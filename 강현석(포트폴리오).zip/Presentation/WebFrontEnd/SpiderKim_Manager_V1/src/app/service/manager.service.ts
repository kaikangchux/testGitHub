import { Injectable, EventEmitter, OnDestroy } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/internal/Observable';
import { BehaviorSubject, Subscription } from 'rxjs';
import * as CryptoJS from 'crypto-js';
import base64url from 'base64url';
import * as jwt_decode from 'jwt-decode';

import { ConfigService } from '../config';
import { CommonService } from './common.service';
import { ResultServerData, ResultServerDatalist } from '../common';
import { ManagerModel, ManagerLoginInfo } from '../model';

@Injectable({
    providedIn: 'root'
})

export class ManagerService implements OnDestroy
{
    managerList:ManagerModel[] = [];
    managerListBS= new BehaviorSubject<ManagerModel[]>([]);
    managerList$ = this.managerListBS.asObservable();

    evtEmitter = new EventEmitter();    
    evtEmitterSub:Subscription;

    constructor(private router:Router,
                private cmnService:CommonService,
                private http:HttpClient){}

    changeManagerList(managerList:ManagerModel[]){
        this.managerList = managerList;
        this.managerListBS.next(managerList);
    }

    login(dataForm: any): void
    {
        const formData = { vcManagerID: dataForm.vcManagerID, vcPassword: dataForm.vcPassword };
        const url = this.cmnService.requestUrl(`/api/Manager/Login`);
        this.http.post<any>(url, JSON.stringify(formData), { headers: new HttpHeaders().set('Content-Type', 'application/json; charset=UTF-8')})
                     .subscribe((response) => this.loginProc(response));
    }

    loginProc(res:any):void
    {
        if(!res.success){
            alert(res.msg);
            this.logout();
            return;
        }

        let data = ((res.data.token)).split('.');
        var signature = base64url.fromBase64((CryptoJS.HmacSHA256(data[0] + "." + data[1], ConfigService.CRYPT_KEY).toString(CryptoJS.enc.Base64)));

        if(data[2] != signature){
            //TODO 에러 코드나 메세지가 정의되면 alert 추가
            this.logout();
            return;
        }

        localStorage.setItem('currentMUser', res.data.token);
        this.router.navigate(['/list']);
    }

    getLoginMUserInfo():ManagerLoginInfo
    {
        let token = localStorage.getItem('currentMUser');
        if(!token){
            return null;
        }

        let payload = jwt_decode(token);
        return JSON.parse(payload.ManagerInfo);
    }

    getLoginUserInfo(iSeq:number):any
    {
        if(this.managerList.length == 0){
            return null;
        }

        let idx = this.managerList.length;

        var mInfo = this.managerList.find((element:ManagerModel, index:number) => {
            idx--;
            return element.iSeq == iSeq;
        });

        return {mInfo:mInfo, idx:idx};
    }

    //detail view 화면
    getMUserInfo(iSeq:number):ManagerModel
    {
        return this.managerList.find((element:ManagerModel) => {
            return element.iSeq == iSeq;
        });
    }

    logout(route:boolean=true):void
    {
        localStorage.removeItem('currentMUser');
        if(route === true){
            this.router.navigate(['']);
        }
    }

    getManagerList(page:number, pageSize:number):Observable<any>
    {
        const url = this.cmnService.requestUrl(`/api/manager/managerlist?page=${page}&pageSize=${pageSize}`);
        return this.http.get<ResultServerData<ResultServerDatalist<ManagerModel[]>>>(url);
    }

    regEditManager(mUser:ManagerModel, isAdd:boolean, idx:number):Observable<any>
    {
        const urlStr = (isAdd) ? `/api/Manager/Regist` : `/list/${idx}`;
        const url = this.cmnService.requestUrl(urlStr);

        return this.http[(isAdd) ? 'post' : 'put'](url, mUser);
    }

    deleteManager(mUser:ManagerModel, idx:number):Observable<any>
    {
        const url = this.cmnService.requestUrl(`/list/${idx}`);
        return this.http.delete(url);
    }

    //Sidebar에서 변경을 눌렀을 경우 ListComponent의 이벤트 호출을 위한 함수
    onEventEmite(param:any) {    
        this.evtEmitter.emit(param);
    }

    ngOnDestroy():void{
        this.managerListBS.unsubscribe();
    }
}
