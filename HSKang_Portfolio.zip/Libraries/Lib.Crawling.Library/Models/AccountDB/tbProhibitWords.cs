﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.AccountDB
{

    #region // !++ tbProhibitWords
    /// <summary>
    /// tbProhibitWords(금지어)
    /// </summary>
    [Table("tbProhibitWords")]
    public class tbProhibitWords
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.None), MinLength(1), MaxLength(32)]
        /// <summary>
        /// 사용불가문자
        /// </summary>
        public String vcProhibitWords { get; set; }

        /// <summary>
        /// 비고(노트)
        /// </summary>
        public String vcNote { get; set; }

        [Required]
        /// <summary>
        /// 사용여부(1:사용, 2:대기)
        /// </summary>
        public Int16 tiStatus { get; set; }

        [Required]
        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
