﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

using log4net;
using log4net.Appender;
using log4net.Config;

namespace Lib.Crawling.Library.Log
{

    #region // !++ ELogType Enum
    /// <summary>
    /// 
    /// </summary>
    public enum ELogType
    {
        None = 0,       // 모름
        Debug = 1,      // 디버그
        Info = 2,       // 정보
        Warning = 3,    // 경보
        Error = 4,      // 오류
        Fatal = 5,      // 치명적 오류
    }
    #endregion


    #region // !++ LoggerBase
    /// <summary>
    /// 
    /// </summary>
    public abstract class LoggerBase
    {
        //!++ Debug 여부
#if TEST
        public static bool isDebug = true;
#else
        public static bool isDebug = false;
#endif

        private static readonly ILog iLog = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        protected static readonly string logLayout = "%date [%5thread] %5level - %message%newline";

        private static readonly log4net.Repository.ILoggerRepository logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
        public virtual void Init() { BasicConfigurator.Configure(logRepository, GetAppender()); }

        // public virtual void Init() { BasicConfigurator.Configure(null, GetAppender()); }

        public abstract IAppender GetAppender();

        public virtual void Log(ELogType eLogType, string logMsg)
        {
            switch (eLogType)
            {
                case ELogType.Debug: if (isDebug) iLog.Debug(logMsg); break;
                case ELogType.Info: iLog.Info(logMsg); break;
                case ELogType.Warning: iLog.Warn(logMsg); break;
                case ELogType.Error: iLog.Error(logMsg); break;
                case ELogType.Fatal: iLog.Fatal(logMsg); break;
            }
        }

        public virtual void Log(ELogType eLogType, string logFormat, params object[] paramArray)
        {
            switch (eLogType)
            {
                case ELogType.Debug: if (isDebug) iLog.DebugFormat(logFormat, paramArray); break;
                case ELogType.Info: iLog.InfoFormat(logFormat, paramArray); break;
                case ELogType.Warning: iLog.WarnFormat(logFormat, paramArray); break;
                case ELogType.Error: iLog.ErrorFormat(logFormat, paramArray); break;
                case ELogType.Fatal: iLog.FatalFormat(logFormat, paramArray); break;
            }
        }

        public virtual void Log(ELogType eLogType, string logMsg, Exception exc)
        {
            switch (eLogType)
            {
                case ELogType.Debug: if (isDebug) iLog.Debug(logMsg, exc); break;
                case ELogType.Info: iLog.Info(logMsg, exc); break;
                case ELogType.Warning: iLog.Warn(logMsg, exc); break;
                case ELogType.Error: iLog.Error(logMsg, exc); break;
                case ELogType.Fatal: iLog.Fatal(logMsg, exc); break;
            }
        }

        public virtual void Log(ELogType eLogType, Exception exc)
        {
            switch (eLogType)
            {
                case ELogType.Debug: if (isDebug) iLog.Debug(exc); break;
                case ELogType.Info: iLog.Info(exc); break;
                case ELogType.Warning: iLog.Warn(exc); break;
                case ELogType.Error: iLog.Error(exc); break;
                case ELogType.Fatal: iLog.Fatal(exc); break;
            }
        }
    }
    #endregion

}
