﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lib.Crawling.Library.Entities
{

    #region // !++ DBConnectionEntity
    /// <summary>
    /// DB 커넥션
    /// </summary>
    [Serializable]
    public class DBConnectionEntity
    {

        /// <summary>
        /// 계정DB
        /// </summary>
        public String AccountDBConnection { get; set; }

        /// <summary>
        /// 크롤링DB
        /// </summary>
        public String CrawlingDBConnection { get; set; }

        /// <summary>
        /// 로그DB
        /// </summary>
        public String LogDBConnection { get; set; }

        /// <summary>
        /// 관리자DB
        /// </summary>
        public String ManagerDBConnection { get; set; }

        /// <summary>
        /// MongoDB
        /// </summary>
        public String MongoDBConnection { get; set; }

        public DBConnectionEntity()
        {
            AccountDBConnection = String.Empty;
            CrawlingDBConnection = String.Empty;
            LogDBConnection = String.Empty;
            ManagerDBConnection = String.Empty;
            MongoDBConnection = String.Empty;
        }
        ~DBConnectionEntity()
        {
            AccountDBConnection = String.Empty;
            CrawlingDBConnection = String.Empty;
            LogDBConnection = String.Empty;
            ManagerDBConnection = String.Empty;
            MongoDBConnection = String.Empty;
        }

    }
    #endregion

}
