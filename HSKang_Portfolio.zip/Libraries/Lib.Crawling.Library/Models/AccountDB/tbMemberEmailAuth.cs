﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lib.Crawling.Library.Models.AccountDB
{

    #region // !++ tbMemberEmailAuth
    /// <summary>
    /// tbMemberEmailAuth(회원Email인증)
    /// </summary>
    [Table("tbMemberEmailAuth")]
    public class tbMemberEmailAuth
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        /// <summary>
        /// 회원고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        [Required, MinLength(2), MaxLength(64)]
        /// <summary>
        /// E-mail ID
        /// </summary>
        public String vcEmailID { get; set; }

        [Required, MinLength(2), MaxLength(128)]
        /// <summary>
        /// E-mail 주소
        /// </summary>
        public String vcEmailAddress { get; set; }

        [Required, MinLength(2), MaxLength(256)]
        /// <summary>
        /// 인증정보(발송메일 인증문자)
        /// </summary>
        public String vcAuth { get; set; }

        [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 인증일시
        /// </summary>
        public DateTime dtAuthDate { get; set; }

    }
    #endregion

}
