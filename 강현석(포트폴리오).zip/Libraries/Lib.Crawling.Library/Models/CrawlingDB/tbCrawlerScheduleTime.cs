﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.CrawlingDB
{

    #region // !++ tbCrawlerScheduleTime
    /// <summary>
    /// 크롤링 스케줄 시간
    /// </summary>
    [Table("tbCrawlerScheduleTime")]
    public class tbCrawlerScheduleTime
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        /// <summary>
        /// 고유번호
        /// </summary>
        public Int64 biSeq { get; set; }

        [Index(1), Required]
        /// <summary>
        /// 회원 고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        [Index(2), Required]
        /// <summary>
        /// 크롤링 스케줄 고유번호
        /// </summary>
        public Int64 biCrawlerScheduleSeq { get; set; }

        /// <summary>
        /// 회차(횟수) 번호
        /// </summary>
        public Int32 iNumber { get; set; }

        /// <summary>
        /// 실행시간(밀리세컨)
        /// </summary>
        public Int64 biMillisecond { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시(스케줄완료일시)
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
