﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Security.Claims;
using System.Text;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;

using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Entities.Manager;
using Lib.Crawling.Library.Utilities;
using Lib.Crawling.Library.Log;
using Lib.Crawling.Library.DataContainers;

using WebApi_SpiderKim_Manager_V1.Handlers;
using WebApi_SpiderKim_Manager_V1.WebUtilities;

namespace WebApi_SpiderKim_Manager_V1.Controllers
{

    #region // !++ ManagerController
    /// <summary>
    /// ManagerController
    /// </summary>
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class ManagerController : ControllerBase
    {

        #region // !++ Event handler(funtions)
        /// <summary>
        /// StaticDataHandler
        /// </summary>
        public StaticDataHandler staticDataHandler = new StaticDataHandler();

        /// <summary>
        /// LibUtility
        /// </summary>
        public LibUtility libUtility = new LibUtility();

        /// <summary>
        /// LibWebUtility
        /// </summary>
        public LibWebUtility libWebUtility = new LibWebUtility();

        /// <summary>
        /// LibraryController
        /// </summary>
        public LibraryController libraryController = new LibraryController();
        #endregion


        #region // !++ Class 상속
        private readonly IConfiguration _configuration;

        public ManagerController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        #endregion


        #region // !++ SetCreateToken (JWT Token 만들기)
        /// <summary>
        /// JWT Token 만들기
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        private ManagerLoginTokenEntity SetCreateToken(ManagerLoginEntity model)
        {

            try
            {

                #region // !++ [1] 보안키 생성
                var key = _configuration.GetSection("SymmetricSecurityKey").Value;
                var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
                var signingCredentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
                #endregion

                #region // !++ [2] 클레임 생성
                var claims = new Claim[]
                {
                    // new Claim(JwtRegisteredClaimNames.Sub, loginModel.vcManagerID)
                    new Claim(ClaimTypes.Role, "SpiderKimManager"),                     // Role
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),  // Random GUID
                    new Claim(JwtRegisteredClaimNames.Website, _configuration.GetSection("SpiderKimManagerSettings").GetSection("DomainUrl").Value),    // Site
                    new Claim("ManagerInfo", libUtility.ToJson(model))                  // Manager Json info
                };
                #endregion

                #region // !++ [3] 토큰 생성하기
                var token = new JwtSecurityToken(
                        claims: claims,
                        signingCredentials: signingCredentials,
                        issuer: _configuration.GetSection("SpiderKimManagerSettings").GetSection("Issuer").Value,
                        audience: _configuration.GetSection("SpiderKimManagerSettings").GetSection("Audience").Value,
                        // expires: DateTime.Now.AddMinutes(Int32.Parse(_configuration.GetSection("SpiderKimManagerSettings").GetSection("ExpiredDays").Value))
                        expires: DateTime.Now.AddDays(Int32.Parse(_configuration.GetSection("SpiderKimManagerSettings").GetSection("ExpiredDays").Value))
                    );
                var resultToken = new JwtSecurityTokenHandler().WriteToken(token);
                #endregion

                #region // !++ [4] Return value
                var retunDate = new ManagerLoginTokenEntity()
                {
                    Token = resultToken,
                    ExpiredDate = token.ValidTo
                };
                #endregion

                // [!] 토큰 반환
                return retunDate;
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API SetCreateToken : \n [ManagerLoginEntity:{0}], \n {1}, \n {2}",
                                        libUtility.ToJson(model), exc.Message, exc.StackTrace);

                return null;
            }
        }
        #endregion


        #region // !++ SetCreateCookie (쿠키 정보 만들기)
        /// <summary>
        /// 쿠키 정보 만들기
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        private async Task<Boolean> SetCreateCookie(ManagerLoginEntity model)
        {

            try
            {

                #region // !++ 인증 부여: 인증된 사용자의 주요 정보(Name, Role, ...)를 기록
                var claims = new List<Claim>()
                    {
                        // 로그인 아이디 지정
                        new Claim("AdminSeq", model.adminSeq.ToString()),

                        new Claim(ClaimTypes.NameIdentifier, model.adminId),

                        new Claim(ClaimTypes.Name, model.adminId), 

                        // 기본 역할 지정, "Role" 기능에 "Users" 값 부여
                        new Claim(ClaimTypes.Role, "SpiderKimManager") // 추가 정보 기록
                    };

                var ci = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                // var ci = new ClaimsIdentity(claims, _configuration.GetSection("SpiderKimManagerSettings").GetSection("DomainCookie").Value);

                var authenticationProperties = new AuthenticationProperties()
                {
                    ExpiresUtc = DateTimeOffset.UtcNow.AddMinutes(60),
                    IssuedUtc = DateTimeOffset.UtcNow,
                    IsPersistent = true
                };

                // await HttpContext.SignInAsync(_configuration.GetSection("SpiderKimManagerSettings").GetSection("DomainCookie").Value, new ClaimsPrincipal(ci), authenticationProperties);
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(ci), authenticationProperties);
                #endregion


                return true;
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API SetCreateCookie : \n [ManagerLoginEntity:{0}], \n {1}, \n {2}",
                                        libUtility.ToJson(model), exc.Message, exc.StackTrace);

                return false;
            }

        }
        #endregion


        #region // !++ Login (관리자 로그인)
        /// <summary>
        /// 관리자 로그인
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        [HttpPost("Login")]
        [AllowAnonymous]    // 인증되지 않은 사용자도 접근 가능
        public async Task<IActionResult> GetLogin([FromBody] ManagerLoginFormEntity loginModel)
        {

            // Return message
            var resultClient = new ResultClientEntity<ManagerLoginTokenEntity>();

            try
            {

                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion


                #region // !++ Value check
                if (String.IsNullOrEmpty(loginModel.vcManagerID) || String.IsNullOrEmpty(loginModel.vcPassword))
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "계정 또는 암호가 없습니다.";
                    resultClient.error = "계정 또는 암호가 없습니다.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 정보 가져오기
                var model = new ManagerEntity()
                {
                    vcManagerID = loginModel.vcManagerID,
                    vcPassword = loginModel.vcPassword
                };
                var resultData = await ManagerHandler.GetManagerLogin(dbConnectionEntity, model);
                #endregion


                if (resultData.bresult == false)
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "일치하는 정보가 없습니다.";
                    resultClient.error = "일치하는 정보가 없습니다.";
                    resultClient.data = null;
                    #endregion
                }
                else
                {

                    #region // !++ JWT Token 생성
                    var resultToken = Task.Run(() => SetCreateToken(resultData.gClass)).Result;
                    #endregion

                    #region // !++ Token 예외처리
                    if (resultToken == null)
                    {
                        #region // !++ Client message
                        resultClient.success = false;
                        resultClient.msg = "Access token failed";
                        resultClient.error = "Access token failed";
                        resultClient.data = null;
                        #endregion
                    }
                    else
                    {
                        #region // !++ Client message
                        resultClient.success = true;
                        resultClient.msg = null;
                        resultClient.error = null;
                        resultClient.data = resultToken;
                        #endregion
                    }
                    #endregion
                }

                return Ok(resultClient);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API GetLogin : \n [ManagerLoginFormEntity:{0}], \n {1}, \n {2}",
                                        libUtility.ToJson(loginModel), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }
        }
        #endregion


        #region // !++ GetManagerList (관리자 리스트)
        /// <summary>
        /// 관리자 리스트
        /// </summary>
        /// <returns></returns>
        // [Authorize]
        [HttpGet("ManagerList")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> GetManagerList([FromQuery] Int32 page, Int32 pageSize)
        {

            // Return message
            var resultClient = new ResultClientEntity<ListPageDataContainer<List<ManagerEntity>>>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion

                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ Parameter value
                if (libUtility.IsSpace(libWebUtility.OnNullCheckInt(page.ToString()).ToString()))
                    page = 1;

                if (libUtility.IsSpace(pageSize.ToString()))
                    pageSize = 20;
                #endregion

                #region // !++ DB 정보가져오기
                var pageModel = new PageDBEntity()
                {
                    page = page,
                    pageSize = pageSize
                };
                var resultData = await ManagerHandler.GetManagerList(dbConnectionEntity, pageModel);
                #endregion

                #region // !++ Client message
                resultClient.success = true;
                resultClient.msg = String.Empty;
                resultClient.error = String.Empty;
                resultClient.data = resultData;
                #endregion

                return Ok(resultClient);

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API GetManagerList : \n [Page:{0}], \n [PageSize:{1}], \n {2}, \n {3}",
                                        page, pageSize, exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }

        }
        #endregion


        #region // !++ SetManagerRegist (관리자 등록)
        /// <summary>
        /// 관리자 등록
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("Regist")]
        [Produces("application/json", Type = typeof(ManagerEntity))]
        [Consumes("application/json")] // application/xml
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> SetManagerRegist([FromBody] ManagerEntity model)
        {

            // Return message
            var resultClient = new ResultClientEntity<Int32?>();

            try
            {

                #region // !++ Parameter value check
                if (model == null)
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied parameter.";
                    resultClient.error = "Invalied parameter.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }

                // E-mail 확인
                if (libUtility.GetEmailParamValue(String.Concat(model.vcEmailID, model.vcEmailAddress)) == false)
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "The e-mail format is not correct.";
                    resultClient.error = "The e-mail format is not correct.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }

                // 연락처 확인
                if (libUtility.GetOnlyNum(model.vcPhone) == false)
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "The phone format is not correct.";
                    resultClient.error = "The phone format is not correct.";
                    resultClient.data = null;
                    #endregion
                    return Ok(resultClient);
                }
                #endregion


                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ DB 등록하기
                var resultData = await ManagerHandler.SetManagerRegist(dbConnectionEntity, model, managerLogin);
                #endregion

                #region // !++ Client message
                if (resultData == 1)
                {
                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = null;

                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);
            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API SetManagerRegist : \n [ManagerEntity:{0}], \n {1}, \n {2}",
                                        libUtility.ToJson(model), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }
        }
        #endregion


        #region // !++ GetManagerInfo (관리자 상세정보)
        /// <summary>
        /// 관리자 상세정보
        /// </summary>
        /// <returns></returns>
        [HttpGet("{id:int}")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "SpiderKimManager")]
        public async Task<IActionResult> GetManagerInfo(Int32 id)
        {
            
            // Return message
            var resultClient = new ResultClientEntity<ManagerEntity>();

            try
            {

                #region // !++ 관리자 정보 가져오기
                var managerLogin = new ManagerLoginEntity();

                if (User.Identity.IsAuthenticated)
                {
                    managerLogin = Task.Run(() => libraryController.GetManagerLoginInfo(User)).Result;
                }
                else
                {
                    #region // !++ Client message
                    resultClient.success = false;
                    resultClient.msg = "Invalied Login info";
                    resultClient.error = "Invalied Login info";
                    resultClient.data = null;
                    #endregion

                    return Ok(resultClient);
                }
                #endregion


                #region // !++ DB 연결 문자열
                var dbConnectionEntity = staticDataHandler.GetDataBaseConnection();
                #endregion

                #region // !++ Data struct 변경
                var model = new ManagerEntity()
                {
                    iSeq = id
                };
                #endregion

                #region // !++ 정보가져오기
                var resultData = await ManagerHandler.GetManagerInfo(dbConnectionEntity, model);
                #endregion

                #region // !++ Client message
                if (resultData != null)
                {
                    resultClient.success = true;
                    resultClient.msg = String.Empty;
                    resultClient.error = String.Empty;
                    resultClient.data = resultData;

                }
                else
                {
                    resultClient.success = false;
                    resultClient.msg = resultData.ToString();
                    resultClient.error = resultData.ToString();
                    resultClient.data = null;
                }
                #endregion

                return Ok(resultClient);

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "API GetManagerInfo : \n [ID:{0}], \n {1}, \n {2}",
                                        id.ToString(), exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }
        }
        #endregion


        


        #region // !++ SetLogOut (로그아웃)
        /// <summary>
        /// 로그아웃
        /// </summary>
        /// <returns></returns>
        [HttpPost("Logout")]
        public async Task<IActionResult> SetLogOut()
        {
            // Return message
            var resultClient = new ResultClientEntity<ManagerEntity>();

            try
            {

                await HttpContext.SignOutAsync("Cookies");

                #region // !++ Client message
                resultClient.success = true;
                resultClient.msg = String.Empty;
                resultClient.error = String.Empty;
                resultClient.data = null;
                #endregion

                return Ok(resultClient);

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "SetLogOut :\n {0}, \n {1}",
                                        exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }

        }
        #endregion


        [HttpGet("LoginTest")]
        // [Authorize]
        // [Authorize(Roles = "Users")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public IActionResult LoginTest()
        {
            //return Ok("인증된 사용자만 보는 내용");
            return Ok(HttpContext.User.Claims.First().Value); // a@a.com
        }


        [HttpGet("LoginOutTest")]
        // [Authorize]
        // [Authorize(Roles = "Users")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public IActionResult LoginOutTest()
        {

            var resultClient = new ResultClientEntity<Int32?>();

            // return Ok("인증된 사용자만 보는 내용");
            // return Ok(HttpContext.User.Claims.First().Value); // a@a.com

            // var t = HttpContext.User.Claims.Where(x => x.Type ==);

            #region // !++ Client message
            resultClient.success = true;
            resultClient.msg = null;
            resultClient.error = null;
            resultClient.data = null;
            #endregion

            JwtBearerDefaults.AuthenticationScheme.Replace(HttpContext.User.Claims.ToList().ToString(), "");

            

            return Ok(resultClient);
        }


    }
    #endregion

}