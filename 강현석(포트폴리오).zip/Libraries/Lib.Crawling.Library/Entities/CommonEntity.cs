﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lib.Crawling.Library.Entities
{

    #region // !++ PageEntity
    /// <summary>
    /// 페이지
    /// </summary>
    [Serializable]
    public class PageEntity
    {

        /// <summary>
        /// 레코드 출력
        /// </summary>
        public String record { get; set; }

        /// <summary>
        /// 페이지 번호
        /// </summary>
        public Int32 pageNumber { get; set; }

        /// <summary>
        /// 전체 페이지 수
        /// </summary>
        public Int32 totalPage { get; set; }

        /// <summary>
        /// 전체 레코드 수
        /// </summary>
        public Int32 totalRecord { get; set; }

        /// <summary>
        /// 검색 파라미터
        /// </summary>
        public String param { get; set; }

        public PageEntity()
        {
            record = String.Empty;
            pageNumber = 0;
            totalPage = 0;
            totalRecord = 0;
            param = String.Empty;
        }
        ~PageEntity()
        {
            record = String.Empty;
            pageNumber = 0;
            totalPage = 0;
            totalRecord = 0;
            param = String.Empty;
        }

    }
    #endregion


    #region // !++ PagingEntity
    /// <summary>
    /// 페이징
    /// </summary>
    [Serializable]
    public class PagingEntity
    {

        /// <summary>
        /// 
        /// </summary>
        public String strBlockSize { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public String strTotalPage { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public String strActionScript { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public String strValue { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public String strText { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public String strParam { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public String strPage { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public String strUrl { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public String strDiv { get; set; }

        public PagingEntity()
        {
            strBlockSize = "20";
            strTotalPage = String.Empty;
            strActionScript = String.Empty;
            strValue = "0";
            strText = "0";
            strParam = String.Empty;
            strPage = "1";
            strUrl = String.Empty;
            strDiv = String.Empty;
        }
        ~PagingEntity()
        {
            strBlockSize = "20";
            strTotalPage = String.Empty;
            strActionScript = String.Empty;
            strValue = "0";
            strText = "0";
            strParam = String.Empty;
            strPage = "1";
            strUrl = String.Empty;
            strDiv = String.Empty;
        }

    }
    #endregion


    #region // !++ PageDBEntity
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    public class PageDBEntity
    {

        /// <summary>
        /// 페이지
        /// </summary>
        public Int32 page { get; set; }

        /// <summary>
        /// 페이지 사이즈(default : 20)
        /// </summary>
        public Int32 pageSize { get; set; }

        public PageDBEntity()
        {
            page = 0;
            pageSize = 20;
        }
        ~PageDBEntity()
        {
            page = 0;
            pageSize = 20;
        }

    }
    #endregion


    #region // !++ BulkCopyExcelEntity
    /// <summary>
    /// 벌크카피 by 엑셀
    /// </summary>
    [Serializable]
    public class BulkCopyExcelEntity
    {

        /// <summary>
        /// CSV 파일명
        /// </summary>
        public String fileCSV { get; set; }

        /// <summary>
        /// 머신(하드웨어) 폴더경로
        /// </summary>
        public String folderPath { get; set; }

        /// <summary>
        /// 웹(브라우져) 폴더경로
        /// </summary>
        public String folderUrl { get; set; }

        /// <summary>
        /// 파일경로
        /// </summary>
        public String filePath { get; set; }

        /// <summary>
        /// 전체 파일경로
        /// </summary>
        public String filePathFull { get; set; }

        /// <summary>
        /// 엑셀커넥션
        /// </summary>
        public String ExConn { get; set; }

        /// <summary>
        /// 엑셀쿼리
        /// </summary>
        public String ExQuery { get; set; }

        /// <summary>
        /// 테이블명
        /// </summary>
        public String bulkCopyTableName { get; set; }

        /// <summary>
        /// 칸 구분자
        /// </summary>
        public String bulkCopyFieldTerminator { get; set; }

        /// <summary>
        /// 열 구분자
        /// </summary>
        public String bulkCopyLineTerminator { get; set; }

        /// <summary>
        /// 파일명
        /// </summary>
        public String bulkCopyFileName { get; set; }

        /// <summary>
        /// 인코딩형식
        /// </summary>
        public String bulkCopyCharacterSet { get; set; }

        /// <summary>
        /// 시작 라인
        /// </summary>
        public Int32 bulkCopyNumberOfLinesToSkip { get; set; }

        /// <summary>
        /// 결과
        /// </summary>
        public Int32 bulkCopyResult { get; set; }

        public BulkCopyExcelEntity()
        {
            fileCSV = String.Empty;
            folderPath = String.Empty;
            folderUrl = String.Empty;
            filePath = String.Empty;
            filePathFull = String.Empty;
            ExConn = String.Empty;
            ExQuery = String.Empty;
            bulkCopyTableName = String.Empty;
            bulkCopyFieldTerminator = String.Empty;
            bulkCopyLineTerminator = String.Empty;
            bulkCopyFileName = String.Empty;
            bulkCopyCharacterSet = String.Empty;
            bulkCopyNumberOfLinesToSkip = 0;
            bulkCopyResult = 0;
        }
        ~BulkCopyExcelEntity()
        {
            fileCSV = String.Empty;
            folderPath = String.Empty;
            folderUrl = String.Empty;
            filePath = String.Empty;
            filePathFull = String.Empty;
            ExConn = String.Empty;
            ExQuery = String.Empty;
            bulkCopyTableName = String.Empty;
            bulkCopyFieldTerminator = String.Empty;
            bulkCopyLineTerminator = String.Empty;
            bulkCopyFileName = String.Empty;
            bulkCopyCharacterSet = String.Empty;
            bulkCopyNumberOfLinesToSkip = 0;
            bulkCopyResult = 0;
        }

    }
    #endregion


    #region // !++ ManagerSettings
    /// <summary>
    /// 관리자 URL 셋팅정보
    /// </summary>
    [Serializable]
    public class ManagerSettings
    {

        /// <summary>
        /// 사이트 명
        /// </summary>
        public String siteName { get; set; }

        /// <summary>
        /// 사이트 URL
        /// </summary>
        public String siteUrl { get; set; }

        /// <summary>
        /// 사이트 속성
        /// </summary>
        public String siteMethod { get; set; }

        public ManagerSettings()
        {
            siteName = "SpiderKim manager";
            siteUrl = "manager.spiderkim.com";
            siteMethod = "Manager";
        }
        ~ManagerSettings()
        {
            siteName = "SpiderKim manager";
            siteUrl = "manager.spiderkim.com";
            siteMethod = "Manager";
        }

    }
    #endregion


    #region // !++ SpiderKimManagerSettings
    /// <summary>
    /// 관리툴 Web Setting 정보
    /// </summary>
    [Serializable]
    public class SpiderKimManagerSettings
    {

        /// <summary>
        /// 도메인 명
        /// </summary>
        public String DomainName { get; set; }

        /// <summary>
        /// 도메인 주소(URL)
        /// </summary>
        public String DomainUrl { get; set; }

        /// <summary>
        /// 도메인 쿠키명
        /// </summary>
        public String DomainCookie { get; set; }

        /// <summary>
        /// 도메인 폴더경로(Upload파일)
        /// </summary>
        public String DomainMapPath { get; set; }

        public SpiderKimManagerSettings()
        {
            DomainName = "SpiderKimManager";
            DomainUrl = "http://managertool.spiderkim.com";
            DomainCookie = "ManagerTool";
            DomainMapPath = "/WebUpload";
        }
        ~SpiderKimManagerSettings()
        {
            DomainName = "SpiderKimManager";
            DomainUrl = "http://managertool.spiderkim.com";
            DomainCookie = "ManagerTool";
            DomainMapPath = "/WebUpload";
        }

    }
    #endregion


    #region // !++ SpiderKimSettings
    /// <summary>
    /// Web Setting 정보
    /// </summary>
    [Serializable]
    public class SpiderKimSettings
    {

        /// <summary>
        /// 도메인 명
        /// </summary>
        public String DomainName { get; set; }

        /// <summary>
        /// 도메인 주소(URL)
        /// </summary>
        public String DomainUrl { get; set; }

        /// <summary>
        /// 도메인 쿠키명
        /// </summary>
        public String DomainCookie { get; set; }

        /// <summary>
        /// 도메인 폴더경로(Upload파일)
        /// </summary>
        public String DomainMapPath { get; set; }

        public SpiderKimSettings()
        {
            DomainName = "SpiderKim";
            DomainUrl = "http://www.spiderkim.com";
            DomainCookie = "SpiderKimUser";
            DomainMapPath = "/WebUpload";
        }
        ~SpiderKimSettings()
        {
            DomainName = "SpiderKim";
            DomainUrl = "http://www.spiderkim.com";
            DomainCookie = "SpiderKimUser";
            DomainMapPath = "/WebUpload";
        }

    }
    #endregion


    #region // !++ SendEmailEntity
    /// <summary>
    /// E-mail 발송
    /// </summary>
    [Serializable]
    public class SendEmailEntity
    {

        /// <summary>
        /// SMTP 메일 서버
        /// </summary>
        public String SMTPMailServer { get; set; }

        /// <summary>
        /// 발송 메일주소
        /// </summary>
        public String FromEmail { get; set; }

        /// <summary>
        /// 발송 메일주소 이름(표기용)
        /// </summary>
        public String FromEmailDisplayName { get; set; }

        /// <summary>
        /// 발송 메일주소 비밀번호(회사메일)
        /// </summary>
        public String FromEmailPassword { get; set; }

        /// <summary>
        /// 발송 메일서버 Port(SSL)
        /// </summary>
        public Int32 FromEmailPort { get; set; }

        /// <summary>
        /// TLS/STARTTLS Port
        /// </summary>
        public Int32 FromEmailTLS { get; set; }

        /// <summary>
        /// 받는 메일주소
        /// </summary>
        public String ToEmail { get; set; }

        /// <summary>
        /// 받는 메일주소 이름(표기용) 있을 경우만
        /// </summary>
        public String ToEmailDisplayName { get; set; }

        /// <summary>
        /// 메일 제목
        /// </summary>
        public String Subject { get; set; }

        /// <summary>
        /// 메일 내용
        /// </summary>
        public String BodyContents { get; set; }

        public SendEmailEntity()
        {
            SMTPMailServer = String.Empty;
            FromEmail = String.Empty;
            FromEmailDisplayName = String.Empty;
            FromEmailPassword = String.Empty;
            FromEmailPort = 0;
            FromEmailTLS = 0;
            ToEmail = String.Empty;
            ToEmailDisplayName = String.Empty;
            Subject = String.Empty;
            BodyContents = String.Empty;
        }
        ~SendEmailEntity()
        {
            SMTPMailServer = String.Empty;
            FromEmail = String.Empty;
            FromEmailDisplayName = String.Empty;
            FromEmailPassword = String.Empty;
            FromEmailPort = 0;
            FromEmailTLS = 0;
            ToEmail = String.Empty;
            ToEmailDisplayName = String.Empty;
            Subject = String.Empty;
            BodyContents = String.Empty;
        }

    }
    #endregion


    #region // !++ UrlQueryStringSeparationEntity
    /// <summary>
    /// 도메인과 파라미터 정보
    /// </summary>
    [Serializable]
    public class UrlQueryStringSeparationEntity
    {

        /// <summary>
        /// URL (도메인[주소])
        /// </summary>
        public String vcUri { get; set; }

        /// <summary>
        /// 파라미터(QueryString)
        /// </summary>
        public Dictionary<String, String> queryStringDictionary { get; set; }

        public UrlQueryStringSeparationEntity()
        {
            vcUri = String.Empty;
            queryStringDictionary = null;
        }
        ~UrlQueryStringSeparationEntity()
        {
            vcUri = String.Empty;
            queryStringDictionary = null;
        }

    }
    #endregion



}
