// 상품가격
export class GoodsPriceModel
{

  iSeq: number;
  iGoodsSeq: number;
  tiDivision: number;
  fMoney: number;
  iRate: number;
  fMoneyRate: number;
  iUseDay: number;
  iManagerSeq: number;
  dtRegDate: string;

  constructor() {
    this.iSeq = 0;
    this.iGoodsSeq = 0;
    this.tiDivision = 0;
    this.fMoney = 0;
    this.iRate = 0;
    this.fMoneyRate = 0;
    this.iUseDay = 0;
    this.iManagerSeq = 0;
    this.dtRegDate = '';
  }

}
