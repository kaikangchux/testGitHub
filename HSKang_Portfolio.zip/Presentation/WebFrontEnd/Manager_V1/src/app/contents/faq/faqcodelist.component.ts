import { Component, OnInit, Optional} from '@angular/core';
import { Title } from "@angular/platform-browser";
import { TranslateService } from '@ngx-translate/core';
import { NgxSpinnerService } from "ngx-spinner";
import { MatDialog } from '@angular/material';

import { ConfigService } from '../../config';
import { FaqService } from '../../service';
import { FaqCodeModel } from '../../model';

import { FaqCodeDetailComponent } from './faqcodedetail.component';
import { FaqCodeRegistComponent } from './faqcoderegist.component';
import { FaqCodeModifyComponent } from './faqcodemodify.component';

@Component({
    selector: 'app-list',
    templateUrl: './faqcodelist.component.html',
    styleUrls: ['../scss/list.component.scss']
})

export class FaqCodeListComponent implements OnInit
{

    start:number = 0;
    len:number = 20;
    total:number = 0;
    faqCodeList:FaqCodeModel[] = [];
    curPage:number = 1;

    constructor(private titleService:Title,
                private translate:TranslateService,
                private mService:FaqService,
                private spinnerService:NgxSpinnerService,
                private config:ConfigService,
                public dialog: MatDialog){

        this.titleService.setTitle(this.translate.instant('TITLE.FAQCODE'));
        this.config.setSettings({layout: {navbar: 'show'}});
    }

    ngOnInit():void
    {
        this.getFaqCodeList(this.curPage, this.len);
    }

    getFaqCodeList(curPage:number, len:number):void
    {
        this.spinnerService.show();

        this.mService.getFaqCodeList(curPage, len).subscribe(
            list => {
                this.faqCodeList = list.data.gClass;
                this.total = list.data.totalRecord;
                this.mService.changeFaqCodeList(this.faqCodeList);
            },
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

    pagingArr():number[]
    {
        let result = Math.ceil(this.total/this.len);
        return Array.from({length: result}, (v, k) => k+1);
    }

    pager(page:number)
    {
        if(page === this.curPage){
            return;
        }

        this.curPage = page;
        this.getFaqCodeList(this.curPage, this.len);
    }

    // FAQ code 상세정보
    openDetail(iSeq:number):void
    {
        this.dialog.open(FaqCodeDetailComponent, {data:{iSeq:iSeq}});
    }

    // FAQ code 등록
    openRegist():void
    {
        const dialogRef =this.dialog.open(FaqCodeRegistComponent, {data:null});

        // 팝업일 경우: 데이터 등록 후 리스트 갱신
        dialogRef.afterClosed().subscribe(res => {
            if(res === true){
                this.getFaqCodeList(this.curPage, this.len);
            }
        });
    }

    // FAQ code 정보수정
    openModify(iSeq:number, curPage:number):void
    {
        const dialogRef = this.dialog.open(FaqCodeModifyComponent, {data:{iSeq:iSeq}});

        // 팝업일 경우: 데이터 수정 후 리스트 갱신
        dialogRef.afterClosed().subscribe(res => {
            if(res === true){
                if(curPage < 0){
                    this.curPage = 1;
                }
                this.getFaqCodeList(this.curPage, this.len);
            }
        });
    }
    
    // FAQ code 삭제
    onDelete(iSeq:number):void
    {
        const result = window.confirm(this.translate.instant('DELETE.MSG'));
        if(!result){
            return;
        }

        this.spinnerService.show();

        this.mService.deleteFaqCode(iSeq).subscribe(
            (res) => this.ngOnInit(),
            error => {this.spinnerService.hide(); console.log(error)},
            () => this.spinnerService.hide()
        );
    }

}