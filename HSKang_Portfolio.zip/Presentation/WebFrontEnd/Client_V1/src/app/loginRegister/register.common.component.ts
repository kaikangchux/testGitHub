import { Component } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
    selector: 'app-register-common',
    templateUrl: './register.common.component.html',
    styleUrls: ['./register.common.component.scss']
})

export class RegisterCommonComponent
{
    currentRoute:string;
    completed:boolean = false;

    constructor(private router:Router)
    {
        this.router.events.pipe(
            filter(event => event instanceof NavigationEnd)
            ).subscribe((event: NavigationEnd) => {
                const urlArr = event.url.split('/');
                this.currentRoute = urlArr[urlArr.length-1];
                this.completed = (this.currentRoute.includes('completed') || this.currentRoute === 'confirm');
            }
        );
    }

    onClick(e:any):void{
        const targetRoute = e.target.id;

        if(this.currentRoute == targetRoute){
            return;
        }

        this.router.navigate([`./register/${targetRoute}`]);
    }

    isMemberSelected(routeStr:string):string {
        return (this.currentRoute == routeStr) ? 'selected' : '';
    }
}