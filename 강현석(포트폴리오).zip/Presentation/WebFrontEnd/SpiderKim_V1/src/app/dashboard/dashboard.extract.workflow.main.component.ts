import { Component, ViewChild, ElementRef, OnInit, OnDestroy, AfterViewInit } from '@angular/core';
import { DataExtractService } from '../service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { trigger, state, style, transition, animate } from '@angular/animations';

@Component({
    selector: 'app-dashboard-workflow-main',
    templateUrl: './dashboard.extract.workflow.main.component.html',
    styleUrls: ['./dashboard.extract.workflow.main.component.scss'],
    animations: [
        trigger('displayState',
            [
                state('off', style({
                    right: '-280px' //checkto scss $workflow-width
                })),
                state('on', style({
                    right: '0px'
                })),
                transition('off => on', animate('200ms linear')),
                transition('on => off', animate('200ms linear'))
            ]
        )
    ]
})
export class WorkFlowMainComponent implements OnInit, AfterViewInit, OnDestroy 
{
    flag:string = 'off';

    constructor(private dataExtractService:DataExtractService, 
                private router: Router,
                private http:HttpClient){
    }

    ngOnInit():void {
        if(this.dataExtractService.evtEmitterWorkflowSub === undefined){
            this.dataExtractService.evtEmitterWorkflowSub = this.dataExtractService.evtEmitterWorkflow.subscribe((param:any) => {
                this.flag = (param === true) ? 'on' : 'off';
                this.toggle();
            });
        }
    }

    toggle():void {
        //TODO show/hide시 처리해야할 것들
    }

    ngAfterViewInit():void {
    }

    ngOnDestroy() {
    }
}