import { Injectable, EventEmitter, OnDestroy } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/internal/Observable';

import { CommonService } from './common.service';
import { ResultServerData, ResultServerDatalist } from '../common';
import { FaqModel, FaqCodeModel } from '../model';

@Injectable({
    providedIn: 'root'
})

export class FaqService implements OnDestroy
{

    // FAQ Code
    faqcodeList:FaqCodeModel[] = [];
    faqcodeDetail:FaqCodeModel;

    // FAQ
    faqList:FaqModel[] = [];
    faqDetail:FaqModel;

    constructor(private router:Router,
        private cmnService:CommonService,
        private http:HttpClient){}


    // FAQ code
    changeFaqCodeList(faqcodeList:FaqCodeModel[]){
        this.faqcodeList = faqcodeList;
    }

    // 목록
    getFaqCodeList(page:number, pageSize:number):Observable<any>
    {
        const url = this.cmnService.requestUrl(`/api/faq/faqcodelist?page=${page}&pageSize=${pageSize}`);
        return this.http.get<ResultServerData<ResultServerDatalist<FaqCodeModel[]>>>(url);
    }

    // 상세정보
    getFaqCodeDetail(iSeq:number):Observable<any>
    {
        const url = this.cmnService.requestUrl(`/api/faq/FaqCodeDetail/${iSeq}`);
        return this.http.get<ResultServerData<ResultServerDatalist<FaqCodeModel>>>(url);
    }

    // 등록 및 수정
    regEditFaqCode(mFaqCode:FaqCodeModel, isAdd:boolean, iSeq:number):Observable<any>
    {
        const urlStr = (isAdd) ? `/api/faq/faqcoderegist` : `/api/faq/faqcodemodify`;
        const url = this.cmnService.requestUrl(urlStr);

        return this.http[(isAdd) ? 'post' : 'put'](url, mFaqCode);
    }

    // 삭제
    deleteFaqCode(iSeq:number):Observable<any>
    {
        const url = this.cmnService.requestUrl(`/api/faq/faqcodedelete/${iSeq}`);
        return this.http.delete<ResultServerData<ResultServerDatalist<number>>>(url);
    }

    // FAQ
    changeFaqList(faqList:FaqModel[]){
        this.faqList = faqList;
    }

    // 목록
    getFaqList(page:number, pageSize:number):Observable<any>
    {
        const url = this.cmnService.requestUrl(`/api/faq/faqlist?page=${page}&pageSize=${pageSize}`);
        return this.http.get<ResultServerData<ResultServerDatalist<FaqModel[]>>>(url);
    }

    // 상세정보
    getFaqDetail(iSeq:number):Observable<any>
    {
        const url = this.cmnService.requestUrl(`/api/faq/FaqDetail/${iSeq}`);
        return this.http.get<ResultServerData<ResultServerDatalist<FaqModel>>>(url);
    }

    // 등록 및 수정
    regEditFaq(mFaq:FaqModel, isAdd:boolean, iSeq:number):Observable<any>
    {
        const urlStr = (isAdd) ? `/api/faq/faqregist` : `/api/faq/faqmodify`;
        const url = this.cmnService.requestUrl(urlStr);

        return this.http[(isAdd) ? 'post' : 'put'](url, mFaq);
    }

    // 삭제
    deleteFaq(iSeq:number):Observable<any>
    {
        const url = this.cmnService.requestUrl(`/api/faq/faqdelete/${iSeq}`);
        return this.http.delete<ResultServerData<ResultServerDatalist<number>>>(url);
    }


    ngOnDestroy():void{
        
    }

}
