﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.CrawlingDB
{

    #region // !++ tbInquiry
    /// <summary>
    /// tbInquiry
    /// </summary>
    [Table("tbInquiry")]
    public class tbInquiry
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        /// <summary>
        /// 고유번호(AI)
        /// </summary>
        public Int64 biSeq { get; set; }

        [Index(1), Required]
        /// <summary>
        /// 문의유형(1:수집의뢰, 2:제휴문의, 3:상담신청, 4:기타문의)
        /// </summary>
        public Int16 tiType { get; set; }

        [Index(2)]
        /// <summary>
        /// 회원고유번호(0:단체, 0>개인)
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        /// <summary>
        /// 사업자번호
        /// </summary>
        public String vcOrganizationSerial { get; set; }

        [Required, MinLength(2), MaxLength(128)]
        /// <summary>
        /// 업종
        /// </summary>
        public String vcBusiness { get; set; }

        [Required, MinLength(2), MaxLength(128)]
        /// <summary>
        /// 업체명
        /// </summary>
        public String vcCompany { get; set; }

        [Required, MinLength(2), MaxLength(32)]
        /// <summary>
        /// 담당자명
        /// </summary>
        public String vcName { get; set; }

        [Required, MinLength(2), MaxLength(12)]
        /// <summary>
        /// 연락처
        /// </summary>
        public String vcPhone { get; set; }

        [Required, MinLength(2), MaxLength(128)]
        /// <summary>
        /// 제목
        /// </summary>
        public String vcTitle { get; set; }

        [Required, MinLength(10)]
        /// <summary>
        /// 내용
        /// </summary>
        public String tDescription { get; set; }

        /// <summary>
        /// 개인정보동의여부(1:동의)
        /// </summary>
        public Int16 tiAgree { get; set; }

        /// <summary>
        /// 상태(1:접수, 2:확인, 3:답변완료)
        /// </summary>
        public Int16 tiStatus { get; set; }

        [Required, MinLength(2), MaxLength(16)]
        /// <summary>
        /// 등록IP
        /// </summary>
        public String vcIP { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
