﻿import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgxSpinnerModule } from "ngx-spinner";
import { CookieService } from 'ngx-cookie-service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatDialogModule } from '@angular/material';

import { AppComponent } from './app.component';
import { LoginComponent } from './contents/login.component';
import { MainComponent } from './contents/main.component';
import { ContentsComponent } from './contents/contents.component';
import { SideBarComponent } from './contents/sidebar.component';

import { ConfigService } from './config';
import { JwtInterceptor } from './helper';
import { AppGlobalErrorhandler } from './error';

import { TranslationLoaderService, CommonService, CookieManageService, ManagerService, FaqService, PlatFormService, AccountService } from './service';

// Manager
import { ManagerListComponent, ManagerViewComponent, ManagerRegEditComponent } from './contents/manager';

// FAQ code
import { FaqCodeListComponent, FaqCodeDetailComponent, FaqCodeModifyComponent, FaqCodeRegistComponent } from './contents/faq';

// FAQ
import { FaqListComponent, FaqRegistComponent, FaqDetailComponent, FaqModifyComponent } from './contents/faq';

// PlatForm
import { PlatFormListComponent, PlatFormRegistComponent, PlatFormDetailComponent, PlatFormModifyComponent } from './contents/platform';

// PlatForm Api
import { PlatFormApiListComponent, PlatFormApiRegistComponent, PlatFormApiDetailComponent, PlatFormApiModifyComponent } from './contents/platform';

// Member
import { AccountListComponent } from './contents/account';

@NgModule({
    declarations: [
        AppComponent,
        LoginComponent,
        MainComponent,
        ContentsComponent,
        SideBarComponent,
        ManagerListComponent,
        ManagerViewComponent,
        ManagerRegEditComponent,
        FaqCodeListComponent,
        FaqCodeDetailComponent,
        FaqCodeModifyComponent,
        FaqCodeRegistComponent,
        FaqListComponent,
        FaqRegistComponent,
        FaqDetailComponent,
        FaqModifyComponent,
        PlatFormListComponent,
        PlatFormRegistComponent,
        PlatFormDetailComponent,
        PlatFormModifyComponent,
        PlatFormApiListComponent,
        PlatFormApiRegistComponent,
        PlatFormApiDetailComponent,
        PlatFormApiModifyComponent,
        AccountListComponent
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        TranslateModule.forRoot(),
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        NgxSpinnerModule,
        BrowserAnimationsModule,
        MatDialogModule
    ],
    providers: [
        { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
        { provide: ErrorHandler, useClass: AppGlobalErrorhandler },
        TranslationLoaderService,
        ConfigService,
        CookieService,
        CookieManageService,
        CommonService,
        ManagerService,
        FaqService,
        PlatFormService,
        AccountService
    ],
    entryComponents: [
        ManagerRegEditComponent,
        FaqCodeDetailComponent,
        FaqCodeModifyComponent,
        FaqCodeRegistComponent,
        FaqRegistComponent,
        FaqDetailComponent,
        FaqModifyComponent,
        PlatFormRegistComponent,
        PlatFormDetailComponent,
        PlatFormModifyComponent,
        PlatFormApiRegistComponent,
        PlatFormApiDetailComponent,
        PlatFormApiModifyComponent,
        AccountListComponent
    ],
    exports: [
        MainComponent
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }