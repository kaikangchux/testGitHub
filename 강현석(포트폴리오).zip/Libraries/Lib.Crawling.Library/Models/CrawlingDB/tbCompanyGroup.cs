﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.CrawlingDB
{

    #region // !++ tbCompanyGroup
    /// <summary>
    /// 회사조직(분류)
    /// </summary>
    [Table("tbCompanyGroup")]
    public class tbCompanyGroup
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        /// <summary>
        /// 고유번호
        /// </summary>
        public Int32 iSeq { get; set; }

        [Required, MinLength(2), MaxLength(32)]
        /// <summary>
        /// 그룹명
        /// </summary>
        public String vcName { get; set; }

        /// <summary>
        /// 그룹명(언어ID)
        /// </summary>
        public String vcNameKeyText { get; set; }

        /// <summary>
        /// 그룹약어(간단소개)
        /// </summary>
        public String vcAbbreviation { get; set; }

        /// <summary>
        /// 그룹약어(언어ID)
        /// </summary>
        public String vcAbbreviationKeyText { get; set; }

        /// <summary>
        /// 관리자 고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
