import { Component, ViewChild, ElementRef, OnInit, OnDestroy, AfterViewInit } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
import { DataExtractService } from '../service';
import { DomSanitizer } from '@angular/platform-browser';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import { Router, NavigationEnd } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
    selector: 'app-dashboard-extract-data',
    templateUrl: './dashboard.extract.component.html',
    styleUrls: ['./dashboard.extract.component.scss']
})
export class DataExtractComponent implements OnInit, AfterViewInit, OnDestroy
{
    contents:string;
    iframeSetting:boolean = false;
    showSideBar:boolean = false;
    showMask:boolean = true;

    @ViewChild('iframe', {static: false}) iframe: ElementRef;

    constructor(private dataExtractService:DataExtractService, 
                private spinnerService:NgxSpinnerService,
                private sanitizer:DomSanitizer,
                private translate:TranslateService,
                private router: Router,
                private http:HttpClient){

        this.spinnerService.show();
        //this.contents = this.router.getCurrentNavigation().extras.state.data.contents;

        //TODO Test need to delete after !!!
        this.http.get('./assets/test.txt', {responseType: 'text'}).subscribe(data => {
            this.contents = data;
            this.iframe.nativeElement.contentWindow.document.open();
            this.iframe.nativeElement.contentWindow.document.write(this.contents);
            this.iframe.nativeElement.contentWindow.document.close();
            this.iframeSetting = true;
        });
    }

    ngOnInit():void{
        //this.spinnerService.show();

        //작업창 활성화(워크플로우에서 버튼 클릭) 처리
        if(this.dataExtractService.evtEmitterWindowSub === undefined){
            this.dataExtractService.evtEmitterWindowSub = this.dataExtractService.evtEmitterWindow.subscribe((param:any) => {
                this.showMask = param;
            });
        }
    }

    ngAfterViewInit():void { //TODO 서버에서 받을 경우 주석해제하기
        // this.iframe.nativeElement.contentWindow.document.open();
        // this.iframe.nativeElement.contentWindow.document.write(this.contents);
        // this.iframe.nativeElement.contentWindow.document.close();
    }

    onload():void{
        if(!this.iframeSetting){
            return;
        }
        setTimeout(()=>this.onIframeLoad(), 1000);
    }

    onIframeLoad():void
    {
        console.log("-------- iframe loaded ----------");//TODO delete
        const nativeEl = this.iframe.nativeElement.contentDocument.body;

        let s = document.createElement('script');
        s.onload = ()=>{
            console.log("-------- selectorgadget library loaded ----------");//TODO delete
            this.spinnerService.hide();
        }
        s.setAttribute('type', 'text/javascript');
        s.setAttribute('src', '/assets/lib/selectorgadget_edge.js');
        nativeEl.appendChild(s);
    }

    ngOnDestroy() {
        
    }
}