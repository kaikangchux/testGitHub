﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.Extensions.Configuration;

using Lib.Crawling.Library.Entities;
using Lib.Crawling.Library.Utilities;
using Lib.Crawling.Library.Log;
using Lib.Crawling.Library.DataContainers;

using WebApi_SpiderKim_V1.Handlers;
using WebApi_SpiderKim_V1.WebUtilities;

namespace WebApi_SpiderKim_V1.Controllers
{

    #region // !++ ErrorController
    /// <summary>
    /// ErrorController
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class ErrorController : ControllerBase
    {

        #region // !++ Event handler(funtions)
        /// <summary>
        /// StaticDataHandler
        /// </summary>
        public StaticDataHandler staticDataHandler = new StaticDataHandler();

        /// <summary>
        /// LibUtility
        /// </summary>
        public LibUtility libUtility = new LibUtility();

        /// <summary>
        /// LibWebUtility
        /// </summary>
        public LibWebUtility libWebUtility = new LibWebUtility();
        #endregion


        #region // !++ Class 상속
        private readonly IConfiguration _configuration;

        public ErrorController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        #endregion


        #region // !++ GetBadRequestMessage (잘못된 요청 메시지 출력)
        /// <summary>
        /// 잘못된 요청 메시지 출력
        /// </summary>
        /// <returns></returns>
        [HttpGet("BadRequestMessage")]
        public IActionResult GetBadRequestMessage()
        {
            // Return message
            var resultClient = new ResultClientEntity<Int32?>();

            try
            {

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Not a valid request";
                resultClient.error = "BadRequest";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetBadRequestMessage : \n {0}, \n {1}",
                                        exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }

        }
        #endregion


        #region // !++ GetLoginMessage (인증정보 없을 시 메시지 출력)
        /// <summary>
        /// 인증정보 없을 시 메시지 출력
        /// </summary>
        /// <returns></returns>
        [HttpGet("UnauthorizedMessage")]
        public IActionResult GetLoginMessage()
        {
            // Return message
            var resultClient = new ResultClientEntity<Int32?>();

            try
            {

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Not invalied login info";
                resultClient.error = "Unauthorized";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetLoginMessage : \n {0}, \n {1}",
                                        exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }

        }
        #endregion


        #region // !++ GetForbiddenMessage (권한 없을 시 메시지 출력)
        /// <summary>
        /// 권한 없을 시 메시지 출력
        /// </summary>
        /// <returns></returns>
        [HttpGet("ForbiddenMessage")]
        public IActionResult GetForbiddenMessage()
        {
            // Return message
            var resultClient = new ResultClientEntity<Int32?>();

            try
            {

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Request forbidden";
                resultClient.error = "Forbidden";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetForbiddenMessage : \n {0}, \n {1}",
                                        exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }

        }
        #endregion


        #region // !++ GetNotFoundMessage (요청페이지 없을 시 메시지 출력)
        /// <summary>
        /// 요청페이지 없을 시 메시지 출력
        /// </summary>
        /// <returns></returns>
        [HttpGet("NotFoundMessage")]
        public IActionResult GetNotFoundMessage()
        {
            // Return message
            var resultClient = new ResultClientEntity<Int32?>();

            try
            {

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Page not found";
                resultClient.error = "NotFound";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);

            }
            catch (Exception exc)
            {
                // Error 로그 처리!!!
                Logger.Log(ELogType.Fatal, "GetNotFoundMessage : \n {0}, \n {1}",
                                        exc.Message, exc.StackTrace);

                #region // !++ Client message
                resultClient.success = false;
                resultClient.msg = "Server Exception";
                resultClient.error = "Server Exception";
                resultClient.data = null;
                #endregion

                return Ok(resultClient);
            }

        }
        #endregion

    }
    #endregion

}