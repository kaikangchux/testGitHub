import { Component, Input } from '@angular/core';

@Component({
  selector: 'workflow-node',
  templateUrl: './node.component.html',
  styleUrls: ['./node.component.scss']
})
export class NodeComponent
{
    @Input() type: string;
    types:string[] = [];

    constructor(){
        this.types.push(this.type);
    }

    drop(evt:any):void {

    }
}