﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.CrawlingDB
{

    #region // !++ tbLanguageImage
    /// <summary>
    /// tbLanguageImage
    /// </summary>
    [Table("tbLanguageImage")]
    public class tbLanguageImage
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.None), MinLength(2), MaxLength(8)]
        /// <summary>
        /// 언어코드
        /// </summary>
        public String vcLanguageCode { get; set; }

        [Key, Required, MinLength(2), MaxLength(64)]
        /// <summary>
        /// 언어ID(고유키)
        /// </summary>
        public String vcKeyImage { get; set; }

        [Required, MinLength(2), MaxLength(256)]
        /// <summary>
        /// 파일경로
        /// </summary>
        public String vcUrl { get; set; }

        [Required, MinLength(2), MaxLength(128)]
        /// <summary>
        /// 이미지명
        /// </summary>
        public String vcImage { get; set; }

        /// <summary>
        /// 사용여부(1:사용, 2:대기, 3:삭제)
        /// </summary>
        public Int16 tiStatus { get; set; }

        /// <summary>
        /// 관리자고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

        [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 승인일시
        /// </summary>
        public DateTime dtApprovalDate { get; set; }

    }
    #endregion

}
