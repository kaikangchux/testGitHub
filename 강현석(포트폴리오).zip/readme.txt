


1. 프로젝트는 VS2019를 사용했습니다.
2. .Net Framework 와 Angular Framework 는 같은 프로젝트에 있지 않습니다.
3. .Net Standard 로 제작되었습니다.(Linux 사용고려)
4. API는 .Net core 2.X으로 되어있습니다.
5. Angular Framework는 8.X 버전입니다.
6. API & Angular 경로
API : Presentation/WebApi
Angular : Presentation/WebFrontEnd
7. Angular module은 포함되어있지 않습니다.(ng build 시 생성)










