﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.CrawlingDB
{

    #region // !++ tbBoardComment
    /// <summary>
    /// 게시판댓글
    /// </summary>
    [Table("tbBoardComment")]
    public class tbBoardComment
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        /// <summary>
        /// 고유번호(AI)
        /// </summary>
        public Int64 biSeq { get; set; }

        [Key]
        /// <summary>
        /// 게시판 고유번호
        /// </summary>
        public Int64 biBoardSeq { get; set; }

        [Required]
        /// <summary>
        /// 회원고유번호
        /// </summary>
        public Int64 biMemberSeq { get; set; }

        [Required, MinLength(4), MaxLength(32)]
        /// <summary>
        /// 계정ID
        /// </summary>
        public String vcAccount { get; set; }

        [Required, MinLength(4), MaxLength(32)]
        /// <summary>
        /// 이름
        /// </summary>
        public String vcName { get; set; }

        [Required, MinLength(4)]
        /// <summary>
        /// 내용
        /// </summary>
        public String tDescription { get; set; }

        [Required, MinLength(2), MaxLength(16)]
        /// <summary>
        /// 등록IP
        /// </summary>
        public String vcIP { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
