﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZeroFormatter;

namespace Lib.Crawling.Library.Models.CrawlingDB
{

    #region // !++ tbFAQ
    /// <summary>
    /// FAQ
    /// </summary>
    [Table("tbFAQ")]
    public class tbFAQ
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        /// <summary>
        /// 고유번호(AI)
        /// </summary>
        public Int32 iSeq { get; set; }

        [Key]
        /// <summary>
        /// FAQ 분류고유번호
        /// </summary>
        public Int32 iFaqCodeSeq { get; set; }

        [Required, MinLength(2), MaxLength(64)]
        /// <summary>
        /// 제목(언어ID)
        /// </summary>
        public String vcTitleKeyText { get; set; }

        [Required, MinLength(2), MaxLength(64)]
        /// <summary>
        /// 내용(언어ID)
        /// </summary>
        public String vcDescriptKeyText { get; set; }

        /// <summary>
        /// Main등록여부(1:노출안함, 2:노출)
        /// </summary>
        public Int16 tiMain { get; set; }

        /// <summary>
        /// 관리자고유번호
        /// </summary>
        public Int32 iManagerSeq { get; set; }

        [Required, DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        /// <summary>
        /// 등록일시
        /// </summary>
        public DateTime dtRegDate { get; set; }

    }
    #endregion

}
