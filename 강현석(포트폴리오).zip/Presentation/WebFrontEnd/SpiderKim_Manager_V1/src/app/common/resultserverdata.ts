export class ResultServerData<T>
{
    success: boolean;
    msg: string;
    error: string;
    data: T[];

    constructor()
    {
        this.success = false;
        this.msg = '';
        this.error = '';
        this.data = null;
    }
}