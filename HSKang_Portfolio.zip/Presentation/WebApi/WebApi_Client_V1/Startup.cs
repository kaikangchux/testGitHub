﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Net;

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;

using Lib.Crawling.Library.Log;
using Lib.Crawling.Library.Entities;

using WebApi_SpiderKim_V1.Handlers;
using WebApi_SpiderKim_V1.WebUtilities;
using WebApi_SpiderKim_V1.Controllers;

namespace WebApi_SpiderKim_V1
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            // [!] Configuration: JSON 파일의 데이터를 POCO 클래스에 주입
            services.Configure<SpiderKimSettings>(Configuration.GetSection("SpiderKimSettings"));

            // [DNN] TempData[] 개체 사용
            // In-Memory 캐싱 
            services.AddMemoryCache();


            #region // !++ ASP.NET Core 2.X JWT [쿠키X] 인증: ConfigureServices()
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultSignInScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;

            })
               .AddCookie(options =>
               {
                   options.LoginPath = new PathString("/api/Login/Login");                  // 로그인 페이지
                   options.LogoutPath = new PathString("/api/Login/Logout");                // 로그아웃 페이지
                   options.AccessDeniedPath = new PathString("/api/Login/Forbidden");       // 인증권한(권한이 없을경우) 페이지
                                                                                            // options.Cookie.Domain = Configuration.GetSection("SpiderKimSettings").GetSection("DomainUrl").Value;    // 쿠키 도메인
                                                                                            // options.Cookie.Name = Configuration.GetSection("SpiderKimSettings").GetSection("DomainCookie").Value;    // 직접 이름 지정
                   options.Cookie.Name = CookieAuthenticationDefaults.AuthenticationScheme; // 정의되어 있는 이름으로 지정
                   options.Cookie.Expiration = TimeSpan.FromDays(1);   // 쿠키 만료일(운영툴 1일)
                   options.Cookie.HttpOnly = false;
                   options.Cookie.SameSite = SameSiteMode.None;
                   options.SlidingExpiration = true;
               })
            .AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, options =>
            {
                options.RequireHttpsMetadata = false;
                options.SaveToken = true;
                // options.Audience = new PathString("/api/Login/Login");
                // options.Authority = "";
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    // 토큰 만기 보장
                    RequireExpirationTime = true,
                    ValidateLifetime = true,
                    // 토큰 대상이 사이트 대상 값과 일치하는지 확인
                    ValidateAudience = false,
                    ValidAudience = Configuration["SpiderKimSettings:Audience"],
                    // 신뢰할 수있는 권한 부여 서버가 토큰을 발행했는지 확인
                    ValidateIssuer = false,
                    ValidIssuer = Configuration["SpiderKimSettings:Issuer"],
                    // 토큰이 사용하는 키 지정
                    ValidateIssuerSigningKey = true,
                    // 보안키 문자열 길게 설정할 것
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["SymmetricSecurityKey"])),
                    // 서버 드리프트 보상
                    ClockSkew = TimeSpan.FromMinutes(5)
                };
            });
            #endregion


            #region // !++ [User] Policy 설정
            services.AddAuthorization(options =>
            {
                // Users Role이 있으면, Users Policy 부여
                options.AddPolicy("SpiderKim", policy =>
                {
                    policy.AuthenticationSchemes.Add(JwtBearerDefaults.AuthenticationScheme);
                    policy.RequireAuthenticatedUser();
                });
            });
            #endregion


            #region // !++ [CORS] CORS 설정 공식 코드 1/2
            services.AddCors(options =>
            {
                options.AddPolicy("AllowAllOrigins",
                    builder =>
                    {
                        builder
                            .AllowAnyOrigin()
                            .AllowAnyHeader()
                            .AllowAnyMethod();
                    });
            });
            #endregion


            #region // !++ 쿠키 옵션
            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });
            #endregion


            #region // !++ Identity 옵션 설정
            services.Configure<IdentityOptions>(options =>
            {
                // 암호 설정
                options.Password.RequiredLength = 8;
                options.Password.RequireDigit = true;
                options.Password.RequireLowercase = true;

                // 잠금 설정
                options.Lockout.MaxFailedAccessAttempts = 5;
                options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(10);

                // 사용자 설정
                options.User.RequireUniqueEmail = true;
            });
            #endregion


            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);


            #region // !++ 의존성 주입 (DependencyInjectionContainer)
            DependencyInjectionContainer(services);
            #endregion

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, IApplicationLifetime applicationLifetime)
        {

            #region // !++ Application start & stop
            applicationLifetime.ApplicationStarted.Register(OnAppStart);
            applicationLifetime.ApplicationStopping.Register(OnShutdown);
            #endregion


            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();

            #region // !++ ASP.NET Core 2.X 쿠키 인증: Configure()
            // ASP.NET Core 2.X에서 쿠키 인증
            app.UseAuthentication(); // 인증 미들웨어를 사용하겠다고 지정 
            var cookiePolicyOptions = new CookiePolicyOptions() { MinimumSameSitePolicy = SameSiteMode.Strict };
            app.UseCookiePolicy(cookiePolicyOptions);
            #endregion


            #region // !++ 인증 정보가 없을 경우 로그인하라는 메시지 출력 페이지로 보내기(API 가 아니면 Page redirect)
            app.UseStatusCodePages(async context => {
                var request = context.HttpContext.Request;
                var response = context.HttpContext.Response;

                // 특정 방법에 대해서만 요청 경로를 확인할 수도 있습니다.
                // var path = request.Path.Value ?? "";
                // 예) && path.StartsWith("/api", StringComparison.InvariantCultureIgnoreCase)

                switch (response.StatusCode)
                {
                    case (Int32)HttpStatusCode.BadRequest:
                        response.Redirect("/api/Error/BadRequestMessage");
                        break;
                    case (Int32)HttpStatusCode.Unauthorized:
                        response.Redirect("/api/Error/UnauthorizedMessage");
                        break;
                    case (Int32)HttpStatusCode.Forbidden:
                        response.Redirect("/api/Error/ForbiddenMessage");
                        break;
                    case (Int32)HttpStatusCode.NotFound:
                        response.Redirect("/api/Error/NotFoundMessage");
                        break;
                }
            });
            #endregion


            // [CORS] CORS 설정 공식 코드 2/2
            app.UseCors("AllowAllOrigins");

            app.UseMvc();
        }


        #region // !++ DependencyInjectionContainer
        /// <summary>
        /// 의존성 주입 관련 코드만 따로 모아서 관리
        /// </summary>
        /// <param name="services"></param>
        private void DependencyInjectionContainer(IServiceCollection services)
        {

            //[?] ConfigureServices가 호출되기 전에는 DI(종속성 주입)가 설정되지 않습니다.

            //[DNN][!] Configuration 개체 주입: 
            //    IConfiguration 또는 IConfigurationRoot에 Configuration 개체 전달
            //    appsettings.json 파일의 데이터베이스 연결 문자열을 
            //    리포지토리 클래스에서 사용할 수 있도록 설정
            // IConfiguration 주입 -> Configuration의 인스턴스를 실행 
            services.AddSingleton<IConfiguration>(Configuration);
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services.AddTransient<StaticDataHandler>();

            services.AddTransient<LibWebUtility>();

        }
        #endregion


        #region // !++ Application start
        /// <summary>
        /// App 시작
        /// </summary>
        private void OnAppStart()
        {

            #region // !++ Log 저장소 초기화(호출)
            Logger.CreateLogger("SpiderKim_Server");

            // Application 시작 문자열
            Logger.Log(ELogType.Info, "[System] SpiderKim Application Start Time : {0}", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            #endregion

            #region // !++  기본(ManagerDB) DB Connection 및 DB 정보 Static 호출
            var connection = Configuration.GetConnectionString("DefaultConnection");

            StaticDataHandler.SetDBMSInfo(connection);
            #endregion

        }
        #endregion


        #region // !++ Application end
        /// <summary>
        /// App 종료
        /// </summary>
        private void OnShutdown()
        {

            #region // !++ Log Application 종료 문자열
            Logger.Log(ELogType.Info, "[System] SpiderKim Application End Time : {0}", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            #endregion

        }
        #endregion


    }
}
