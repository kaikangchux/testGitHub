import { Component } from '@angular/core';
import { DataExtractService } from '../service';

@Component({
  selector: 'app-workflow-header',
  templateUrl: './dashboard.extract.workflow.header.component.html',
  styleUrls: ['./dashboard.extract.workflow.header.component.scss']
})
export class WorkflowHeaderComponent
{
    displayWorkflow:boolean = false;

    constructor(private dataExtractService:DataExtractService){}

    onChange():void {
        this.dataExtractService.onEventEmiteDisplayWorkflow(this.displayWorkflow);
    }
}
