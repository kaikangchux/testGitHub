// 회원비밀번호정보
export class MemberPasswordModel
{

  biMemberSeq: number;
  vcPassword: string;
  dtLoginDate: string;
  dtModifyDate: string;

  constructor() {
    this.biMemberSeq = 0;
    this.vcPassword = '';
    this.dtLoginDate = '';
    this.dtModifyDate = '';
  }
}
