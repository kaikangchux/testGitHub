import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { TranslateService } from '@ngx-translate/core';

import { ConfigService } from '../config';

@Injectable({
    providedIn: 'root'
})

export class CommonService
{
    constructor(
        private http:HttpClient,
        private translate:TranslateService
        ){}

    public requestUrl(url:string){
        return `${ConfigService.PROTOCOL}://${ConfigService.URL}:${ConfigService.PORT}${url}`;
    }

    public getIP():Promise<any>
    {
        return fetch('https://jsonip.com')
            .then(function(response) {
                return response.json();
            });
    }

    // Main 등록여부 문자열리턴
    public getMainChk(tiMain:number):string {
        if (tiMain === 1)
        {
            return this.translate.instant('LIST.TBLCOMMAND.HEADER.MAINYES');
        }
        else if(tiMain === 2)
        {
            return this.translate.instant('LIST.TBLCOMMAND.HEADER.MAINNO');
        }
        else
        {
            return this.translate.instant('COMMON.UNKNOWN');
        }
    }

    // 사용여부
    public getStatus(tiStatus:number):string {
        if (tiStatus === 0)
        {
            return this.translate.instant('LIST.TBLCOMMAND.HEADER.STATUSUSED');
        }
        else if(tiStatus === 1)
        {
            return this.translate.instant('LIST.TBLCOMMAND.HEADER.STATUSSTANDBY');
        }
        else if(tiStatus === 2)
        {
            return this.translate.instant('LIST.TBLCOMMAND.HEADER.STATUSDELETE');
        }
        else
        {
            return this.translate.instant('COMMON.UNKNOWN');
        }
    }

    // 전화번호 하이픈(-) 처리
    public getPhoneReplaceHyphen(phone:string):string{
        return phone.replace(/(^02.{0}|^01.{1}|[0-9]{3})([0-9]+)([0-9]{4})/,"$1-$2-$3");
    }

    // 기업(단체) 여부
    public getOrganization(tiOrganization:number):string{
        if(tiOrganization === 1)
        {
            return this.translate.instant('LIST.TBLCOMMAND.HEADER.PERSON');
        }
        else if(tiOrganization === 2)
        {
            return this.translate.instant('LIST.TBLCOMMAND.HEADER.ORGANIZATION');
        }
        else
        {
            return this.translate.instant('COMMON.UNKNOWN');
        }
    }

}